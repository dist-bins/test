"""Bounded native GitLab pipeline relationships; no inferred ref/SHA matching."""

from __future__ import annotations

import time
from collections import deque
from datetime import UTC, datetime
from typing import Annotated, Literal

from pydantic import Field, ValidationError

from gspace.config import ProjectConfig
from gspace.gitlab_release import read_release
from gspace.glab import DTO, AdapterError, DeployDTO, GlabAdapter, JobDTO, VersionDTO, status
from gspace.models import (
    Association,
    CompleteRead,
    GraphDeployment,
    GraphPipelineReference,
    Job,
    JobId,
    Origin,
    Pipeline,
    PipelineEdge,
    PipelineGraph,
    PipelineId,
    PipelineIid,
    PipelineKey,
    PipelineNode,
    PipelineNodeAvailable,
    PipelineNodeUnavailable,
    PipelineRoot,
    PositiveInt,
    ProjectId,
    ReadCoverage,
    Sha,
    Text,
    TriggerEvidence,
    TriggerJob,
    Unknown,
    UnknownPipelineRelation,
    WorkItem,
)
from gspace.pipeline_query import PAGE_SIZE

Gid = Annotated[str, Field(strict=True, pattern=r"^gid://gitlab/[A-Za-z:]+/[1-9][0-9]*$")]


class GraphProjectDTO(DTO):
    id: Gid
    fullPath: Text


class SourceJobDTO(DTO):
    id: Gid | None = None
    kind: Text | None = None
    retried: bool | None = Field(default=None, strict=True)


class GraphPipelineDTO(DTO):
    id: Gid
    iid: Text | None = None
    sha: Sha | None = None
    ref: Text | None = None
    source: Text | None = None
    status: Text | None = None
    project: GraphProjectDTO | None = None
    sourceJob: SourceJobDTO | None = None


class PageInfoDTO(DTO):
    hasNextPage: bool = Field(strict=True)
    endCursor: str | None


class ConnectionDTO(DTO):
    nodes: tuple[GraphPipelineDTO | None, ...] = Field(max_length=PAGE_SIZE)
    pageInfo: PageInfoDTO


class ExpandedPipelineDTO(GraphPipelineDTO):
    upstream: GraphPipelineDTO | None = None
    downstream: ConnectionDTO | None = None


class ProjectReadDTO(GraphProjectDTO):
    pipeline: ExpandedPipelineDTO | None = None


class GraphDataDTO(DTO):
    project: ProjectReadDTO | None = None


class GraphErrorDTO(DTO):
    # Error messages/extensions are intentionally discarded, never logged or propagated.
    path: tuple[str | int, ...] | None = None


class EnvelopeDTO(DTO):
    data: GraphDataDTO | None = None
    errors: tuple[GraphErrorDTO, ...] = ()


class DeployPipelineDTO(DTO):
    id: PositiveInt
    project_id: PositiveInt


class DeployJobDTO(DTO):
    id: PositiveInt
    pipeline: DeployPipelineDTO | None = None


class GraphDeployDTO(DeployDTO):
    deployable: DeployJobDTO | None = None


class GraphJobDTO(JobDTO):
    pipeline: DeployPipelineDTO | None = None


def gid_value(raw: str, kinds: tuple[str, ...]) -> int:
    prefix, _, value = raw.rpartition("/")
    if prefix not in {f"gid://gitlab/{kind}" for kind in kinds} or not value.isdecimal():
        raise ValueError("Unexpected GitLab global identity type")
    return int(value)


class Budget:
    def __init__(self, adapter: GlabAdapter) -> None:
        self.limits = adapter.config.pipeline_graph
        self.deadline = time.monotonic() + self.limits.timeout_seconds
        self.requests = 0

    def take(self) -> None:
        if self.requests >= self.limits.max_requests or time.monotonic() >= self.deadline:
            raise AdapterError("limit", "Pipeline graph request/time budget reached")
        self.requests += 1


class GraphReader:
    def __init__(self, adapter: GlabAdapter, item: WorkItem) -> None:
        self.adapter = adapter
        self.item = item
        self.budget = Budget(adapter)
        self.projects = {p.id: p for p in adapter.config.projects}
        self.refs: dict[PipelineKey, GraphPipelineReference] = {}
        self.raw: dict[PipelineKey, GraphPipelineDTO] = {}
        self.depth: dict[PipelineKey, int] = {}
        self.edges: dict[tuple[PipelineKey, PipelineKey], PipelineEdge] = {}
        self.unknown: dict[tuple[PipelineKey, str, str], UnknownPipelineRelation] = {}
        self.warnings: list[str] = []
        self.queue: deque[PipelineKey] = deque()
        self.deployments: dict[ProjectId, tuple[tuple[GraphDeployDTO, ...], ReadCoverage]] = {}
        self.hydration_failed: dict[PipelineKey, str] = {}

    def missing(
        self, owner: PipelineKey, direction: Literal["upstream", "downstream"], reason: str
    ) -> None:
        relation = UnknownPipelineRelation(pipeline=owner, direction=direction, reason=reason)
        self.unknown[(owner, direction, reason)] = relation

    def warn(self, reason: str) -> None:
        if reason not in self.warnings:
            self.warnings.append(reason)

    def reference(self, raw: GraphPipelineDTO) -> GraphPipelineReference:
        if raw.project is None:
            raise ValueError("Pipeline project is not visible")
        project = ProjectId(value=gid_value(raw.project.id, ("Project",)))
        key = PipelineKey(
            project=project, pipeline=PipelineId(value=gid_value(raw.id, ("Ci::Pipeline",)))
        )
        configured = self.projects.get(project)
        if configured is not None and configured.path != raw.project.fullPath:
            raise ValueError("Graph project path differs from configured identity")
        # Validate project paths before constructing contract links; never follow remote path URLs.
        project_config = ProjectConfig(id=project, path=raw.project.fullPath)
        iid = (
            PipelineIid(value=int(raw.iid))
            if raw.iid and raw.iid.isdecimal() and int(raw.iid) > 0
            else None
        )
        return GraphPipelineReference(
            key=key,
            project_path=project_config.path,
            iid=iid,
            sha=raw.sha,
            status=status(raw.status.lower()) if raw.status else status("unknown"),
            link=self.adapter.link(project_config, f"pipelines/{key.pipeline.value}"),
        )

    def add(
        self,
        raw: GraphPipelineDTO,
        owner: PipelineKey,
        direction: Literal["upstream", "downstream"],
    ) -> PipelineKey | None:
        try:
            ref = self.reference(raw)
        except (ValueError, ValidationError):
            self.missing(
                owner, direction, "Linked pipeline identity or project is unavailable/invalid"
            )
            return None
        prior = self.refs.get(ref.key)
        if prior:
            if prior.project_path != ref.project_path or (
                prior.sha and ref.sha and prior.sha != ref.sha
            ):
                self.missing(owner, direction, "Linked pipeline identity changed between reads")
                return None
            if prior.sha is None and ref.sha is not None:
                self.refs[ref.key] = ref
                self.raw[ref.key] = raw
            return ref.key
        if len(self.refs) >= self.budget.limits.max_nodes:
            self.missing(owner, direction, "Pipeline node budget reached; linked node omitted")
            return None
        self.refs[ref.key] = ref
        self.raw[ref.key] = raw
        depth = self.depth[owner] + 1
        self.depth[ref.key] = depth
        if ref.key.project not in self.projects:
            self.hydration_failed[ref.key] = (
                "Project is outside the configured active-profile scope"
            )
            self.missing(
                ref.key, "downstream", "Project outside allowed scope; relationships not loaded"
            )
            self.missing(
                ref.key, "upstream", "Project outside allowed scope; relationships not loaded"
            )
        elif depth > self.budget.limits.max_depth:
            self.missing(ref.key, "downstream", "Pipeline traversal depth limit reached")
            self.missing(ref.key, "upstream", "Pipeline traversal depth limit reached")
        else:
            self.queue.append(ref.key)
        return ref.key

    def trigger(self, raw: SourceJobDTO | None, upstream: PipelineKey) -> TriggerEvidence:
        if raw is None or raw.id is None or raw.kind is None or raw.retried is None:
            return Unknown(reason="Native source job is not visible or not reported")
        try:
            ident = gid_value(raw.id, ("Ci::Build", "Ci::Bridge", "CommitStatus"))
            kind = raw.kind.lower()
            return TriggerJob(
                project=upstream.project,
                id=JobId(value=ident),
                job_kind=kind if kind in ("build", "bridge") else "unknown",
                retried=raw.retried,
            )
        except ValueError:
            return Unknown(reason="Native source job identity is invalid")

    def edge(
        self, upstream: PipelineKey, downstream: PipelineKey, job: SourceJobDTO | None
    ) -> None:
        evidence = self.trigger(job, upstream)
        prior = self.edges.get((upstream, downstream))
        if prior is not None and isinstance(evidence, Unknown):
            return
        if (
            prior is not None
            and isinstance(prior.source_job, TriggerJob)
            and isinstance(evidence, TriggerJob)
            and prior.source_job != evidence
        ):
            evidence = Unknown(reason="Source job evidence differs between reads")
        self.edges[(upstream, downstream)] = PipelineEdge(
            upstream=upstream, downstream=downstream, source_job=evidence
        )

    def expand(self, key: PipelineKey) -> None:
        project = self.projects[key.project]
        cursor: str | None = None
        seen: set[str] = set()
        for _ in range(self.budget.limits.max_pages):
            try:
                self.budget.take()
                response = EnvelopeDTO.model_validate_json(
                    self.adapter.graph_page(project, key, cursor)
                )
                read_project = response.data.project if response.data else None
                if read_project is None or read_project.pipeline is None:
                    self.hydration_failed[key] = (
                        "Native pipeline/project is not visible or unavailable"
                    )
                    self.missing(
                        key, "upstream", "Native pipeline relationship read is unavailable"
                    )
                    self.missing(
                        key, "downstream", "Native pipeline relationship read is unavailable"
                    )
                    return
                if (
                    gid_value(read_project.id, ("Project",)) != project.id.value
                    or read_project.fullPath != project.path
                ):
                    raise ValueError("Graph response project differs")
                pipeline = read_project.pipeline
                ref = self.reference(pipeline)
                if ref.key != key or (
                    self.refs[key].sha is not None and ref.sha != self.refs[key].sha
                ):
                    raise ValueError("Graph response pipeline identity/SHA differs")
                self.refs[key] = ref
                self.raw[key] = pipeline
                if response.errors:
                    self.missing(
                        key, "downstream", "Native query returned partial errors; messages redacted"
                    )
                    self.missing(
                        key, "upstream", "Native query returned partial errors; messages redacted"
                    )
                if cursor is None:
                    if pipeline.upstream is not None:
                        parent = self.add(pipeline.upstream, key, "upstream")
                        if parent is not None:
                            self.edge(parent, key, pipeline.sourceJob)
                    elif pipeline.source and pipeline.source.lower() in (
                        "parent_pipeline",
                        "pipeline",
                    ):
                        self.missing(key, "upstream", "Triggered pipeline upstream is not visible")
                children = pipeline.downstream
                if children is None:
                    self.missing(key, "downstream", "Native downstream connection is not visible")
                    return
                for child in children.nodes:
                    if child is None:
                        self.missing(
                            key, "downstream", "A linked pipeline is hidden or unavailable"
                        )
                        continue
                    target = self.add(child, key, "downstream")
                    if target is not None:
                        self.edge(key, target, child.sourceJob)
                if not children.pageInfo.hasNextPage:
                    return
                next_cursor = children.pageInfo.endCursor
                if not next_cursor or next_cursor in seen:
                    self.missing(
                        key, "downstream", "Native pagination cursor is missing or repeated"
                    )
                    return
                seen.add(next_cursor)
                cursor = next_cursor
            except (AdapterError, ValueError, ValidationError):
                self.missing(
                    key, "downstream", "Native graph read failed or reached its configured budget"
                )
                self.missing(
                    key, "upstream", "Native graph read failed or reached its configured budget"
                )
                return
        self.missing(key, "downstream", "Native downstream page limit reached")

    def pages(
        self, path: str, dto: type[GraphJobDTO] | type[GraphDeployDTO], params: dict[str, str]
    ) -> tuple[tuple[GraphJobDTO | GraphDeployDTO, ...], ReadCoverage]:
        from pydantic import TypeAdapter

        parser = TypeAdapter(list[dto])
        values: list[GraphJobDTO | GraphDeployDTO] = []
        for page in range(1, self.budget.limits.max_pages + 1):
            try:
                self.budget.take()
                read = parser.validate_json(
                    self.adapter.get(path, {**params, "per_page": "100", "page": str(page)})
                )
                if len(read) > 100:
                    raise AdapterError("validation", "Hydration page exceeds requested size")
                values.extend(read)
                if len(read) < 100:
                    return tuple(values), CompleteRead()
            except (AdapterError, ValidationError):
                return tuple(values), Unknown(
                    reason="Pipeline hydration read failed or reached its configured budget"
                )
        return tuple(values), Unknown(reason="Pipeline hydration page limit reached")

    def hydrate(self, key: PipelineKey) -> PipelineNode:
        reference = self.refs[key]
        project = self.projects.get(key.project)
        raw = self.raw.get(key)
        reason = self.hydration_failed.get(key)
        if project is None or reason or raw is None or raw.sha is None or raw.ref is None:
            return PipelineNodeUnavailable(
                reference=reference, reason=reason or "Pipeline metadata is incomplete"
            )
        job_rows, jobs_coverage = self.pages(
            f"projects/{project.id.value}/pipelines/{key.pipeline.value}/jobs",
            GraphJobDTO,
            {"include_retried": "true"},
        )
        jobs: list[Job] = []
        counts: dict[tuple[str, str], int] = {}
        job_ids: set[int] = set()
        for row in sorted((r for r in job_rows if isinstance(r, GraphJobDTO)), key=lambda j: j.id):
            if row.id in job_ids or (
                row.pipeline is not None
                and (
                    row.pipeline.id != key.pipeline.value
                    or row.pipeline.project_id != key.project.value
                )
            ):
                jobs_coverage = Unknown(reason="Duplicate or foreign job identity omitted")
                continue
            job_ids.add(row.id)
            group = (row.name, row.stage)
            counts[group] = counts.get(group, 0) + 1
            jobs.append(
                Job(
                    project=project.id,
                    id=JobId(value=row.id),
                    name=row.name,
                    stage=row.stage,
                    status=status(row.status),
                    attempt=counts[group],
                    retried=row.retried,
                    failure_reason=row.failure_reason,
                    link=self.adapter.link(project, f"jobs/{row.id}"),
                )
            )
        if project.id not in self.deployments:
            deploy_rows, coverage = self.pages(
                f"projects/{project.id.value}/deployments",
                GraphDeployDTO,
                {"order_by": "id", "sort": "desc"},
            )
            self.deployments[project.id] = (
                tuple(r for r in deploy_rows if isinstance(r, GraphDeployDTO)),
                coverage,
            )
        deploy_rows, deployments_coverage = self.deployments[project.id]
        deployments: list[GraphDeployment] = []
        deploy_ids: set[int] = set()
        for row in deploy_rows:
            binding = row.deployable.pipeline if row.deployable else None
            if binding is None:
                deployments_coverage = Unknown(
                    reason="Some deployment records lack native deployable pipeline identity"
                )
                continue
            if binding.project_id != project.id.value:
                deployments_coverage = Unknown(
                    reason="Foreign deployment pipeline identity omitted"
                )
                continue
            if binding.id != key.pipeline.value:
                continue
            if row.id in deploy_ids:
                deployments_coverage = Unknown(reason="Duplicate deployment identity omitted")
                continue
            deploy_ids.add(row.id)
            try:
                from gspace.models import Deployment

                deployments.append(
                    GraphDeployment(
                        pipeline=key,
                        environment=row.environment.name,
                        record=Deployment(
                            project=project.id,
                            id=row.id,
                            status=status(row.status),
                            ref=row.ref,
                            sha=row.sha,
                            source=(
                                "GitLab deployment deployable.pipeline identity; "
                                "application version not proven"
                            ),
                            link=self.adapter.link(project, f"environments/{row.environment.id}"),
                        ),
                    )
                )
            except ValidationError:
                deployments_coverage = Unknown(
                    reason="Unsupported deployment environment identity omitted"
                )
        pipeline = Pipeline(
            project=project.id,
            id=key.pipeline,
            ref=raw.ref,
            sha=raw.sha,
            source=raw.source or "unknown",
            status=status(raw.status.lower()) if raw.status else status("unknown"),
            jobs=tuple(jobs),
            association=Association(
                origin=Origin.API,
                reason="Native GraphQL pipeline identity; edge is not application version evidence",
            ),
            link=reference.link,
        )
        return PipelineNodeAvailable(
            reference=reference,
            pipeline=pipeline,
            jobs_coverage=jobs_coverage,
            deployments_coverage=deployments_coverage,
            deployments=tuple(deployments),
        )

    def read(self) -> PipelineGraph:
        self.budget.take()
        release = self.adapter.single("version", VersionDTO).version
        try:
            parsed_release = read_release(release, self.adapter.config.supported_version)
        except ValueError as error:
            raise AdapterError(
                "compatibility", "Native graph requires pinned GitLab18.11.12 CE/EE"
            ) from error
        roots: list[PipelineRoot] = []
        for pipeline in self.item.pipelines:
            key = PipelineKey(project=pipeline.project, pipeline=pipeline.id)
            if key.project not in self.projects:
                raise AdapterError("scope", "Work-item graph root exceeds configured profile scope")
            if self.projects[key.project].path != self.item.project_path:
                raise AdapterError("scope", "Work-item graph root project path differs")
            if len(self.refs) >= self.budget.limits.max_nodes:
                self.warn("Pipeline root/node budget reached; remaining work-item roots omitted")
                break
            self.refs[key] = GraphPipelineReference(
                key=key,
                project_path=self.item.project_path,
                sha=pipeline.sha,
                status=pipeline.status,
                link=pipeline.link,
            )
            self.depth[key] = 0
            self.queue.append(key)
            roots.append(PipelineRoot(key=key, application_sha=pipeline.sha))
        visited: set[PipelineKey] = set()
        while self.queue:
            key = self.queue.popleft()
            if key in visited:
                continue
            visited.add(key)
            self.expand(key)
        nodes = tuple(self.hydrate(key) for key in self.refs)
        partial = (
            bool(self.unknown or self.warnings)
            or any(isinstance(edge.source_job, Unknown) for edge in self.edges.values())
            or any(
                isinstance(node, PipelineNodeUnavailable)
                or isinstance(node.jobs_coverage, Unknown)
                or isinstance(node.deployments_coverage, Unknown)
                for node in nodes
            )
        )
        return PipelineGraph(
            release=parsed_release,
            roots=tuple(roots),
            nodes=nodes,
            edges=tuple(self.edges.values()),
            unknown_relations=tuple(self.unknown.values()),
            coverage=Unknown(
                reason="Bounded graph has unavailable, incomplete or out-of-scope evidence"
            )
            if partial
            else CompleteRead(),
            fetched_at=datetime.now(UTC),
            warnings=tuple(self.warnings),
        )


def read_pipeline_graph(adapter: GlabAdapter, item: WorkItem) -> PipelineGraph:
    return GraphReader(adapter, item).read()


def synthetic_pipeline_graph(item: WorkItem) -> PipelineGraph:
    """Explicit invented A→B scenario; never attached to ordinary WorkItem associations."""
    from gspace.models import Deployment, Link, Status

    nodes: list[PipelineNode] = []
    roots: list[PipelineRoot] = []
    edges: list[PipelineEdge] = []
    for pipeline in item.pipelines:
        key = PipelineKey(project=pipeline.project, pipeline=pipeline.id)
        roots.append(PipelineRoot(key=key, application_sha=pipeline.sha))
        nodes.append(
            PipelineNodeAvailable(
                reference=GraphPipelineReference(
                    key=key,
                    project_path=item.project_path,
                    sha=pipeline.sha,
                    status=pipeline.status,
                    link=pipeline.link,
                ),
                pipeline=pipeline,
                jobs_coverage=CompleteRead(),
                deployments_coverage=CompleteRead(),
            )
        )
    if roots:
        project = ProjectId(value=99 if item.identity.project.value == 42 else 42)
        project_path = "demo/ground-service" if project.value == 99 else "demo/flight-service"
        key = PipelineKey(
            project=project, pipeline=PipelineId(value=97001 + item.identity.issue.value)
        )
        sha = "b" * 40

        def link(path: str) -> Link:
            return Link(
                url=f"https://gitlab.example.invalid/{project_path}/-/{path}",
                verification="fixture",
            )

        job = Job(
            project=project,
            id=JobId(value=88001 + item.identity.issue.value),
            name="deploy-dev",
            stage="deploy",
            status=Status.SUCCESS,
            attempt=1,
            retried=False,
            link=link(f"jobs/{88001 + item.identity.issue.value}"),
        )
        pipeline = Pipeline(
            project=project,
            id=key.pipeline,
            ref="main",
            sha=sha,
            source="pipeline",
            status=Status.SUCCESS,
            jobs=(job,),
            association=Association(
                origin=Origin.FIXTURE,
                reason=("Synthetic downstream deploy/config pipeline; distinct application SHA"),
            ),
            link=link(f"pipelines/{key.pipeline.value}"),
        )
        nodes.append(
            PipelineNodeAvailable(
                reference=GraphPipelineReference(
                    key=key,
                    project_path=project_path,
                    sha=sha,
                    status=pipeline.status,
                    link=pipeline.link,
                ),
                pipeline=pipeline,
                jobs_coverage=CompleteRead(),
                deployments_coverage=CompleteRead(),
                deployments=(
                    GraphDeployment(
                        pipeline=key,
                        environment="dev",
                        record=Deployment(
                            project=project,
                            id=48001 + item.identity.issue.value,
                            status=Status.SUCCESS,
                            ref="main",
                            sha=sha,
                            source=(
                                "Synthetic deployment belongs to B config pipeline; "
                                "application version unknown"
                            ),
                            link=link("environments/55"),
                        ),
                    ),
                ),
            )
        )
        edges.append(
            PipelineEdge(
                upstream=roots[0].key,
                downstream=key,
                source_job=TriggerJob(
                    project=roots[0].key.project,
                    id=JobId(value=77001 + item.identity.issue.value),
                    job_kind="bridge",
                    retried=False,
                ),
                origin="fixture",
            )
        )
    return PipelineGraph(
        source="fixture",
        roots=tuple(roots),
        nodes=tuple(nodes),
        edges=tuple(edges),
        coverage=CompleteRead(),
        fetched_at=datetime.now(UTC),
    )
