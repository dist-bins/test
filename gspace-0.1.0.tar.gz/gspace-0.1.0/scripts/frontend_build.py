"""Check strict maintained frontend source and build reproducible browser assets.

Root-owned integration only. Never invokes package lifecycle scripts or reads npm
configuration. Generated outputs are distinct from Claude's maintained TS source.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend-new"
ENV = {"PATH": os.environ.get("PATH", os.defpath), "DO_NOT_TRACK": "1"}
ASSETS = (
    "index.html",
    "app.js",
    "theme.js",
    "styles.css",
    "gspace-wolf.svg",
    "gspace-wolf-gray.svg",
    "icon.svg",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(arguments: list[str]) -> None:
    subprocess.run(arguments, cwd=FRONTEND, env=ENV, check=True, timeout=120)


def compiler_guard(toolchain: Path) -> None:
    """Check resolved compiler settings, including individually overridden strict flags."""
    source = """
const ts = require(process.argv[1]);
const config = ts.readConfigFile(process.argv[2], ts.sys.readFile);
if (config.error) throw new Error(ts.flattenDiagnosticMessageText(config.error.messageText, '\\n'));
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, process.argv[3]);
if (parsed.errors.length) throw new Error('Invalid TypeScript configuration');
const options = parsed.options;
if (options.strict !== true || options.noUncheckedIndexedAccess !== true ||
    options.exactOptionalPropertyTypes !== true || options.allowJs === true ||
    options.skipLibCheck === true) throw new Error('Required compiler guards changed');
for (const flag of ['noImplicitAny', 'noImplicitThis', 'strictNullChecks',
 'strictFunctionTypes', 'strictBindCallApply', 'strictPropertyInitialization',
 'useUnknownInCatchVariables', 'alwaysStrict', 'strictBuiltinIteratorReturn']) {
 if (options[flag] === false) throw new Error('Strict compiler guard disabled: ' + flag);
}
for (const entry of ['app.ts', 'theme.ts']) {
 if (!parsed.fileNames.some(name => name.endsWith('/src/' + entry)))
  throw new Error('Unchecked maintained TypeScript entrypoint: ' + entry);
}
"""
    run(
        [
            "node",
            "-e",
            source,
            str(toolchain / "node_modules/typescript/lib/typescript.js"),
            str(FRONTEND / "tsconfig.json"),
            str(FRONTEND),
        ]
    )


def sources() -> dict[str, str]:
    candidates = list((FRONTEND / "src").rglob("*"))
    candidates += [FRONTEND / name for name in ("tsconfig.json", "biome.json", "package.json")]
    candidates += [FRONTEND / "contracts" / name for name in ("api.d.ts", "schema-validation.js")]
    candidates += [FRONTEND / name for name in ASSETS if name not in ("app.js", "theme.js")]
    return {
        str(path.relative_to(FRONTEND)): digest(path)
        for path in sorted(candidates)
        if path.is_file()
    }


def build(output: Path) -> dict[str, str]:
    for source, name, module_format in (
        ("src/app.ts", "app.js", "esm"),
        ("src/theme.ts", "theme.js", "iife"),
    ):
        run(
            [
                "bun",
                "build",
                str(FRONTEND / source),
                "--target=browser",
                f"--format={module_format}",
                "--minify",
                f"--outfile={output / name}",
            ]
        )
    for name in ASSETS:
        if name not in ("app.js", "theme.js"):
            shutil.copyfile(FRONTEND / name, output / name)
    for name in ("app.js", "theme.js"):
        source = (output / name).read_text()
        if "new Function(" in source or "eval(" in source:
            raise RuntimeError(f"Forbidden runtime evaluation in {name}")
    return {name: digest(output / name) for name in ASSETS}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--toolchain", type=Path, default=FRONTEND)
    parser.add_argument("--check", action="store_true", help="Require current generated assets")
    args = parser.parse_args()
    toolchain = args.toolchain.resolve()
    if not all((FRONTEND / "src" / name).is_file() for name in ("app.ts", "theme.ts")):
        raise RuntimeError("Maintained TypeScript conversion has not produced both entrypoints")
    before = sources()
    compiler_guard(toolchain)
    # Command flags keep these guards effective even if a project config changes.
    run(
        [
            "node",
            str(toolchain / "node_modules/typescript/bin/tsc"),
            "--project",
            str(FRONTEND / "tsconfig.json"),
            "--noEmit",
            "--strict",
            "--noUncheckedIndexedAccess",
            "--exactOptionalPropertyTypes",
            "--allowJs",
            "false",
        ]
    )
    maintained = ["src", "tsconfig.json", "biome.json", "package.json"]
    if (FRONTEND / "scripts").is_dir():
        maintained.append("scripts")
    run([str(toolchain / "node_modules/.bin/biome"), "check", *maintained])
    with tempfile.TemporaryDirectory(prefix="gspace-browser-build-") as temporary:
        directory = Path(temporary)
        first, second = directory / "first", directory / "second"
        first.mkdir()
        second.mkdir()
        hashes = build(first)
        if hashes != build(second):
            raise RuntimeError("Identical source produced different browser build bytes")
        if before != sources():
            raise RuntimeError(
                "Frontend source changed during checks/build; retry after checkpoint"
            )
        differences = [name for name in ASSETS if digest(FRONTEND / name) != hashes[name]]
        if args.check and differences:
            print(json.dumps({"result": "compiled asset drift", "files": differences}))
            return 1
        if not args.check:
            for name in ("app.js", "theme.js"):
                shutil.copyfile(first / name, FRONTEND / name)
        report = {
            "purpose": "Strict maintained frontend and reproducible compiled asset verification",
            "strict_tsc": True,
            "biome": True,
            "reproducible": True,
            "sources": before,
            "assets": hashes,
            "mode": "check" if args.check else "build",
        }
        report_path = ROOT / "output/verification/frontend-build.json"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
        print(json.dumps({"result": "current" if args.check else "built", "reproducible": True}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
