"""Dependency-free acceptance driver executed inside the owned fixture container."""

from __future__ import annotations

import errno
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.request import Request, urlopen


def negative_controls() -> list[dict[str, object]]:
    controls: list[dict[str, object]] = []
    for family, address in ((socket.AF_INET, "192.0.2.1"), (socket.AF_INET6, "2001:db8::1")):
        for kind, protocol in ((socket.SOCK_STREAM, "TCP"), (socket.SOCK_DGRAM, "UDP")):
            try:
                with socket.socket(family, kind) as connection:
                    connection.settimeout(0.5)
                    if kind == socket.SOCK_DGRAM:
                        connection.sendto(b"gspace-negative-control", (address, 443))
                    else:
                        connection.connect((address, 443))
            except OSError as error:
                denied = error.errno in (
                    errno.ENETUNREACH,
                    errno.EHOSTUNREACH,
                    errno.EPERM,
                    errno.EACCES,
                    errno.EAFNOSUPPORT,
                )
                controls.append(
                    {
                        "protocol": protocol,
                        "address": address,
                        "errno": error.errno,
                        "denied": denied,
                    }
                )
            else:
                controls.append({"protocol": protocol, "address": address, "denied": False})
    assert all(control["denied"] for control in controls), controls
    return controls


def request(origin: str, path: str, body: object = None) -> bytes:
    data = None if body is None else json.dumps(body).encode()
    call = Request(
        origin + path,
        data=data,
        headers={"Content-Type": "application/json"} if data else {},
    )
    with urlopen(call, timeout=2) as response:
        assert response.status == 200
        return response.read()


def fixture_acceptance() -> dict[str, object]:
    import gspace

    assert str(gspace.__file__).startswith("/app/.venv/")
    expected = json.loads(Path("/app/asset-hashes.json").read_text())
    with tempfile.TemporaryDirectory(prefix="gspace-container-fixture-") as temporary:
        config = Path(temporary) / "fixture.toml"
        config.write_text(
            'mode="fixture"\npreferences_path="preferences.toml"\ncache_path="cache.json"\n'
        )
        with socket.socket() as allocator:
            allocator.bind(("127.0.0.1", 0))
            port = allocator.getsockname()[1]
        server = subprocess.Popen(
            [sys.executable, "-m", "gspace", "serve", "--config", str(config), "--port", str(port)],
            stdout=subprocess.DEVNULL,
            stderr=sys.stderr,
        )
        try:
            origin = f"http://127.0.0.1:{port}"
            for _ in range(80):
                assert server.poll() is None, "Installed fixture server exited"
                try:
                    dashboard = json.loads(request(origin, "/api/dashboard"))
                    break
                except OSError:
                    time.sleep(0.1)
            else:
                raise AssertionError("Installed fixture server startup timed out")
            assert len(dashboard["views"]) == 4 and dashboard["total"] == 7
            hashes = {}
            for name, digest in expected.items():
                route = "/" if name == "index.html" else "/assets/" + name
                hashes[name] = hashlib.sha256(request(origin, route)).hexdigest()
                assert hashes[name] == digest, name
            capabilities = json.loads(request(origin, "/api/capabilities"))
            assert capabilities["remote_mutations"] is False
            assert capabilities["write_scope"] == "disabled"
            profiles = json.loads(request(origin, "/api/access/profiles"))
            settings = json.loads(request(origin, "/api/settings"))
            settings["settings"]["timezone"] = "UTC"
            saved = json.loads(
                request(
                    origin,
                    "/api/settings",
                    {"revision": settings["revision"], "settings": settings["settings"]},
                )
            )
            assert saved["settings"]["timezone"] == "UTC"
            reread = json.loads(request(origin, "/api/settings"))
            assert reread["revision"] == saved["revision"]
            return {
                "dashboard_total": dashboard["total"],
                "asset_sha256": hashes,
                "remote_mutations": capabilities["remote_mutations"],
                "write_scope": capabilities["write_scope"],
                "profiles": profiles,
                "settings_save_and_reread": True,
                "installed_module": str(gspace.__file__),
            }
        finally:
            server.terminate()
            try:
                server.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait(timeout=3)


def main() -> int:
    if sys.argv[1:] == ["--negative-child"]:
        print(json.dumps(negative_controls()))
        return 0
    assert sys.version_info[:2] == (3, 12)
    assert os.getuid() == 65534 and os.getgid() == 65534
    installed = {
        package.metadata["Name"]: package.version for package in importlib.metadata.distributions()
    }
    assert shutil.which("uv") is None
    assert not {"uv", "pytest", "playwright", "ruff", "basedpyright"}.intersection(installed)
    interfaces = sorted(path.name for path in Path("/sys/class/net").iterdir())
    assert interfaces == ["lo"], interfaces
    controls = negative_controls()
    child = subprocess.run(
        [sys.executable, __file__, "--negative-child"],
        check=True,
        text=True,
        capture_output=True,
        timeout=4,
    )
    child_controls = json.loads(child.stdout)
    assert all(control["denied"] for control in child_controls)
    started = time.monotonic()
    resolver = subprocess.run(
        [
            sys.executable,
            "-c",
            "import socket\ntry: socket.getaddrinfo('gspace-network-control.invalid',443)"
            "\nexcept socket.gaierror as e: print(e.errno)"
            "\nelse: raise RuntimeError('Unexpected resolver success')",
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=5,
    )
    elapsed = time.monotonic() - started
    assert resolver.stdout.strip()
    try:
        Path("/app/negative-write-control").write_text("must fail")
    except OSError as error:
        assert error.errno == errno.EROFS
    else:
        raise AssertionError("Container root filesystem was writable")
    report = {
        "passed": True,
        "python": platform.python_version(),
        "uid": os.getuid(),
        "runtime_distributions": installed,
        "uv_and_development_tools_absent": True,
        "interfaces": interfaces,
        "blocked_attempts": controls,
        "inherited_child_controls": child_controls,
        "resolver": {"failed": True, "errno": int(resolver.stdout), "seconds": elapsed},
        "readonly_root": True,
        "fixture": fixture_acceptance(),
        "limitations": [
            "Actual Linux container fixture acceptance only; no browser engine installed",
            "No live glab, authenticated GitLab, corporate service or DevPod acceptance",
            "No external runtime interface; public dependency downloads occur only during build",
            "Python base OS and build tooling attribution remain separate inventory scope",
        ],
    }
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
