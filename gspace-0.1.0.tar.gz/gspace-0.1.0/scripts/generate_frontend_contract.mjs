/** Root-owned build integration: local OpenAPI types and CSP-safe validators. */
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

const [toolchain, schemaPath, output] = process.argv.slice(2);
if (!toolchain || !schemaPath || !output) throw new Error("Missing fixed build arguments");
const moduleUrl = (relative) => pathToFileURL(join(toolchain, "node_modules", relative));
const { default: openapiTS, astToString, COMMENT_HEADER } = await import(
  moduleUrl("openapi-typescript/dist/index.mjs")
);
const { default: Ajv } = await import(moduleUrl("ajv/dist/2020.js"));
const { default: addFormats } = await import(moduleUrl("ajv-formats/dist/index.js"));
const { default: standalone } = await import(moduleUrl("ajv/dist/standalone/index.js"));
const document = JSON.parse(await readFile(schemaPath, "utf8"));
// Reject external references before either library is invoked. Generation cannot fetch URLs.
function localReferences(value) {
  if (!value || typeof value !== "object") return;
  if (typeof value.$ref === "string" && !value.$ref.startsWith("#/")) {
    throw new Error("Only local OpenAPI references are permitted");
  }
  for (const child of Object.values(value)) localReferences(child);
}
localReferences(document);
await writeFile(join(output, "api.d.ts"), COMMENT_HEADER + astToString(await openapiTS(document, {
  immutable: true, alphabetize: true, silent: true,
})));

const identifier = "https://gspace.invalid/local-openapi-schema";
const ajv = new Ajv({
  strict: true, allErrors: true, coerceTypes: false,
  useDefaults: false, removeAdditional: false,
  inlineRefs: false,
  code: { source: true, esm: true, lines: true, optimize: 1 },
});
// OpenAPI discriminator is an annotation. Actual oneOf/const validation remains enforced.
ajv.addKeyword({ keyword: "discriminator", valid: true });
addFormats(ajv);
const entries = {};
const maps = { schemas: {}, requests: {}, responses: {} };
const declarations = { schemas: [], requests: [], responses: [] };
let sequence = 0;
function entry(group, name, schema, type) {
  const key = `v${sequence++}`;
  entries[key] = schema;
  maps[group][name] = key;
  declarations[group].push(`  readonly ${JSON.stringify(name)}: Validator<${type}>;`);
}
for (const name of Object.keys(document.components.schemas).sort()) {
  entry("schemas", name, { $ref: `#/components/schemas/${name}` },
    `components["schemas"][${JSON.stringify(name)}]`);
}
for (const path of Object.keys(document.paths).sort()) {
  for (const method of ["get", "post", "put", "patch", "delete"]) {
    const operation = document.paths[path][method];
    if (!operation) continue;
    const base = `paths[${JSON.stringify(path)}][${JSON.stringify(method)}]`;
    const request = operation.requestBody?.content?.["application/json"]?.schema;
    if (request) entry("requests", `${method.toUpperCase()} ${path}`, request,
      `NonNullable<${base}["requestBody"]>["content"]["application/json"]`);
    for (const status of Object.keys(operation.responses).sort()) {
      const schema = operation.responses[status].content?.["application/json"]?.schema;
      if (schema) entry("responses", `${method.toUpperCase()} ${path} ${status}`, schema,
        `${base}["responses"][${JSON.stringify(Number(status))}]["content"]["application/json"]`);
    }
  }
}
const definitions = {
  ...Object.fromEntries(Object.entries(document.components.schemas).map(([name, schema]) => [`m_${name}`, structuredClone(schema)])),
  ...structuredClone(entries),
};
function schemaReferences(value) {
  if (!value || typeof value !== "object") return;
  if (typeof value.$ref === "string") {
    if (!value.$ref.startsWith("#/components/schemas/")) throw new Error("Unsupported local schema reference");
    value.$ref = "#/$defs/m_" + value.$ref.slice("#/components/schemas/".length);
  }
  for (const child of Object.values(value)) schemaReferences(child);
}
schemaReferences(definitions);
ajv.addSchema({ $id: identifier, $defs: definitions });
const refs = Object.fromEntries(Object.keys(entries).map((key) => [key, `${identifier}#/$defs/${key}`]));
let code = standalone(ajv, refs);
for (const [group, values] of Object.entries(maps)) {
  code += `\nexport const ${group} = Object.freeze({\n`;
  code += Object.entries(values).map(([name, key]) => `  ${JSON.stringify(name)}: ${key}`).join(",\n");
  code += "\n});\n";
}
await writeFile(join(output, "validation.raw.js"), code);
let types = '// Generated from the same OpenAPI document; do not hand-edit.\nimport type { components, paths } from "./api";\n';
types += "export interface ValidationIssue { readonly instancePath: string; readonly keyword: string; readonly message?: string; }\n";
types += "export type Validator<T> = ((value: unknown) => value is T) & { readonly errors?: readonly ValidationIssue[] | null };\n";
for (const [group, fields] of Object.entries(declarations)) types += `export const ${group}: {\n${fields.join("\n")}\n};\n`;
await writeFile(join(output, "schema-validation.d.ts"), types);
await writeFile(join(output, "counts.json"), JSON.stringify({
  schemas: Object.keys(maps.schemas).length,
  requests: Object.keys(maps.requests).length,
  responses: Object.keys(maps.responses).length,
}));
