"""Generate/check one local OpenAPI type surface and precompiled browser validators."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from export_openapi import schema_text

ROOT = Path(__file__).resolve().parents[1]
CONTRACTS = ROOT / "frontend-new/contracts"
FILES = ("api.d.ts", "schema-validation.js", "schema-validation.d.ts", "type-manifest.json")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--toolchain", type=Path, default=ROOT / "frontend-new")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    toolchain = args.toolchain.resolve()
    if (CONTRACTS / "openapi.json").read_text() != schema_text():
        raise RuntimeError("Pydantic/OpenAPI drift: export and review the canonical schema first")
    with tempfile.TemporaryDirectory(prefix="generation-", dir=toolchain) as temporary:
        output = Path(temporary)
        subprocess.run(
            [
                "node",
                str(ROOT / "scripts/generate_frontend_contract.mjs"),
                str(toolchain),
                str(CONTRACTS / "openapi.json"),
                str(output),
            ],
            check=True,
            timeout=90,
            env={"PATH": os.environ.get("PATH", os.defpath)},
        )
        subprocess.run(
            [
                "bun",
                "build",
                str(output / "validation.raw.js"),
                "--target=browser",
                "--format=esm",
                "--outfile=" + str(output / "schema-validation.js"),
            ],
            check=True,
            timeout=30,
            cwd=output,
            env={"PATH": os.environ.get("PATH", os.defpath), "DO_NOT_TRACK": "1"},
        )
        source = (output / "schema-validation.js").read_text()
        if "new Function(" in source or "eval(" in source:
            raise RuntimeError("Generated browser validators require forbidden runtime evaluation")
        versions = json.loads((toolchain / "package.json").read_text())["devDependencies"]
        manifest = {
            "purpose": "One OpenAPI HTTP type surface and CSP-safe runtime validation",
            "openapi_sha256": digest(CONTRACTS / "openapi.json"),
            "versions": versions,
            "counts": json.loads((output / "counts.json").read_text()),
            "assets": {name: digest(output / name) for name in FILES[:-1]},
        }
        (output / "type-manifest.json").write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n"
        )
        differences = [
            name
            for name in FILES
            if not (CONTRACTS / name).is_file()
            or (CONTRACTS / name).read_bytes() != (output / name).read_bytes()
        ]
        if args.check and differences:
            print(json.dumps({"result": "drift", "files": differences}))
            return 1
        if not args.check:
            for name in FILES:
                shutil.copyfile(output / name, CONTRACTS / name)
        print(
            json.dumps({"result": "current" if args.check else "generated", **manifest["counts"]})
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
