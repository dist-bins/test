import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from scripts.bundle_provenance import canonical_metafile, digest, verify_inputs


def test_provenance_help_needs_no_clone_toolchain_or_output_directory(tmp_path):
    scripts = tmp_path / "scripts"
    scripts.mkdir()
    source = Path(__file__).resolve().parents[1] / "scripts/bundle_provenance.py"
    shutil.copyfile(source, scripts / source.name)
    result = subprocess.run(
        [sys.executable, str(scripts / source.name), "--help"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        timeout=5,
    )
    assert result.returncode == 0 and "--assets" in result.stdout
    assert not (tmp_path / "output").exists()


def test_current_attribution_rejects_changed_inputs_and_linked_sources(tmp_path):
    path = tmp_path / "source.ts"
    path.write_bytes(b"current source")
    frozen = {"source.ts": hashlib.sha256(b"current source").hexdigest()}
    verify_inputs(tmp_path, frozen)
    path.write_bytes(b"changed after generation")
    with pytest.raises(RuntimeError, match="changed"):
        verify_inputs(tmp_path, frozen)
    link = tmp_path / "linked.ts"
    link.symlink_to(path)
    with pytest.raises(ValueError, match="linked"):
        digest(link)


def test_metafile_provenance_does_not_depend_on_temporary_directory(tmp_path):
    import json

    first, second = tmp_path / "first", tmp_path / "second"
    one = json.dumps(
        {"inputs": {"src/app.ts": {"imports": [{"path": str(first / "src/api.ts")}]}}}
    ).encode()
    two = json.dumps(
        {"inputs": {"src/app.ts": {"imports": [{"path": str(second / "src/api.ts")}]}}}
    ).encode()
    assert canonical_metafile(one, first, tmp_path / "generation-one") == canonical_metafile(
        two, second, tmp_path / "generation-two"
    )
