"""Run the sole recovery frontend writer with finite permissions and exact model."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend-new"
OUTPUT = ROOT / "output/claude"
MODEL = "claude-opus-5-5"
EFFORT = "high"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "phase", choices=("hierarchy", "implement", "review", "correct", "final_review")
    )
    parser.add_argument("--resume")
    args = parser.parse_args()
    if args.phase != "hierarchy" and args.resume is None:
        parser.error("Later phases require this recovery's verified exact owned session")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    owned = [json.loads(p.read_text()) for p in OUTPUT.glob("recovery-*.status.json")]
    for prior in owned:
        if prior.get("status") in ("starting", "running") and prior.get("pid"):
            try:
                os.kill(prior["pid"], 0)
            except ProcessLookupError:
                continue
            raise RuntimeError("An owned recovery writer is active; no concurrent launch")
    session = str(UUID(args.resume)) if args.resume else None
    if session and not any(
        p.get("session_id") == session
        and p.get("actual_model") == MODEL
        and p.get("model_verified") is True
        for p in owned
    ):
        raise ValueError("Session must belong to the verified recovery writer")
    checkpoint = f"{ROOT / '.venv/bin/python'} {ROOT / 'scripts/frontend_checkpoint.py'}"
    allowed = ["Read", "Glob", "Grep", f"Bash({checkpoint} --message *)"]
    if args.phase == "hierarchy":
        allowed += [
            "Write(./docs/application-recovery-hierarchy.md)",
            "Edit(./docs/application-recovery-hierarchy.md)",
        ]
    elif args.phase in ("review", "final_review"):
        document = (
            "application-recovery-final-review.md"
            if args.phase == "final_review"
            else "application-recovery-review.md"
        )
        allowed += [
            f"Write(./docs/{document})",
            f"Edit(./docs/{document})",
        ]
    else:
        allowed += ["Edit(./**)", "Write(./**)"]
    deny = [
        f"{tool}({path})"
        for tool in ("Read", "Write", "Edit")
        for path in ("./.git/**", "./.claude/**", "./.env", "./.env.*")
    ]
    deny += ["Bash(git *)"]
    prompt = (
        "You are the sole GSpace frontend recovery writer, exact Claude Opus5.5/high. "
        "No model fallback or subagents. Read docs/application-recovery-brief.md. "
        "The exact user clarification in that file must retain its meaning. "
        "Read API.md and current contracts. Own only frontend-new. No network, auth, "
        "unrelated sessions/project data, arbitrary shell or permission bypass. "
        "The only Bash permission is the fixed frontend_checkpoint.py wrapper. "
    )
    if args.phase == "hierarchy":
        prompt += (
            "Perform Phase1 only: inspect all15 curated images and audit, then write "
            "docs/application-recovery-hierarchy.md with explicit cross-page hierarchy "
            "and realistic journeys. No source/asset implementation yet. Checkpoint the "
            "hierarchy through the wrapper and finish. Root will review before Phase2."
        )
    elif args.phase == "implement":
        prompt += (
            "Perform approved Phase2 from docs/application-recovery-hierarchy.md and "
            "docs/application-recovery-handoff.md. Implement the complete hierarchy and "
            "functional corrections across the app; preserve detailed tables and complete "
            "evidence. Root owns backend/build/tests and is not editing your source. "
            "Use finite Git checkpoints, document exact implemented/deferred features, "
            "do not claim tests you did not run. Finish a usable complete candidate."
        )
    elif args.phase == "correct":
        prompt += (
            "Implement the bounded findings F1-F7 from your completed "
            "docs/application-recovery-review.md and root-approved "
            "docs/application-recovery-corrections.md. Read those current files "
            "and source first. Preserve the whole hierarchy and truthful complete "
            "evidence; no broad redesign or backend/contract changes. Root owns "
            "build/tests and the separately frozen preview. Finish all bounded "
            "corrections and implementation documentation with finite Git checkpoints. "
            "Do not claim tests or image review you did not perform."
        )
    elif args.phase == "final_review":
        prompt += (
            "Perform the final read-only corrected-candidate review from "
            "docs/application-recovery-final-review-brief.md. Inspect its actual current "
            "images, especially all F1-F7 corrected interactions and both theme/width "
            "variants specified there. Preserve your original review. Write only "
            "docs/application-recovery-final-review.md, state precisely which images "
            "you opened and any actual remaining acceptance blockers. No source/assets "
            "edits or claimed test execution. Checkpoint only that final report."
        )
    else:
        prompt += (
            "Read docs/application-recovery-review-brief.md and its current actual "
            "compiled images. Review only, write docs/application-recovery-review.md; "
            "do not edit app source. Report whether the app is materially clearer and "
            "specific findings honestly. Checkpoint the review document."
        )
    arguments = [
        "/opt/homebrew/bin/claude",
        "--print",
        "--model",
        MODEL,
        "--effort",
        EFFORT,
        "--safe-mode",
        "--restricted",
        "--strict-mcp-config",
        "--mcp-config",
        '{"mcpServers":{}}',
        "--disable-slash-commands",
        "--permission-mode",
        "dontAsk",
        "--permission-prompts",
        "none",
        "--tools",
        "Read,Glob,Grep,Edit,Write,Bash",
        "--allowedTools",
        *allowed,
        "--settings",
        json.dumps({"permissions": {"allow": allowed, "deny": deny}, "switchModelsOnFlag": False}),
        "--output-format",
        "stream-json",
        "--verbose",
    ]
    if session:
        arguments += ["--resume", session]
    prefix = OUTPUT / f"recovery-{args.phase}-{datetime.now(UTC):%Y%m%dT%H%M%SZ}"
    state = {
        "status": "starting",
        "phase": args.phase,
        "model": MODEL,
        "effort": EFFORT,
        "model_verified": False,
        "cwd": str(FRONTEND),
        "started_at": datetime.now(UTC).isoformat(),
        "stream": str(prefix.with_suffix(".jsonl")),
    }
    status = prefix.with_suffix(".status.json")
    with prefix.with_suffix(".stderr.txt").open("w") as stderr:
        process = subprocess.Popen(
            arguments,
            cwd=FRONTEND,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=stderr,
            text=True,
            env={**os.environ, "CLAUDE_CODE_EFFORT_LEVEL": EFFORT},
        )
        state.update(status="running", pid=process.pid)
        status.write_text(json.dumps(state, indent=2) + "\n")
        print(json.dumps(state), flush=True)
        assert process.stdin is not None and process.stdout is not None
        process.stdin.write(prompt)
        process.stdin.close()
        with prefix.with_suffix(".jsonl").open("w") as stream:
            for line in process.stdout:
                stream.write(line)
                stream.flush()
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if row.get("type") == "system" and row.get("subtype") == "init":
                    actual = row.get("model")
                    state.update(
                        actual_model=actual,
                        model_verified=actual == MODEL,
                        session_id=row.get("session_id"),
                    )
                    if actual != MODEL:
                        state.update(status="error", public_result="Model mismatch; stopped")
                        process.terminate()
                    status.write_text(json.dumps(state, indent=2) + "\n")
                    print(
                        json.dumps(
                            {"event": "init", "model": actual, "session_id": state["session_id"]}
                        ),
                        flush=True,
                    )
                if row.get("type") == "result":
                    state.update(
                        status="error" if row.get("is_error") else "done",
                        public_result=str(row.get("result", ""))[:3500],
                        session_id=row.get("session_id"),
                        actual_models_used=list(row.get("modelUsage", {})),
                    )
                    if state["actual_models_used"] != [MODEL]:
                        state.update(status="error", model_error="Final modelUsage differs")
        state.update(exit_code=process.wait(), finished_at=datetime.now(UTC).isoformat())
        if state["status"] == "running":
            state["status"] = "error" if state["exit_code"] else "done"
        status.write_text(json.dumps(state, indent=2) + "\n")
        print(json.dumps({"status": state["status"], "exit_code": state["exit_code"]}), flush=True)
        return state["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
