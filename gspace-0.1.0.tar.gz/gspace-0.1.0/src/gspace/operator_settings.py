"""Comment-preserving operator TOML writes with an optimistic content revision."""

from __future__ import annotations

import fcntl
import os
import tempfile
import tomllib
from collections.abc import Callable
from hashlib import sha256
from pathlib import Path
from typing import Literal

import tomlkit
from pydantic import Field, JsonValue, TypeAdapter
from tomlkit.container import Container
from tomlkit.items import Item, Table

from gspace.config import AppConfig, TagConvention, resolve_config
from gspace.models import Model
from gspace.pipeline_config import EffectivePipeline, PipelineRules, ProjectPipelineOverride


class OperatorSettings(Model, frozen=True):
    timezone: str = "Europe/Zurich"
    branch_template: str = "issue-{iid}"
    tag_convention: TagConvention = TagConvention()
    pipeline: PipelineRules = PipelineRules()
    project_pipeline_overrides: tuple[ProjectPipelineOverride, ...] = ()

    @classmethod
    def from_config(cls, config: AppConfig) -> OperatorSettings:
        return cls.model_validate(config.model_dump(include=set(cls.model_fields)))


class SettingsResponse(Model, frozen=True):
    revision: str
    settings: OperatorSettings
    effective: tuple[EffectivePipeline, ...]
    scope: Literal["local_operator_file"] = "local_operator_file"
    remote_effect: Literal[False] = False
    refresh_required: bool = False


class SettingsChange(Model, frozen=True):
    revision: str = Field(pattern=r"^[0-9a-f]{64}$")
    settings: OperatorSettings


class SettingsConflict(ValueError):
    pass


JSON = TypeAdapter[dict[str, JsonValue]](dict[str, JsonValue])


def patch_table(document: Container | Table, payload: dict[str, JsonValue]) -> None:
    for name, value in payload.items():
        # Typed item access avoids tomlkit's untyped get() boundary.
        existing = document[name] if name in document else None  # noqa: SIM401
        if isinstance(value, dict) and isinstance(existing, Table):
            patch_table(existing, value)
        elif existing is None or (isinstance(existing, Item) and existing.unwrap() != value):
            document[name] = tomlkit.item(value)


class OperatorStore:
    def __init__(self, path: Path, fallback: AppConfig) -> None:
        self.path = path
        self.fallback = fallback

    def revision(self) -> str:
        return sha256(self.path.read_bytes() if self.path.exists() else b"").hexdigest()

    def read(self) -> AppConfig:
        return self.snapshot()[0]

    def snapshot(self) -> tuple[AppConfig, str]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.with_suffix(".operator.lock").open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_SH)
            payload = self.path.read_bytes() if self.path.exists() else b""
            config = (
                resolve_config(AppConfig.model_validate(tomllib.loads(payload.decode())), self.path)
                if payload
                else self.fallback
            )
            return config, sha256(payload).hexdigest()

    def update(
        self, change: SettingsChange, *, validate: Callable[[AppConfig], None] | None = None
    ) -> AppConfig:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.with_suffix(".operator.lock").open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            if change.revision != self.revision():
                raise SettingsConflict(
                    "Operator settings changed; reload before applying your edits"
                )
            original = self.path.read_text() if self.path.exists() else ""
            document = tomlkit.parse(original)
            if not original:
                # Persist the already authorized scope/paths, never implicit auth sources.
                for name, value in self.fallback.model_dump(mode="json", exclude_none=True).items():
                    document[name] = tomlkit.item(value)
            # Patch only this public DTO. Unrelated config, comments and endpoint policies survive.
            patch_table(
                document,
                JSON.validate_python(change.settings.model_dump(mode="json", exclude_none=True)),
            )
            payload = tomlkit.dumps(document).encode()
            config = resolve_config(
                AppConfig.model_validate(tomllib.loads(payload.decode())), self.path
            )
            if validate is not None:
                # Validate the exact protected, revision-checked file before replacement.
                validate(config)
            descriptor, temporary = tempfile.mkstemp(dir=self.path.parent, prefix=".operator-")
            try:
                with os.fdopen(descriptor, "wb") as output:
                    output.write(payload)
                    output.flush()
                    os.fsync(output.fileno())
                os.replace(temporary, self.path)
                directory = os.open(self.path.parent, os.O_RDONLY)
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
        return config
