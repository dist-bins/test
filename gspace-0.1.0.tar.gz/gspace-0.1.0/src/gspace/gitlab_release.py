"""Pinned read compatibility preserves raw version and explicit edition evidence."""

from __future__ import annotations

import re
from typing import Literal

from gspace.models import GitLabRelease


def read_release(raw: str, supported: str = "18.11.12") -> GitLabRelease:
    match = re.fullmatch(r"(\d+\.\d+\.\d+)(?:-(ce|ee))?", raw)
    if match is None or match[1] != supported:
        raise ValueError("GitLab release differs from pinned read contract")
    edition: Literal["ce", "ee", "unknown"] = (
        "ee" if match[2] == "ee" else "ce" if match[2] == "ce" else "unknown"
    )
    return GitLabRelease(raw=raw, release=match[1], edition=edition)
