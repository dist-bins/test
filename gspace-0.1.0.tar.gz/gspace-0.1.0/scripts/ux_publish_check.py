"""Prove one-job/multiple-artifact evidence using typed loopback fixture mutations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from playwright.sync_api import expect, sync_playwright
from recovery_fixture import ROOT, recovery_fixture

from gspace.models import Snapshot


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    if not output.is_relative_to(ROOT / "output/verification"):
        parser.error("Use owned verification output")
    output.mkdir(parents=True, exist_ok=False)
    checks, errors, outside = [], [], []
    with recovery_fixture() as fixture, sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        for theme, width in (("light", 1600), ("dark", 390)):
            context = browser.new_context(
                viewport={"width": width, "height": 1100 if width == 1600 else 844},
                service_workers="block",
            )
            page = context.new_page()
            page.on("pageerror", lambda error: errors.append(str(error)))

            def guard(route):
                if route.request.url.startswith(fixture.base + "/"):
                    route.continue_()
                else:
                    outside.append(route.request.url)
                    route.abort()

            context.route("**/*", guard)
            page.goto(fixture.base + "/#/work")
            expect(page.locator("main")).to_contain_text("Preserve passenger")
            page.locator('[data-fk="theme"]').click()
            page.locator(f'[data-fk="ap-th-{theme}"]').click()
            page.keyboard.press("Escape")
            # Bootstrap/settings reads have completed; then replace ONLY this
            # owned fixture's typed snapshot, never operator or remote state.
            data = fixture.service.snapshot().model_dump(mode="json")
            original = data["items"][0]["publishes"][0]
            secondary = dict(original, artifact="synthetic.flight:secondary:2.4.8")
            data["items"][0]["publishes"] = [original, secondary]
            shared = data["items"][1]
            shared["pipelines"] = data["items"][0]["pipelines"]
            shared["publishes"] = [original, secondary]
            fixture.service._snapshot = Snapshot.model_validate(data)
            api = page.request.get(fixture.base + "/api/dashboard?all=true").json()
            assert len(api["views"][0]["item"]["publishes"]) == 2
            page.goto(fixture.base + "/#/pipelines/42/9201")
            page.reload()
            drawer = page.get_by_role("complementary", name="Pipeline #9201 details")
            expect(drawer).to_be_visible()
            expect(drawer).to_contain_text(original["artifact"])
            expect(drawer).to_contain_text(secondary["artifact"])
            # Both items share evidence; only identical entries are collapsed.
            expect(drawer.get_by_text(secondary["artifact"], exact=True)).to_have_count(1)
            expect(drawer.get_by_text(original["artifact"], exact=True)).to_have_count(1)
            expect(drawer).to_contain_text("Failed")
            expect(drawer.get_by_role("listitem").filter(has_text="PublishSuccess")).to_have_count(
                2
            )
            page.screenshot(
                path=str(output / f"two-artifacts-{theme}-{width}.png"),
                animations="disabled",
            )
            checks.append({"theme": theme, "width": width, "passed": True})
            context.close()
        browser.close()
    report = {"checks": checks, "errors": errors, "outside": outside}
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))
    return int(bool(errors or outside))


if __name__ == "__main__":
    raise SystemExit(main())
