"""Fixed synthetic mobile viewport/inner-scroll supplements; never changes retained previews."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output/verification/mobile-supplements"


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    captures = []
    outside = []
    errors = []
    with fixture_server(ROOT / "src/gspace/static") as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(
            viewport={"width": 390, "height": 844}, service_workers="block", color_scheme="light"
        )

        def guard(route):
            parsed = urlsplit(route.request.url)
            if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.port != port:
                outside.append(route.request.url)
                route.abort()
            else:
                route.continue_()

        context.route("**/*", guard)
        page = context.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))

        def go(route):
            page.goto(base + "/#/" + route)
            page.reload()
            page.wait_for_load_state("networkidle")
            expect(page.locator("main")).to_be_visible()

        def capture(name):
            path = OUTPUT / (name + ".png")
            page.screenshot(path=str(path), full_page=False)
            captures.append(
                {
                    "name": name,
                    "file": path.relative_to(ROOT).as_posix(),
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "viewport": [390, 844],
                    "main_scroll": page.locator("main").evaluate("e => e.scrollTop"),
                }
            )

        def rows():
            page.get_by_label("View options: layout, fields, sort and save").click()
            page.get_by_role("button", name="Rows", exact=True).click()
            page.keyboard.press("Escape")
            expect(page.get_by_role("button", name="Rows", exact=True)).not_to_be_visible()

        go("work")
        rows()
        capture("work-rows-menu-closed")
        for issue in (791, 793):
            prefs = page.request.get(base + "/api/preferences").json()
            response = page.request.post(
                base + "/api/preferences",
                data={
                    "operation": "select",
                    "revision": prefs["revision"],
                    "key": {"project": {"value": 42}, "issue": {"value": issue}},
                    "enabled": True,
                },
            )
            assert response.status == 200
        go("compare")
        page.reload()
        page.wait_for_load_state("networkidle")
        rows()
        capture("compare-rows-menu-closed")
        go("pipelines")
        capture("pipeline-catalog-viewport")
        for name, route in [
            ("item-multiple-branches", "item/42/791"),
            ("branch-details", "branches/42/issue-791"),
            ("pipeline-failed", "pipelines/42/9201"),
            ("job-attempt", "pipelines/42/9201/job/92010"),
        ]:
            go(route)
            trigger = page.locator(".inspector button[data-ev]:visible").first
            if not trigger.count():
                trigger = page.locator("main button[data-ev]:visible").first
            trigger.click()
            pop = page.locator("#ev-pop")
            expect(pop).to_be_visible()
            expect(pop).to_have_css("opacity", "1")
            page.wait_for_function(
                "document.querySelector('#ev-pop').getAnimations().every(a=>a.playState==='finished')"
            )
            capture(name + "-evidence-settled")
            page.keyboard.press("Escape")
        go("item/42/793")
        page.locator(".lane-step").filter(
            has=page.locator(".lane-label", has_text="Preprod")
        ).first.scroll_into_view_if_needed()
        capture("item-preprod-tested-lower-process")
        latest = page.request.get(base + "/api/settings").json()
        latest["settings"]["pipeline"]["environments"].append(
            {"name": "qa", "label": "QA", "ref_source": "branch"}
        )
        latest["settings"]["project_pipeline_overrides"] = [
            {
                "project": {"value": 42},
                "important_job_patterns": ["publish-*"],
                "stages": None,
                "jobs": None,
                "environments": None,
            }
        ]
        configured = page.request.post(
            base + "/api/settings",
            data={"revision": latest["revision"], "settings": latest["settings"]},
        )
        assert configured.status == 200
        go("settings")
        page.locator("main").evaluate("e => e.scrollTop = e.scrollHeight")
        capture("settings-effective-custom-rules")
        browser.close()
    assert not outside and not errors
    report = {
        "purpose": "Fresh isolated mobile supplements; capture is separate from pixel review",
        "captures": captures,
        "js_errors": errors,
        "external_requests": outside,
    }
    (OUTPUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
