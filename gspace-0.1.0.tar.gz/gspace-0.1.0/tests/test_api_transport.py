"""Actual synthetic TLS/socket tests for explicitly selected PAT API transport."""

import json
import shutil
import socket
import ssl
import subprocess
import threading
import time
from contextlib import suppress
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest
from pydantic import ValidationError

import gspace.access as access
from gspace.access import AccessError, ProfileTransport
from gspace.access_models import PatProfile
from gspace.config import ProjectConfig
from gspace.models import PipelineId, PipelineKey, ProjectId
from gspace.pipeline_query import PIPELINE_QUERY

HOST = "gspace.api.invalid"
MARKER = "synthetic-fixture-marker-not-a-credential"


@pytest.fixture(scope="module")
def certificate(tmp_path_factory):
    executable = shutil.which("openssl")
    if executable is None:
        pytest.skip("Actual TLS fixture requires existing OpenSSL")
    directory = tmp_path_factory.mktemp("gspace-api-tls")
    cert, key = directory / "certificate.pem", directory / "synthetic-key.pem"
    subprocess.run(
        [
            executable,
            "req",
            "-x509",
            "-newkey",
            "rsa:2048",
            "-nodes",
            "-days",
            "1",
            "-keyout",
            str(key),
            "-out",
            str(cert),
            "-subj",
            "/CN=" + HOST,
            "-addext",
            "subjectAltName=DNS:" + HOST,
        ],
        check=True,
        capture_output=True,
        timeout=10,
    )
    return cert, key


@pytest.fixture
def endpoint(certificate, monkeypatch):
    cert, key = certificate
    events = []
    scenario = {"kind": "direct", "code": 302, "location": "/api/v4/projects/999/pipelines"}

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def handle_api(self):
            body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
            events.append(
                {
                    "method": self.command,
                    "path": self.path,
                    "marker": self.headers.get("PRIVATE-TOKEN") == MARKER,
                    "body": json.loads(body) if body else None,
                    "host": self.headers.get("Host"),
                }
            )
            kind = scenario["kind"]
            if kind == "redirect":
                self.send_response(scenario["code"])
                self.send_header("Location", scenario["location"])
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            payload = json.dumps(
                {"data": {"project": None}} if self.command == "POST" else {"version": "18.11.12"}
            ).encode()
            if kind == "slow_close":
                time.sleep(0.2)
            self.send_response(200)
            if kind == "compressed":
                self.send_header("Content-Encoding", "gzip")
            if kind == "large":
                payload = b" " * 1024
            extra = 100 if kind == "truncated" else 0
            self.send_header("Content-Length", str(len(payload) + extra))
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            with suppress(OSError):
                if kind == "slow_close":
                    time.sleep(0.2)
                    self.wfile.write(payload[:1])
                    self.wfile.flush()
                    time.sleep(0.6)
                    self.wfile.write(payload[1:])
                else:
                    self.wfile.write(payload)

        do_GET = handle_api
        do_POST = handle_api

        def log_message(self, _format, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(cert, key)
    names = []
    context.set_servername_callback(lambda _connection, name, _context: names.append(name))
    server.socket = context.wrap_socket(server.socket, server_side=True)
    worker = threading.Thread(
        target=server.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True
    )
    worker.start()
    original_lookup = socket.getaddrinfo
    lookups = []

    def lookup(host, port, *args, **kwargs):
        if host in (HOST, "other.api.invalid"):
            lookups.append(host)
            return original_lookup("127.0.0.1", port, *args, **kwargs)
        if host in ("127.0.0.1", "::1"):
            return original_lookup(host, port, *args, **kwargs)
        lookups.append(host)
        raise socket.gaierror("Unexpected synthetic lookup")

    monkeypatch.setattr(socket, "getaddrinfo", lookup)
    original_context = ssl.create_default_context
    monkeypatch.setattr(ssl, "create_default_context", lambda: original_context(cafile=str(cert)))
    profile = PatProfile(
        name="synthetic",
        host=f"https://{HOST}:{server.server_port}",
        projects=(ProjectId(value=42),),
        secret_env="GSPACE_SYNTHETIC_UNUSED",
        allowed_networks=("127.0.0.1/32",),
    )
    try:
        yield profile, scenario, events, lookups, names
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=2)


def transport(profile):
    return ProfileTransport(profile, resolver=lambda _: MARKER)


def test_actual_tls_host_sni_fixed_query_and_no_environment_proxy(endpoint, monkeypatch):
    profile, _scenario, events, lookups, names = endpoint
    monkeypatch.setenv("HTTPS_PROXY", "http://proxy.invalid:1")
    client = transport(profile)
    assert client.request("GET", "version") == {"version": "18.11.12"}
    key = PipelineKey(project=ProjectId(value=42), pipeline=PipelineId(value=9201))
    project = ProjectConfig(id=ProjectId(value=42), path="demo/application")
    assert client.pipeline_graphql(project, key, None) == {"data": {"project": None}}
    assert events[1]["path"] == "/api/graphql"
    assert events[1]["body"]["query"] == PIPELINE_QUERY
    assert events[0]["host"] == profile.host.removeprefix("https://")
    assert all(event["marker"] for event in events)
    assert lookups == [HOST, HOST] and names == [HOST, HOST]


@pytest.mark.parametrize("code", [301, 302, 303, 307, 308])
@pytest.mark.parametrize("method", ["GET", "POST"])
@pytest.mark.parametrize(
    "location",
    [
        "/api/v4/projects/999/pipelines",
        "https://foreign.invalid/api/v4/version",
        "https://" + HOST + ":1/api/v4/version",
        "http://127.0.0.1:1/api/v4/version",
    ],
)
def test_redirect_rejected_before_second_request_or_lookup(endpoint, code, method, location):
    profile, scenario, events, lookups, _names = endpoint
    scenario.update(kind="redirect", code=code, location=location)
    client = transport(profile)
    with pytest.raises(AccessError) as error:
        if method == "POST":
            client.pipeline_graphql(
                ProjectConfig(id=ProjectId(value=42), path="demo/application"),
                PipelineKey(project=ProjectId(value=42), pipeline=PipelineId(value=9201)),
                None,
            )
        else:
            client.request("GET", "version")
    assert error.value.code == "remote" and MARKER not in str(error.value)
    assert len(events) == 1 and lookups == [HOST]


@pytest.mark.parametrize(
    "kind,code", [("compressed", "limit"), ("large", "limit"), ("truncated", "transport")]
)
def test_actual_response_boundaries(endpoint, monkeypatch, kind, code):
    profile, scenario, _events, _lookups, _names = endpoint
    scenario["kind"] = kind
    monkeypatch.setattr(access, "_ApiPolicy", partial(access._ApiPolicy, max_bytes=128))
    with pytest.raises(AccessError) as error:
        transport(profile).request("GET", "version")
    assert error.value.code == code


def test_total_deadline_covers_detached_connection_close_socket(endpoint, monkeypatch):
    profile, scenario, _events, _lookups, _names = endpoint
    scenario["kind"] = "slow_close"
    monkeypatch.setattr(access, "_ApiPolicy", partial(access._ApiPolicy, timeout_seconds=0.5))
    start = time.monotonic()
    with pytest.raises(AccessError):
        transport(profile).request("GET", "version")
    assert time.monotonic() - start < 0.75


def test_dns_rebinding_to_private_address_rejected_before_connect(endpoint):
    profile, _scenario, events, _lookups, names = endpoint
    restricted = profile.model_copy(update={"allowed_networks": ()})
    with pytest.raises(AccessError) as error:
        transport(restricted).request("GET", "version")
    assert error.value.code == "scope" and not events and not names


def test_valid_test_ca_still_requires_hostname_match(endpoint):
    profile, _scenario, events, _lookups, _names = endpoint
    wrong = profile.model_copy(update={"host": profile.host.replace(HOST, "other.api.invalid")})
    with pytest.raises(AccessError) as error:
        transport(wrong).request("GET", "version")
    assert error.value.code == "transport" and not events


def test_secret_resolver_exception_is_redacted_before_transport():
    profile = PatProfile(
        name="bad",
        host="https://example.invalid",
        projects=(ProjectId(value=42),),
        secret_env="GSPACE_SYNTHETIC_UNUSED",
    )

    def broken(_name):
        raise RuntimeError("synthetic resolver detail " + MARKER)

    with pytest.raises(AccessError) as error:
        ProfileTransport(profile, resolver=broken).request("GET", "version")
    assert error.value.code == "missing_secret" and MARKER not in str(error.value)


def test_profile_rejects_noncanonical_cidr():
    with pytest.raises(ValidationError):
        PatProfile(
            name="bad",
            host="https://example.invalid",
            projects=(ProjectId(value=42),),
            secret_env="GSPACE_SYNTHETIC_UNUSED",
            allowed_networks=("127.0.0.1/24",),
        )
