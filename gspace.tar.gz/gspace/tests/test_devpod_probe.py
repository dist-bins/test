"""Synthetic evidence for the no-config operator diagnostic entry point."""

from __future__ import annotations

import io
import json
from pathlib import Path
from urllib.parse import unquote

import pytest

from gspace.glab import AdapterError, RunResult
from gspace.pipeline_query import PIPELINE_QUERY
from scripts.devpod_probe import MAX_REQUESTS, NativeRunner, execute, main


class Terminal(io.StringIO):
    def isatty(self) -> bool:
        return True


class FakeNative:
    def __init__(self, *, samples: bool = False) -> None:
        self.calls: list[tuple[list[str], float]] = []
        self.responses: dict[str, tuple[int, object]] = {
            "version": (200, {"version": "18.11.12-ee", "revision": "private-revision"}),
            "metadata": (200, {"version": "18.11.12-ee", "enterprise": True}),
            "user": (200, {"id": 9, "username": "private-user", "token": "glpat-SECRET"}),
            "projects/42": (200, {"id": 42, "path_with_namespace": "team/project"}),
            "projects/team%2Fproject": (200, {"id": 42, "path_with_namespace": "team/project"}),
            "graphql": (
                200,
                {
                    "data": {
                        "project": {
                            "id": "gid://gitlab/Project/42",
                            "fullPath": "team/project",
                            "pipeline": {"id": "gid://gitlab/Ci::Pipeline/7"},
                        }
                    }
                },
            ),
        }
        if samples:
            self.responses["projects/42/issues"] = (200, [{"iid": 3, "title": "secret-title"}])
            self.responses["projects/42/pipelines"] = (200, [{"id": 7, "sha": "private-sha"}])

    def __call__(self, argv: list[str], timeout: float) -> RunResult:
        self.calls.append((argv, timeout))
        target = argv[argv.index("--method") + 2].split("?")[0]
        status, payload = self.responses.get(target, (200, []))
        raw = f"HTTP/2.0 {status} status\r\nPrivate-Token: glpat-HEADERSECRET\r\n\r\n" + json.dumps(
            payload
        )
        return RunResult(code=0 if status == 200 else 1, stdout=raw.encode())


@pytest.fixture(autouse=True)
def synthetic_launcher(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("gspace.access.shutil.which", lambda _: "/synthetic/glab")


def checks(report: dict[str, object]) -> dict[str, dict[str, object]]:
    return {row["capability"]: row for row in report["checks"]}


def test_no_config_command_prompts_for_real_scope() -> None:
    answers = iter(["https://gitlab.example.org", "team/project"])
    prompts: list[str] = []

    def answer(prompt: str) -> str:
        prompts.append(prompt)
        return next(answers)

    output = io.StringIO()
    fake = FakeNative()
    assert main([], stdin=Terminal(), stdout=output, input_fn=answer, runner=fake) == 0
    assert len(prompts) == 2
    assert "GitLab 18.11.12-ee (EE)" in output.getvalue()
    assert "project_id': 42" in output.getvalue()
    assert "Write permission: not tested" in output.getvalue()
    first = fake.calls[0][0]
    assert first[first.index("--method") + 2] == "projects/team%2Fproject"


@pytest.mark.parametrize(
    ("host", "project"),
    [
        ("http://gitlab.example.org", "42"),
        ("https://user:glpat-SECRET@gitlab.example.org", "42"),
        ("https://gitlab.example.org/api/v4", "42"),
        ("https://gitlab.example.org?token=secret", "42"),
        ("https://gitlab.example.org#secret", "42"),
        ("https://gitlab.example.org:99999", "42"),
        ("https://gitlab.example.org:", "42"),
        ("https://gitlab.example.org", "../project"),
        ("https://gitlab.example.org", "team/project?token=secret"),
        ("https://gitlab.example.org", "team/%2e%2e/project"),
        ("https://gitlab.example.org", "0"),
    ],
)
def test_arguments_rejected_before_native_request(host: str, project: str) -> None:
    fake = FakeNative()
    with pytest.raises(SystemExit) as error:
        main(["-H", host, "-p", project], runner=fake)
    assert error.value.code == 2
    assert not fake.calls


def test_noninteractive_missing_scope_is_actionable_without_request(
    capsys: pytest.CaptureFixture[str],
) -> None:
    fake = FakeNative()
    with pytest.raises(SystemExit):
        main([], stdin=io.StringIO(), runner=fake)
    assert "--host and --project" in capsys.readouterr().err
    assert not fake.calls


def test_forbidden_endpoint_does_not_suppress_other_reads_or_leak_secrets() -> None:
    fake = FakeNative()
    fake.responses["projects/42/issues"] = (403, {"message": "glpat-BODYSECRET"})
    report = execute("https://gitlab.example.org", 42, runner=fake)
    rows = checks(report)
    assert rows["issues"]["status"] == "unavailable"
    assert rows["issues"]["reason"] == "access_denied"
    assert rows["issues"]["http_status"] == 403
    assert rows["branches"]["status"] == "readable"
    encoded = json.dumps(report)
    for value in ("glpat-", "secret-title", "private-sha", "private-user", "private-revision"):
        assert value not in encoded
    assert report["write_permission"] == "not_tested"


def test_missing_samples_are_explicit_and_do_not_send_related_requests() -> None:
    fake = FakeNative()
    report = execute("https://gitlab.example.org", 42, runner=fake)
    rows = checks(report)
    for name in ("jobs", "related_merge_requests", "native_pipeline_graphql"):
        assert rows[name]["status"] == "not_tested"
        assert rows[name]["reason"] == "not_tested_no_resource"
    assert report["requests"] == 11
    assert all("graphql" not in argv for argv, _ in fake.calls)


def test_sample_reads_are_bounded_and_graphql_is_the_canonical_read() -> None:
    fake = FakeNative(samples=True)
    report = execute("https://gitlab.example.org", "team/project", runner=fake)
    assert report["requests"] == MAX_REQUESTS
    assert checks(report)["native_pipeline_graphql"]["status"] == "readable"
    for argv, timeout in fake.calls:
        assert 0 < timeout <= 10
        assert "--include" in argv
        assert "--paginate" not in argv
        method_index = argv.index("--method")
        method, target = argv[method_index + 1 : method_index + 3]
        if method == "POST":
            assert target == "graphql"
            assert f"query={PIPELINE_QUERY}" in argv
            assert "mutation" not in PIPELINE_QUERY
            assert "first=25" in argv
            assert "projectPath=team/project" in argv
        else:
            assert method == "GET"
            assert unquote(target).startswith(("projects/", "user", "version", "metadata"))
            if target.endswith(("issues", "pipelines", "branches", "tags")):
                pytest.fail("Collection reads must include a bounded query")


def test_project_resolution_failure_stops_before_numeric_scope() -> None:
    fake = FakeNative()
    fake.responses["projects/team%2Fproject"] = (403, {"message": "secret"})
    report = execute("https://gitlab.example.org", "team/project", runner=fake)
    assert report["requests"] == 1
    assert checks(report)["project_resolution"]["reason"] == "access_denied"
    assert report["identity"]["project_id"] is None


def test_project_resolution_identity_must_match_selected_path() -> None:
    fake = FakeNative()
    fake.responses["projects/team%2Fproject"] = (
        200,
        {"id": 42, "path_with_namespace": "other/project"},
    )
    report = execute("https://gitlab.example.org", "team/project", runner=fake)
    assert report["requests"] == 1
    assert checks(report)["project_resolution"]["status"] == "unknown"


def test_native_budget_does_not_send_extra_request() -> None:
    fake = FakeNative()
    native = NativeRunner(fake)
    native.requests = MAX_REQUESTS
    with pytest.raises(AdapterError, match="budget"):
        native(["glab", "api", "--method", "GET", "version"], 10)
    assert not fake.calls


def test_timeout_error_text_is_not_in_report() -> None:
    def unavailable(argv: list[str], timeout: float) -> RunResult:
        raise AdapterError("timeout", "glpat-SECRET https://private.example.org/raw/body")

    report = execute("https://gitlab.example.org", 42, runner=unavailable)
    assert checks(report)["version"]["reason"] == "request_timeout"
    assert "glpat" not in json.dumps(report)


def test_json_output_file_preserves_existing_file(tmp_path: Path) -> None:
    output_path = tmp_path / "probe.json"
    output = io.StringIO()
    args = ["-H", "https://gitlab.example.org", "-p", "42", "-j", "-o", str(output_path)]
    assert main(args, stdout=output, runner=FakeNative()) == 0
    assert json.loads(output.getvalue()) == json.loads(output_path.read_text())
    output_path.write_text("original user data")
    second = FakeNative()
    with pytest.raises(SystemExit):
        main(args, stdout=io.StringIO(), runner=second)
    assert output_path.read_text() == "original user data"
    assert not second.calls


def test_graphql_error_is_unknown_with_no_raw_error() -> None:
    fake = FakeNative(samples=True)
    fake.responses["graphql"] = (200, {"errors": [{"message": "glpat-SECRET"}]})
    report = execute("https://gitlab.example.org", 42, runner=fake)
    assert checks(report)["native_pipeline_graphql"]["status"] == "unknown"
    assert "glpat" not in json.dumps(report)


def test_graphql_pipeline_identity_must_match_selected_project() -> None:
    fake = FakeNative(samples=True)
    fake.responses["graphql"] = (
        200,
        {
            "data": {
                "project": {
                    "id": "gid://gitlab/Project/43",
                    "fullPath": "other/project",
                    "pipeline": {"id": "gid://gitlab/Ci::Pipeline/7"},
                }
            }
        },
    )
    report = execute("https://gitlab.example.org", 42, runner=fake)
    assert checks(report)["native_pipeline_graphql"]["reason"] == "graph_identity_mismatch"


def test_help_needs_no_gitlab_request(capsys: pytest.CaptureFixture[str]) -> None:
    fake = FakeNative()
    with pytest.raises(SystemExit) as error:
        main(["--help"], runner=fake)
    assert error.value.code == 0
    assert "No GSpace config" in capsys.readouterr().out
    assert not fake.calls
