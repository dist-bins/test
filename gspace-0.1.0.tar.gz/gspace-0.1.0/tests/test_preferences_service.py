import multiprocessing
from pathlib import Path

import pytest

from gspace.models import (
    IssueIid,
    Job,
    JobId,
    Observed,
    ProjectId,
    Status,
    Version,
    WorkItem,
    WorkKey,
)
from gspace.preferences import (
    Filters,
    PreferenceConflict,
    Preferences,
    PreferenceStore,
    StoredPreferences,
)
from gspace.service import ChecklistChange, FlagChange, GroupChange


def append_pin(path: str, number: int) -> None:
    store = PreferenceStore(Path(path))
    key = WorkKey(project=ProjectId(value=42), issue=IssueIid(value=number))

    def transform(old):
        data = old.model_dump()
        data["pinned"] = old.pinned + (key,)
        return StoredPreferences.model_validate(data)

    store.update(transform)


def test_multiprocess_updates_do_not_lose_preferences(tmp_path):
    context = multiprocessing.get_context("spawn")
    path = tmp_path / "preferences.toml"
    workers = [context.Process(target=append_pin, args=(str(path), n)) for n in range(1, 9)]
    for worker in workers:
        worker.start()
    for worker in workers:
        worker.join(timeout=15)
        assert worker.exitcode == 0
    prefs = PreferenceStore(path).read()
    assert prefs.revision == 8
    assert {key.issue.value for key in prefs.pinned} == set(range(1, 9))
    assert not list(tmp_path.glob(".prefs-*"))
    assert path.stat().st_mode & 0o077 == 0


def test_stale_revision_conflict_and_invalid_toml_preserved(tmp_path):
    store = PreferenceStore(tmp_path / "preferences.toml")
    store.update(lambda old: old, 0)
    with pytest.raises(PreferenceConflict):
        store.update(lambda old: old, 0)
    original = store.path.read_bytes()
    assert store.read().revision == 1
    with pytest.raises(ValueError):
        store.update(lambda _: Preferences.model_validate({"token": "not allowed"}), 1)
    assert store.path.read_bytes() == original


def test_default_filter_is_four_active_assigned_items(service):
    dashboard = service.dashboard()
    assert len(dashboard.views) == 4
    assert all(v.item.assigned_to_me and v.item.state == "opened" for v in dashboard.views)
    assert len(service.dashboard(Filters(state="all", assigned=False)).views) == 7


def test_shared_pin_hide_selection_and_group(service, key):
    for change in [
        FlagChange(revision=0, operation="pin", key=key, enabled=True),
        FlagChange(revision=1, operation="select", key=key, enabled=True),
        GroupChange(revision=2, key=key, group="Release", enabled=True),
    ]:
        service.change(change)
    assert service.dashboard(selected_only=True).views[0].item.identity == key
    assert len(service.dashboard(Filters(group="Release")).views) == 1
    service.change(FlagChange(revision=3, operation="hide", key=key, enabled=True))
    assert key not in [v.item.identity for v in service.dashboard().views]
    assert service.dashboard(Filters(show_hidden=True)).views[0].hidden


def test_checklist_completion_never_changes_remote_draft(service, key):
    original = service.item(key)
    for index, field in enumerate(("local_test", "dev_test", "preprod_test", "work_confirmed")):
        service.change(
            ChecklistChange(revision=index, key=key, checklist_field=field, enabled=True)
        )
    assert service.view(original, service.preferences.read()).checklist.complete
    assert service.item(key) == original
    assert original.merge_requests[0].draft
    preview = service.preview(key, "ready")
    assert preview.executed is False
    assert preview.remote_mutation_available is False


def test_pipeline_failure_is_independent_from_deploy_and_test(service, key):
    item = service.item(key)
    assert item.pipelines[0].status == Status.FAILED
    assert item.publishes[0].status == Status.SUCCESS
    assert item.environments[0].deployments[0].status == Status.SUCCESS
    assert item.environments[0].application_test == "unconfirmed"


def test_successful_preprod_deploy_with_two_failed_post_jobs_keeps_four_evidences(service, key):
    original = service.item(key)
    pipeline = original.pipelines[-1]
    template = pipeline.jobs[0]
    jobs = tuple(
        Job.model_validate(
            {
                **template.model_dump(),
                "id": JobId(value=88000 + index),
                "name": name,
                "stage": "deploy" if index == 0 else "post",
                "status": Status.SUCCESS if index == 0 else Status.FAILED,
                "failure_reason": None if index == 0 else "script_failure",
            }
        )
        for index, name in enumerate(("deploy-preprod", "post-audit", "post-report"))
    )
    failed = pipeline.model_copy(update={"status": Status.FAILED, "jobs": jobs})
    expected = Version(tag=pipeline.ref, sha=pipeline.sha)
    record = (
        original.environments[0]
        .deployments[0]
        .model_copy(update={"status": Status.SUCCESS, "ref": pipeline.ref, "sha": pipeline.sha})
    )
    preprod = original.environments[-1].model_copy(
        update={
            "expected": expected,
            "observation": Observed(
                value=expected,
                source="Synthetic configured Swagger version evidence",
                checked_at=service.snapshot().fetched_at,
            ),
            "deployments": (record,),
        }
    )
    item = WorkItem.model_validate(
        {
            **original.model_dump(),
            "pipelines": (*original.pipelines[:-1], failed),
            "environments": (*original.environments[:-1], preprod),
        }
    )
    view = service.view(item, service.preferences.read())
    assert view.item.pipelines[-1].status == Status.FAILED
    assert [job.status for job in view.item.pipelines[-1].jobs] == [
        Status.SUCCESS,
        Status.FAILED,
        Status.FAILED,
    ]
    assert view.item.environments[-1].deployments[0].status == Status.SUCCESS
    assert view.comparisons[-1].result.value == "match"
    assert view.application_tests[-1].outcome == "not_tested"
    assert view.item.environments[-1].application_test == "unconfirmed"
    assert [job.role for job in view.job_configuration if job.pipeline == pipeline.id] == [
        "deploy",
        "normal",
        "normal",
    ]
    assert view.item.pipelines[-1].jobs[1].failure_reason == "script_failure"


def test_preview_never_writes_preferences_or_remote_cache(service, key):
    for action in ("tag", "deploy-dev", "deploy-preprod", "rebase", "retry", "ready", "merge"):
        assert service.preview(key, action).executed is False
    assert service.preview(key, "tag").suggestion == "flight-2.4.09"
    assert not service.config.cache_path.exists()
    assert not service.config.preferences_path.exists()


def test_unknown_endpoint_is_not_fetched(service, key):
    called = False

    def forbidden(endpoint):
        nonlocal called
        called = True
        raise AssertionError("not configured")

    with pytest.raises(ValueError, match="No endpoint configured"):
        service.observe_environment(key, "dev", observer=forbidden)
    assert not called


def test_cache_is_atomic_separate_and_bound_to_operator_configuration(tmp_path):
    from gspace.config import AppConfig, LiveConfig, ProjectConfig
    from gspace.fixture import synthetic_snapshot
    from gspace.models import Snapshot
    from gspace.service import Service

    live = LiveConfig(
        hostname="gitlab.example.invalid",
        web_origin="https://gitlab.example.invalid",
        projects=(ProjectConfig(id=ProjectId(value=42), path="demo/flight"),),
    )
    cfg = AppConfig(
        mode="live",
        live=live,
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
    )
    data = synthetic_snapshot().model_dump()
    data["source"] = "glab"
    snapshot = Snapshot.model_validate(data)
    service = Service(cfg)
    service._write_cache(snapshot)
    assert not cfg.preferences_path.exists()
    assert Service(cfg).dashboard().cache_state == "cached"
    changed = cfg.model_dump()
    changed["branch_template"] = "ticket-{iid}"
    with pytest.raises(ValueError, match="Cache configuration differs"):
        Service(AppConfig.model_validate(changed)).snapshot()


def test_invalid_live_cache_is_rejected_on_every_read(tmp_path):
    from gspace.config import AppConfig, LiveConfig, ProjectConfig
    from gspace.fixture import synthetic_snapshot
    from gspace.service import Service

    cfg = AppConfig(
        mode="live",
        live=LiveConfig(
            hostname="gitlab.example.invalid",
            web_origin="https://gitlab.example.invalid",
            projects=(ProjectConfig(id=ProjectId(value=42), path="demo/flight"),),
        ),
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
    )
    service = Service(cfg)
    service._write_cache(synthetic_snapshot())
    original = cfg.cache_path.read_bytes()
    for _ in range(2):
        with pytest.raises(ValueError, match="Live cache must come from glab"):
            service.snapshot()
    assert service._snapshot is None
    assert cfg.cache_path.read_bytes() == original


@pytest.mark.parametrize("operation", ["refresh", "observe"])
def test_failed_cache_write_keeps_previous_snapshot_and_cache_state(
    tmp_path, monkeypatch, operation
):
    from gspace.config import (
        AppConfig,
        Endpoint,
        JsonExtraction,
        JsonField,
        LiveConfig,
        ProjectConfig,
    )
    from gspace.fixture import synthetic_snapshot
    from gspace.models import EnvironmentName, Snapshot, Unknown
    from gspace.service import Service

    cfg = AppConfig(
        mode="live",
        live=LiveConfig(
            hostname="gitlab.example.invalid",
            web_origin="https://gitlab.example.invalid",
            projects=(ProjectConfig(id=ProjectId(value=42), path="demo/flight"),),
        ),
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
        endpoints=(
            Endpoint(
                name=EnvironmentName.DEV,
                key=WorkKey(project=ProjectId(value=42), issue=IssueIid(value=791)),
                url="https://swagger.example.invalid/openapi.json",
                allowed_origins=("https://swagger.example.invalid",),
                extraction=JsonExtraction(
                    fields=(JsonField(field="version", path="info.version"),)
                ),
            ),
        ),
    )
    data = synthetic_snapshot().model_dump()
    data["source"] = "glab"
    snapshot = Snapshot.model_validate(data)
    service = Service(cfg)
    service._write_cache(snapshot)
    assert service.dashboard().cache_state == "cached"
    original = cfg.cache_path.read_bytes()

    class Adapter:
        def snapshot(self, config, preferences):
            changed = snapshot.model_dump()
            changed["warnings"] = ("New snapshot",)
            return Snapshot.model_validate(changed)

    def fail_write(candidate):
        raise OSError("Synthetic cache write failure")

    service.adapter = Adapter()
    monkeypatch.setattr(service, "_write_cache", fail_write)
    with pytest.raises(OSError, match="Synthetic cache write failure"):
        if operation == "refresh":
            service.refresh()
        else:
            service.observe_environment(
                cfg.endpoints[0].key,
                EnvironmentName.DEV,
                observer=lambda _: Unknown(reason="New observation"),
            )
    assert service.snapshot() == snapshot
    assert service.dashboard().cache_state == "cached"
    assert cfg.cache_path.read_bytes() == original
