"""Manual outcome history with exact identity and supersession kept separate."""

from __future__ import annotations

from typing import Literal, Self

from pydantic import AwareDatetime, model_validator

from gspace.models import ApplicationTestRecord, EnvironmentLabel, Model, Version, WorkKey


def matches_version(record: ApplicationTestRecord, target: Version | None) -> bool:
    if target is None:
        return False
    if target.sha is not None:
        return record.version.sha == target.sha and (
            target.version is None
            or record.version.version is None
            or target.version == record.version.version
        )
    return target.version is not None and record.version.version == target.version


class TestHistoryEntry(Model, frozen=True):
    record: ApplicationTestRecord
    target: Version | None
    state: Literal["current", "superseded", "stale", "unknown"]


class ApplicationTestHistory(Model, frozen=True):
    key: WorkKey
    environment: EnvironmentLabel | None
    timezone: str
    checked_at: AwareDatetime
    entries: tuple[TestHistoryEntry, ...]

    @model_validator(mode="after")
    def scoped(self) -> Self:
        if any(
            e.record.key != self.key
            or (self.environment is not None and e.record.environment != self.environment)
            for e in self.entries
        ):
            raise ValueError("Manual test history exceeds work item/environment scope")
        return self
