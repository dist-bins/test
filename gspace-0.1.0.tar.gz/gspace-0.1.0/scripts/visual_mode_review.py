"""Additional visual mode acceptance on a fresh isolated fixture; retained previews untouched."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    parser.add_argument("--output", type=Path, default=ROOT / "output/verification/visual-mode")
    args = parser.parse_args()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    checks = []
    captures = []
    outside = []
    errors = []
    requests = []
    with fixture_server(args.assets.resolve()) as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(
            viewport={"width": 1600, "height": 1100}, service_workers="block"
        )

        def guard(route):
            u = urlsplit(route.request.url)
            if u.scheme == "http" and u.hostname == "127.0.0.1" and u.port == port:
                requests.append({"path": u.path, "method": route.request.method})
                route.continue_()
            else:
                outside.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.set_default_timeout(4000)
        page.on("pageerror", lambda e: errors.append(str(e)))

        def go(path):
            page.goto(base + "/#/" + path)
            page.wait_for_load_state("networkidle")
            expect(page.locator("main")).to_be_visible()

        def check(name, operation):
            try:
                operation()
                checks.append({"name": name, "passed": True})
            except Exception as e:
                checks.append({"name": name, "passed": False, "error": str(e)[:1000]})
                page.keyboard.press("Escape")
                page.keyboard.press("Escape")

        def shot(name):
            image = args.output / (name + ".png")
            page.screenshot(path=str(image), full_page=False)
            captures.append(
                {
                    "name": name,
                    "file": image.relative_to(ROOT).as_posix(),
                    "sha256": hashlib.sha256(image.read_bytes()).hexdigest(),
                    "viewport": page.viewport_size,
                    "theme": page.locator("html").get_attribute("data-theme"),
                }
            )

        def change(payload):
            payload["revision"] = page.request.get(base + "/api/preferences").json()["revision"]
            response = page.request.post(base + "/api/preferences", data=payload)
            assert response.status == 200

        # Each comparison key is project scoped; identical issue numbers are not merged.
        for issue in (791, 792, 793, 794):
            change(
                {
                    "operation": "select",
                    "key": {"project": {"value": 42}, "issue": {"value": issue}},
                    "enabled": True,
                }
            )
        reference = {
            "kind": "work_item",
            "key": {"project": {"value": 42}, "issue": {"value": 791}},
        }
        change(
            {
                "operation": "bookmark_set",
                "bookmark": {"host": "fixture", "reference": reference, "label": "Flight focus"},
            }
        )
        decoration = {
            "target": {"kind": "bookmark", "host": "fixture", "reference": reference},
            "icon": "rocket",
            "color": "teal",
            "pinned": True,
            "order": 4,
        }
        change({"operation": "navigation_decoration_set", "decoration": decoration})
        change(
            {
                "operation": "saved_view_set",
                "view": {
                    "host": "fixture",
                    "name": "Morning",
                    "scope": "work_items",
                    "projects": [{"value": 42}],
                    "orientation": "columns",
                },
            }
        )
        settings = page.request.get(base + "/api/settings").json()
        settings["settings"]["pipeline"]["environments"].append(
            {"name": "qa", "label": "QA", "ref_source": "branch"}
        )
        assert (
            page.request.post(
                base + "/api/settings",
                data={"revision": settings["revision"], "settings": settings["settings"]},
            ).status
            == 200
        )
        go("work")

        def mode_switch():
            page.locator('[data-fk="mode-visual"]').click()
            expect(page.locator('[data-fk="mode-visual"]')).to_have_attribute(
                "aria-pressed", "true"
            )
            page.reload()
            expect(page.locator('[data-fk="mode-visual"]')).to_have_attribute(
                "aria-pressed", "true"
            )
            assert len(page.request.get(base + "/api/preferences").json()["selected"]) == 4
            page.locator('[data-fk="mode-detailed"]').click()
            expect(page.locator("main table").first).to_be_visible()
            page.locator('[data-fk="mode-visual"]').click()

        check(
            "visual/detailed switch persists appearance and preserves shared selection", mode_switch
        )

        def navigation_roundtrip():
            go("bookmarks")
            page.get_by_role(
                "button", name="Style Flight focus: icon, colour and top-bar shortcut", exact=True
            ).click()
            dialog = page.get_by_role("dialog")
            dialog.get_by_role("radio", name="calendar", exact=True).check()
            dialog.get_by_role("radio", name="Purple", exact=True).check()
            dialog.locator('[data-fk="deco-pin"]').check()
            dialog.locator('[data-fk="deco-order"]').fill("0")
            with page.expect_response(base + "/api/preferences") as saved:
                dialog.get_by_role("button", name="Save style", exact=True).click()
            assert saved.value.status == 200
            expect(dialog).not_to_be_visible()
            actual = page.request.get(base + "/api/navigation").json()["decorations"][0]
            assert (actual["icon"], actual["color"], actual["pinned"], actual["order"]) == (
                "calendar",
                "purple",
                True,
                0,
            )
            page.reload()
            shortcut = page.get_by_role("navigation", name="Pinned shortcuts")
            expect(shortcut.get_by_role("link", name="Flight focus")).to_be_visible()
            shortcut.get_by_role("link", name="Flight focus").click()
            expect(page.locator("main")).to_contain_text("Preserve passenger")

        check("curated icon/color/pin/order UI persists and navigates", navigation_roundtrip)

        def configured_environment():
            go("work")
            expect(page.locator("main")).to_contain_text("QA")
            page.locator('[data-fk="mode-detailed"]').click()
            expect(page.locator("main")).to_contain_text("QA")
            page.locator('[data-fk="mode-visual"]').click()

        check("configured QA appears in visual and detailed environments", configured_environment)

        def native_graph():
            go("item/42/791")
            expect(
                page.get_by_role("list", name="Pipelines by trigger depth, upstream first")
            ).to_be_visible()
            expect(
                page.get_by_label("Pipeline demo/flight-service #9201", exact=True)
            ).to_be_visible()
            expect(
                page.get_by_label("Pipeline demo/ground-service #97792", exact=True)
            ).to_be_visible()
            expect(page.locator("main")).to_contain_text("application SHA")
            expect(page.locator("main")).to_contain_text("config/deploy SHA")
            page.locator(".pgraph").scroll_into_view_if_needed()
            shot("native-graph-desktop")

        check("native scoped graph retains separate application and config identity", native_graph)
        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            page.set_viewport_size({"width": width, "height": 1100 if width > 500 else 844})
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            page.reload()
            for name, path in [
                ("work", "work"),
                ("compare-four", "compare"),
                ("pipelines", "pipelines"),
                ("milestones", "milestones"),
                ("mrs", "mrs"),
                ("branches", "branches"),
                ("bookmarks", "bookmarks"),
                ("views", "views"),
                ("item", "item/42/791"),
            ]:

                def displayed(path=path, name=name, theme=theme, width=width):
                    go(path)
                    assert page.locator("html").get_attribute("data-theme") == theme
                    assert not page.locator("main").inner_text().startswith("Unable to load")
                    shot(f"{name}-{theme}-{width}")

                check(f"visual {name} {theme} {width}", displayed)
        browser.close()
    failed = sum(not c["passed"] for c in checks) + len(outside) + len(errors)
    report = {
        "purpose": __doc__,
        "checks": checks,
        "captures": captures,
        "requests": requests,
        "outside": outside,
        "js_errors": errors,
        "failed": failed,
        "pixel_review": "pending; captures are not inspection",
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {"checks": len(checks), "failed": failed, "report": str(args.output / "report.json")}
        )
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
