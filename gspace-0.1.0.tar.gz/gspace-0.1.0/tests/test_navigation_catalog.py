import json
import subprocess
import sys
import tomllib
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from gspace.api import create_app
from gspace.catalog import fetch_catalog, fixture_catalog
from gspace.config import AppConfig, LiveConfig, ProjectConfig
from gspace.fixture import synthetic_snapshot
from gspace.glab import AdapterError, GlabAdapter, RunResult
from gspace.models import ProjectId
from gspace.navigation import Bookmark, MrReference, SavedView, ViewFilters
from gspace.preferences import PreferenceConflict, PreferenceStore
from gspace.service import BookmarkSet, SavedViewSet, Service
from scripts.claude_monitor import public_events


def view(**kwargs):
    return SavedView(name="Release review", host="fixture", scope="work_items", **kwargs)


def test_saved_view_scope_model_rejects_impossible_shapes():
    for values in (
        {"projects": ({"value": 42}, {"value": 42})},
        {"columns": ()},
        {"columns": ("identity", "identity")},
        {"orientation": "sideways"},
        {"filters": {"state": "success"}},
        {"sort": "updated_at"},
    ):
        with pytest.raises(ValidationError):
            view(**values)
    with pytest.raises(ValidationError):
        SavedView(name="MRs", host="fixture", scope="mrs", filters=ViewFilters(authored=False))


def test_shared_navigation_roundtrip_and_revision_conflict(service, config):
    saved = view(
        projects=(ProjectId(value=42),),
        orientation="columns",
        columns=("identity", "mr", "dev"),
        sort="title",
        descending=True,
    )
    first = service.change(SavedViewSet(revision=0, view=saved))
    bookmark = Bookmark(
        host="fixture",
        label="Historical MR",
        reference=MrReference(project=ProjectId(value=42), iid={"value": 341}),
    )
    service.change(BookmarkSet(revision=first.revision, bookmark=bookmark))
    restored = Service(config)
    prefs = restored.preferences.read()
    assert prefs.saved_views == (saved,)
    assert prefs.bookmarks == (bookmark,)
    assert tomllib.loads(config.preferences_path.read_text())["instance_origin"] == "fixture"
    result = restored.dashboard(saved_view=saved.name)
    assert result.orientation == "columns" and result.columns == saved.columns
    assert all(v.item.identity.project.value == 42 for v in result.views)
    assert [v.item.title for v in result.views] == sorted(
        [v.item.title for v in result.views], key=str.casefold, reverse=True
    )
    with pytest.raises(PreferenceConflict):
        restored.change(SavedViewSet(revision=0, view=saved))


@pytest.mark.parametrize("host,project", [("https://other.invalid", 42), ("fixture", 777)])
def test_navigation_cannot_exceed_instance_or_project_scope(service, host, project):
    saved = SavedView(
        name="Bad scope", host=host, scope="work_items", projects=(ProjectId(value=project),)
    )
    with pytest.raises(ValueError):
        service.change(SavedViewSet(revision=0, view=saved))
    bookmark = Bookmark(
        host=host,
        label="Wrong scope",
        reference=MrReference(project=ProjectId(value=project), iid={"value": 341}),
    )
    with pytest.raises(ValueError):
        service.change(BookmarkSet(revision=0, bookmark=bookmark))
    assert not service.config.preferences_path.exists()


def test_preference_file_cannot_be_reused_by_another_instance(tmp_path):
    path = tmp_path / "prefs.toml"
    store = PreferenceStore(path, instance_origin="https://one.invalid")
    store.update(lambda old: old)
    with pytest.raises(ValueError, match="another GitLab instance"):
        PreferenceStore(path, instance_origin="https://two.invalid").read()
    unscoped = tmp_path / "legacy.toml"
    unscoped.write_text("revision = 1\n")
    with pytest.raises(ValueError, match="no instance scope"):
        PreferenceStore(unscoped, instance_origin="https://one.invalid").read()


def test_fixture_with_unused_live_configuration_never_contacts_remote(tmp_path):
    live = LiveConfig(
        hostname="unused.invalid",
        web_origin="https://unused.invalid",
        projects=(ProjectConfig(id=ProjectId(value=888), path="unused/project"),),
    )
    cfg = AppConfig(live=live, preferences_path=tmp_path / "prefs.toml")
    service = Service(cfg, GlabAdapter(live, lambda *_: pytest.fail("unexpected remote call")))
    assert service.host == "fixture"
    assert service.mr_catalog().source == "fixture"
    assert {p.id.value for p in service.projects()} == {42, 99}


def test_api_configured_projects_and_unlinked_all_state_history(service):
    with TestClient(create_app(service=service)) as api:
        projects = api.get("/api/projects").json()
        assert projects["host"] == "fixture" and projects["coverage"] == "configured_projects"
        assert {p["id"]["value"] for p in projects["projects"]} == {42, 99}
        all_rows = api.get("/api/dashboard?all=true").json()
        assert len(all_rows["views"]) == 7
        scoped = api.get("/api/dashboard?project=99&all=true").json()
        assert len(scoped["views"]) == 1
        assert scoped["selected_project"] == {"value": 99}
        catalog = api.get("/api/merge-requests?project=42").json()
        assert catalog["coverage"] == "configured_projects"
        assert catalog["scope"] == "authored_by_me"
        assert catalog["total"] == len(catalog["rows"])
        assert {r["mr"]["state"] for r in catalog["rows"]} >= {"open", "closed", "merged"}
        assert any(r["mr"]["iid"]["value"] == 355 for r in catalog["rows"])
        assert all(
            r["source_sha"] and r["source_sha"] == r["mr"]["source_sha"] for r in catalog["rows"]
        )
        assert api.get("/api/merge-requests?project=777").status_code == 404
        assert api.get("/api/dashboard?project=777").status_code == 404
        assert api.post("/api/merge-requests/refresh", json={}).status_code == 200


def test_fixture_mr_sources_are_explicit_and_not_inferred_from_branch_heads():
    catalog = fixture_catalog()
    rows = {(row.mr.project, row.mr.iid): row for row in catalog.rows}
    assert all(row.source_sha is not None for row in catalog.rows)
    for item in synthetic_snapshot().items:
        for mr in item.merge_requests:
            assert rows[(mr.project, mr.iid)].source_sha == mr.source_sha
    unlinked = next(row for row in catalog.rows if row.mr.iid.value == 355)
    branch_shas = {branch.sha for item in synthetic_snapshot().items for branch in item.branches}
    assert unlinked.source_sha not in branch_shas
    row = catalog.rows[0]
    with pytest.raises(ValidationError, match="differs"):
        type(row).model_validate({**row.model_dump(), "source_sha": "f" * 40})
    # Legacy or genuinely incomplete MR summaries may remain unknown even with known branch heads.
    unknown = type(row).model_validate(
        {**row.model_dump(), "mr": {**row.mr.model_dump(), "source_sha": None}, "source_sha": None}
    )
    assert unknown.source_sha is None and unknown.mr.source_sha is None


def mr(iid, project=42, author=7):
    return {
        "iid": iid,
        "project_id": project,
        "source_project_id": project,
        "sha": "a" * 40,
        "title": f"Synthetic MR {iid}",
        "state": "merged",
        "draft": False,
        "source_branch": f"history-{iid}",
        "target_branch": "main",
        "author": {"id": author},
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-09-01T00:00:00Z",
    }


def test_authored_catalog_real_adapter_pagination_is_project_scoped_all_states():
    calls = []
    live = LiveConfig(
        hostname="gitlab.example.invalid",
        web_origin="https://gitlab.example.invalid",
        projects=(ProjectConfig(id=ProjectId(value=42), path="demo/flight"),),
        max_pages=3,
    )

    def runner(argv, _timeout):
        calls.append(argv[-1])
        parsed = urlsplit(argv[-1])
        query = parse_qs(parsed.query)
        if parsed.path == "version":
            value = {"version": "18.11.12"}
        elif parsed.path == "user":
            value = {"id": 7}
        else:
            assert parsed.path == "projects/42/merge_requests"
            assert query["scope"] == ["created_by_me"] and query["state"] == ["all"]
            assert query["author_id"] == ["7"]
            value = [mr(i) for i in range(1, 101)] if query["page"] == ["1"] else [mr(101)]
        return RunResult(code=0, stdout=json.dumps(value).encode())

    catalog = fetch_catalog(GlabAdapter(live, runner))
    assert catalog.total == 101
    assert len(calls) == 4
    assert catalog.rows[-1].mr.iid.value == 101
    assert all(row.mr.state == "merged" for row in catalog.rows)
    assert all(row.source_sha == row.mr.source_sha == "a" * 40 for row in catalog.rows)


@pytest.mark.parametrize("project,author", [(99, 7), (42, 8)])
def test_catalog_rejects_backend_scope_violation(project, author):
    live = LiveConfig(
        hostname="gitlab.example.invalid",
        web_origin="https://gitlab.example.invalid",
        projects=(ProjectConfig(id=ProjectId(value=42), path="demo/flight"),),
    )

    def runner(argv, _timeout):
        path = urlsplit(argv[-1]).path
        value = (
            {"version": "18.11.12"}
            if path == "version"
            else ({"id": 7} if path == "user" else [mr(1, project, author)])
        )
        return RunResult(code=0, stdout=json.dumps(value).encode())

    with pytest.raises(AdapterError, match="identity scope"):
        fetch_catalog(GlabAdapter(live, runner))


def test_catalog_failed_refresh_preserves_prior_cache_and_memory(tmp_path, monkeypatch):
    import gspace.service as module

    live = LiveConfig(
        hostname="gitlab.example.invalid",
        web_origin="https://gitlab.example.invalid",
        projects=fixture_catalog().projects,
    )
    cfg = AppConfig(
        mode="live",
        live=live,
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
    )
    data = fixture_catalog().model_dump()
    data.update(source="glab", host=live.web_origin)
    catalog = module.MRCatalog.model_validate(data)
    monkeypatch.setattr(module, "fetch_catalog", lambda _: catalog)
    service = Service(cfg)
    service.mr_catalog(refresh=True)
    path = tmp_path / "cache-mrs.json"
    before = path.read_bytes()

    def failed(_):
        raise AdapterError("timeout", "Synthetic failure")

    monkeypatch.setattr(module, "fetch_catalog", failed)
    with pytest.raises(AdapterError):
        service.mr_catalog(refresh=True)
    assert path.read_bytes() == before
    assert service.mr_catalog() == catalog


def test_cli_shared_view_columns_and_clean_json(config, service, tmp_path):
    service.change(SavedViewSet(revision=0, view=view(orientation="columns")))
    cfg = tmp_path / "config.toml"
    cfg.write_text(
        f'preferences_path = "{config.preferences_path}"\ncache_path = "{config.cache_path}"\n'
    )
    command = [
        sys.executable,
        "-m",
        "gspace",
        "dashboard",
        "--config",
        str(cfg),
        "--view",
        "Release review",
        "--no-color",
        "--width",
        "90",
    ]
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    assert "Evidence" in result.stdout and "42:791" in result.stdout
    assert "\x1b" not in result.stdout and not result.stderr
    result = subprocess.run([*command, "--json"], capture_output=True, text=True, check=True)
    assert json.loads(result.stdout)["orientation"] == "columns" and not result.stderr
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "gspace",
            "mrs",
            "--config",
            str(cfg),
            "--project",
            "42",
            "--state",
            "merged",
            "--json",
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    assert all(row["mr"]["state"] == "merged" for row in json.loads(result.stdout)["rows"])


def test_public_claude_monitor_never_renders_private_blocks():
    secret = "PRIVATE_SENTINEL"
    row = {
        "type": "assistant",
        "message": {
            "content": [
                {"type": "thinking", "thinking": secret},
                {"type": "text", "text": secret},
                {
                    "type": "tool_use",
                    "name": "Write",
                    "input": {"file_path": "app.js", "content": secret},
                },
            ]
        },
    }
    output = json.dumps(public_events(row))
    assert secret not in output and "Write" in output and "app.js" in output
    assert public_events({"type": "result", "result": secret}) == [
        {"event": "result", "state": "done"}
    ]
    assert public_events({"type": "system", "subtype": "auth", "token": secret}) == []


def test_inline_poe_has_safe_and_sensitive_tasks():
    root = Path(__file__).resolve().parents[1]
    pyproject = tomllib.loads((root / "pyproject.toml").read_text())
    assert "include" not in pyproject["tool"]["poe"]
    assert not (root / "poe_tasks.toml").exists()
    tasks = pyproject["tool"]["poe"]["tasks"]
    assert {
        "setup",
        "serve",
        "dashboard",
        "compare",
        "demo",
        "check",
        "build",
        "browser-qa",
        "claude-monitor",
        "lab-preflight",
        "lab-up",
        "lab-status",
        "lab-seed",
        "lab-runner",
        "lab-exercise",
        "lab-verify",
        "lab-stop",
    } <= tasks.keys()
    assert tasks["check"]["sequence"] == [
        "lint",
        "format-check",
        "typecheck",
        "test",
        "contract-check",
    ]
    for name in ("default", "help", "list", "setup", "check", "lab-up"):
        assert "--approved" not in json.dumps(tasks[name])
    for task in tasks.values():
        assert "shell" not in task
    listed = subprocess.run(
        [sys.executable, "-m", "poethepoet", "--help"], capture_output=True, text=True, check=True
    )
    assert "lab-preflight" in listed.stdout and "serve" in listed.stdout


def test_shared_search_includes_associated_resource_tokens(service):
    from gspace.preferences import Filters

    result = service.dashboard(Filters(search="issue-791 passenger"))
    assert [v.item.identity.issue.value for v in result.views] == [791]
    result = service.dashboard(Filters(search="!154"))
    assert [v.item.identity.issue.value for v in result.views] == [791]
