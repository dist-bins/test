"""Actual opt-in avatar API GET on an owned synthetic loopback image server."""

from __future__ import annotations

import json
import struct
import tempfile
import threading
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Protocol, cast

import httpx
from fastapi.testclient import TestClient

from gspace.api import create_app
from gspace.avatar_policy import AvatarPolicy
from gspace.avatars import ProjectPresentation
from gspace.config import AppConfig, LiveConfig, ProjectConfig
from gspace.glab import GlabAdapter, RunResult
from gspace.models import ProjectId
from gspace.service import Service

ROOT = Path(__file__).resolve().parents[1]


class LocalApiClient(Protocol):
    """Finite boundary for the installed third-party TestClient whose inherited stub is absent."""

    def get(self, url: str) -> httpx.Response: ...


def image() -> bytes:
    def chunk(kind: bytes, body: bytes) -> bytes:
        return (
            struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body))
        )

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(b"\0\xff\0\0\xff"))
        + chunk(b"IEND", b"")
    )


def main() -> None:
    scenario = "png"
    hits: list[str] = []
    metadata: list[str] = []

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            hits.append(self.path)
            self.send_response(302 if scenario == "redirect" else 200)
            if scenario == "redirect":
                self.send_header("Location", "http://192.0.2.1/icon.png")
            self.end_headers()
            self.wfile.write(b"x" * 500 if scenario == "oversize" else image())

        def log_message(self, format: str, *args: object) -> None:
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    cases: list[dict[str, object]] = []
    try:
        with tempfile.TemporaryDirectory(prefix="gspace-avatar-network-") as directory:
            temporary = Path(directory)
            origin = f"http://127.0.0.1:{server.server_port}"
            live = LiveConfig(
                hostname=f"127.0.0.1:{server.server_port}",
                web_origin=origin,
                transport="isolated_loopback_http",
                projects=(ProjectConfig(id=ProjectId(value=42), path="demo/flight"),),
            )

            def runner(argv: list[str], timeout: float) -> RunResult:
                assert argv[-1] == "projects/42" and timeout > 0
                metadata.append(argv[-1])
                body = {
                    "id": 42,
                    "avatar_url": origin + "/uploads/-/system/project/avatar/42/icon.png",
                }
                return RunResult(code=0, stdout=json.dumps(body).encode())

            for scenario in ("png", "redirect", "oversize"):
                hits.clear()
                metadata.clear()
                config = AppConfig(
                    mode="live",
                    live=live,
                    preferences_path=temporary / "prefs.toml",
                    cache_path=temporary / "cache.json",
                    avatars=AvatarPolicy(
                        enabled=True, allowed_networks=("127.0.0.0/8",), max_bytes=128
                    ),
                )
                client = cast(
                    LocalApiClient,
                    TestClient(create_app(service=Service(config, GlabAdapter(live, runner)))),
                )
                response = client.get("/api/projects/42/presentation")
                assert response.status_code == 200
                presentation = ProjectPresentation.model_validate_json(response.content)
                kind = presentation.avatar.kind
                assert kind == ("cached_png" if scenario == "png" else "fallback")
                binary = client.get(presentation.avatar_src)
                assert binary.status_code == 200 and (binary.content == image()) == (
                    scenario == "png"
                )
                assert binary.headers["content-security-policy"] == "default-src 'none'; sandbox"
                assert hits == ["/uploads/-/system/project/avatar/42/icon.png"] and metadata == [
                    "projects/42"
                ]
                assert client.get("/api/projects/999/presentation").status_code == 400
                cases.append(
                    {
                        "scenario": scenario,
                        "avatar": presentation.avatar.model_dump(mode="json"),
                        "metadata_paths": list(metadata),
                        "image_paths": list(hits),
                        "cached_binary_status": binary.status_code,
                    }
                )
    finally:
        server.shutdown()
        server.server_close()
    report = {
        "purpose": "Actual synthetic avatar API/cache/GET limits",
        "cases": cases,
        "remote_credentials": False,
        "corporate_contact": False,
        "tls": "Owned synthetic loopback HTTP only; TLS unit guards separate",
    }
    path = ROOT / "output/verification/avatar-network-probe.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
