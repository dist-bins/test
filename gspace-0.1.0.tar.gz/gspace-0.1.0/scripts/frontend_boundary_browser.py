"""Verify generated validation in an actual browser under the served self-only CSP."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]
PROBE = """async () => {
 const {schemas, requests, responses} = await import('/assets/contracts/schema-validation.js');
 const dashboard = await (await fetch('/api/dashboard')).json();
 const settings = await (await fetch('/api/settings')).json();
 const checks = [];
 function check(name, result) { checks.push({name, passed: result === true}); }
 check('actual Dashboard response', responses['GET /api/dashboard 200'](dashboard));
 check('actual Settings response', responses['GET /api/settings 200'](settings));
 const navigation = await (await fetch('/api/navigation')).json();
 const presentation = await (await fetch('/api/projects/42/presentation')).json();
 const graph = await (await fetch('/api/items/42/791/pipeline-graph')).json();
 check('actual NavigationCatalog', responses['GET /api/navigation 200'](navigation));
 check('actual ProjectPresentation',
   responses['GET /api/projects/{project}/presentation 200'](presentation));
 check('actual PipelineGraph',
   responses['GET /api/items/{project}/{issue}/pipeline-graph 200'](graph));
 const target = {kind:'bookmark',host:'fixture',reference:{kind:'work_item',
   key:{project:{value:42},issue:{value:791}}}};
 const decoration = {target,icon:'rocket',color:'teal',pinned:true,order:4};
 check('curated decoration validates', schemas.NavigationDecoration(decoration));
 check('arbitrary icon URL rejects', !schemas.NavigationDecoration({
   ...decoration,icon:'https://evil.invalid/icon.svg'}));
 check('arbitrary color CSS rejects', !schemas.NavigationDecoration({
   ...decoration,color:'url(https://evil.invalid)'}));
 check('decoration pin does not coerce',
   !schemas.NavigationDecoration({...decoration,pinned:'true'}));
 check('tagged target rejects unknown variant',
   !schemas.NavigationDecoration({...decoration,target:{kind:'invented'}}));
 check('decoration operation validates', requests['POST /api/preferences']({
   operation:'navigation_decoration_set',revision:0,decoration}));
 const avatar = await fetch(presentation.avatar_src);
 check('avatar fixed same-origin fallback',
   presentation.avatar_src==='/api/projects/42/avatar' && avatar.ok &&
   avatar.headers.get('content-type').startsWith('image/svg+xml'));
 check('avatar restrictive binary CSP',
   avatar.headers.get('content-security-policy')==="default-src 'none'; sandbox");
 check('wrong response container rejects', !responses['GET /api/dashboard 200']([]));
 check('string ID rejects without coercion', !schemas.ProjectId({value: '42'}));
 check('extra field rejects without removal', !schemas.ProjectId({value: 42, extra: true}));
 check('empty identity rejects', !schemas.Version({}));
 const record = {
   key: {project: {value: 42}, issue: {value: 791}}, environment: 'dev',
   version: {sha: 'a'.repeat(40)}, outcome: 'passed',
   checked_at: '2026-10-06T12:00:00Z', source: 'operator', notes: ''
 };
 check('exact SHA manual record validates', schemas.ApplicationTestRecord(record));
 check('branch-only manual record rejects',
   !schemas.ApplicationTestRecord({...record, version: {branch: 'issue-791'}}));
 check('unknown preference command rejects',
   !requests['POST /api/preferences']({operation: 'invented'}));
 return checks;
}"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/frontend-boundary-browser.json"
    )
    output = parser.parse_args().output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []
    outbound: list[str] = []
    with fixture_server() as port, sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        page = browser.new_page()

        def guard(route):
            url = urlsplit(route.request.url)
            if url.hostname == "127.0.0.1" and url.port == port:
                route.continue_()
            else:
                outbound.append(route.request.url)
                route.abort()

        page.route("**/*", guard)
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.on(
            "console",
            lambda message: (
                errors.append(message.text)
                if message.type == "error" and "Content Security Policy" in message.text
                else None
            ),
        )
        response = page.goto(f"http://127.0.0.1:{port}/")
        assert response is not None
        csp = response.headers.get("content-security-policy", "")
        assert "'unsafe-eval'" not in csp and "script-src 'self'" in csp
        checks = page.evaluate(PROBE)
        browser.close()
    failed = sum(not check["passed"] for check in checks) + len(errors) + len(outbound)
    report = {
        "purpose": "Actual browser generated-boundary/CSP verification on synthetic loopback",
        "checks": checks,
        "csp": csp,
        "browser_errors": errors,
        "outbound": outbound,
        "failed": failed,
    }
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"checks": len(checks), "failed": failed, "report": str(output)}))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
