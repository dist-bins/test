"""Credential-free access descriptors and explicit permission evidence variants."""

from __future__ import annotations

import ipaddress
import re
from typing import Annotated, Literal, Self
from urllib.parse import urlsplit

from pydantic import AwareDatetime, Field, model_validator

from gspace.models import Model, ProjectId, Text, UserId


class ProfileBase(Model, frozen=True):
    name: Annotated[str, Field(pattern=r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")]
    host: Text
    projects: tuple[ProjectId, ...]
    write_enabled: bool = Field(default=False, strict=True)

    @model_validator(mode="after")
    def scoped(self) -> Self:
        parsed = urlsplit(self.host)
        if (
            parsed.scheme not in ("https", "http")
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
            or parsed.path not in ("", "/")
        ):
            raise ValueError("Profile requires an explicit credential-free origin")
        if parsed.scheme == "http" and parsed.netloc != "127.0.0.1:8929":
            raise ValueError("HTTP profiles are restricted to the isolated synthetic lab")
        if not self.projects or len(set(self.projects)) != len(self.projects):
            raise ValueError("Profile projects must be nonempty and unique")
        return self


class GlabProfile(ProfileBase, frozen=True):
    kind: Literal["glab"] = "glab"
    executable: Text = "glab"
    launcher_arguments: tuple[str, ...] = ()
    reject_redirects: bool = Field(default=False, strict=True)

    @model_validator(mode="after")
    def launcher(self) -> Self:
        # A deliberately configured executable wrapper is supported. An alias or
        # shell command is not. No interpreter, shell, eval or runtime option injection.
        from pathlib import Path

        if not re.fullmatch(r"[A-Za-z0-9_./-]+", self.executable):
            raise ValueError("Launcher must be a single executable name/path")
        name = Path(self.executable).name
        if name in ("sh", "bash", "zsh", "fish", "env", "node", "ruby", "perl") or name.startswith(
            "python"
        ):
            raise ValueError("General interpreters are not controlled glab launchers")
        for argument in self.launcher_arguments:
            if (
                not re.fullmatch(r"[A-Za-z0-9_./:=@+,-]{1,200}", argument)
                or argument in ("-c", "--command", "--eval", "api", "auth")
                or argument.startswith(("--token", "--password", "--host", "--url"))
            ):
                raise ValueError("Unsupported launcher argument")
        return self


class PatProfile(ProfileBase, frozen=True):
    kind: Literal["pat"] = "pat"
    secret_env: Annotated[str, Field(pattern=r"^GSPACE_[A-Z][A-Z0-9_]{0,63}$")]
    allowed_networks: tuple[str, ...] = ()

    @model_validator(mode="after")
    def network_policy(self) -> Self:
        for network in self.allowed_networks:
            ipaddress.ip_network(network, strict=True)
        return self


type AccessProfile = Annotated[GlabProfile | PatProfile, Field(discriminator="kind")]


class PermissionScope(Model, frozen=True):
    profile: Text
    host: Text
    project: ProjectId
    identity: UserId


class PermissionBase(Model, frozen=True):
    scope: PermissionScope
    reason: Text
    evidence: tuple[Text, ...]
    checked_at: AwareDatetime


class PermissionSupported(PermissionBase, frozen=True):
    kind: Literal["supported"] = "supported"


class PermissionDenied(PermissionBase, frozen=True):
    kind: Literal["denied"] = "denied"


class PermissionUnknown(PermissionBase, frozen=True):
    kind: Literal["unknown"] = "unknown"


type Permission = Annotated[
    PermissionSupported | PermissionDenied | PermissionUnknown, Field(discriminator="kind")
]
