// The server supplies only the validated operator path prefix, never an origin.
export function localUrl(path: string): string {
  if (!path.startsWith('/') || path.startsWith('//') || path.includes('\\')) throw new Error('Expected an application-local URL');
  const prefix = document.querySelector<HTMLMetaElement>('meta[name="gspace-base-path"]')?.content ?? '';
  return prefix + path;
}
