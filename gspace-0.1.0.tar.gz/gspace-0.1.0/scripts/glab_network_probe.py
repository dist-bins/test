"""Actual installed glab against owned synthetic GET servers and a finite process sandbox.

Never reads existing auth configuration. The only credential is an inert synthetic fixture value.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output/verification/offline-runtime"


def main() -> int:
    executable = shutil.which("glab")
    if executable is None:
        raise RuntimeError("The authorized installed glab binary is absent")
    hits: list[str] = []
    target_hits: list[str] = []
    synthetic_header_forwarded: list[bool] = []
    scenario = "direct"
    target_port = 0

    class Target(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            target_hits.append(self.path)
            synthetic_header_forwarded.append(
                self.headers.get("Private-Token") == "gspace-inert-synthetic-fixture-only"
            )
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'{"version":"18.11.12","revision":"synthetic"}')

        def log_message(self, format: str, *args: object) -> None:
            pass

    class Source(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            hits.append(self.path)
            if self.path == "/api/v4/version" and scenario != "direct":
                self.send_response(302)
                destination = (
                    f"http://127.0.0.1:{target_port}/api/v4/version"
                    if scenario in ("other-port", "other-port-broad-gate")
                    else (
                        "/api/v4/projects/999/pipelines"
                        if scenario == "same-origin-out-of-scope-project"
                        else "/same-origin-unapproved-path"
                    )
                )
                self.send_header("Location", destination)
            else:
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
            self.end_headers()
            if self.path != "/api/v4/version" or scenario == "direct":
                self.wfile.write(b'{"version":"18.11.12","revision":"synthetic"}')

        def log_message(self, format: str, *args: object) -> None:
            pass

    source = ThreadingHTTPServer(("127.0.0.1", 0), Source)
    target = ThreadingHTTPServer(("127.0.0.1", 0), Target)
    source_port, target_port = source.server_port, target.server_port
    for server in (source, target):
        threading.Thread(target=server.serve_forever, daemon=True).start()
    report: dict[str, object] = {}
    try:
        with tempfile.TemporaryDirectory(prefix="gspace-glab-synthetic-") as directory:
            temporary = Path(directory)
            profile = temporary / "exact-source-port.sb"
            profile.write_text(
                "(version 1)\n(allow default)\n(deny network*)\n"
                f'(allow network-outbound (remote ip "localhost:{source_port}"))\n'
                '(deny mach-lookup (global-name "com.apple.mDNSResponder"))\n'
                '(deny network-outbound (literal "/private/var/run/mDNSResponder"))\n'
            )
            isolated_env = {
                "PATH": "/opt/homebrew/bin:/usr/bin:/bin",
                "PYTHONPATH": str(ROOT / "src"),
                "GLAB_CONFIG_DIR": str(temporary / "glab"),
                "XDG_CONFIG_HOME": str(temporary / "xdg"),
                "GIT_CONFIG_GLOBAL": "/dev/null",
                "GIT_CONFIG_SYSTEM": "/dev/null",
                "GIT_CONFIG_NOSYSTEM": "1",
                "GITLAB_TOKEN": "gspace-inert-synthetic-fixture-only",
                "GLAB_USE_KEYRING": "false",
                "USE_KEYRING": "false",
            }
            (temporary / "glab").mkdir()
            (temporary / "xdg").mkdir()
            script = (
                "import sys,json;from gspace.glab import run_argv;"
                "r=run_argv([sys.argv[1],'api','--hostname',sys.argv[2],"
                "'--method','GET','version'],3,api_protocol='http');"
                "print(json.dumps({'code':r.code,'synthetic_version':"
                "json.loads(r.stdout).get('version') if r.code==0 else None}))"
            )
            cases: list[dict[str, object]] = []
            broad_profile = temporary / "owned-two-port.sb"
            broad_profile.write_text(
                profile.read_text()
                + f'(allow network-outbound (remote ip "localhost:{target_port}"))\n'
            )
            for scenario in (
                "direct",
                "other-port",
                "same-origin-path",
                "same-origin-out-of-scope-project",
                "other-port-broad-gate",
            ):
                hits.clear()
                target_hits.clear()
                synthetic_header_forwarded.clear()
                result = subprocess.run(
                    [
                        "/usr/bin/sandbox-exec",
                        "-f",
                        str(broad_profile if scenario == "other-port-broad-gate" else profile),
                        sys.executable,
                        "-c",
                        script,
                        executable,
                        f"127.0.0.1:{source_port}",
                    ],
                    cwd=temporary,
                    env=isolated_env,
                    capture_output=True,
                    text=True,
                    check=True,
                    timeout=8,
                )
                parsed = json.loads(result.stdout)
                cases.append(
                    {
                        "scenario": scenario,
                        **parsed,
                        "source_paths": list(hits),
                        "other_port_paths": list(target_hits),
                        "synthetic_private_token_forwarded": any(synthetic_header_forwarded),
                    }
                )
                if scenario == "direct":
                    assert parsed["code"] == 0 and parsed["synthetic_version"] == "18.11.12", cases
                    assert hits == ["/api/v4/version"]
                elif scenario == "other-port":
                    assert parsed["code"] != 0 and not target_hits
                elif scenario == "same-origin-path":
                    assert parsed["code"] == 0 and "/same-origin-unapproved-path" in hits
                elif scenario == "same-origin-out-of-scope-project":
                    assert parsed["code"] == 0 and "/api/v4/projects/999/pipelines" in hits
                else:
                    assert parsed["code"] == 0 and target_hits == ["/api/v4/version"]
            dns = subprocess.run(
                [
                    "/usr/bin/sandbox-exec",
                    "-f",
                    str(profile),
                    "/usr/bin/dns-sd",
                    "-G",
                    "v4",
                    "gspace-denial-test.invalid",
                ],
                cwd=temporary,
                env=isolated_env,
                capture_output=True,
                text=True,
                timeout=3,
            )
            assert dns.returncode != 0 and "Service Not Running" in dns.stdout + dns.stderr
            version = subprocess.run(
                ["/usr/bin/sandbox-exec", "-f", str(profile), executable, "--version"],
                cwd=temporary,
                env={**isolated_env, "GLAB_CHECK_UPDATE": "false"},
                capture_output=True,
                text=True,
                check=True,
                timeout=3,
            )
            report = {
                "purpose": "Actual synthetic installed-glab redirect and system DNS boundary",
                "version": version.stdout.splitlines()[0],
                "cases": cases,
                "dns_client_exit": dns.returncode,
                "dns_client_result": (dns.stdout + dns.stderr).strip(),
                "global_settings_changed": False,
                "corporate_contact": False,
                "credential": "inert synthetic fixture only; isolated empty config dirs",
                "enforcement": (
                    "exact source-port child gate; broader control allows the two owned ports"
                ),
                "limitations": [
                    (
                        "glab follows same-origin redirects into paths and "
                        "projects outside initial app allowlist"
                    ),
                    (
                        "With both owned ports permitted glab reaches the "
                        "unapproved redirected origin/port"
                    ),
                    (
                        "No supported CLI redirect-denial control found in "
                        "pinned source; this remains an acceptance gap"
                    ),
                    "No production DevPod OS gate installed or corporate transport verification",
                    "DNS client denial tested; arbitrary local relays remain unaudited",
                    "Operator glab config may define proxy, headers, trust or client certificates",
                ],
            }
    finally:
        for server in (source, target):
            server.shutdown()
            server.server_close()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "glab-dns-redirect-probe.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
