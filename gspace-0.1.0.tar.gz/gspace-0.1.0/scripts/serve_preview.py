"""Serve stable or explicitly selected draft assets with isolated fixture state on loopback."""

from __future__ import annotations

import argparse
from pathlib import Path

import uvicorn
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import RequestResponseEndpoint
from starlette.responses import Response

import gspace.api as api
from gspace.config import AppConfig

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8877)
    parser.add_argument("--assets", choices=("stable", "draft"), default="stable")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        raise SystemExit("Unprivileged port required")
    api.STATIC = ROOT / ("src/gspace/static" if args.assets == "stable" else "frontend-new")
    config = AppConfig(
        preferences_path=ROOT / ".state/preview-new/preferences.toml",
        cache_path=ROOT / ".state/preview-new/cache.json",
    )
    app = api.create_app(config)

    @app.middleware("http")
    async def preview_guard(request: Request, next_call: RequestResponseEndpoint) -> Response:
        if request.url.path.startswith(("/api/actions/", "/api/access/doctor/")):
            return JSONResponse(
                {"detail": "New frontend preview: remote actions and access diagnostics disabled"},
                status_code=403,
            )
        return await next_call(request)

    uvicorn.run(app, host="127.0.0.1", port=args.port, access_log=False)


if __name__ == "__main__":
    main()
