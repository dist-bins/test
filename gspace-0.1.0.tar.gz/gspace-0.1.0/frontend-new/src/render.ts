// Render scheduling. Every state change asks for render(); renders are
// batched into one microtask. The renderer itself is registered by the app
// entry, so this module has no dependency on screens.

export interface RenderOptions {
  readonly screenChanged?: boolean;
}

let renderer: ((opts: RenderOptions) => void) | null = null;
let renderQueued = false;

export function setRenderer(fn: (opts: RenderOptions) => void): void {
  renderer = fn;
}

export function render(opts: RenderOptions = {}): void {
  if (opts.screenChanged) {
    renderer?.(opts);
    return;
  }
  if (renderQueued) return;
  renderQueued = true;
  queueMicrotask(() => {
    renderQueued = false;
    if (pressHeld) {
      renderHeld = true;
      return;
    }
    renderer?.(opts);
  });
}

// Click safety. Pressing a button blurs the focused text field, whose
// "change" may ask for a re-render; replacing the pressed button before its
// "click" would lose that click. While a pointer is pressed on a clickable
// control, re-renders wait until its click has run (or the press ends
// without one). Selects and text fields are not held, and a hold never lasts
// longer than HOLD_MAX.
let pressHeld = false;
let renderHeld = false;
let holdTimer = 0;
const HOLD_MAX = 1500;
const CLICKABLE = 'button, a[href], summary, label, [role="button"], input[type="checkbox"], input[type="radio"]';

/** True while a press on a clickable control is in progress. */
export const pressInProgress = (): boolean => pressHeld;

/** Ask for a full render once the current press has completed. */
export function renderAfterPress(): void {
  renderHeld = true;
}

function releaseHold(): void {
  window.clearTimeout(holdTimer);
  pressHeld = false;
  if (!renderHeld) return;
  renderHeld = false;
  render();
}

document.addEventListener(
  'pointerdown',
  (e) => {
    if (e.button > 0 || !(e.target instanceof Element) || !e.target.closest(CLICKABLE)) return;
    pressHeld = true;
    window.clearTimeout(holdTimer);
    holdTimer = window.setTimeout(releaseHold, HOLD_MAX);
  },
  true,
);
// The click (window, bubble phase) runs after the target's own handler.
window.addEventListener('click', releaseHold);
// A press that ends without a click (drag, scroll, cancel) releases shortly after.
const pressEnded = (): void => {
  if (!pressHeld) return;
  window.clearTimeout(holdTimer);
  holdTimer = window.setTimeout(releaseHold, 400);
};
document.addEventListener('pointerup', pressEnded, true);
document.addEventListener('pointercancel', pressEnded, true);
