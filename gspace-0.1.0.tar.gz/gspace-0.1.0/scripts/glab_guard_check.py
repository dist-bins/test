"""Actual guarded native CLI success/redirect matrix, using only owned synthetic servers."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import ssl
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

ROOT = Path(__file__).resolve().parents[1]
MARKER = "gspace-owned-public-synthetic-marker"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--executable", type=Path, default=ROOT / "dist/tools/gspace-glab")
    parser.add_argument(
        "--python", type=Path, help="Test an installed Python without workspace imports"
    )
    parser.add_argument("--default-companion", action="store_true")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "output/verification/glab-guard-20261020/matrix.json",
    )
    args = parser.parse_args()
    executable = args.executable.absolute()
    output = args.output.absolute()
    if not executable.is_file() or executable.is_symlink():
        parser.error("A built ordinary guarded executable is required")
    if not output.resolve().is_relative_to(ROOT.resolve()):
        parser.error("Report must stay in the owned workspace")
    records = []
    status = 200
    location = ""

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            length = int(self.headers.get("Content-Length", "0"))
            assert 0 <= length <= 4096
            body = self.rfile.read(length)
            initial = self.path in ("/api/v4/version", "/api/graphql")
            records.append(
                {
                    "path": self.path,
                    "method": self.command,
                    "server_port": self.server.server_port,
                    "native_auth_marker": self.headers.get("Private-Token") == MARKER,
                    "graphql_body": b"GSpaceSyntheticRead" in body,
                    "initial": initial,
                }
            )
            self.send_response(status if initial else 200)
            if initial and location:
                self.send_header("Location", location)
            payload = (
                b'{"data":{"__typename":"Query"},"errors":[{"message":"inert"}]}'
                if initial and location
                else b'{"data":{"__typename":"Query"}}'
            )
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        do_POST = do_GET

        def log_message(self, format: str, *args: object) -> None:
            pass

    with tempfile.TemporaryDirectory(prefix="gspace-guard-fixture-") as temporary:
        owned = Path(temporary)
        openssl = shutil.which("openssl")
        if openssl is None:
            raise RuntimeError("Existing OpenSSL is required for actual synthetic TLS")
        cert, key = owned / "public-cert.pem", owned / "synthetic-key.pem"
        env = {
            "PATH": os.environ.get("PATH", os.defpath),
            "HOME": str(owned),
            "GLAB_CONFIG_DIR": str(owned / "empty-glab"),
            "XDG_CONFIG_HOME": str(owned / "xdg"),
            "GIT_CONFIG_GLOBAL": os.devnull,
            "GIT_CONFIG_SYSTEM": os.devnull,
            "GIT_CONFIG_NOSYSTEM": "1",
            "GITLAB_TOKEN": MARKER,
            "GLAB_USE_KEYRING": "false",
            "USE_KEYRING": "false",
            "GLAB_CHECK_UPDATE": "false",
            "SSL_CERT_FILE": str(cert),
            "SSL_CERT_DIR": str(owned / "empty-ca-dir"),
            "PYTHONPATH": str(ROOT / "src"),
            "NO_COLOR": "1",
        }
        if args.python is not None:
            env.pop("PYTHONPATH")
        for name in ("empty-glab", "xdg", "empty-ca-dir"):
            (owned / name).mkdir()
        subprocess.run(
            [
                openssl,
                "req",
                "-x509",
                "-newkey",
                "rsa:2048",
                "-nodes",
                "-days",
                "1",
                "-keyout",
                str(key),
                "-out",
                str(cert),
                "-subj",
                "/CN=localhost",
                "-addext",
                "subjectAltName=DNS:localhost,IP:127.0.0.1",
            ],
            env=env,
            check=True,
            capture_output=True,
            timeout=30,
        )
        tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        tls.load_cert_chain(cert, key)
        servers = [ThreadingHTTPServer(("127.0.0.1", 0), Handler) for _ in range(3)]
        for server in servers[:2]:
            server.socket = tls.wrap_socket(server.socket, server_side=True)
        for server in servers:
            threading.Thread(target=server.serve_forever, daemon=True).start()
        port, second_port, plain_port = (s.server_port for s in servers)
        child = (
            "import sys,json;from gspace.glab import run_argv;"
            "r=run_argv(json.loads(sys.argv[1]),5,reject_redirects=True);"
            "print(json.dumps({'code':r.code,'stdout':r.stdout.decode()}))"
        )
        outcomes = []
        try:

            def invoke(method):
                argv = [
                    "glab" if args.default_companion else str(executable),
                    "api",
                    "--hostname",
                    f"127.0.0.1:{port}",
                    "--method",
                    method,
                    "graphql" if method == "POST" else "version",
                ]
                if method == "POST":
                    argv += ["-f", "query=query GSpaceSyntheticRead { __typename }"]
                run = subprocess.run(
                    [
                        str(args.python) if args.python else sys.executable,
                        "-c",
                        child,
                        json.dumps(argv),
                    ],
                    cwd=owned,
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=10,
                    check=True,
                )
                return json.loads(run.stdout)

            for method in ("GET", "POST"):
                records.clear()
                result = invoke(method)
                assert result["code"] == 0 and json.loads(result["stdout"])["data"]
                assert len(records) == 1 and records[0]["native_auth_marker"]
                assert records[0]["graphql_body"] is (method == "POST")
                outcomes.append({"method": method, "status": 200, "passed": True})
            destinations = {
                "other-project": "/api/v4/projects/999/synthetic",
                "other-path": f"https://127.0.0.1:{port}/api/v4/projects/42/other",
                "other-port": f"https://127.0.0.1:{second_port}/api/v4/projects/42",
                "other-host": f"https://localhost:{second_port}/api/v4/projects/42",
                "scheme-downgrade": f"http://127.0.0.1:{plain_port}/api/v4/projects/42",
            }
            for method in ("GET", "POST"):
                for status in (301, 302, 303, 307, 308):
                    for destination in destinations:
                        location = destinations[destination]
                        records.clear()
                        result = invoke(method)
                        assert result["code"] != 0 and not result["stdout"].strip()
                        assert len(records) == 1 and records[0]["initial"]
                        assert records[0]["native_auth_marker"]
                        outcomes.append(
                            {
                                "method": method,
                                "status": status,
                                "destination": destination,
                                "requests": len(records),
                                "destination_requests": 0,
                                "passed": True,
                            }
                        )
        finally:
            for server in servers:
                server.shutdown()
                server.server_close()
    report = {
        "passed": True,
        "purpose": "Actual native guarded CLI and production Python runner",
        "binary_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
        "native_synthetic_auth": True,
        "actual_tls": True,
        "installed_python": str(args.python) if args.python else None,
        "default_companion_selection": args.default_companion,
        "redirect_cases": 50,
        "success_cases": 2,
        "cases": outcomes,
        "real_credentials_or_corporate_or_devpod": False,
        "limitations": [
            "No actual operator wrapper or credential acceptance",
            "No full runtime egress claim",
        ],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {"passed": True, "redirect_cases": 50, "success_cases": 2, "report": str(output)}
        )
    )


if __name__ == "__main__":
    main()
