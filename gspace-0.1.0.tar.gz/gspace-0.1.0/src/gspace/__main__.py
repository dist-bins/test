from gspace.cli import main

raise SystemExit(main())
