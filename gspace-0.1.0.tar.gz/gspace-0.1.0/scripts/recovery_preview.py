"""Serve a frozen recovery candidate on an owned synthetic loopback fixture.

Original bundled assets/operator files are never changed. The fixture has an
inert GET-only profile transport and rejects action execution independently.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import threading
from datetime import UTC, datetime
from pathlib import Path

from recovery_fixture import ROOT, recovery_fixture

from gspace.models import Model
from gspace.operator_settings import OperatorSettings
from gspace.preferences import StoredPreferences

ASSETS = (
    "index.html",
    "app.js",
    "theme.js",
    "styles.css",
    "icon.svg",
    "gspace-wolf.svg",
    "gspace-wolf-gray.svg",
)


class SyntheticState(Model, frozen=True):
    settings: OperatorSettings
    preferences: StoredPreferences


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--restore-synthetic-state", type=Path)
    args = parser.parse_args()
    state = args.state.resolve()
    if not state.is_relative_to(ROOT / "output/verification") or state.exists():
        parser.error("Use a fresh owned verification state path")
    if not 0 <= args.port <= 65535:
        parser.error("Invalid loopback port")
    restored = None
    if args.restore_synthetic_state is not None:
        source = args.restore_synthetic_state.resolve()
        if args.restore_synthetic_state.is_symlink() or not source.is_relative_to(
            ROOT / "output/verification"
        ):
            parser.error("Restore only public synthetic verification state")
        restored = SyntheticState.model_validate_json(source.read_bytes())
        if restored.preferences.instance_origin != "fixture":
            parser.error("Restore only synthetic fixture preferences")
    frozen = state.with_suffix(".assets")
    frozen.mkdir()
    build = json.loads((ROOT / "output/verification/frontend-build.json").read_text())
    hashes = {}
    for name in ASSETS:
        source = ROOT / "frontend-new" / name
        if source.is_symlink():
            raise ValueError("Linked assets are not permitted")
        data = source.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if digest != build["assets"][name]:
            raise ValueError("Candidate differs from the tested build")
        (frozen / name).write_bytes(data)
        hashes[name] = digest
    stopped = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stopped.set())
    signal.signal(signal.SIGINT, lambda *_: stopped.set())
    with recovery_fixture(
        frozen,
        port=args.port,
        settings=restored.settings if restored is not None else None,
        preferences=restored.preferences if restored is not None else None,
    ) as fixture:
        record = {
            "purpose": "Separate frozen synthetic candidate preview, original state preserved",
            "status": "running",
            "pid": os.getpid(),
            "url": fixture.base + "/#/work",
            "base": fixture.base,
            "mode": "fixture",
            "assets": hashes,
            "frozen_assets": str(frozen),
            "started_at": datetime.now(UTC).isoformat(),
            "original_operator_files_used": False,
            "real_credentials_used": False,
            "remote_requests": "inert GET-only MockTransport",
            "action_execution": "independently rejected",
            "public_synthetic_state_restored": restored is not None,
        }
        state.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps({"pid": record["pid"], "url": record["url"]}), flush=True)
        stopped.wait()
    record.update(status="stopped", stopped_at=datetime.now(UTC).isoformat())
    state.write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
