import json
from datetime import UTC, datetime, timedelta

import httpx
import pytest
from fastapi.testclient import TestClient
from pydantic import TypeAdapter, ValidationError

from gspace.access import AccessError, ProfileTransport
from gspace.access_models import AccessProfile, GlabProfile, PatProfile
from gspace.actions import (
    ActionService,
    ChangeJob,
    ChangePipeline,
    ConfirmAction,
    CreateDraftMR,
    CreateTag,
    EditDraftMR,
    RunPipeline,
)
from gspace.api import create_app
from gspace.config import AppConfig, LiveConfig, ProjectConfig
from gspace.models import ProjectId
from gspace.service import Service

SECRET = "SYNTHETIC_PAT_SENTINEL"
SHA = "a" * 40


def profile(**kwargs):
    return PatProfile(
        name="lab-owner",
        host="http://127.0.0.1:8929",
        projects=(ProjectId(value=42),),
        secret_env="GSPACE_LAB_TOKEN",
        write_enabled=True,
        **kwargs,
    )


def tag():
    return CreateTag(
        profile="lab-owner",
        project=ProjectId(value=42),
        branch="issue-791",
        expected_sha=SHA,
        tag="flight-2.4.10",
    )


class Remote:
    def __init__(self):
        self.calls = []
        self.membership = 50
        self.scopes = ["api"]
        self.protected = False
        self.protected_tags = []
        self.identity = 7
        self.sha = SHA
        self.denied = False
        self.archived = False
        self.missing_policy = False
        self.mr_iid = 154
        self.pipeline_status = "failed"
        self.job_status = "manual"
        self.http = httpx.MockTransport(self.handle)

    def handle(self, request):
        assert request.url.host == "127.0.0.1" and request.url.port == 8929
        assert request.headers["PRIVATE-TOKEN"] == SECRET
        path = request.url.path.removeprefix("/api/v4/")
        self.calls.append((request.method, path, request.content))
        if self.denied:
            return httpx.Response(403, text=SECRET)
        if request.method != "GET":
            return httpx.Response(201, json={"id": 99, "sha": self.sha})
        if path == "version":
            value = {"version": "18.11.12"}
        elif path == "metadata":
            value = {"version": "18.11.12", "enterprise": False}
        elif path == "user":
            value = {"id": self.identity}
        elif path == "personal_access_tokens/self":
            value = {
                "user_id": self.identity,
                "scopes": self.scopes,
                "active": True,
                "revoked": False,
            }
        elif path == "projects/42":
            value = {
                "id": 42,
                "archived": self.archived,
                "description": "GSpace isolated integration lab v1",
                "permissions": {"project_access": {"access_level": self.membership}},
                "merge_requests_enabled": True,
                "builds_access_level": "enabled",
            }
            if self.missing_policy:
                value.pop("permissions")
        elif path == "projects/42/protected_tags":
            value = [{"name": name} for name in self.protected_tags]
        elif "/repository/branches/" in path:
            name = path.split("/repository/branches/", 1)[1]
            value = {"name": name, "commit": {"id": self.sha}, "protected": self.protected}
        elif "/merge_requests/" in path:
            value = {
                "iid": self.mr_iid,
                "project_id": 42,
                "source_project_id": 42,
                "sha": self.sha,
                "title": "Draft: synthetic",
                "state": "opened",
                "draft": True,
                "source_branch": "issue-791",
                "target_branch": "main",
            }
        elif "/jobs/" in path:
            value = {
                "id": 501,
                "name": "deploy-dev",
                "stage": "deploy",
                "status": self.job_status,
                "ref": "issue-791",
                "pipeline": self.pipeline(),
            }
        else:
            value = self.pipeline()
        return httpx.Response(200, json=value)

    def pipeline(self):
        return {
            "id": 901,
            "ref": "issue-791",
            "sha": self.sha,
            "status": self.pipeline_status,
            "tag": False,
        }

    def factory(self, p):
        return ProfileTransport(p, resolver=lambda _: SECRET, http_transport=self.http)


def test_credential_descriptors_reject_plaintext_and_shell_execution():
    adapter = TypeAdapter(AccessProfile)
    data = profile().model_dump()
    for extra in ("token", "password", "oauth", "secret"):
        with pytest.raises(ValidationError):
            adapter.validate_python({**data, extra: SECRET})
    for executable, args in [
        ("bash", ("-c",)),
        ("glab;evil", ()),
        ("glab", ("--token=leak",)),
        ("python3.12", ()),
    ]:
        with pytest.raises(ValidationError):
            GlabProfile(
                name="bad",
                host="https://gitlab.example.invalid",
                projects=(ProjectId(value=42),),
                executable=executable,
                launcher_arguments=args,
            )
    valid = GlabProfile(
        name="devpod",
        host="https://gitlab.example.invalid",
        projects=(ProjectId(value=42),),
        executable="/opt/bin/glab-devpod",
        launcher_arguments=("--profile", "team"),
    )
    assert valid.launcher_arguments == ("--profile", "team")


def test_doctor_and_public_profile_are_redacted_read_only():
    remote = Remote()
    core = ActionService((profile(),), remote.factory)
    report = core.doctor("lab-owner")
    assert report.identity.value == 7 and report.api_version == "18.11.12"
    assert all(method == "GET" for method, _, _ in remote.calls)
    assert SECRET not in report.model_dump_json()
    assert "secret_env" not in core.summaries()[0].model_dump_json()


@pytest.mark.parametrize(
    "variation,kind",
    [
        ("readonly", "denied"),
        ("insufficient", "denied"),
        ("membership", "denied"),
        ("protected", "denied"),
        ("tag_protected", "denied"),
        ("archived", "denied"),
        ("missing", "unknown"),
    ],
)
def test_probe_combines_scopes_membership_policy_and_resource(variation, kind):
    remote = Remote()
    p = profile()
    if variation == "readonly":
        p = PatProfile.model_validate({**p.model_dump(), "write_enabled": False})
    if variation == "insufficient":
        remote.scopes = ["read_api"]
    if variation == "membership":
        remote.membership = 20
    if variation == "protected":
        remote.protected = True
    if variation == "tag_protected":
        remote.protected_tags = ["flight-*"]
    if variation == "archived":
        remote.archived = True
    if variation == "missing":
        remote.missing_policy = True
    core = ActionService((p,), remote.factory)
    plan = core.preview(tag())
    assert plan.permission.kind == kind
    assert plan.confirmation is None and plan.executed is False
    assert all(method == "GET" for method, _, _ in remote.calls)


def test_project_restriction_fails_before_any_remote_request():
    remote = Remote()
    core = ActionService((profile(),), remote.factory)
    bad = CreateTag.model_validate({**tag().model_dump(), "project": {"value": 99}})
    with pytest.raises(AccessError, match="project exceeds"):
        core.probe(bad)
    assert not remote.calls


def test_supported_plan_fresh_execute_and_single_use_confirmation():
    remote = Remote()
    core = ActionService((profile(),), remote.factory)
    plan = core.preview(tag())
    assert plan.permission.kind == "supported" and plan.confirmation
    assert plan.permission.scope.identity.value == 7
    before = len(remote.calls)
    result = core.execute(ConfirmAction(confirmation=plan.confirmation, confirmed=True))
    assert result.executed and result.effect == "accepted"
    fresh = remote.calls[before:]
    assert fresh[0][:2] == ("GET", "version")
    assert fresh[-1][:2] == ("POST", "projects/42/repository/tags")
    assert json.loads(fresh[-1][2])["ref"] == SHA
    with pytest.raises(AccessError, match="used or expired"):
        core.execute(ConfirmAction(confirmation=plan.confirmation, confirmed=True))
    assert sum(m != "GET" for m, _, _ in remote.calls) == 1


@pytest.mark.parametrize("race", ["identity", "sha", "revocation"])
def test_click_time_races_consume_confirmation_without_writing(race):
    remote = Remote()
    core = ActionService((profile(),), remote.factory)
    plan = core.preview(tag())
    if race == "identity":
        remote.identity = 8
    if race == "sha":
        remote.sha = "b" * 40
    if race == "revocation":
        remote.scopes = ["read_api"]
    with pytest.raises(AccessError, match="changed"):
        core.execute(ConfirmAction(confirmation=plan.confirmation, confirmed=True))
    assert all(m == "GET" for m, _, _ in remote.calls)


def test_403_and_secret_response_never_leak_or_retry():
    remote = Remote()
    transport = remote.factory(profile())
    remote.denied = True
    with pytest.raises(AccessError) as error:
        transport.request("GET", "user")
    assert error.value.code == "denied" and SECRET not in str(error.value)
    assert len(remote.calls) == 1


def test_confirmation_requires_boolean_true_and_expires():
    for value in (False, 1, "true"):
        with pytest.raises(ValidationError):
            ConfirmAction(confirmation="a" * 43, confirmed=value)
    remote = Remote()
    core = ActionService((profile(),), remote.factory)
    plan = core.preview(tag())
    record = core._plans[plan.confirmation]
    core._plans[plan.confirmation] = type(record).model_validate(
        {**record.model_dump(), "expires_at": datetime.now(UTC) - timedelta(seconds=1)}
    )
    with pytest.raises(AccessError, match="expired"):
        core.execute(ConfirmAction(confirmation=plan.confirmation, confirmed=True))
    assert all(m == "GET" for m, _, _ in remote.calls)


@pytest.mark.parametrize(
    "action,route",
    [
        (
            CreateDraftMR(
                profile="lab-owner",
                project={"value": 42},
                source_branch="issue-791",
                target_branch="main",
                expected_sha=SHA,
                title="Synthetic title",
            ),
            "merge_requests",
        ),
        (
            EditDraftMR(
                profile="lab-owner",
                project={"value": 42},
                iid={"value": 154},
                expected_sha=SHA,
                title="Updated synthetic",
            ),
            "merge_requests/154",
        ),
        (
            RunPipeline(
                profile="lab-owner", project={"value": 42}, branch="issue-791", expected_sha=SHA
            ),
            "pipelines",
        ),
        (
            ChangePipeline(
                profile="lab-owner",
                project={"value": 42},
                id={"value": 901},
                expected_sha=SHA,
                operation="retry",
            ),
            "pipelines/901/retry",
        ),
        (
            ChangeJob(
                profile="lab-owner",
                project={"value": 42},
                id={"value": 501},
                pipeline={"value": 901},
                expected_sha=SHA,
                operation="play",
            ),
            "jobs/501/play",
        ),
    ],
)
def test_guarded_action_routes_have_explicit_non_get_effect(action, route):
    remote = Remote()
    core = ActionService((profile(),), remote.factory)
    plan = core.preview(action)
    assert plan.permission.kind == "supported", plan.permission.reason
    core.execute(ConfirmAction(confirmation=plan.confirmation, confirmed=True))
    method, path, body = remote.calls[-1]
    assert method in ("POST", "PUT") and path == "projects/42/" + route
    if isinstance(action, (CreateDraftMR, EditDraftMR)):
        assert json.loads(body)["title"].startswith("Draft: ")
    assert SECRET not in body.decode()


@pytest.mark.parametrize(
    "kind,operation", [("pipeline", "cancel"), ("job", "retry"), ("job", "cancel")]
)
def test_remaining_finite_actions_require_current_state(kind, operation):
    remote = Remote()
    remote.pipeline_status = "running" if operation == "cancel" else "failed"
    remote.job_status = remote.pipeline_status
    data = dict(profile="lab-owner", project={"value": 42}, expected_sha=SHA, operation=operation)
    action = (
        ChangePipeline(id={"value": 901}, **data)
        if kind == "pipeline"
        else ChangeJob(id={"value": 501}, pipeline={"value": 901}, **data)
    )
    core = ActionService((profile(),), remote.factory)
    plan = core.preview(action)
    assert plan.permission.kind == "supported", plan.permission.reason
    core.execute(ConfirmAction(confirmation=plan.confirmation, confirmed=True))
    assert remote.calls[-1][:2] == (
        "POST",
        f"projects/42/{'pipelines/901' if kind == 'pipeline' else 'jobs/501'}/{operation}",
    )
    assert SECRET not in remote.calls[-1][2].decode()


def test_draft_edit_rejects_a_different_mr_identity():
    remote = Remote()
    remote.mr_iid = 155
    core = ActionService((profile(),), remote.factory)
    action = EditDraftMR(
        profile="lab-owner",
        project={"value": 42},
        iid={"value": 154},
        expected_sha=SHA,
        title="Synthetic update",
    )
    plan = core.preview(action)
    assert plan.permission.kind == "denied"
    assert "identity" in plan.permission.reason
    assert all(method == "GET" for method, _, _ in remote.calls)


def test_api_has_typed_schema_and_no_auth_metadata(service):
    remote = Remote()
    actions = ActionService((profile(),), remote.factory)
    with TestClient(create_app(service=service, actions=actions)) as client:
        public = client.get("/api/access/profiles").json()
        assert "secret_env" not in json.dumps(public)
        plan = client.post("/api/actions/preview", json=tag().model_dump(mode="json")).json()
        assert plan["executed"] is False
        response = client.post(
            "/api/actions/execute", json={"confirmation": plan["confirmation"], "confirmed": True}
        )
        assert response.status_code == 200 and response.json()["executed"] is True
        assert (
            client.post(
                "/api/actions/execute",
                json={"confirmation": plan["confirmation"], "confirmed": True},
            ).status_code
            == 409
        )
        schema = client.get("/openapi.json").json()
        for path, operations in schema["paths"].items():
            if path.startswith("/api/"):
                for operation in operations.values():
                    success = operation["responses"]["200"]["content"]
                    if path == "/api/projects/{project}/avatar":
                        assert set(success) == {"image/png", "image/svg+xml"}
                        assert all(
                            media["schema"] == {"type": "string", "format": "binary"}
                            for media in success.values()
                        )
                    else:
                        assert success["application/json"]["schema"]
                    assert operation["responses"]["422"]["content"]["application/json"]["schema"][
                        "$ref"
                    ].endswith("/DetailError")
        invalid = client.post(
            "/api/actions/preview", json={"kind": "delete_project", "token": SECRET}
        )
        assert invalid.status_code == 422 and SECRET not in invalid.text
        assert "secret_env" not in json.dumps(schema)


def test_profile_configuration_requires_bound_host_project_and_named_active():
    live = LiveConfig(
        hostname="127.0.0.1:8929",
        web_origin="http://127.0.0.1:8929",
        transport="isolated_loopback_http",
        projects=(ProjectConfig(id=ProjectId(value=42), path="lab/main"),),
    )
    config = AppConfig(
        mode="live", live=live, access_profiles=(profile(),), active_profile="lab-owner"
    )
    service = Service(config)
    assert service.projects() == live.projects
    assert service.adapter is not None
    for change in ({"active_profile": "unknown"}, {"access_profiles": (profile(), profile())}):
        with pytest.raises(ValidationError):
            AppConfig.model_validate({**config.model_dump(), **change})
    fixture = AppConfig(live=live, access_profiles=(profile(),))
    with TestClient(create_app(fixture)) as api:
        assert api.get("/api/access/profiles").json() == []
        assert api.get("/api/capabilities").json()["remote_mutations"] is False


def test_transport_cannot_mutate_admin_or_protection_paths():
    remote = Remote()
    transport = remote.factory(profile())
    for method, path in (
        ("POST", "user"),
        ("PUT", "personal_access_tokens/self"),
        ("POST", "projects/42/protected_branches"),
        ("PUT", "projects/42/merge_requests/154/merge"),
        ("DELETE", "projects/42/repository/tags/flight-2.4.10"),
    ):
        with pytest.raises(AccessError):
            transport.request(method, path)
    assert not remote.calls


def test_plan_variants_reject_optional_state_bags():
    from gspace.actions import ActionPlan

    remote = Remote()
    core = ActionService((profile(),), remote.factory)
    good = core.preview(tag()).model_dump()
    for bad in (
        {**good, "kind": "blocked"},
        {**good, "confirmation": None},
        {**good, "expires_at": None},
        {**good, "executed": True},
    ):
        with pytest.raises(ValidationError):
            TypeAdapter(ActionPlan).validate_python(bad)
    remote.missing_policy = True
    blocked = core.preview(tag()).model_dump()
    with pytest.raises(ValidationError):
        TypeAdapter(ActionPlan).validate_python({**blocked, "confirmation": "a" * 43})


def test_source_tag_pipeline_protection_is_checked():
    remote = Remote()
    original = remote.handle

    def handler(request):
        path = request.url.path
        if path.endswith("/pipelines/901"):
            remote.calls.append(("GET", "projects/42/pipelines/901", b""))
            return httpx.Response(
                200,
                json={
                    "id": 901,
                    "ref": "flight-2.4.10",
                    "sha": SHA,
                    "status": "failed",
                    "tag": True,
                },
            )
        if "/repository/tags/" in path:
            remote.calls.append(("GET", "projects/42/repository/tags/flight-2.4.10", b""))
            return httpx.Response(
                200, json={"name": "flight-2.4.10", "commit": {"id": SHA}, "protected": True}
            )
        return original(request)

    remote.http = httpx.MockTransport(handler)
    core = ActionService((profile(),), remote.factory)
    permission = core.probe(
        ChangePipeline(
            profile="lab-owner",
            project={"value": 42},
            id={"value": 901},
            expected_sha=SHA,
            operation="retry",
        )
    )
    assert permission.kind == "denied" and "Protected source" in permission.reason
    assert all(m == "GET" for m, _, _ in remote.calls)


def test_export_is_deterministic_fixture_only_and_detects_drift(tmp_path, monkeypatch):
    from gspace.glab import GlabAdapter
    from scripts.export_openapi import schema_text

    monkeypatch.setattr(GlabAdapter, "get", lambda *_: pytest.fail("Unexpected remote schema call"))
    first = schema_text()
    assert first == schema_text()
    schema = json.loads(first)
    assert (
        schema["components"]["schemas"]["MRCatalogResponse"]["properties"]["total"]["type"]
        == "integer"
    )
    assert "secret_env" not in first
    output = tmp_path / "schema.json"
    output.write_text(first + " ")
    import subprocess
    import sys

    result = subprocess.run(
        [sys.executable, "scripts/export_openapi.py", str(output), "--check"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 1 and "drift" in result.stderr
    assert output.read_text() == first + " "


def test_profile_cache_fingerprint_is_bound_to_identity(tmp_path, monkeypatch):
    import gspace.service as module

    live = LiveConfig(
        hostname="127.0.0.1:8929",
        web_origin="http://127.0.0.1:8929",
        transport="isolated_loopback_http",
        projects=(ProjectConfig(id=ProjectId(value=42), path="lab/main"),),
    )
    config = AppConfig(
        mode="live",
        live=live,
        access_profiles=(profile(),),
        active_profile="lab-owner",
        preferences_path=tmp_path / "preferences.toml",
        cache_path=tmp_path / "cache.json",
    )
    remote = Remote()
    monkeypatch.setattr(module, "ProfileTransport", remote.factory)
    service = Service(config)
    initial = service._fingerprint()
    remote.identity = 8
    assert service._fingerprint() != initial
    assert all(method == "GET" for method, _, _ in remote.calls)
