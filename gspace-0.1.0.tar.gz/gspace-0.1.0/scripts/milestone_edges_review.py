"""Render synthetic milestone date edges with raw dates preserved, using owned loopback only."""

from __future__ import annotations

import argparse
import json
import re
import sys
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from gspace.milestones import catalog  # noqa: E402
from gspace.models import MilestoneFilter, ProjectId  # noqa: E402
from tests.milestone_edge_fixture import edge_catalog, edge_snapshot  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/milestone-edges-browser-20261007"
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    original = edge_catalog().model_dump(mode="json")
    malformed = deepcopy(original)
    negative = deepcopy(malformed["entries"][0])
    negative["milestone"].update(
        title="Reversed negative response",
        start_date="2026-10-09",
        due_date="2026-10-05",
        key={"kind": "project", "project": {"value": 42}, "id": {"value": 799999}},
        iid={"value": 599},
        link={
            "url": "https://gitlab.example.invalid/demo/flight-service/-/milestones/599",
            "verification": "fixture",
        },
    )
    negative.update(
        date_current="unknown",
        date_reason="Invalid synthetic range: due before start",
        work_items=0,
        opened_work_items=0,
        visible_work_items=0,
    )
    malformed["entries"].append(negative)
    (args.output / "valid-catalog.json").write_text(json.dumps(original, indent=2) + "\n")
    (args.output / "malformed-negative-catalog.json").write_text(
        json.dumps(malformed, indent=2) + "\n"
    )
    checks, outside, errors, measurements = [], [], [], []
    payload = {"value": original}
    with fixture_server(args.assets.resolve()) as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(service_workers="block", timezone_id="Pacific/Honolulu")

        def guard(route):
            url = urlsplit(route.request.url)
            if url.scheme == "http" and url.hostname == "127.0.0.1" and url.port == port:
                route.continue_()
            else:
                outside.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.set_default_timeout(5000)
        page.on("pageerror", lambda error: errors.append(str(error)))
        # A different browser year/timezone proves the Today marker is catalog data.
        page.clock.install(time=datetime(2030, 1, 1, 12, tzinfo=UTC))

        def response(route):
            assert route.request.method == "GET"
            route.fulfill(
                status=200, content_type="application/json", body=json.dumps(payload["value"])
            )

        page.route(base + "/api/milestones*", response)

        def reload_catalog():
            page.reload()
            expect(page.locator(".tl")).to_be_visible()
            page.wait_for_timeout(200)
            page.wait_for_load_state("networkidle")

        def row(title):
            return page.locator(".tl-list > .tl-row").filter(
                has=page.locator(".tl-title", has_text=re.compile("^" + re.escape(title) + "$"))
            )

        def check(name, operation):
            try:
                operation()
                checks.append({"name": name, "passed": True})
            except Exception as error:
                checks.append({"name": name, "passed": False, "error": str(error)[:2000]})

        page.goto(base + "/#/milestones")
        page.evaluate("localStorage.setItem('gspace.mode','visual')")

        def run_case(theme, width):
            page.set_viewport_size({"width": width, "height": 1100 if width > 500 else 844})
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            suffix = f"{theme}-{width}"
            payload["value"] = original

            def valid_ranges():
                reload_catalog()
                expect(row("Start only").locator(".tl-dates")).to_have_text(
                    "2026-10-07 → no due date"
                )
                expect(row("Due only").locator(".tl-dates")).to_have_text(
                    "no start date → 2026-10-07"
                )
                expect(row("Start only").locator(".tl-open-end.t-unknown")).to_have_count(1)
                expect(row("Due only").locator(".tl-open-start.t-unknown")).to_have_count(1)
                for title in ("Start only", "Due only", "Missing dates"):
                    expect(row(title).locator(".tl-facts")).to_contain_text("Unknown")
                expect(row("Missing dates").locator(".tl-nodate")).to_have_text(
                    "No start or due date"
                )
                expect(row("Missing dates").locator(".tl-bar")).to_have_count(0)
                for title in ("Exact start", "Exact due", "Same day"):
                    expect(row(title).locator(".tl-facts")).to_contain_text("Date-current")
                for title in ("Not started", "Past due", "Closed range"):
                    expect(row(title).locator(".tl-facts")).to_contain_text("Not current")
                expect(page.locator(".tl-today-l")).to_have_text("Today 2026-10-07")
                assert page.evaluate("new Date().getFullYear()") == 2030
                boxes = page.locator(".tl-list .tl-bar").evaluate_all(
                    "els=>els.map(e=>{const b=e.getBoundingClientRect();"
                    "const t=e.parentElement.getBoundingClientRect();"
                    "return {left:b.left,right:b.right,width:b.width,"
                    "trackLeft:t.left,trackRight:t.right}})"
                )
                assert boxes and all(
                    b["width"] > 0
                    and b["left"] >= b["trackLeft"] - 1
                    and b["right"] <= b["trackRight"] + 1
                    for b in boxes
                ), boxes
                measurements.append({"theme": theme, "width": width, "valid_bar_bounds": boxes})
                page.screenshot(path=str(args.output / f"valid-{suffix}.png"), full_page=True)
                page.locator(".tl").screenshot(path=str(args.output / f"timeline-{suffix}.png"))
                if width == 390:
                    for title in (
                        "Start only",
                        "Due only",
                        "Missing dates",
                        "Exact start",
                        "Exact due",
                        "Same day",
                        "Not started",
                        "Past due",
                        "Closed range",
                    ):
                        target = row(title)
                        target.scroll_into_view_if_needed()
                        slug = title.lower().replace(" ", "-")
                        target.screenshot(path=str(args.output / f"row-{slug}-{suffix}.png"))

            check(f"partial/missing/inclusive/closed dates and server Today {suffix}", valid_ranges)
            for day, expected in ((6, "Not current"), (9, "Date-current"), (10, "Not current")):

                def boundary(day=day, expected=expected):
                    snapshot = edge_snapshot()
                    payload["value"] = catalog(
                        snapshot,
                        "fixture",
                        (ProjectId(value=42), ProjectId(value=99)),
                        MilestoneFilter(),
                        snapshot.items,
                        "Europe/Zurich",
                        now=datetime(2026, 10, day, 10, tzinfo=UTC),
                    ).model_dump(mode="json")
                    reload_catalog()
                    expect(row("Exact start").locator(".tl-facts")).to_contain_text(expected)
                    expect(page.locator(".tl-today-l")).to_have_text(f"Today 2026-10-{day:02}")
                    expect(row("Exact start").locator(".tl-dates")).to_have_text(
                        "2026-10-07 → 2026-10-09"
                    )

                check(f"timeline exact/outside interval day{day} {suffix}", boundary)

            def reversed_range():
                payload["value"] = malformed
                reload_catalog()
                r = row("Reversed negative response")
                expect(r.locator(".tl-dates")).to_have_text(
                    "2026-10-09 → 2026-10-05 (due before start)"
                )
                expect(r.locator(".tl-bar.t-warn")).to_have_count(1)
                expect(r.locator(".tl-facts")).to_contain_text("Unknown")
                expect(r.locator(".tl-facts")).not_to_contain_text("Date-current")
                page.screenshot(path=str(args.output / f"reversed-{suffix}.png"), full_page=True)
                r.scroll_into_view_if_needed()
                r.screenshot(path=str(args.output / f"reversed-row-{suffix}.png"))

            check(
                f"malformed reversed response warns and retains original dates {suffix}",
                reversed_range,
            )

        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            run_case(theme, width)
        browser.close()
    failed = sum(not row["passed"] for row in checks) + len(outside) + len(errors)
    report = {
        "purpose": __doc__,
        "checks": checks,
        "measurements": measurements,
        "outside": outside,
        "js_errors": errors,
        "failed": failed,
        "negative_fixture_scope": "Reversed ranges are rejected by Python domain validation; "
        "malformed HTTP row exercises existing defensive rendering only",
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"checks": len(checks), "failed": failed}))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
