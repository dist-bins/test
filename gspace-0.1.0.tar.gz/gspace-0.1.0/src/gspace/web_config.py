"""Operator-owned public web URL; never inferred from untrusted forwarding headers."""

from __future__ import annotations

import re
from urllib.parse import urlsplit

from pydantic import Field, field_validator

from gspace.models import Model

LOCAL_HOSTS = ("localhost", "127.0.0.1", "[::1]", "testserver")


class WebConfig(Model, frozen=True):
    public_url: str | None = Field(default=None, max_length=2048)

    @field_validator("public_url")
    @classmethod
    def exact_public_url(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not value.isascii() or any(ord(character) <= 32 for character in value):
            raise ValueError("Public URL must be an explicit ASCII HTTP URL")
        parsed = urlsplit(value)
        if (
            parsed.scheme not in ("http", "https")
            or not parsed.hostname
            or parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
            or "?" in value
            or "#" in value
            or "\\" in value
        ):
            raise ValueError(
                "Public URL needs an exact HTTP origin/path without credentials or query"
            )
        host = parsed.hostname.lower()
        if ":" not in host and not all(
            re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
            for label in host.split(".")
        ):
            raise ValueError("Public URL needs one exact hostname")
        path = parsed.path
        if not re.fullmatch(r"(?:/[A-Za-z0-9_.~-]+)*/?", path) or any(
            segment in (".", "..") for segment in path.split("/")
        ):
            raise ValueError("Public URL path must contain unambiguous plain path segments")
        if path.split("/")[1:2] in (["api"], ["assets"]):
            raise ValueError("Public path prefix cannot overlap the application api/assets routes")
        port = parsed.port
        if port is not None and not 1 <= port <= 65535:
            raise ValueError("Invalid public port")
        authority = f"[{host}]" if ":" in host else host
        if port is not None and port != (443 if parsed.scheme == "https" else 80):
            authority += f":{port}"
        return f"{parsed.scheme}://{authority}{path.rstrip('/')}/"

    @property
    def root_path(self) -> str:
        return urlsplit(self.public_url).path.rstrip("/") if self.public_url else ""

    @property
    def public_origin(self) -> str | None:
        if self.public_url is None:
            return None
        parsed = urlsplit(self.public_url)
        return f"{parsed.scheme}://{parsed.netloc}"

    @property
    def public_host(self) -> str | None:
        host = urlsplit(self.public_url).hostname if self.public_url else None
        return f"[{host}]" if host and ":" in host else host
