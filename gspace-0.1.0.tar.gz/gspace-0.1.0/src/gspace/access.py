"""Explicit profile transports. Secrets never enter models, stdout, URLs or argv."""

from __future__ import annotations

import http.client
import json
import os
import re
import shutil
import socket
import threading
import time
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass
from functools import partial
from typing import TypeVar
from urllib.parse import urlencode, urlsplit

import httpx
from pydantic import BaseModel, TypeAdapter, ValidationError

from gspace.access_models import AccessProfile, GlabProfile, PatProfile
from gspace.config import ProjectConfig
from gspace.glab import AdapterError, RunResult, run_argv
from gspace.models import PipelineKey
from gspace.observation import ObservationFailure, PinnedTLS, resolve_address
from gspace.pipeline_query import PIPELINE_QUERY, pipeline_argv, pipeline_variables

T = TypeVar("T", bound=BaseModel)
SecretResolver = Callable[[str], str | None]


class AccessError(AdapterError):
    pass


@dataclass(frozen=True)
class _ApiPolicy:
    url: str
    allowed_origins: tuple[str, ...]
    allowed_networks: tuple[str, ...]
    allow_http: bool
    timeout_seconds: float = 10.0
    max_bytes: int = 5_000_000
    max_redirects: int = 0


def pinned_api_request(
    profile: PatProfile,
    token: str,
    method: str,
    path: str,
    body: dict[str, object] | None,
    query: dict[str, str] | None,
) -> object:
    """One pinned connection, verified TLS, no redirects/proxies, one total deadline."""
    origin = urlsplit(profile.host)
    port = origin.port or (443 if origin.scheme == "https" else 80)
    host = origin.hostname
    if host is None:
        raise AccessError("configuration", "Configured API host is unavailable")
    policy = _ApiPolicy(
        url=profile.host,
        allowed_origins=(profile.host,),
        allowed_networks=profile.allowed_networks
        or (("127.0.0.1/32",) if origin.scheme == "http" else ()),
        allow_http=origin.scheme == "http",
    )
    deadline = time.monotonic() + policy.timeout_seconds
    address = resolve_address(host, port, policy, policy.timeout_seconds)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise AccessError("timeout", "Configured API total deadline expired; no automatic retry")
    connection: http.client.HTTPConnection = (
        PinnedTLS(host, port, address, remaining)
        if origin.scheme == "https"
        else http.client.HTTPConnection(address, port, timeout=remaining)
    )
    active_socket: socket.socket | None = None
    response: http.client.HTTPResponse | None = None

    def abort() -> None:
        connected = active_socket or connection.sock
        if connected is not None:
            with suppress(OSError):
                connected.shutdown(socket.SHUT_RDWR)
        connection.close()

    timer = threading.Timer(remaining, abort)
    timer.daemon = True
    timer.start()
    try:
        target = path + ("?" + urlencode(query) if query else "")
        headers = {"Host": origin.netloc, "Accept": "application/json", "PRIVATE-TOKEN": token}
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        connection.request(method, target, body=data, headers=headers)
        # HTTP/1.0 or Connection: close transfers ownership to HTTPResponse.
        active_socket = connection.sock
        response = connection.getresponse()
        if response.status in (401, 403):
            raise AccessError("denied", "Access denied or revoked; no automatic retry")
        if not 200 <= response.status < 300:
            raise AccessError("remote", f"Configured API returned status {response.status}")
        if response.getheader("Content-Encoding", "identity").lower() != "identity":
            raise AccessError("limit", "Compressed API response is unsupported")
        if response.length is not None and response.length > policy.max_bytes:
            raise AccessError("limit", "Response exceeded size limit")
        output = bytearray()
        while len(output) <= policy.max_bytes:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise AccessError(
                    "timeout", "Configured API total deadline expired; no automatic retry"
                )
            if active_socket is not None:
                active_socket.settimeout(remaining)
            chunk = response.read1(min(65536, policy.max_bytes + 1 - len(output)))
            if not chunk:
                break
            output.extend(chunk)
        if len(output) > policy.max_bytes:
            raise AccessError("limit", "Response exceeded size limit")
        if response.length not in (None, 0):
            raise AccessError("transport", "Configured API response was incomplete")
        return json.loads(output)
    finally:
        timer.cancel()
        if response is not None:
            response.close()
        connection.close()


class ProfileTransport:
    def __init__(
        self,
        profile: AccessProfile,
        *,
        resolver: SecretResolver = os.environ.get,
        http_transport: httpx.BaseTransport | None = None,
        runner: Callable[[list[str], float], RunResult] = run_argv,
    ) -> None:
        self.profile = profile
        self._resolver = resolver
        self._http_transport = http_transport
        self._runner = (
            partial(
                run_argv,
                api_protocol="http" if urlsplit(profile.host).scheme == "http" else "https",
                reject_redirects=isinstance(profile, GlabProfile) and profile.reject_redirects,
            )
            if runner is run_argv
            else runner
        )

    def executable(self) -> str:
        if not isinstance(self.profile, GlabProfile):
            raise AccessError("profile", "This profile does not use a glab executable")
        if self.profile.executable == "glab" and self.profile.reject_redirects:
            return "glab"  # Only explicit strict mode selects the private companion.
        resolved = shutil.which(self.profile.executable)
        if resolved is None:
            raise AccessError("unavailable", "Configured glab launcher is unavailable")
        return resolved

    def version(self) -> str | None:
        if isinstance(self.profile, GlabProfile):
            result = self._runner(
                [self.executable(), *self.profile.launcher_arguments, "--version"], 5
            )
            match = re.search(rb"glab(?: version)? ([0-9]+\.[0-9]+\.[0-9]+)", result.stdout[:256])
            if result.code or match is None:
                raise AccessError("launcher", "Configured launcher did not identify as glab")
            return match.group(1).decode()
        return None

    def path(self, path: str) -> None:
        common = path in ("user", "version", "metadata", "personal_access_tokens/self")
        matched = re.fullmatch(
            r"projects/(\d+)(?:/(issues(?:/\d+/(?:related_merge_requests|closed_by))?|milestones|"
            r"merge_requests(?:/\d+(?:/(?:merge|rebase|pipelines))?)?|"
            r"pipelines(?:/\d+(?:/(?:retry|cancel|jobs))?)?|jobs/\d+(?:/(?:retry|cancel|play))?|"
            r"repository/(?:branches(?:/[^/?#]+)?|tags(?:/[^/?#]+)?)|deployments|"
            r"protected_tags|protected_branches))?",
            path,
        )
        if not common and (
            matched is None or int(matched.group(1)) not in {p.value for p in self.profile.projects}
        ):
            raise AccessError("scope", "Request exceeds configured profile project/path scope")
        if any(c in path for c in ("\\", "..")):
            raise AccessError("scope", "Unsafe API path")

    def request(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, object] | None = None,
        query: dict[str, str] | None = None,
    ) -> object:
        self.path(path)
        if method not in ("GET", "POST", "PUT"):
            raise AccessError("scope", "Unsupported HTTP method")
        if method != "GET":
            writable = (
                re.fullmatch(
                    r"projects/\d+/(?:merge_requests|repository/tags|pipelines|"
                    r"pipelines/\d+/(?:retry|cancel)|jobs/\d+/(?:retry|cancel|play))",
                    path,
                )
                if method == "POST"
                else re.fullmatch(r"projects/\d+/merge_requests/\d+", path)
            )
            if writable is None:
                raise AccessError("scope", "Mutation path is outside the finite action allowlist")
            if (
                not self.profile.write_enabled
                or self.profile.host.rstrip("/") != "http://127.0.0.1:8929"
            ):
                raise AccessError(
                    "disabled", "Writes are enabled only in the explicitly configured synthetic lab"
                )
            if isinstance(self.profile, GlabProfile):
                raise AccessError(
                    "unknown",
                    "Glab profile write transport is deferred; use approved lab PAT profile",
                )
        if isinstance(self.profile, GlabProfile):
            endpoint = path + ("?" + urlencode(query) if query else "")
            argv = [
                self.executable(),
                *self.profile.launcher_arguments,
                "api",
                "--hostname",
                urlsplit(self.profile.host).netloc,
                "--method",
                "GET",
                endpoint,
            ]
            result = self._runner(argv, 10)
            if result.code:
                raise AccessError("remote", "Configured glab GET failed; diagnostics were redacted")
            try:
                return json.loads(result.stdout)
            except ValueError as error:
                raise AccessError("validation", "Invalid glab JSON response") from error
        return self._pat(method, path, body, query)

    def _pat(
        self,
        method: str,
        path: str,
        body: dict[str, object] | None,
        query: dict[str, str] | None,
        *,
        graphql: bool = False,
    ) -> object:
        profile = self.profile
        if not isinstance(profile, PatProfile):
            raise AccessError("profile", "PAT profile required")
        try:
            token = self._resolver(profile.secret_env)
        except Exception as error:
            raise AccessError("missing_secret", "Configured PAT secret is unavailable") from error
        if not token or len(token) > 512 or any(ord(c) < 33 for c in token):
            raise AccessError("missing_secret", "Configured PAT secret is unavailable or invalid")
        try:
            if self._http_transport is None:
                target = "/api/graphql" if graphql else "/api/v4/" + path
                return pinned_api_request(profile, token, method, target, body, query)
            with (
                httpx.Client(
                    base_url=profile.host.rstrip("/") + ("/" if graphql else "/api/v4/"),
                    timeout=10,
                    trust_env=False,
                    follow_redirects=False,
                    verify=True,
                    transport=self._http_transport,
                ) as client,
                client.stream(
                    method,
                    "api/graphql" if graphql else path,
                    headers={"PRIVATE-TOKEN": token},
                    json=body,
                    params=query,
                ) as response,
            ):
                if response.status_code in (401, 403):
                    raise AccessError("denied", "Access denied or revoked; no automatic retry")
                if not 200 <= response.status_code < 300:
                    raise AccessError(
                        "remote", f"Configured API returned status {response.status_code}"
                    )
                output = bytearray()
                for block in response.iter_bytes():
                    output.extend(block)
                    if len(output) > 5_000_000:
                        raise AccessError("limit", "Response exceeded size limit")
                return json.loads(output)
        except ObservationFailure as error:
            raise AccessError(
                "scope", "Configured API destination rejected by network policy"
            ) from error
        except (
            httpx.HTTPError,
            ValueError,
            OSError,
            http.client.HTTPException,
            RecursionError,
        ) as error:
            if isinstance(error, AccessError):
                raise
            raise AccessError(
                "transport", "Configured API transport or JSON failed; details redacted"
            ) from error

    def get(self, path: str, dto: type[T]) -> T:
        try:
            return dto.model_validate(self.request("GET", path))
        except ValidationError as error:
            raise AccessError(
                "validation", "Remote data does not match pinned API contract"
            ) from error

    def pipeline_graphql(
        self, project: ProjectConfig, key: PipelineKey, cursor: str | None
    ) -> object:
        """Fixed read operation via POST; never enters the finite mutation transport."""
        if key.project not in self.profile.projects or project.id != key.project:
            raise AccessError("scope", "Pipeline graph exceeds profile project scope")
        variables = pipeline_variables(project, key, cursor)
        if isinstance(self.profile, GlabProfile):
            result = self._runner(
                pipeline_argv(
                    [self.executable(), *self.profile.launcher_arguments],
                    urlsplit(self.profile.host).netloc,
                    project,
                    key,
                    cursor,
                ),
                10,
            )
            if len(result.stdout) > 5_000_000:
                raise AccessError("limit", "Pipeline graph response exceeds byte limit")
            try:
                body = TypeAdapter[dict[str, object]](dict[str, object]).validate_python(
                    json.loads(result.stdout)
                )
            except (ValueError, ValidationError) as error:
                raise AccessError("validation", "Invalid native pipeline graph response") from error
            if result.code and (not body.get("data") or not body.get("errors")):
                raise AccessError("remote", "Native pipeline graph read failed; details redacted")
            return body
        return self._pat(
            "POST", "", {"query": PIPELINE_QUERY, "variables": variables}, None, graphql=True
        )

    def pages(self, path: str, dto: type[T]) -> tuple[T, ...]:
        values: list[T] = []
        for page in range(1, 21):
            raw = self.request("GET", path, query={"page": str(page), "per_page": "100"})
            if not isinstance(raw, list):
                raise AccessError("validation", "Expected a paginated list")
            rows = TypeAdapter[list[object]](list[object]).validate_python(raw)
            try:
                values.extend(dto.model_validate(row) for row in rows)
            except ValidationError as error:
                raise AccessError("validation", "Invalid paginated remote data") from error
            if len(rows) < 100:
                return tuple(values)
        raise AccessError("limit", "Pagination limit exceeded; coverage remains unknown")
