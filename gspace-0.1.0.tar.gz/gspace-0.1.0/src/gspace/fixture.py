"""Synthetic situations that deliberately separate pipeline, deployment and runtime evidence."""

from datetime import UTC, date, datetime
from hashlib import sha1

from gspace.models import (
    ApplicationTestRecord,
    Association,
    Branch,
    Deployment,
    Environment,
    EnvironmentName,
    GroupId,
    GroupMilestoneKey,
    IssueIid,
    Job,
    JobId,
    Link,
    MergeRequest,
    Milestone,
    MilestoneId,
    MilestoneIid,
    MrIid,
    MrState,
    Observed,
    Origin,
    Pipeline,
    PipelineId,
    ProjectId,
    ProjectMilestoneKey,
    Publish,
    RebaseVerified,
    Snapshot,
    Status,
    Tag,
    Unknown,
    Version,
    WorkItem,
    WorkKey,
)

NOW = datetime(2026, 10, 5, 20, 0, tzinfo=UTC)


def synthetic_snapshot() -> Snapshot:
    project = ProjectId(value=42)
    path = "demo/flight-service"
    base = f"https://gitlab.example.invalid/{path}/-/"

    def link(suffix: str) -> Link:
        return Link(url=base + suffix, verification="fixture")

    items: list[WorkItem] = []
    titles = (
        "Preserve passenger preferences during rescheduling",
        "Add airport transfer availability",
        "Correct overnight connection pricing",
        "Expose baggage allowance in the itinerary",
        "Archive retired fare rules",
        "Validate loyalty programme identifiers",
        "Revise ground handling dispatch",
    )
    for offset, title in enumerate(titles):
        if offset == 6:
            project = ProjectId(value=99)
            path = "demo/ground-service"
            base = f"https://gitlab.example.invalid/{path}/-/"
        iid = 791 if offset == 6 else 791 + offset
        sha = sha1(
            f"synthetic-commit-{project.value}-{iid}".encode(), usedforsecurity=False
        ).hexdigest()
        previous_sha = sha1(f"previous-commit-{iid}".encode(), usedforsecurity=False).hexdigest()
        branch_name = f"issue-{iid}"
        mr_number = 154 + offset
        pipeline_number = 9201 + offset * 10
        association = Association(
            origin=Origin.CONVENTION, reason=f"Exact issue branch convention {branch_name}"
        )
        branch = Branch(
            project=project,
            name=branch_name,
            sha=sha,
            association=association,
            rebase=RebaseVerified(
                source_sha=sha,
                target_branch="main",
                required=offset == 1,
                behind=3 if offset == 1 else 0,
                source=f"Synthetic MR !{mr_number} diverged_commits_count",
                checked_at=NOW,
            )
            if offset < 2
            else Unknown(reason="Target branch ancestry has not been checked"),
            link=link("tree/" + branch_name),
        )
        jobs = (
            Job(
                project=project,
                id=JobId(value=pipeline_number * 10),
                name="unit-tests",
                stage="test",
                status=Status.FAILED if offset == 0 else Status.SUCCESS,
                attempt=2 if offset == 2 else 1,
                retried=False,
                failure_reason="script_failure" if offset == 0 else None,
                link=link(f"jobs/{pipeline_number * 10}"),
            ),
            Job(
                project=project,
                id=JobId(value=pipeline_number * 10 + 1),
                name="publish-nexus",
                stage="publish",
                status=Status.SUCCESS,
                attempt=1,
                retried=False,
                link=link(f"jobs/{pipeline_number * 10 + 1}"),
            ),
            Job(
                project=project,
                id=JobId(value=pipeline_number * 10 + 2),
                name="deploy-dev",
                stage="deploy",
                status=Status.MANUAL,
                attempt=1,
                retried=False,
                link=link(f"jobs/{pipeline_number * 10 + 2}"),
            ),
        )
        if offset == 2:
            jobs += (
                Job(
                    project=project,
                    id=JobId(value=pipeline_number * 10 - 1),
                    name="unit-tests",
                    stage="test",
                    status=Status.FAILED,
                    attempt=1,
                    retried=True,
                    failure_reason="script_failure",
                    link=link(f"jobs/{pipeline_number * 10 - 1}"),
                ),
            )
        pipeline = Pipeline(
            project=project,
            id=PipelineId(value=pipeline_number),
            ref=branch_name,
            sha=sha,
            source="merge_request_event",
            status=Status.FAILED if offset == 0 else Status.SUCCESS,
            jobs=jobs,
            association=Association(
                origin=Origin.API, reason=f"Synthetic MR !{mr_number} pipeline"
            ),
            link=link(f"pipelines/{pipeline_number}"),
        )
        tag_name = f"flight-2.4.{8 + offset:02}"
        tag = Tag(
            project=project,
            name=tag_name,
            sha=sha,
            association=Association(
                origin=Origin.OPERATOR,
                reason="Operator confirmed tag created from this branch",
                overrides="SHA-only association",
            ),
            link=link("tags/" + tag_name),
        )
        tag_jobs = (
            Job(
                project=project,
                id=JobId(value=pipeline_number * 10 + 3),
                name="deploy-preprod",
                stage="deploy",
                status=Status.SUCCESS if offset == 2 else Status.MANUAL,
                attempt=1,
                retried=False,
                link=link(f"jobs/{pipeline_number * 10 + 3}"),
            ),
        )
        tag_pipeline = Pipeline(
            project=project,
            id=PipelineId(value=pipeline_number + 1),
            ref=tag_name,
            sha=sha,
            source="push",
            status=Status.SUCCESS,
            jobs=tag_jobs,
            association=Association(
                origin=Origin.API, reason="Synthetic tag pipeline with matching tag ref"
            ),
            link=link(f"pipelines/{pipeline_number + 1}"),
        )
        deployment = Deployment(
            project=project,
            id=3001 + offset,
            status=Status.SUCCESS,
            ref=branch_name,
            sha=previous_sha if offset == 1 else sha,
            source="Synthetic GitLab deployment record; independent from latest pipeline",
            link=link(f"environments/{100 + offset}"),
        )
        dev_observation = (
            Observed(
                value=Version(branch=branch_name, sha=previous_sha if offset == 1 else sha),
                source="Synthetic OpenAPI info.x-build.branch/sha",
                checked_at=NOW,
            )
            if offset < 3
            else Unknown(reason="Configure a dev Swagger endpoint to observe the runtime")
        )
        preprod_observation = (
            Observed(
                value=Version(tag=tag_name, sha=sha),
                source="Synthetic Swagger #build-tag and #build-sha",
                checked_at=NOW,
            )
            if offset == 2
            else Unknown(reason="No preprod version observation available")
        )
        mrs = (
            MergeRequest(
                project=project,
                source_project=project,
                iid=MrIid(value=mr_number),
                title=title,
                state=MrState.MERGED if offset == 4 else MrState.OPEN,
                draft=offset != 4,
                source_branch=branch_name,
                target_branch="main",
                source_sha=sha,
                association=Association(
                    origin=Origin.API, reason="MR source_branch matches associated branch"
                ),
                link=link(f"merge_requests/{mr_number}"),
            ),
        )
        if offset == 0:
            # One issue can have more than one branch and MR. Numbers are deliberately unrelated.
            mrs += (
                MergeRequest(
                    project=project,
                    source_project=project,
                    iid=MrIid(value=209),
                    title="Follow-up integration for passenger preferences",
                    state=MrState.CLOSED,
                    draft=False,
                    source_branch="passenger-followup",
                    target_branch="main",
                    source_sha=previous_sha,
                    association=Association(
                        origin=Origin.OPERATOR,
                        reason="Related follow-up recorded manually",
                        overrides="branch convention",
                    ),
                    link=link("merge_requests/209"),
                ),
            )
        item_branches = (branch,)
        if offset == 0:
            item_branches += (
                Branch(
                    project=project,
                    name="passenger-followup",
                    sha=previous_sha,
                    association=Association(
                        origin=Origin.OPERATOR,
                        reason="Historical follow-up branch explicitly related to this issue",
                        overrides="issue branch naming convention",
                    ),
                    rebase=Unknown(reason="Historical branch ancestry has not been checked"),
                    link=link("tree/passenger-followup"),
                ),
            )
        items.append(
            WorkItem(
                identity=WorkKey(project=project, issue=IssueIid(value=iid)),
                project_path=path,
                title=title,
                state="closed" if offset == 4 else "opened",
                assigned_to_me=offset < 5,
                labels=("booking", "release-2.4") if offset != 2 else ("pricing", "release-2.4"),
                link=link(f"issues/{iid}"),
                branches=item_branches,
                merge_requests=mrs,
                pipelines=(pipeline, tag_pipeline),
                tags=(tag,),
                publishes=(
                    Publish(
                        pipeline=pipeline.id,
                        job=jobs[1].id,
                        status=Status.SUCCESS,
                        artifact=f"demo.flight:flight-service:2.4.{8 + offset}",
                        source="Synthetic Nexus fixture, independently supplied artifact identity",
                    ),
                ),
                environments=(
                    Environment(
                        name=EnvironmentName.DEV,
                        expected=Version(branch=branch_name, sha=sha),
                        observation=dev_observation,
                        deployments=(deployment,),
                        application_test="failed" if offset == 1 else "unconfirmed",
                    ),
                    Environment(
                        name=EnvironmentName.PREPROD,
                        expected=Version(tag=tag_name, sha=sha),
                        observation=preprod_observation,
                        deployments=(
                            Deployment(
                                project=project,
                                id=4003,
                                status=Status.SUCCESS,
                                ref=tag_name,
                                sha=sha,
                                source="Synthetic tag deployment record",
                                link=link("environments/203"),
                            ),
                        )
                        if offset == 2
                        else (),
                        application_test="passed" if offset == 2 else "unconfirmed",
                    ),
                ),
            )
        )
    milestone_rows = (
        (
            ProjectMilestoneKey(project=ProjectId(value=42), id=MilestoneId(value=701)),
            11,
            "Flight October",
            date(2026, 10, 1),
            date(2026, 10, 15),
            "demo/flight-service",
        ),
        (
            GroupMilestoneKey(group=GroupId(value=9), id=MilestoneId(value=702)),
            11,
            "Shared October",
            date(2026, 10, 1),
            date(2026, 10, 15),
            "groups/demo",
        ),
        (
            ProjectMilestoneKey(project=ProjectId(value=42), id=MilestoneId(value=703)),
            12,
            "Next flight",
            date(2026, 10, 16),
            date(2026, 10, 31),
            "demo/flight-service",
        ),
        (
            ProjectMilestoneKey(project=ProjectId(value=42), id=MilestoneId(value=704)),
            13,
            "Undated active",
            None,
            None,
            "demo/flight-service",
        ),
    )
    milestones = tuple(
        Milestone(
            key=key,
            iid=MilestoneIid(value=iid),
            title=title,
            state="active",
            start_date=start,
            due_date=end,
            link=Link(
                url=f"https://gitlab.example.invalid/{owner}/-/milestones/{iid}",
                verification="fixture",
            ),
        )
        for key, iid, title, start, end, owner in milestone_rows
    )
    membership = {"42:791": 0, "42:792": 0, "42:793": 1, "99:791": 1, "42:794": 2, "42:795": 3}
    for index, item in enumerate(items):
        chosen = membership.get(item.identity.key)
        if chosen is not None:
            data = item.model_dump()
            data["milestone"] = milestones[chosen].key
            items[index] = WorkItem.model_validate(data)
    return Snapshot(
        source="fixture",
        gitlab_version="18.11.12",
        fetched_at=NOW,
        items=tuple(items),
        milestones=milestones,
        issue_coverage="complete_configured_projects",
        application_tests=tuple(
            ApplicationTestRecord(
                key=item.identity,
                environment=env.name,
                version=env.expected,
                outcome=env.application_test,
                checked_at=NOW,
                source="fixture",
                notes="Explicit synthetic application outcome bound to this fixture commit",
            )
            for item in items
            for env in item.environments
            if env.application_test in ("passed", "failed") and env.expected is not None
        ),
        warnings=("Synthetic data: links use example.invalid and are not live endpoints",),
    )
