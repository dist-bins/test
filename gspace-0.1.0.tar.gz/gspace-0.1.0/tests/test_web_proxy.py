import json

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from gspace.api import create_app
from gspace.cli_commands import prepare
from gspace.config import AppConfig, load_config
from gspace.service import Service
from gspace.web_config import WebConfig

PREFIX = "/workspace/example/proxy/8876"
PUBLIC = "https://devpod.example.invalid" + PREFIX + "/"


def configured(tmp_path, public_url=PUBLIC):
    return AppConfig(
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
        web=WebConfig(public_url=public_url),
    )


@pytest.mark.parametrize(
    "value",
    [
        "https://user:secret@example.invalid/proxy/8876/",
        "https://example.invalid/proxy/8876/?token=private",
        "https://example.invalid/proxy/8876/#fragment",
        "https://*.example.invalid/",
        "ftp://example.invalid/",
        "//example.invalid/",
        "https://example.invalid/a/../b/",
        "https://example.invalid//proxy/8876/",
        "https://example.invalid/%2fproxy/",
        "https://example.invalid/\\proxy/",
        "https://example.invalid/\nproxy/",
        "https://example.invalid/api/",
        "https://example.invalid/assets/nested/",
    ],
)
def test_public_url_rejects_ambiguous_or_credential_bearing_values(value):
    with pytest.raises(ValidationError):
        WebConfig(public_url=value)


def test_public_url_has_one_normalized_origin_and_prefix():
    config = WebConfig(public_url="https://DevPod.Example.invalid:443" + PREFIX + "/")
    assert config.public_origin == "https://devpod.example.invalid"
    assert config.root_path == PREFIX
    assert config.public_host == "devpod.example.invalid"
    assert WebConfig().root_path == ""
    assert WebConfig(public_url="http://[::1]:8876/").public_host == "[::1]"


@pytest.mark.parametrize("stripped", [False, True])
def test_configured_host_and_both_proxy_path_styles_work(tmp_path, stripped):
    client = TestClient(create_app(configured(tmp_path)), base_url="http://devpod.example.invalid")
    prefix = "" if stripped else PREFIX
    index = client.get(prefix + "/")
    assert index.status_code == 200
    assert f'content="{PREFIX}"' in index.text
    assert f'"{PREFIX}/assets/app.js"' in index.text
    assert client.get(prefix + "/assets/app.js").status_code == 200
    dashboard = client.get(prefix + "/api/dashboard")
    assert dashboard.status_code == 200 and dashboard.json()["total"] == 7
    assert "base-uri 'none'" in index.headers["content-security-policy"]
    settings = client.get(prefix + "/api/settings").json()
    assert "web" not in settings["settings"]
    settings["settings"]["timezone"] = "UTC"
    payload = {"revision": settings["revision"], "settings": settings["settings"]}
    saved = client.post(
        prefix + "/api/settings", json=payload, headers={"Origin": "https://devpod.example.invalid"}
    )
    assert saved.status_code == 200 and saved.json()["settings"]["timezone"] == "UTC"
    capabilities = client.get(prefix + "/api/capabilities").json()
    assert capabilities["remote_mutations"] is False


@pytest.mark.parametrize("origin", ["https://other.invalid", "http://devpod.example.invalid"])
def test_public_https_origin_rejects_wrong_origin_and_forged_forwarding(tmp_path, origin):
    client = TestClient(create_app(configured(tmp_path)), base_url="http://devpod.example.invalid")
    response = client.post(
        "/api/settings",
        json={},
        headers={
            "Origin": origin,
            "X-Forwarded-Proto": "https",
            "X-Forwarded-Host": "other.invalid",
        },
    )
    assert response.status_code == 403


def test_arbitrary_hosts_and_unconfigured_forwarded_hosts_are_not_trusted(tmp_path):
    for config in (configured(tmp_path), configured(tmp_path, public_url=None)):
        client = TestClient(create_app(config))
        response = client.get(
            "/", headers={"Host": "evil.invalid", "X-Forwarded-Host": "devpod.example.invalid"}
        )
        assert response.status_code == 400
        assert "Invalid host header" in response.text
    local = TestClient(create_app(configured(tmp_path, public_url=None)))
    assert local.get("/").status_code == 200
    assert local.get(PREFIX + "/api/dashboard").status_code == 404


def test_canonical_prefix_redirect_preserves_browser_scheme(tmp_path):
    client = TestClient(create_app(configured(tmp_path)), base_url="http://devpod.example.invalid")
    response = client.get(PREFIX, follow_redirects=False)
    assert response.status_code == 307
    assert response.headers["location"] == PREFIX + "/"


@pytest.mark.parametrize(
    "path,target", [("/api/dashboard/", "/api/dashboard"), ("/assets", "/assets/")]
)
@pytest.mark.parametrize("stripped", [False, True])
def test_other_route_redirects_also_preserve_public_scheme(tmp_path, path, target, stripped):
    client = TestClient(create_app(configured(tmp_path)), base_url="http://devpod.example.invalid")
    response = client.get(("" if stripped else PREFIX) + path, follow_redirects=False)
    assert response.status_code == 307
    assert response.headers["location"] == PREFIX + target


def test_external_web_policy_changes_require_restart(tmp_path):
    path = tmp_path / "config.toml"
    path.write_text('mode="fixture"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n')
    service = Service(load_config(path), config_path=path)
    client = TestClient(create_app(service=service))
    path.write_text(path.read_text() + "\n[web]\npublic_url=" + json.dumps(PUBLIC) + "\n")
    response = client.get("/api/settings")
    assert response.status_code == 400 and "restart" in response.json()["detail"]
    assert service.config.web.public_url is None


def test_web_command_is_an_alias_of_serve():
    args, topic, display = prepare(["web", "--config", "config.toml", "--port", "8876"])
    assert args == ["serve", "--config", "config.toml", "--port", "8876"]
    assert topic is None and display == "gspace web"
