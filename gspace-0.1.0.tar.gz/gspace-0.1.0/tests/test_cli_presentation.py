"""Presentation behavior, not golden snapshots: scope, width, semantics and terminal safety."""

import io
import json
import re
import subprocess
import sys

import pytest
from rich.cells import cell_len
from rich.console import Console
from rich.text import Text

from gspace import cli_render
from gspace.models import Association, Origin, Unknown, Version, WorkItem
from gspace.service import FlagChange, ItemView
from scripts.cli_visual_capture import capture, environment


def render(function, *args, width=120, color=False):
    output = io.StringIO()
    console = Console(
        file=output,
        width=width,
        theme=cli_render.THEME,
        force_terminal=color,  # Only a deterministic renderer test; product never forces TTY.
        color_system="standard" if color else None,
        highlight=False,
        markup=False,
    )
    function(*args, console)
    raw = output.getvalue()
    plain = Text.from_ansi(raw).plain
    assert all(cell_len(line) <= width for line in plain.splitlines())
    return raw, plain


@pytest.mark.parametrize("width", [40, 80, 120, 160])
@pytest.mark.parametrize("orientation", ["rows", "columns"])
def test_matrix_keeps_all_scoped_items_and_independent_states(service, width, orientation):
    data = service.dashboard(orientation=orientation)
    before = data.model_dump_json()
    _, plain = render(cli_render.matrix, data, width=width)
    for view in data.views:
        assert view.item.identity.key in plain
        for pipeline in view.item.pipelines:
            assert str(pipeline.id.value) in plain
        for mr in view.item.merge_requests:
            assert f"!{mr.iid.value}" in plain
    assert "failed" in plain and "success" in plain and "mismatch" in plain
    assert "unconfirmed" in plain and "unknown" in plain
    assert "override" in plain
    assert "…" not in plain  # No important identity/status is silently ellipsized.
    assert data.model_dump_json() == before
    if orientation == "columns" and width == 80:
        assert "Columns 1–2 of 4" in plain and "Columns 3–4 of 4" in plain
    if orientation == "columns" and width >= 120:
        assert "Columns 1–" not in plain  # All four can be compared together.


def test_selection_and_pin_have_plain_labels_and_json_is_unaffected(service, key):
    for operation in ("pin", "select"):
        service.change(
            FlagChange(
                revision=service.preferences.read().revision,
                key=key,
                operation=operation,
                enabled=True,
            )
        )
    data = service.dashboard(orientation="columns")
    _, plain = render(cli_render.matrix, data)
    assert "42:791 · sel · pin" in plain
    assert "[selected]" not in plain
    assert data.views[0].selected is True and data.views[0].pinned is True


def test_semantic_styles_and_ascii_cues_are_distinct_without_color_only_meaning():
    good, bad, unknown, waiting = [
        cli_render.state(label) for label in ("success", "failed", "unknown", "manual")
    ]
    assert len({text.spans[-1].style for text in (good, bad, unknown, waiting)}) == 4
    assert [t.plain for t in (good, bad, unknown, waiting)] == [
        "+ success",
        "x failed",
        "? unknown",
        "! manual",
    ]
    for label in (
        "running",
        "pending",
        "created",
        "canceled",
        "skipped",
        "open",
        "draft",
        "merged",
        "closed",
        "match",
        "mismatch",
        "unconfirmed",
        "passed",
        "stale",
        "superseded",
    ):
        assert label in cli_render.state(label).plain


def test_external_text_is_literal_and_controls_cannot_create_terminal_effects(service):
    item = service.snapshot().items[0]
    title = "literal [red]name[/red] \x1b[31m\x1b]8;;https://evil.invalid\x07line\n\u202e界"
    data = item.model_dump()
    data["title"] = title
    item = WorkItem.model_validate(data)
    view = service.view(item, service.preferences.read())
    raw, plain = render(lambda v, c: cli_render.details(v, c, "show"), view, color=True)
    assert "[red]name[/red]" in plain
    assert "\\x1b[31m" in plain and "\\x07" in plain and "\\u202e" in plain
    assert "\x1b]8" not in raw and "\u202e" not in raw
    assert json.loads(view.model_dump_json())["item"]["title"] == title


def test_detail_keeps_exact_sha_provenance_and_independent_deploy_test(service, key):
    view = service.view(service.item(key), service.preferences.read())
    _, plain = render(lambda v, c: cli_render.details(v, c, "show"), view, width=80)
    assert view.item.branches[0].sha in plain
    assert "Ancestry source" in plain and "Synthetic MR !154" in plain
    assert "override" in plain and "Reason" in plain
    assert "Checklist" not in plain or "never changes draft" in plain
    assert "9201" in plain and "failed" in plain
    assert "Deploy #3001" in plain and "success" in plain
    assert "Application test" in plain and "unconfirmed" in plain
    assert "Expected" in plain and "Observed" in plain


def test_custom_environment_label_and_no_false_association(service):
    original = service.dashboard()
    view = original.views[0]
    data = view.item.model_dump()
    data["environments"] = [
        *data["environments"],
        {
            "name": "qa",
            "expected": Version(sha="a" * 40).model_dump(),
            "observation": Unknown(reason="Not observed").model_dump(),
        },
    ]
    item = WorkItem.model_validate(data)
    custom = ItemView.model_validate(
        {
            **view.model_dump(),
            "item": item,
            "comparisons": [
                *view.comparisons,
                {"name": "qa", "result": "unknown", "reason": "Not observed"},
            ],
        }
    )
    dashboard = original.model_copy(
        update={
            "views": (custom,),
            "columns": ("identity", "environment:qa"),
            "environment_columns": (
                type(original.environment_columns[0])(
                    project=item.identity.project,
                    name="qa",
                    label="Quality assurance",
                    column="environment:qa",
                ),
            )
            if original.environment_columns
            else (),
        }
    )
    _, plain = render(cli_render.matrix, dashboard, width=80)
    assert "qa" in plain or "Quality assurance" in plain
    assert "Runtime ? unknown" in plain and "Deploy ? unknown" in plain
    assert cli_render.environment_cell(custom, "missing").plain == "not configured"
    assert (
        cli_render.association(Association(origin=Origin.OPERATOR, reason="manual")).plain
        == "override"
    )


@pytest.mark.parametrize("width", [80, 120, 160])
def test_actual_pty_modes_and_raw_json_remain_separate(tmp_path, width):
    cfg = tmp_path / "fixture.toml"
    cfg.write_text('mode="fixture"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n')
    argv = [
        sys.executable,
        "-m",
        "gspace",
        "dashboard",
        "--config",
        str(cfg),
        "--width",
        str(width),
        "--orientation",
        "columns",
    ]
    colored = capture(argv, environment(width), width, True)
    assert "\x1b[" in colored
    assert re.search(r"\x1b\[(?:\d+;)*3[126]m", colored)
    for env, extra, tty in (
        (environment(width, True), [], True),
        (environment(width), ["--no-color"], True),
        (environment(width, dumb=True), [], True),
        (environment(width), [], False),
    ):
        plain = Text.from_ansi(capture([*argv, *extra], env, width, tty)).plain
        assert "failed" in plain and "success" in plain
        assert all(cell_len(line) <= width for line in plain.splitlines())
    for tty in (True, False):
        raw = capture([*argv, "--json"], environment(width), width, tty)
        assert "\x1b" not in raw and len(json.loads(raw)["views"]) == 4
    assert not (tmp_path / "prefs.toml").exists()


def test_help_errors_and_human_catalogs_are_useful_and_machine_errors_stay_raw(tmp_path):
    cfg = tmp_path / "fixture.toml"
    cfg.write_text('mode="fixture"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n')
    base = [sys.executable, "-m", "gspace"]
    help_text = capture(
        [*base, "dashboard", "--help", "--no-color", "--width", "80"], environment(80), 80, True
    )
    assert "side-by-side process columns" in help_text and "Raw JSON stdout" in help_text
    assert not re.search(r"\x1b\[(?:\d+;)*3\d+m", help_text)
    for command in ("projects", "profiles", "views", "bookmarks", "settings"):
        human = capture([*base, command, "--config", str(cfg)], environment(80), 80, False)
        assert not human.lstrip().startswith(("{", "["))
        raw = capture([*base, command, "--config", str(cfg), "--json"], environment(80), 80, False)
        assert isinstance(json.loads(raw), dict | list) and "\x1b" not in raw
    for extra in ([], ["--json"]):
        bad = subprocess.run(
            [*base, "show", "42:999", "--config", str(cfg), *extra],
            env=environment(80),
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert bad.returncode == 2 and bad.stdout == ""
        if extra:
            assert "error" in json.loads(bad.stderr)
        else:
            assert "Error:" in bad.stderr
