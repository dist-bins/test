"""Operator-owned configuration; no authentication values are accepted."""

from __future__ import annotations

import ipaddress
import re
import tomllib
from pathlib import Path
from typing import Annotated, Literal, Self
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import Field, model_validator

from gspace.access_models import AccessProfile
from gspace.avatar_policy import AvatarPolicy
from gspace.models import EnvironmentLabel, Model, PositiveInt, ProjectId, Text, Version, WorkKey
from gspace.pipeline_config import (
    EffectivePipeline,
    PipelineRules,
    ProjectPipelineOverride,
    effective,
)
from gspace.web_config import WebConfig


class JsonField(Model, frozen=True):
    field: Literal["tag", "branch", "version", "sha"]
    path: Annotated[str, Field(pattern=r"^[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+){0,12}$")]


class JsonExtraction(Model, frozen=True):
    kind: Literal["json"] = "json"
    fields: tuple[JsonField, ...]


class HtmlField(Model, frozen=True):
    field: Literal["tag", "branch", "version", "sha"]
    selector: Annotated[str, Field(pattern=r"^[.#]?[A-Za-z][A-Za-z0-9_-]{0,79}$")]
    pattern: Annotated[str, Field(min_length=7, max_length=200)] = "{value}"

    @model_validator(mode="after")
    def one_placeholder(self) -> Self:
        if self.pattern.count("{value}") != 1:
            raise ValueError("HTML pattern needs exactly one {value} placeholder")
        return self


class HtmlExtraction(Model, frozen=True):
    kind: Literal["html"]
    fields: tuple[HtmlField, ...]


type Extraction = Annotated[JsonExtraction | HtmlExtraction, Field(discriminator="kind")]


class Endpoint(Model, frozen=True):
    name: EnvironmentLabel
    key: WorkKey
    url: Text
    allowed_origins: tuple[str, ...]
    allowed_networks: tuple[str, ...] = ()
    allow_http: bool = Field(default=False, strict=True)
    extraction: Extraction
    expected: Version | None = None
    timeout_seconds: Annotated[float, Field(gt=0, le=30)] = 5.0
    max_bytes: Annotated[int, Field(strict=True, ge=128, le=2_000_000)] = 500_000
    max_redirects: Annotated[int, Field(strict=True, ge=0, le=3)] = 2

    @model_validator(mode="after")
    def policy(self) -> Self:
        if not self.allowed_origins:
            raise ValueError("environment requires explicit allowed origins")
        for origin in self.allowed_origins:
            parsed = urlsplit(origin)
            if (
                parsed.scheme not in ("https", "http")
                or not parsed.hostname
                or parsed.path not in ("", "/")
                or parsed.username
                or parsed.password
                or parsed.query
                or parsed.fragment
            ):
                raise ValueError("invalid allowed origin")
        for network in self.allowed_networks:
            ipaddress.ip_network(network, strict=True)
        if not self.extraction.fields:
            raise ValueError("at least one extraction field required")
        names = [entry.field for entry in self.extraction.fields]
        if len(set(names)) != len(names):
            raise ValueError("duplicate extraction field")
        return self


class ProjectConfig(Model, frozen=True):
    id: ProjectId
    path: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)+$")]


class PipelineGraphLimits(Model, frozen=True):
    max_depth: Annotated[int, Field(strict=True, ge=0, le=8)] = 4
    max_nodes: Annotated[int, Field(strict=True, ge=1, le=128)] = 64
    max_pages: Annotated[int, Field(strict=True, ge=1, le=10)] = 4
    max_requests: Annotated[int, Field(strict=True, ge=1, le=512)] = 128
    timeout_seconds: Annotated[float, Field(gt=0, le=120)] = 30.0


class LiveConfig(Model, frozen=True):
    hostname: Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9.-]{0,252}(?::[0-9]{1,5})?$")]
    transport: Literal["https", "isolated_loopback_http"] = "https"
    reject_redirects: bool = Field(default=False, strict=True)
    web_origin: Text
    projects: tuple[ProjectConfig, ...]
    timeout_seconds: Annotated[float, Field(gt=0, le=60)] = 10.0
    max_pages: Annotated[int, Field(strict=True, ge=1, le=100)] = 20
    max_pipelines_per_ref: Annotated[int, Field(strict=True, ge=1, le=50)] = 10
    nexus_job_names: tuple[str, ...] = ("publish-nexus",)
    supported_version: Literal["18.11.12"] = "18.11.12"
    pipeline_graph: PipelineGraphLimits = PipelineGraphLimits()

    @model_validator(mode="after")
    def origin(self) -> Self:
        parsed = urlsplit(self.web_origin)
        loopback_http = self.transport == "isolated_loopback_http"
        if (
            parsed.scheme != ("http" if loopback_http else "https")
            or parsed.netloc != self.hostname
            or parsed.path not in ("", "/")
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
        ):
            raise ValueError("live web origin must match configured transport and host")
        if loopback_http and (parsed.hostname != "127.0.0.1" or parsed.port is None):
            raise ValueError("isolated HTTP requires explicit IPv4 loopback and port")
        if parsed.port is not None and not 1024 <= parsed.port <= 65535:
            raise ValueError("live port must be unprivileged and valid")
        if not self.projects:
            raise ValueError("live mode requires projects")
        if len({p.id for p in self.projects}) != len(self.projects):
            raise ValueError("Duplicate configured project identity")
        if len({p.path for p in self.projects}) != len(self.projects):
            raise ValueError("Duplicate configured project path")
        return self


class TagConvention(Model, frozen=True):
    component_from_right: Annotated[int, Field(strict=True, ge=0, le=10)] = 0
    increment: PositiveInt = 1
    preserve_padding: bool = Field(default=True, strict=True)

    def suggest(self, previous: str) -> str:
        matches = list(re.finditer(r"\d+", previous))
        if len(matches) <= self.component_from_right:
            raise ValueError("tag has no configured numeric component")
        part = matches[-1 - self.component_from_right]
        number = str(int(part.group()) + self.increment)
        if self.preserve_padding:
            number = number.zfill(len(part.group()))
        return previous[: part.start()] + number + previous[part.end() :]


class AppConfig(Model, frozen=True):
    mode: Literal["fixture", "live"] = "fixture"
    preferences_path: Path = Path(".state/preferences.toml")
    cache_path: Path = Path(".state/cache/snapshot.json")
    branch_template: str = "issue-{iid}"
    tag_convention: TagConvention = TagConvention()
    live: LiveConfig | None = None
    endpoints: tuple[Endpoint, ...] = ()
    access_profiles: tuple[AccessProfile, ...] = ()
    active_profile: str | None = None
    timezone: str = "Europe/Zurich"
    pipeline: PipelineRules = PipelineRules()
    project_pipeline_overrides: tuple[ProjectPipelineOverride, ...] = ()
    avatars: AvatarPolicy = AvatarPolicy()
    web: WebConfig = WebConfig()

    def effective_pipeline(self, project: ProjectId) -> EffectivePipeline:
        legacy = (
            self.live.nexus_job_names
            if self.live and "nexus_job_names" in self.live.model_fields_set
            else None
        )
        return effective(self.pipeline, self.project_pipeline_overrides, project, legacy)

    @model_validator(mode="after")
    def coherent(self) -> Self:
        try:
            ZoneInfo(self.timezone)
        except ZoneInfoNotFoundError as error:
            raise ValueError("Unknown IANA timezone") from error
        if self.mode == "live" and self.live is None:
            raise ValueError("live mode requires explicit configuration")
        if self.preferences_path.resolve() == self.cache_path.resolve():
            raise ValueError("cache and preferences must be separate")
        if self.branch_template.count("{iid}") != 1:
            raise ValueError("branch template requires one {iid}")
        if "{" in self.branch_template.replace("{iid}", ""):
            raise ValueError("unsupported branch template placeholder")
        names = [p.name for p in self.access_profiles]
        if len(set(names)) != len(names):
            raise ValueError("Duplicate access profile name")
        if self.active_profile is not None and self.active_profile not in names:
            raise ValueError("Active profile must be explicitly configured")
        for profile in self.access_profiles:
            if self.live is None or profile.host.rstrip("/") != self.live.web_origin.rstrip("/"):
                raise ValueError("Access profile host must match configured live scope")
            if any(
                p not in {project.id for project in self.live.projects} for p in profile.projects
            ):
                raise ValueError("Access profile exceeds configured project scope")
        identities = [(e.key, e.name) for e in self.endpoints]
        if len(set(identities)) != len(identities):
            raise ValueError("duplicate environment endpoint")
        projects = [o.project for o in self.project_pipeline_overrides]
        if len(set(projects)) != len(projects):
            raise ValueError("Duplicate project pipeline override")
        if self.live and any(p not in {p.id for p in self.live.projects} for p in projects):
            raise ValueError("Pipeline override exceeds configured project scope")
        for project in projects:
            self.effective_pipeline(project)
        for endpoint in self.endpoints:
            if endpoint.name not in {
                e.name for e in self.effective_pipeline(endpoint.key.project).rules.environments
            }:
                raise ValueError(
                    "Endpoint environment is not defined in effective pipeline settings"
                )
        return self


def load_config(path: Path | None) -> AppConfig:
    if path is None:
        return AppConfig()
    with path.open("rb") as file:
        config = AppConfig.model_validate(tomllib.load(file))
    return resolve_config(config, path)


def resolve_config(config: AppConfig, path: Path) -> AppConfig:
    """Resolve authorized config-relative paths without changing explicitly set fields."""
    # Paths are relative to the configuration file, not to a renderer's cwd.
    data = config.model_dump(exclude_unset=True)
    for name in ("preferences_path", "cache_path"):
        value = getattr(config, name)
        if not value.is_absolute():
            data[name] = path.resolve().parent / value
    return AppConfig.model_validate(data)
