from pathlib import Path

import pytest

from gspace.config import AppConfig
from gspace.models import IssueIid, ProjectId, WorkKey
from gspace.service import Service


@pytest.fixture
def config(tmp_path: Path) -> AppConfig:
    return AppConfig(
        preferences_path=tmp_path / "preferences.toml", cache_path=tmp_path / "cache.json"
    )


@pytest.fixture
def service(config: AppConfig) -> Service:
    return Service(config)


@pytest.fixture
def key() -> WorkKey:
    return WorkKey(project=ProjectId(value=42), issue=IssueIid(value=791))
