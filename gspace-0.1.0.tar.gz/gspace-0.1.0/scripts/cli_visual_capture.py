"""Capture actual synthetic CLI ANSI from PTYs and export local-only review images.

These are labelled browser renders of actual terminal output, not macOS screenshots.
No forced-color application change, credential access or remote service is involved.
"""

from __future__ import annotations

import argparse
import errno
import fcntl
import hashlib
import io
import json
import os
import pty
import re
import select
import struct
import subprocess
import sys
import tempfile
import termios
import time
from datetime import UTC, datetime
from pathlib import Path

from playwright.sync_api import sync_playwright
from rich.console import Console
from rich.terminal_theme import DEFAULT_TERMINAL_THEME, MONOKAI
from rich.text import Text

from gspace.config import load_config
from gspace.models import ApplicationTestRecord, Version
from gspace.service import ApplicationTestChange, FlagChange, Service

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "frontend-new/review-input/cli-before"
SGR = re.compile(r"\x1b\[([0-9;]*)m")


def capture(argv: list[str], environment: dict[str, str], width: int, tty: bool) -> str:
    if not tty:
        result = subprocess.run(argv, env=environment, cwd=ROOT, capture_output=True, timeout=15)
        if result.returncode or result.stderr:
            raise RuntimeError("Synthetic CLI pipe capture failed")
        return result.stdout.decode("utf-8")
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 50, width, 0, 0))
    process = subprocess.Popen(
        argv,
        cwd=ROOT,
        env=environment,
        stdin=subprocess.DEVNULL,
        stdout=slave,
        stderr=subprocess.PIPE,
    )
    os.close(slave)
    output = bytearray()
    deadline = time.monotonic() + 15
    try:
        while True:
            if time.monotonic() >= deadline:
                raise RuntimeError("Synthetic CLI PTY capture timed out")
            readable, _, _ = select.select([master], [], [], 0.1)
            if not readable:
                continue
            try:
                chunk = os.read(master, 65536)
            except OSError as error:
                if error.errno == errno.EIO:
                    break
                raise
            if not chunk:
                break
            output.extend(chunk)
        process.wait(timeout=2)
        assert process.stderr is not None
        if process.returncode or process.stderr.read():
            raise RuntimeError("Synthetic CLI PTY capture failed")
        return output.decode("utf-8").replace("\r\n", "\n")
    finally:
        os.close(master)
        if process.poll() is None:
            process.kill()
            process.wait(timeout=2)


def environment(width: int, no_color: bool = False, dumb: bool = False) -> dict[str, str]:
    values = {
        "PATH": "/opt/homebrew/bin:/usr/bin:/bin",
        "LANG": "en_US.UTF-8",
        "TERM": "dumb" if dumb else "xterm-256color",
        "COLORTERM": "truecolor",
        "COLUMNS": str(width),
        "LINES": "50",
    }
    if no_color:
        values["NO_COLOR"] = "1"
    return values


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT)
    parser.add_argument("--phase", choices=("before", "after"), default="before")
    parser.add_argument("--theme", choices=("dark", "light"), default="dark")
    parser.add_argument("--representative", action="store_true")
    args = parser.parse_args()
    destination = args.output.resolve()
    if not destination.is_relative_to(ROOT) or destination.is_symlink():
        raise ValueError("Capture output must remain in the owned workspace")
    destination.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    with tempfile.TemporaryDirectory(prefix="gspace-cli-visual-") as temporary:
        cfg = Path(temporary) / "fixture.toml"
        cfg.write_text('mode="fixture"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n')
        service = Service(load_config(cfg), config_path=cfg)
        for item in service.snapshot().items[:4]:
            service.change(
                FlagChange(
                    revision=service.preferences.read().revision,
                    operation="select",
                    key=item.identity,
                    enabled=True,
                )
            )
        first = service.snapshot().items[0].identity
        service.change(
            ApplicationTestChange(
                revision=service.preferences.read().revision,
                record=ApplicationTestRecord(
                    key=first,
                    environment="dev",
                    version=Version(sha="f" * 40),
                    outcome="passed",
                    checked_at=datetime.now(UTC),
                    notes="Synthetic historical pass for a different SHA",
                ),
            )
        )
        cli = [sys.executable, "-m", "gspace"]
        for width in (80, 120, 160):
            for orientation in ("rows", "columns"):
                for color in ("auto-tty", "no-color"):
                    name = f"dashboard-{orientation}-{width}-{color}"
                    argv = [
                        *cli,
                        "dashboard",
                        "--config",
                        str(cfg),
                        "--width",
                        str(width),
                        "--orientation",
                        orientation,
                    ]
                    raw = capture(argv, environment(width, color == "no-color"), width, True)
                    rows.append(
                        {
                            "name": name,
                            "command": ["gspace", *argv[3:]],
                            "width": width,
                            "orientation": orientation,
                            "color": color,
                            "tty": True,
                            "raw": raw,
                        }
                    )
        for command, extra in [
            ("compare", ["--orientation", "columns"]),
            ("show", [first.key]),
            ("pipelines", ["42:793"]),
            ("environments", ["42:792"]),
            ("milestones", []),
            ("branches", ["--project", "42"]),
            ("pipeline-catalog", ["--project", "42"]),
            ("mrs", []),
            ("app-history", [first.key]),
            ("settings", []),
            ("projects", []),
            ("profiles", []),
            ("dashboard", ["--help"]),
            ("list", []),
            ("help", []),
            ("help", ["pipelines"]),
            ("preferences", ["filters", "--search", "airport"]),
        ]:
            argv = [*cli, command, *extra, "--config", str(cfg), "--width", "120"]
            if command == "help":
                argv = [*cli, command, *extra]
            rows.append(
                {
                    "name": command
                    + ("-" + extra[0] if command == "help" and extra else "")
                    + "-120-auto-tty",
                    "command": ["gspace", *argv[3:]],
                    "width": 120,
                    "color": "auto-tty",
                    "tty": True,
                    "raw": capture(argv, environment(120), 120, True),
                }
            )
        diag: list[dict[str, object]] = []
        for name, tty, env, extra in [
            ("actual-tty-auto", True, environment(120), []),
            ("pipe-default", False, environment(120), []),
            ("pipe-color-flag", False, environment(120), ["--color"]),
            ("tty-NO_COLOR", True, environment(120, True), []),
            ("tty-no-color-flag", True, environment(120), ["--no-color"]),
            ("tty-dumb", True, environment(120, dumb=True), []),
            ("pipe-json", False, environment(120), ["--json"]),
            ("tty-json", True, environment(120), ["--json"]),
        ]:
            raw = capture(
                [*cli, "dashboard", "--config", str(cfg), "--width", "120", *extra], env, 120, tty
            )
            codes = SGR.findall(raw)
            colors = [
                c
                for c in codes
                if any((30 <= int(p) <= 49 or 90 <= int(p) <= 107) for p in c.split(";") if p)
            ]
            diag.append(
                {
                    "case": name,
                    "tty": tty,
                    "TERM": env["TERM"],
                    "NO_COLOR": "NO_COLOR" in env,
                    "sgr_count": len(codes),
                    "color_sgr_count": len(colors),
                    "json_valid": isinstance(json.loads(raw), dict) if "--json" in extra else None,
                }
            )
        if args.representative:
            names = {
                "dashboard-columns-80-auto-tty",
                "dashboard-columns-120-auto-tty",
                "dashboard-rows-160-auto-tty",
                "pipelines-120-auto-tty",
                "mrs-120-auto-tty",
                "app-history-120-auto-tty",
            }
            rows = [row for row in rows if row["name"] in names]
        with sync_playwright() as engine:
            browser = engine.chromium.launch(
                executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                headless=True,
            )
            page = browser.new_page()
            outbound: list[str] = []

            def block(route):
                outbound.append(route.request.url)
                route.abort()

            page.route("**/*", block)
            for row in rows:
                name = str(row["name"])
                raw = str(row.pop("raw"))
                text = Text.from_ansi(raw)
                (destination / f"{name}.ansi.txt").write_text(raw)
                console = Console(
                    file=io.StringIO(),
                    width=int(str(row["width"])),
                    record=True,
                    markup=False,
                    highlight=False,
                )
                console.print(text, end="", soft_wrap=True)
                html = console.export_html(
                    inline_styles=True,
                    theme=MONOKAI if args.theme == "dark" else DEFAULT_TERMINAL_THEME,
                )
                (destination / f"{name}.html").write_text(html)
                page.set_viewport_size({"width": int(str(row["width"])) * 9 + 32, "height": 900})
                page.set_content(html)
                cell_width = page.locator("pre").evaluate(
                    "element => {"
                    "const c = document.createElement('canvas').getContext('2d');"
                    "const s = getComputedStyle(element); c.font = s.fontSize + ' ' + s.fontFamily;"
                    "return c.measureText('M').width; }"
                )
                page.set_viewport_size(
                    {"width": round(int(str(row["width"])) * cell_width) + 20, "height": 900}
                )
                page.locator("pre").screenshot(path=str(destination / f"{name}.png"))
                row.update(
                    image=f"{name}.png",
                    ansi=f"{name}.ansi.txt",
                    html=f"{name}.html",
                    lines=len(text.plain.splitlines()),
                    max_line_width=max((len(line) for line in text.plain.splitlines()), default=0),
                    sgr_codes=sorted(set(SGR.findall(raw))),
                )
            browser.close()
        assert not outbound, "Terminal export attempted external traffic"
    manifest = {
        "purpose": f"Actual synthetic PTY CLI {args.phase} Codex presentation redesign",
        "captured_at": datetime.now(UTC).isoformat(),
        "renderer_sha256": hashlib.sha256((ROOT / "src/gspace/cli.py").read_bytes()).hexdigest(),
        "source_sha256": {
            name: hashlib.sha256((ROOT / "src/gspace" / name).read_bytes()).hexdigest()
            for name in ("cli.py", "cli_render.py", "cli_models.py", "cli_commands.py")
            if (ROOT / "src/gspace" / name).exists()
        },
        "format": "PNG browser render of actual ANSI through Rich HTML export; "
        f"local fonts, explicit {args.theme} theme, cropped to terminal text",
        "export_theme": args.theme,
        "reference": {
            "library_file_id": "libfile_3cfe6b3f7ffc8191be67536e1a4c0ab7",
            "pixels_inspected": False,
            "status": "Supported read/materialize tool unavailable; parent observations only",
        },
        "images": rows,
        "diagnostics": diag,
        "outbound_requests": outbound,
        "state": "Temporary synthetic selected rows/manual history; "
        "existing user preferences untouched",
    }
    (destination / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"images": len(rows), "diagnostics": diag, "outbound_requests": outbound}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
