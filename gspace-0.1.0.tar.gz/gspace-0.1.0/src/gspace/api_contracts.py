"""Explicit public response DTOs. No authentication descriptor or secret is exposed."""

from __future__ import annotations

from typing import Literal, Self

from pydantic import AwareDatetime, Field, model_validator

from gspace.catalog import AuthoredMr, MRCatalog
from gspace.config import ProjectConfig
from gspace.models import Model, Text


class DetailError(Model, frozen=True):
    detail: str


class AdapterErrorResponse(DetailError, frozen=True):
    code: str


class ProjectCatalogResponse(Model, frozen=True):
    host: Text
    projects: tuple[ProjectConfig, ...]
    coverage: Literal["configured_projects"] = "configured_projects"


class MRCatalogResponse(Model, frozen=True):
    source: Literal["fixture", "glab"]
    host: Text
    scope: Literal["authored_by_me"] = "authored_by_me"
    coverage: Literal["configured_projects"] = "configured_projects"
    projects: tuple[ProjectConfig, ...]
    fetched_at: AwareDatetime
    total: int = Field(strict=True, ge=0)
    rows: tuple[AuthoredMr, ...]

    @model_validator(mode="after")
    def coherent(self) -> Self:
        MRCatalog.model_validate(self.model_dump(exclude={"total"}))
        if self.total != len(self.rows):
            raise ValueError("Catalog total differs from complete returned rows")
        return self

    @classmethod
    def from_catalog(cls, catalog: MRCatalog) -> MRCatalogResponse:
        return cls.model_validate({**catalog.model_dump(), "total": catalog.total})


class CapabilitiesResponse(Model, frozen=True):
    remote_read_only: bool
    remote_mutations: bool
    previews: tuple[
        Literal["tag", "rebase", "retry", "deploy-dev", "deploy-preprod", "ready", "merge"], ...
    ]
    write_scope: Literal["disabled", "isolated_synthetic_lab"] = "disabled"
    actions: tuple[
        Literal[
            "create_draft_mr",
            "edit_draft_mr",
            "create_tag",
            "run_pipeline",
            "change_pipeline",
            "change_job",
        ],
        ...,
    ] = ()
    deferred_actions: tuple[str, ...] = ("ready", "merge", "rebase")
    permission_check_required: Literal[True] = True
    confirmation_required: Literal[True] = True
