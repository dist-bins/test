"""Check action confirmation UI with typed synthetic browser responses, never real effects."""

from __future__ import annotations

import argparse
import json
import socket
import subprocess
import sys
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen

from playwright.sync_api import expect, sync_playwright

from gspace.access_models import PermissionScope, PermissionSupported, PermissionUnknown
from gspace.actions import BlockedPlan, ConfirmablePlan, CreateTag, ProfileSummary
from gspace.api_contracts import CapabilitiesResponse
from gspace.models import ProjectId, UserId


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=Path("src/gspace/static"))
    parser.add_argument(
        "--output", type=Path, default=Path("output/verification/integrated-access-browser")
    )
    args = parser.parse_args()
    output = args.output
    output.mkdir(parents=True, exist_ok=True)
    now = datetime.now(UTC)
    scope = PermissionScope(
        profile="synthetic",
        host="http://127.0.0.1:8929",
        project=ProjectId(value=42),
        identity=UserId(value=7),
    )
    common = dict(
        scope=scope,
        reason="Explicit synthetic browser response; no GitLab probe",
        evidence=("Synthetic browser mock only",),
        checked_at=now,
    )
    unknown = PermissionUnknown(**common)
    supported = PermissionSupported(**common)
    profile = ProfileSummary(
        name="synthetic", kind="pat", host=scope.host, projects=(scope.project,), write_enabled=True
    )
    caps = CapabilitiesResponse(
        remote_read_only=False,
        remote_mutations=True,
        previews=(),
        write_scope="isolated_synthetic_lab",
        actions=("create_tag",),
    )
    state = {"mode": "blocked"}
    outside: list[str] = []
    errors: list[str] = []
    effects: list[str] = []
    checks: list[str] = []
    with tempfile.TemporaryDirectory(prefix="gspace-access-browser-") as temporary:
        config = Path(temporary) / "fixture.toml"
        config.write_text(
            'mode = "fixture"\npreferences_path = "prefs.toml"\ncache_path = "cache.json"\n'
        )
        with socket.socket() as allocator:
            allocator.bind(("127.0.0.1", 0))
            port = allocator.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        source = (
            "import sys; from pathlib import Path; import uvicorn; import gspace.api as api; "
            "from gspace.config import load_config; api.STATIC=Path(sys.argv[1]); "
            "p=Path(sys.argv[2]); uvicorn.run(api.create_app(load_config(p),config_path=p), "
            "host='127.0.0.1',port=int(sys.argv[3]),access_log=False)"
        )
        server = subprocess.Popen(
            [sys.executable, "-c", source, str(args.assets.resolve()), str(config), str(port)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            for _ in range(100):
                if server.poll() is not None:
                    raise RuntimeError("Fixture server exited")
                try:
                    with urlopen(base + "/api/dashboard", timeout=0.2):
                        break
                except OSError:
                    time.sleep(0.1)
            else:
                raise RuntimeError("Fixture server did not start")
            with sync_playwright() as engine:
                browser = engine.chromium.launch(
                    executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                    headless=True,
                )
                context = browser.new_context(viewport={"width": 1400, "height": 1000})

                def guard(route):
                    request = route.request
                    parsed = urlsplit(request.url)
                    if parsed.hostname != "127.0.0.1" or parsed.port != port:
                        outside.append(request.url)
                        route.abort()
                    elif parsed.path == "/api/actions/execute":
                        effects.append(request.url)
                        route.fulfill(
                            status=403, json={"detail": "Browser gate blocks all effects"}
                        )
                    elif parsed.path == "/api/capabilities":
                        route.fulfill(json=caps.model_dump(mode="json"))
                    elif parsed.path == "/api/access/profiles":
                        route.fulfill(json=[profile.model_dump(mode="json")])
                    elif parsed.path == "/api/actions/probe":
                        route.fulfill(json=unknown.model_dump(mode="json"))
                    elif parsed.path == "/api/actions/preview":
                        action = CreateTag.model_validate(request.post_data_json)
                        if state["mode"] == "blocked":
                            plan = BlockedPlan(
                                action=action, permission=unknown, summary="Synthetic blocked plan"
                            )
                        else:
                            expiry = datetime.now(UTC) + timedelta(
                                seconds=-1 if state["mode"] == "expired" else 90
                            )
                            plan = ConfirmablePlan(
                                action=action,
                                permission=supported,
                                summary="Synthetic confirmable plan; no remote execution",
                                confirmation="synthetic-only-confirmation-00000000000000",
                                expires_at=expiry,
                            )
                        route.fulfill(json=plan.model_dump(mode="json"))
                    elif parsed.path.startswith("/api/access/doctor/"):
                        route.fulfill(
                            status=503,
                            json={"detail": "Synthetic unavailable doctor; no network request"},
                        )
                    else:
                        route.continue_()

                context.route("**/*", guard)
                page = context.new_page()
                page.on("pageerror", lambda error: errors.append(str(error)))
                page.goto(base + "/#/access")
                expect(page.locator('[data-fk="act-project"]')).to_be_visible()
                expect(page.locator('input[type="password"]')).to_have_count(0)
                checks.append("redacted profile form has no credential field")
                page.locator('[data-fk="act-project"]').select_option("42")
                page.locator('[data-fk="act-expected_sha"]').fill("a" * 40)
                page.locator('[data-fk="act-branch"]').fill("issue-791")
                page.locator('[data-fk="act-tag"]').fill("flight-2.4.11")
                page.get_by_role("button", name="Check permission", exact=True).click()
                expect(page.get_by_text("Permission unknown", exact=True)).to_be_visible()
                checks.append("unknown permission stays explicit")
                page.get_by_role("button", name="Preview", exact=True).click()
                expect(page.locator(".plan.blocked")).to_be_visible()
                expect(page.locator('[data-fk="act-exec"]')).to_have_count(0)
                checks.append("blocked preview has no execute control")
                state["mode"] = "confirmable"
                page.get_by_role("button", name="Preview", exact=True).click()
                expect(page.locator(".plan.confirmable")).to_be_visible()
                page.locator('[data-fk="act-exec"]').click()
                dialog = page.get_by_role("dialog")
                expect(dialog).to_be_visible()
                dialog.get_by_role("button", name="Submit to GitLab", exact=True).click()
                expect(dialog).to_contain_text("Tick the confirmation box first.")
                assert not effects
                checks.append("confirmation dialog refuses submission without acknowledgement")
                page.keyboard.press("Escape")
                page.locator('[data-fk="act-tag"]').fill("flight-2.4.12")
                expect(page.locator(".plan.confirmable")).to_have_count(0)
                checks.append("changing action invalidates prior confirmation")
                state["mode"] = "expired"
                page.get_by_role("button", name="Preview", exact=True).click()
                expect(page.locator('[data-fk="act-exec"]')).to_be_disabled()
                checks.append("expired preview cannot be submitted")
                assert not effects and not outside and not errors
                checks.append("no execute request, outbound network or JavaScript error")
                page.screenshot(path=str(output / "expired-preview.png"), full_page=True)
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)
    report = {
        "result": "passed",
        "evidence": "typed synthetic browser mocks only",
        "actual_gitlab_tests": False,
        "checks": checks,
        "execute_requests": effects,
        "external_requests": outside,
        "javascript_errors": errors,
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
