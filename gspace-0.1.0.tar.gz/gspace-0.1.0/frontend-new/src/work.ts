// Work items, Compare and item detail: the central process views, the
// shared milestone filter and the item-side manual tools.

import type { Filters, ItemView, MilestoneKey } from './api';
import { ATTN, attentionBar, attentionLine, hasAttention } from './attention';
import type { IconName, Kid } from './dom';
import { checkedOf, controlValue, extLink, h, icon, lines, none, openOf, plural, tone, workStateBadge } from './dom';
import { evidence } from './evidence';
import { graphSection } from './graph';
import { loadGraph, loadItem, preview, reloadItemData } from './load';
import type { StageDef } from './model';
import { processOf, projectPath, scopeLabel, scopeProjects, stagesFor, views, visibleEnvs, visibleStages } from './model';
import { projectAvatar } from './nav';
import { environmentsPanel, legendEl, recordKey, stageLabel, stageRun } from './process';
import { render } from './render';
import { bookmarkBtn } from './resources';
import type { ListUi, MsFilter, Sort, UiFilters, WorkState } from './state';
import {
  CHECKLIST,
  colLabel,
  isWorkState,
  itemHref,
  msKeyFromStr,
  msKeyStr,
  normMs,
  PREVIEW_ACTIONS,
  PREVIEW_LABEL,
  pref,
  S,
  STATES,
  sameKey,
  sectionOpen,
  to,
  wkStr,
} from './state';
import { confirmDialog, emptyState, menu, sec, toggleBtn } from './ui';
import type { SortKey } from './views';
import { mobileQuery, modeSwitch, mxFrame, sortRecords, viewControls } from './views';
import { evidenceToggle, flowBoard, itemFlow } from './visual';

/* ---------------------------------------------------- milestone filter */
// Modes: all | active (GitLab state) | date_current (every server candidate;
// none is picked automatically) | unassigned | selected (typed key). Active
// and date-current need the catalog; without it they are not applied and the
// screen says so instead of guessing.

const msEval = (m: MsFilter): boolean => m.mode === 'all' || m.mode === 'unassigned' || m.mode === 'selected' || !!S.ms;
const msEntry = (k: MilestoneKey | null | undefined) => (k ? (S.d?.ms.get(msKeyStr(k)) ?? null) : null);

export function msOwner(k: MilestoneKey): string {
  return k.kind === 'group' ? `group ${k.group.value}` : projectPath(k.project.value);
}

export function msTitle(k: MilestoneKey): string {
  const e = msEntry(k);
  return e ? e.milestone.title : `Milestone ${k.id.value} (not in the catalog)`;
}

function msMatch(v: ItemView, m: MsFilter): boolean {
  if (m.mode === 'all') return true;
  const k = v.item.milestone ?? null;
  if (m.mode === 'unassigned') return !k;
  if (m.mode === 'selected') return !!k && msKeyStr(k) === msKeyStr(m.selected);
  if (!S.ms) return true; // not evaluable: msNote() explains that it is not applied
  if (!k) return false;
  if (m.mode === 'date_current') return S.d?.msCurrent.has(msKeyStr(k)) ?? false;
  return msEntry(k)?.milestone.state === 'active';
}

export function msModeLabel(m: MsFilter): string {
  switch (m.mode) {
    case 'active':
      return 'Active milestones';
    case 'date_current':
      return 'Date-current milestones';
    case 'unassigned':
      return 'No milestone';
    case 'selected':
      return `${msTitle(m.selected)} · ${msOwner(m.selected)}`;
    case 'all':
      return 'All milestones';
  }
}

function msExplain(): Kid[] {
  const C = S.ms;
  const cands = (C?.date_current_candidates ?? []).map((k) => `${msTitle(k)} (${msOwner(k)})`);
  return [
    h('p', null, h('strong', null, 'Active'), ': GitLab state is active, whatever the dates.'),
    h(
      'p',
      null,
      h('strong', null, 'Date-current'),
      ': an active milestone whose start and due dates both include ',
      C ? [h('span', { class: 'nowrap' }, C.date), ` (${C.timezone})`] : 'the configured local date',
      '. A milestone without both dates is unknown and never date-current.',
    ),
    C
      ? h(
          'p',
          null,
          cands.length
            ? `${plural(cands.length, 'candidate')}: ${cands.join(', ')}. All are included; none is chosen automatically.`
            : 'No milestone is date-current today.',
        )
      : h('p', null, 'The milestone catalog is not loaded.'),
    h('p', null, h('strong', null, 'No milestone'), ': work items without a milestone.'),
    h(
      'p',
      null,
      'Shared through preferences by Work items, Compare, Milestones and saved work-item views: choosing a milestone in any of them changes this filter for everyone using the preference file. Milestones are identified by owner and ID, not by IID or title.',
    ),
  ];
}

function msFromValue(val: string): MsFilter {
  if (val.startsWith('k:')) {
    const key = msKeyFromStr(val.slice(2));
    return key ? { mode: 'selected', selected: key } : { mode: 'all', selected: null };
  }
  switch (val) {
    case 'active':
    case 'date_current':
    case 'unassigned':
      return { mode: val, selected: null };
    default:
      return { mode: 'all', selected: null };
  }
}

export function milestoneControl(): HTMLSpanElement {
  const m = S.ui.work_items.filters.milestone;
  const entries = S.ms?.entries ?? [];
  const value = m.mode === 'selected' ? `k:${msKeyStr(m.selected)}` : m.mode;
  const known = m.mode !== 'selected' || entries.some((e) => msKeyStr(e.milestone.key) === msKeyStr(m.selected));
  const nCur = S.d?.msCurrent.size ?? 0;
  return h(
    'span',
    { class: 'msf' },
    h(
      'label',
      { class: 'isel', title: 'Milestone filter (shared)' },
      icon('milestone', 'sm'),
      h('span', { class: 'sr' }, 'Milestone filter'),
      h(
        'select',
        { class: 'select', 'data-fk': 'w-ms', disabled: !S.prefs, onchange: (e: Event) => setWorkFilter({ milestone: msFromValue(controlValue(e)) }) },
        h('option', { value: 'all', selected: value === 'all' }, 'All milestones'),
        h('option', { value: 'active', selected: value === 'active' }, 'Active milestones'),
        h('option', { value: 'date_current', selected: value === 'date_current' }, S.ms ? `Date-current (${plural(nCur, 'candidate')})` : 'Date-current'),
        h('option', { value: 'unassigned', selected: value === 'unassigned' }, 'No milestone'),
        entries.length
          ? h(
              'optgroup',
              { label: 'One milestone' },
              entries.map((e) => {
                const ks = `k:${msKeyStr(e.milestone.key)}`;
                return h(
                  'option',
                  { value: ks, selected: value === ks },
                  `${e.milestone.title} · ${msOwner(e.milestone.key)}${e.milestone.state === 'closed' ? ' · closed' : ''}`,
                );
              }),
            )
          : null,
        !known && m.mode === 'selected' ? h('option', { value, selected: true }, `${msTitle(m.selected)} · ${msOwner(m.selected)}`) : null,
      ),
    ),
    evidence('ev-ms-filter', null, msExplain(), 'Milestone filter'),
  );
}

// Explains when the milestone filter is not (fully) applied.
function msNote(recsBefore: readonly ItemView[]): Kid {
  const m = S.ui.work_items.filters.milestone;
  if (m.mode === 'all') return null;
  if (!msEval(m)) {
    return h(
      'div',
      { class: 'inline-err' },
      icon('warning', 'sm'),
      h(
        'div',
        null,
        S.msLoading
          ? `Loading the milestone catalog; "${msModeLabel(m)}" applies when it arrives.`
          : `"${msModeLabel(m)}" is not applied: the milestone catalog is unavailable${S.msError ? ` (${S.msError})` : ''}.`,
      ),
    );
  }
  if (m.mode === 'active' || m.mode === 'date_current') {
    const missing = recsBefore.filter((v) => v.item.milestone && !msEntry(v.item.milestone)).length;
    if (missing)
      return h(
        'p',
        { class: 'hint' },
        `${plural(missing, 'item')} with a milestone that is not in the catalog ${missing === 1 ? 'is' : 'are'} excluded because its state and dates are unknown.`,
      );
  }
  return null;
}

export function milestoneChip(k: MilestoneKey | null | undefined): HTMLSpanElement | null {
  if (!k) return null;
  const e = msEntry(k);
  const cur = S.d?.msCurrent.has(msKeyStr(k)) ?? false;
  return h(
    'span',
    {
      class: `chip ms-chip${e?.milestone.state === 'closed' ? ' closed' : ''}`,
      title: `Milestone ${e ? `${e.milestone.title} (${e.milestone.state}${cur ? ', date-current' : ''})` : 'not in the catalog'} · ${msOwner(k)}`,
    },
    icon('milestone', 'sm'),
    h('span', null, e ? e.milestone.title : 'Milestone ?'),
    cur ? [h('span', { class: 'ms-now', 'aria-hidden': 'true' }, '•'), h('span', { class: 'sr' }, ', date-current')] : null,
  );
}

/* ------------------------------------------------------- filtering */

function workMatches(v: ItemView, f: UiFilters, projectSet: Set<number> | null): boolean {
  const it = v.item;
  if (projectSet && !projectSet.has(it.identity.project.value)) return false;
  if (!msMatch(v, f.milestone)) return false;
  if (f.state !== 'all' && it.state !== f.state) return false;
  if (f.assigned && !it.assigned_to_me) return false;
  if (!f.show_hidden && v.hidden) return false;
  if (f.group && !v.groups.includes(f.group)) return false;
  const q = f.search.trim().toLowerCase();
  if (q) {
    const hay = [
      `#${it.identity.issue.value}`,
      it.title,
      it.project_path,
      ...it.labels,
      ...it.branches.map((b) => b.name),
      ...it.merge_requests.map((m) => `!${m.iid.value} ${m.title}`),
      ...it.tags.map((t) => t.name),
      ...it.pipelines.map((p) => `#${p.id.value}`),
      ...v.groups,
      msEntry(it.milestone)?.milestone.title ?? '',
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();
    if (!q.split(/\s+/).every((t) => hay.includes(t))) return false;
  }
  return true;
}

function workSortKey(v: ItemView, sort: Sort): SortKey {
  const it = v.item;
  switch (sort) {
    case 'title':
      return [it.title];
    case 'state':
      return [it.state, it.identity.issue.value];
    case 'project':
      return [it.project_path, it.identity.issue.value];
    default:
      return [it.identity.project.value, it.identity.issue.value];
  }
}

let filterTimer = 0;
export function setWorkFilter(patch: Partial<UiFilters>, delay = 0): void {
  Object.assign(S.ui.work_items.filters, patch);
  S.filterSeq++;
  render();
  persistWorkFilters(delay);
}

// operation:filters always carries the complete Filters object.
function fullFilters(f: UiFilters): Filters {
  const state: WorkState = isWorkState(f.state) ? f.state : 'all';
  return {
    state,
    assigned: f.assigned,
    search: f.search.slice(0, 200),
    group: f.group.slice(0, 80),
    show_hidden: f.show_hidden,
    milestone: normMs(f.milestone),
  };
}

let afterFilterSave: () => void = () => {};
/** Registers what to refresh after the shared filters were saved (catalog visible counts). */
export function onFiltersSaved(fn: () => void): void {
  afterFilterSave = fn;
}

export function persistWorkFilters(delay: number): void {
  window.clearTimeout(filterTimer);
  filterTimer = window.setTimeout(() => {
    const seq = S.filterSeq;
    void pref({ operation: 'filters', filters: fullFilters(S.ui.work_items.filters) }, 'Work-item filters').then((ok) => {
      if (ok || seq === S.filterSeq) S.filterSaved = Math.max(S.filterSaved, seq);
      if (ok && seq === S.filterSeq) afterFilterSave();
    });
  }, delay);
}

/* ---------------------------------------------------------- columns */

/**
 * Facts the active Work filters already guarantee for every shown item, so
 * the column heads need not repeat them (Work Overview only; Compare,
 * Detailed and the item page always show them).
 */
export interface Implied {
  readonly state: boolean;
  readonly assigned: boolean;
}

export function workHead(v: ItemView, inverted: boolean, cols: readonly string[], implied: Implied | null = null): HTMLDivElement {
  const it = v.item;
  const id = it.identity;
  const k = wkStr(id);
  const n = `#${id.issue.value}`;
  return h(
    'div',
    { class: 'lines' },
    h(
      'div',
      { class: 'idc' },
      h('input', {
        type: 'checkbox',
        checked: v.selected,
        'data-fk': `sel-${k}`,
        disabled: !S.prefs,
        'aria-label': `Select ${n} for comparison`,
        title: 'Shared selection used by Compare',
        onchange: (e: Event) => {
          const on = checkedOf(e);
          void pref({ operation: 'select', key: id, enabled: on }, `${on ? 'Select' : 'Deselect'} ${n}`);
        },
      }),
      h('a', { href: to(itemHref(id)), title: `${it.project_path} issue ${id.issue.value}` }, n),
      h(
        'button',
        {
          class: 'btn sm icon ghost',
          type: 'button',
          'aria-pressed': String(v.pinned),
          'data-fk': `pin-${k}`,
          disabled: !S.prefs,
          'aria-label': `${v.pinned ? 'Unpin' : 'Pin'} ${n}`,
          title: v.pinned ? 'Pinned (kept first)' : 'Pin first',
          onclick: () => void pref({ operation: 'pin', key: id, enabled: !v.pinned }, `${v.pinned ? 'Unpin' : 'Pin'} ${n}`),
        },
        icon('pin', 'sm'),
      ),
      v.hidden ? h('span', { class: 'chip', title: 'Hidden by preference' }, icon('hide', 'sm'), 'Hidden') : null,
    ),
    inverted ? h('a', { class: 'title-line', href: to(itemHref(id)), title: it.title }, it.title) : null,
    inverted
      ? h(
          'div',
          { class: 'chips' },
          cols.includes('state') && !implied?.state ? workStateBadge(it.state) : null,
          cols.includes('state') && it.assigned_to_me && !implied?.assigned ? h('span', { class: 'chip' }, 'Assigned to me') : null,
          cols.includes('project') || S.scope.project == null
            ? h('span', { class: 'chip mono proj-chip', title: `Project ${id.project.value}` }, projectAvatar(id.project.value, 'avatar sm'), it.project_path)
            : null,
          milestoneChip(it.milestone),
          v.groups.map((g) => h('span', { class: 'chip st t-info', title: 'Local group' }, icon('group', 'sm'), h('span', null, g))),
        )
      : null,
  );
}

function workMeta(v: ItemView, col: 'title' | 'state' | 'project'): Kid {
  const it = v.item;
  switch (col) {
    case 'title':
      return lines(
        h('a', { class: 'title-text', href: to(itemHref(it.identity)) }, it.title),
        it.labels.length || v.groups.length || it.milestone
          ? h(
              'div',
              { class: 'chips' },
              milestoneChip(it.milestone),
              it.labels.map((l) => h('span', { class: 'chip' }, l)),
              v.groups.map((g) => h('span', { class: 'chip st t-info', title: 'Local group' }, icon('group', 'sm'), h('span', null, g))),
            )
          : null,
      );
    case 'state':
      return lines(workStateBadge(it.state), h('span', { class: 'muted' }, it.assigned_to_me ? 'Assigned to me' : 'Not assigned to me'));
    case 'project':
      return h('span', { title: `Project ${it.identity.project.value}` }, it.project_path);
  }
}

const META_COLS = ['title', 'state', 'project'] as const;

function processMatrix(o: { id: string; label: string; recs: readonly ItemView[]; ui: ListUi; empty: HTMLElement }): Kid {
  if (!o.recs.length) return o.empty;
  const { recs, ui, label } = o;
  const wrap = h('div', { class: 'mx-wrap', tabindex: '0', role: 'region', 'aria-label': label, 'data-scroll': o.id });
  const cols = ui.columns;
  const envs = visibleEnvs(recs, cols, scopeProjects());
  const stages = visibleStages(cols, envs);
  const procs = recs.map((v) => processOf(v));
  const so = { det: false, envs: envs.map((e) => e.name) };
  const cell = (P: ReturnType<typeof processOf>, st: StageDef): HTMLTableCellElement => {
    const r = stageRun(P, st, so);
    return h('td', { class: `stage lk-${r.basis}` }, r.nodes);
  };
  if (ui.orientation === 'columns' && mobileQuery.matches) {
    // Narrow screens: stage names become full-width section rows whose label
    // stays pinned while the item columns scroll, so no label column takes
    // space from the evidence.
    wrap.append(
      h(
        'table',
        { class: 'mx inv proc proc-m' },
        h('caption', { class: 'sr' }, `${label}: one column per work item; process stages as section rows, read top to bottom`),
        h(
          'thead',
          null,
          h(
            'tr',
            null,
            recs.map((v) => h('th', { class: `colh${v.hidden ? ' is-hidden' : ''}`, scope: 'col' }, workHead(v, true, cols))),
          ),
        ),
        stages.map((st, si) =>
          h(
            'tbody',
            { class: `stg${si === 0 ? ' first' : ''}${st.summary ? ' summary' : ''}` },
            h('tr', { class: 'stg-h' }, h('th', { colspan: String(recs.length), scope: 'colgroup' }, h('span', { class: 'stg-l' }, stageLabel(st)))),
            h(
              'tr',
              { class: st.summary ? 'summary' : null },
              procs.map((P) => cell(P, st)),
            ),
          ),
        ),
      ),
    );
  } else if (ui.orientation === 'columns') {
    wrap.append(
      h(
        'table',
        { class: 'mx inv proc' },
        h('caption', { class: 'sr' }, `${label}: one column per work item; process stages as rows, read top to bottom`),
        h(
          'thead',
          null,
          h(
            'tr',
            null,
            h('th', { class: 'rh corner', scope: 'col' }, h('span', { class: 'muted' }, 'Stage')),
            recs.map((v) => h('th', { class: `colh${v.hidden ? ' is-hidden' : ''}`, scope: 'col' }, workHead(v, true, cols))),
          ),
        ),
        h(
          'tbody',
          null,
          stages.map((st) =>
            h(
              'tr',
              { class: st.summary ? 'summary' : null },
              h('th', { class: 'rh', scope: 'row' }, stageLabel(st)),
              procs.map((P) => cell(P, st)),
            ),
          ),
        ),
      ),
    );
  } else {
    const meta = META_COLS.filter((c) => cols.includes(c));
    wrap.append(
      h(
        'table',
        { class: 'mx proc-rows' },
        h('caption', { class: 'sr' }, `${label}: one row per work item; process stages left to right`),
        h(
          'thead',
          null,
          h(
            'tr',
            null,
            h('th', { class: 'rh', scope: 'col' }, 'Item'),
            meta.map((c) => h('th', { scope: 'col' }, colLabel('work_items', c))),
            stages.map((st) => h('th', { scope: 'col', title: st.hint }, st.label)),
          ),
        ),
        h(
          'tbody',
          null,
          recs.map((v, i) => {
            const P = procs[i];
            return h(
              'tr',
              { class: v.hidden ? 'is-hidden' : null },
              h('th', { class: 'rh', scope: 'row' }, workHead(v, false, cols)),
              meta.map((c) => h('td', { class: `c-${c}` }, workMeta(v, c))),
              P ? stages.map((st) => cell(P, st)) : null,
            );
          }),
        ),
      ),
    );
  }
  return mxFrame(wrap, label);
}

/* ------------------------------------------------------ work screen */

export function workScreen(compare: boolean, gate: Kid): HTMLElement {
  const uiKey = compare ? 'compare' : 'work_items';
  const ui = S.ui[uiKey];
  const wf = S.ui.work_items.filters;
  const all = views();
  const ms = wf.milestone;
  const msOn = ms.mode !== 'all';
  const selected = all.filter((v) => v.selected);
  let recs: ItemView[];
  let msOut = 0;
  if (compare) {
    // Compare shows the shared selection, narrowed by the shared milestone filter.
    const sel = selected.filter((v) => !v.hidden || wf.show_hidden);
    recs = sel.filter((v) => msMatch(v, ms));
    msOut = sel.length - recs.length;
  } else recs = all.filter((v) => workMatches(v, wf, ui.projectSet));
  recs = sortRecords(recs, ui, workSortKey, (v) => v.pinned);
  // Browser-local attention filter on top of the shared filters; the
  // attention counts always describe the records before it.
  const shared = recs;
  const ak = S.attn[uiKey];
  if (ak) recs = recs.filter((v) => hasAttention(v, ak));
  const selectedElsewhere = (S.prefs?.selected.length ?? 0) - selected.length;
  const groups = [...new Set((S.prefs?.groups ?? []).map((g) => g.name))];
  const hiddenSel = selected.filter((v) => v.hidden && !wf.show_hidden).length;

  // One header row: title, counts and the view toolbar. The repository scope
  // is the top-bar selector, so it is not repeated here.
  const head = h(
    'div',
    { class: 'sh' },
    h(
      'div',
      { class: 'sh-title' },
      h('h1', null, compare ? 'Compare' : 'Work items'),
      S.dash
        ? h(
            'span',
            { class: 'count' },
            compare
              ? [
                  `${recs.length} of ${selected.length} selected`,
                  hiddenSel ? ` · ${hiddenSel} hidden` : '',
                  msOut ? ` · ${msOut} outside the milestone filter` : '',
                  selectedElsewhere > 0 ? ` · ${selectedElsewhere} more outside this repository scope or snapshot` : '',
                ].join('')
              : `${recs.length} shown · ${S.dash.total} in snapshot · ${selected.length} selected`,
          )
        : null,
    ),
    // Layout controls are inert without records, so the empty comparison hides them.
    compare && !recs.length ? null : viewControls('work_items', uiKey, { saveable: !compare, rowsLabel: 'Rows', colsLabel: 'Process columns', lanes: true }),
  );

  const candidates = compare
    ? sortRecords(
        all.filter((v) => !v.selected && (!v.hidden || wf.show_hidden)),
        { sort: 'identity', descending: false },
        workSortKey,
      )
    : [];
  const addSelect = (): HTMLSelectElement =>
    h(
      'select',
      {
        class: 'select',
        'aria-label': 'Add work item to comparison',
        'data-fk': 'cmp-add',
        disabled: !S.prefs || !S.dash || !candidates.length,
        onchange: (e: Event) => {
          const v = candidates.find((x) => wkStr(x.item.identity) === controlValue(e));
          if (v) void pref({ operation: 'select', key: v.item.identity, enabled: true }, `Select #${v.item.identity.issue.value}`);
        },
      },
      h('option', { value: '' }, candidates.length ? 'Add item to comparison…' : 'All visible items are selected'),
      candidates.map((v) => h('option', { value: wkStr(v.item.identity) }, `#${v.item.identity.issue.value} ${v.item.title}`)),
    );

  let bar: HTMLElement;
  if (compare) {
    bar = h(
      'div',
      { class: 'filterbar' },
      recs.length || msOut ? addSelect() : null,
      milestoneControl(),
      selected.length
        ? h(
            'button',
            {
              class: 'btn',
              type: 'button',
              'data-fk': 'cmp-clear',
              onclick: () =>
                void (async () => {
                  if (
                    !(await confirmDialog(
                      'Clear selection',
                      `Deselect all ${selected.length} items in ${scopeLabel()}? The selection is shared through preferences.`,
                      'Clear selection',
                    ))
                  )
                    return;
                  for (const v of selected)
                    void pref({ operation: 'select', key: v.item.identity, enabled: false }, `Deselect #${v.item.identity.issue.value}`);
                })(),
            },
            icon('close'),
            'Clear selection',
          )
        : null,
    );
  } else {
    const nMore = [wf.assigned, !!wf.group, wf.show_hidden, msOn].filter(Boolean).length;
    const compareLink = selected.length ? h('a', { class: 'btn', href: to('#/compare') }, icon('compare'), `Compare ${selected.length}`) : null;
    const secondary: Kid[] = [
      milestoneControl(),
      h(
        'label',
        { class: 'check' },
        h('input', { type: 'checkbox', checked: wf.assigned, 'data-fk': 'w-assigned', onchange: (e: Event) => setWorkFilter({ assigned: checkedOf(e) }) }),
        'Assigned to me',
      ),
      h(
        'select',
        { class: 'select', 'aria-label': 'Group filter', 'data-fk': 'w-group', onchange: (e: Event) => setWorkFilter({ group: controlValue(e) }) },
        h('option', { value: '' }, 'All groups'),
        groups.map((g) => h('option', { value: g, selected: wf.group === g }, g)),
        wf.group && !groups.includes(wf.group) ? h('option', { value: wf.group, selected: true }, `${wf.group} (no longer exists)`) : null,
      ),
      h(
        'label',
        { class: 'check' },
        h('input', { type: 'checkbox', checked: wf.show_hidden, 'data-fk': 'w-hidden', onchange: (e: Event) => setWorkFilter({ show_hidden: checkedOf(e) }) }),
        'Show hidden',
      ),
    ];
    bar = h(
      'div',
      { class: 'filterbar', role: 'search' },
      h(
        'div',
        { class: 'search', title: 'Searches #id, title, project, labels, branches, !MR and MR titles, tags, #pipeline, groups and milestone title' },
        icon('search'),
        h('input', {
          class: 'input',
          type: 'search',
          placeholder: 'Search items…',
          'aria-label': 'Search work items by #id, title, label, branch, !MR, tag, #pipeline, group or milestone',
          value: wf.search,
          'data-fk': 'q-work',
          'data-search': '',
          maxlength: '200',
          oninput: (e: Event) => setWorkFilter({ search: controlValue(e) }, 600),
        }),
      ),
      h(
        'div',
        { class: 'seg', role: 'group', 'aria-label': 'State' },
        STATES.work_items.map((s) =>
          h(
            'button',
            { type: 'button', 'aria-pressed': String(wf.state === s), 'data-fk': `ws-${s}`, onclick: () => setWorkFilter({ state: s }) },
            s === 'opened' ? 'Opened' : s === 'closed' ? 'Closed' : 'All',
          ),
        ),
      ),
      // Narrow screens fold the secondary filters into one menu.
      mobileQuery.matches
        ? menu(
            'wfilters',
            h(
              'summary',
              { class: `btn${nMore ? ' on' : ''}`, 'data-fk': 'w-more', 'aria-label': `More filters${nMore ? `, ${nMore} active` : ''}` },
              icon('filter'),
              'Filters',
              nMore ? h('span', { class: 'nav-count' }, String(nMore)) : null,
            ),
            [
              h('div', { class: 'menu-title' }, 'Filters'),
              h('div', { class: 'menu-stack' }, secondary),
              // The Compare shortcut moves into this sheet on narrow screens
              // (Compare also stays in the navigation).
              compareLink ? h('div', { class: 'menu-stack menu-sep' }, compareLink) : null,
            ],
          )
        : [secondary, compareLink],
    );
  }

  let empty: HTMLElement;
  if (ak && shared.length) {
    empty = emptyState({
      title: `No shown item is in “${ATTN[ak].label}”`,
      body: 'The attention filter applies in this browser only, on top of the shared filters.',
      actions: h(
        'button',
        {
          class: 'btn sm',
          type: 'button',
          onclick: () => {
            S.attn[uiKey] = null;
            render();
          },
        },
        'Show all',
      ),
      compact: true,
    });
  } else if (compare) {
    empty = emptyState({
      title: msOut ? 'No selected item matches the milestone filter' : 'No items selected',
      body: msOut
        ? `${plural(msOut, 'selected item')} ${msOut === 1 ? 'is' : 'are'} outside "${msModeLabel(ms)}". Choose "All milestones" to compare them.`
        : `Pick items here or tick them in Work items. Four or more sit side by side and scroll. The selection is shared through preferences for ${scopeLabel()}.`,
      actions: [msOut ? null : addSelect(), h('a', { class: 'btn sm', href: to('#/work') }, icon('work', 'sm'), 'Go to Work items')],
      compact: true,
    });
  } else {
    empty = emptyState({
      title: 'No work items match these filters',
      body: `Clear the search, choose "All"${msOn ? ', choose "All milestones"' : ''} or enable "Show hidden".`,
      compact: true,
    });
  }

  return h(
    'div',
    { class: 'screen fill' },
    head,
    bar,
    gate ?? [
      msNote(compare ? selected : all.filter((v) => workMatches(v, { ...wf, milestone: { mode: 'all', selected: null } }, ui.projectSet))),
      attentionBar(shared, uiKey),
      recs.length
        ? h(
            'div',
            { class: 'board-tools' },
            ui.orientation === 'columns' ? legendEl() : null,
            S.mode === 'visual' && ui.orientation === 'columns' && !mobileQuery.matches ? evidenceToggle(uiKey) : null,
          )
        : null,
      S.mode === 'visual'
        ? flowBoard({
            id: `fx-${uiKey}`,
            label: compare ? 'Comparison of selected work items' : 'Work items',
            recs,
            ui,
            // Work Overview only: chips that the exact active filter guarantees
            // for every shown item are stated once, by the filter controls.
            head: (v) => workHead(v, true, ui.columns, compare ? null : { state: wf.state !== 'all', assigned: wf.assigned }),
            empty,
            board: uiKey,
            compare,
          })
        : processMatrix({ id: `mx-${uiKey}`, label: compare ? 'Comparison of selected work items' : 'Work items', recs, ui, empty }),
    ],
  );
}

/* ------------------------------------------------------ item detail */

export function itemScreen(p: string, i: string, gate: Kid): HTMLElement {
  const k = `${p}/${i}`;
  const back = h('a', { href: to('#/work'), class: 'd-crumbs' }, icon('back', 'sm'), 'Work items');
  if (S.scope.project != null && Number(p) !== S.scope.project) {
    return h(
      'div',
      { class: 'screen' },
      back,
      emptyState({
        title: `Work item #${i} belongs to ${projectPath(Number(p))}`,
        body: `It is outside the selected repository (${scopeLabel()}), so its data is not loaded here.`,
        actions: h('a', { class: 'btn sm', href: to(`#/item/${p}/${i}`, Number(p)) }, icon('repo', 'sm'), 'Switch repository and open'),
      }),
    );
  }
  if (gate) return h('div', { class: 'screen' }, back, gate);
  const st = S.itemState.get(k) ?? null;
  const v = S.items.get(k) ?? S.d?.items.get(k) ?? null;
  if (!v) {
    const sentence = (s: string): string => (/[.!?]$/.test(s.trim()) ? s.trim() : `${s.trim()}.`);
    return h(
      'div',
      { class: 'screen' },
      back,
      st?.kind === 'loading'
        ? emptyState({ title: `Loading work item #${i}…`, status: true, compact: true })
        : emptyState({
            title: `Work item #${i} (project ${p}) is unavailable`,
            body:
              st?.kind === 'error'
                ? `${sentence(st.error)}${st.status === 404 ? ' It is not in the current snapshot.' : ''}`
                : 'It is not in the current snapshot.',
            actions: [
              h('a', { class: 'btn sm primary', href: to('#/work') }, icon('back', 'sm'), 'Back to Work items'),
              h('button', { class: 'btn sm', type: 'button', onclick: () => void loadItem(p, i) }, icon('retry', 'sm'), 'Try again'),
            ],
          }),
    );
  }
  const it = v.item;
  const id = it.identity;
  const n = `#${id.issue.value}`;

  const header = h(
    'div',
    { class: 'd-head' },
    h(
      'div',
      { class: 'd-crumbs' },
      h('a', { href: to('#/work') }, 'Work items'),
      '›',
      h('span', null, it.project_path),
      '›',
      h('span', { class: 'mono' }, n),
      st?.kind === 'loading' ? h('span', { class: 'muted' }, 'Updating…') : null,
      st?.kind === 'error' ? h('span', { class: 'chip st t-warn', title: st.error }, h('span', null, 'Detail request failed; showing snapshot copy')) : null,
      h('span', { class: 'spacer' }),
      modeSwitch(),
    ),
    h('h1', { class: 'd-title' }, it.title),
    attentionLine(v, 8),
    h(
      'div',
      { class: 'd-actions' },
      h(
        'div',
        { class: 'd-facts' },
        workStateBadge(it.state),
        h('span', { class: 'chip' }, it.assigned_to_me ? 'Assigned to me' : 'Not assigned to me'),
        it.milestone
          ? milestoneChip(it.milestone)
          : h('span', { class: 'chip', title: 'This work item has no milestone' }, icon('milestone', 'sm'), h('span', null, 'No milestone')),
        it.labels.map((l) => h('span', { class: 'chip' }, l)),
        extLink(it.link, 'Issue'),
      ),
      h(
        'div',
        { class: 'd-tools', role: 'group', 'aria-label': 'Work item preferences' },
        toggleBtn(
          'pin',
          v.pinned,
          v.pinned ? 'Pinned' : 'Pin',
          () => void pref({ operation: 'pin', key: id, enabled: !v.pinned }, `${v.pinned ? 'Unpin' : 'Pin'} ${n}`),
        ),
        toggleBtn(
          'hide',
          v.hidden,
          v.hidden ? 'Hidden' : 'Hide',
          () => void pref({ operation: 'hide', key: id, enabled: !v.hidden }, `${v.hidden ? 'Unhide' : 'Hide'} ${n}`),
        ),
        toggleBtn(
          'compare',
          v.selected,
          v.selected ? 'In compare' : 'Add to compare',
          () => void pref({ operation: 'select', key: id, enabled: !v.selected }, `${v.selected ? 'Deselect' : 'Select'} ${n}`),
          'Compare',
        ),
        bookmarkBtn({ kind: 'work_item', key: id }, `${n} ${it.title}`),
      ),
    ),
  );

  const P = processOf(v);
  // Every environment configured for this project (and any only in the data).
  // The runtime read and manual test controls live in the Environments panel
  // above, so the Detailed lane shows those facts without duplicate controls.
  const so = { det: true, envs: P.envDefs.map((e) => e.name), envActions: false };
  const lane =
    S.mode === 'visual'
      ? itemFlow(v)
      : h(
          'ol',
          { class: 'lane', 'aria-label': 'Delivery process, read top to bottom' },
          stagesFor(P.envDefs).map((s) => {
            const r = stageRun(P, s, so);
            return h(
              'li',
              { class: `lane-step lk-${r.basis}${s.summary ? ' summary' : ''}` },
              h('div', { class: 'lane-label', title: s.hint }, icon(s.icon, 'sm'), h('span', null, s.label)),
              h('div', { class: 'lane-body' }, r.nodes),
            );
          }),
        );
  // The native cross-project graph is read once per scope, after render.
  if (!S.graphs.has(k)) queueMicrotask(() => void loadGraph(p, i));
  focusOnce(k);
  return h(
    'div',
    { class: 'screen' },
    header,
    h(
      'div',
      { class: 'd-grid' },
      h(
        'div',
        { class: 'd-main' },
        environmentsPanel(P),
        h(
          'section',
          { class: 'sec', 'aria-label': 'Process' },
          h(
            'div',
            { class: 'sec-h' },
            icon('lanes', 'sm'),
            h('h2', null, 'Process'),
            h('span', { class: 'muted' }, S.mode === 'visual' ? 'Each step opens its evidence' : 'Full evidence'),
            S.mode === 'visual' ? h('div', { class: 'toolbar' }, evidenceToggle('item')) : null,
          ),
          legendEl(),
          lane,
        ),
        graphBlock(p, i, k),
      ),
      h('div', { class: 'd-side' }, checklistSection(v), previewSection(v), groupSection(v), overrideSection(v)),
    ),
  );
}

// One-shot scroll after navigation from a Work column (environment) or a
// pipeline drawer (graph). It runs after this render has restored focus.
function focusOnce(k: string): void {
  const ft = S.focusTarget;
  if (!ft) return;
  const env = ft.startsWith(`env:${k}:`) ? ft.slice(`env:${k}:`.length) : null;
  const graph = ft === `graph:${k}`;
  if (!env && !graph) return;
  S.focusTarget = null;
  if (graph) S.graphOpen.set(k, true);
  // Arriving at an environment ("Record test" / "Test result") opens its editor.
  if (env) S.sections.set(recordKey(`${k}:${env}`), true);
  queueMicrotask(() => {
    const el = document.getElementById(graph ? 'item-graph' : `env-card-${env ?? ''}`);
    if (!el) return;
    const smooth = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    el.scrollIntoView({ block: 'start', behavior: smooth ? 'smooth' : 'auto' });
    el.focus({ preventScroll: true });
  });
}

// The cross-project graph opens with a one-line summary; open by default in
// Detailed, closed in the Overview. The open state is browser memory only.
function graphBlock(p: string, i: string, k: string): HTMLDetailsElement {
  const st = S.graphs.get(k) ?? null;
  let sum: string;
  if (!st || st.kind === 'loading') sum = 'reading…';
  else if (st.kind === 'error') sum = 'unavailable';
  else {
    const g = st.result;
    const deps = g.nodes.reduce((n, x) => n + (x.kind === 'unavailable' ? 0 : x.deployments.length), 0);
    sum = `${plural(g.nodes.length, 'pipeline')} · ${plural(g.edges.length, 'trigger')}${deps ? ` · ${plural(deps, 'deployment')} linked by pipeline` : ''}`;
  }
  return h(
    'details',
    {
      class: 'gsec',
      id: 'item-graph',
      tabindex: '-1',
      open: S.graphOpen.get(k) ?? S.mode !== 'visual',
      ontoggle: (e: Event) => {
        S.graphOpen.set(k, openOf(e));
      },
    },
    h(
      'summary',
      { class: 'gsec-s', 'data-fk': 'graph-toggle' },
      icon('pipeline', 'sm'),
      h('span', { class: 'strong' }, 'Cross-project pipeline graph'),
      h('span', { class: 'muted' }, sum),
    ),
    graphSection(p, i),
  );
}

function checklistSection(v: ItemView): HTMLElement {
  const id = v.item.identity;
  return sec(
    'Manual checklist',
    'checklist',
    h(
      'div',
      { class: 'box pad' },
      h(
        'div',
        { class: 'checklist' },
        CHECKLIST.map(([field, label]) =>
          h(
            'label',
            null,
            h('input', {
              type: 'checkbox',
              checked: v.checklist[field],
              'data-fk': `ck-${field}`,
              disabled: !S.prefs,
              onchange: (e: Event) => void pref({ operation: 'checklist', key: id, enabled: checkedOf(e), checklist_field: field }, `Checklist: ${label}`),
            }),
            label,
          ),
        ),
      ),
      h('p', { class: 'hint' }, 'Local notes in shared preferences. They are not test evidence and never change the MR Draft flag or anything in GitLab.'),
    ),
  );
}

function previewSection(v: ItemView): HTMLElement {
  const k = wkStr(v.item.identity);
  const st = S.previews.get(k) ?? null;
  const advertised = (S.caps?.previews ?? []).filter((a) => PREVIEW_ACTIONS.includes(a));
  const actions = advertised.length ? advertised : PREVIEW_ACTIONS;
  const deferred = new Set(S.caps?.deferred_actions ?? ['ready', 'merge', 'rebase']);
  let result: Kid = null;
  if (st?.kind === 'loading') result = h('p', { class: 'hint', role: 'status' }, `Requesting ${PREVIEW_LABEL[st.action]} preview…`);
  else if (st?.kind === 'error')
    result = h(
      'div',
      { class: 'inline-err', role: 'alert' },
      icon('s_fail', 'sm'),
      h('div', null, h('strong', null, `${PREVIEW_LABEL[st.action]} preview failed`), h('div', null, st.error)),
    );
  else if (st?.kind === 'result') {
    const r = st.result;
    // executed:false and remote_mutation_available:false are contract
    // constants; a response without them is rejected before it gets here.
    result = h(
      'div',
      { class: 'preview-result' },
      h(
        'div',
        { class: 'ph' },
        tone('neutral', 'eye', `${PREVIEW_LABEL[st.action]} preview`),
        tone('neutral', 'lock', 'Not executed'),
        h('span', { class: 'muted' }, 'Remote mutation available: no'),
      ),
      r.description ? h('p', null, r.description) : null,
      r.action === 'tag'
        ? h(
            'dl',
            { class: 'kv' },
            h('dt', null, 'Suggested tag'),
            h('dd', null, r.suggestion ? h('code', { class: 'mono' }, r.suggestion) : none('None supplied')),
            h('dt', null, 'Previous tag'),
            h('dd', null, r.previous_tag ? h('code', { class: 'mono' }, r.previous_tag) : none('None supplied')),
          )
        : null,
      r.blockers.length
        ? h(
            'div',
            null,
            h('strong', null, 'Blockers'),
            h(
              'ul',
              null,
              r.blockers.map((b) => h('li', null, b)),
            ),
          )
        : h('p', { class: 'muted' }, 'The server listed no blockers.'),
    );
  }
  const dWrites = actions.filter((a) => deferred.has(a)).map((a) => PREVIEW_LABEL[a].toLowerCase());
  const prev = S.prevTag.get(k) ?? '';
  let note: string;
  if (st?.kind === 'loading') note = `${PREVIEW_LABEL[st.action]} preview requested`;
  else if (st?.kind === 'error') note = `${PREVIEW_LABEL[st.action]} preview failed`;
  else if (st?.kind === 'result') note = `${PREVIEW_LABEL[st.action]} preview shown`;
  else note = `${actions.length} previews · never executed`;
  return sideSection(
    `previews:${k}`,
    st !== null || prev.trim() !== '',
    'Planning previews',
    'eye',
    note,
    h(
      'div',
      { class: 'box pad lines' },
      // One shared note for the deferred writes; every preview stays available.
      h(
        'p',
        { class: 'hint' },
        `Describes what an action would involve. These previews are never executed.${dWrites.length ? ` Writes for ${dWrites.join(', ')} are deferred; their previews still work.` : ''}`,
      ),
      actions.includes('tag')
        ? h(
            'label',
            { class: 'field' },
            h('span', null, 'Previous tag for tag preview (optional)'),
            h('input', {
              class: 'input mono',
              value: prev,
              'data-fk': 'prev-tag',
              autocomplete: 'off',
              oninput: (e: Event) => {
                S.prevTag.set(k, controlValue(e));
              },
            }),
          )
        : null,
      h(
        'div',
        { class: 'preview-actions' },
        actions.map((a) =>
          h(
            'button',
            {
              class: 'btn sm',
              type: 'button',
              disabled: st?.kind === 'loading',
              'data-fk': `pv-${a}`,
              onclick: () => void preview(v, a),
              title: deferred.has(a) ? 'Write deferred; preview only' : 'Preview only',
            },
            icon('eye', 'sm'),
            `Preview ${PREVIEW_LABEL[a].toLowerCase()}`,
            deferred.has(a) ? h('span', { class: 'sr' }, ' (write deferred)') : null,
          ),
        ),
      ),
      result,
    ),
  );
}

function groupSection(v: ItemView): HTMLElement {
  const id = v.item.identity;
  const wk = wkStr(id);
  const names = [...new Set((S.prefs?.groups ?? []).map((g) => g.name))];
  const typed = grpDraft.get(wk) ?? '';
  const input = h('input', {
    class: 'input',
    placeholder: 'New group name',
    'aria-label': 'New group name',
    'data-fk': 'grp-new',
    autocomplete: 'off',
    maxlength: '80',
    value: typed,
    oninput: (e: Event) => {
      grpDraft.set(wk, controlValue(e));
    },
  });
  const nk = `item:newgroup:${wk}`;
  const nDflt = typed.trim() !== '';
  return sec(
    'Groups',
    'group',
    h(
      'div',
      { class: 'box pad lines' },
      names.length
        ? h(
            'div',
            { class: 'checklist' },
            names.map((g) =>
              h(
                'label',
                null,
                h('input', {
                  type: 'checkbox',
                  checked: v.groups.includes(g),
                  'data-fk': `grp-${g}`,
                  disabled: !S.prefs,
                  onchange: (e: Event) => {
                    const on = checkedOf(e);
                    void pref({ operation: 'group', key: id, enabled: on, group: g }, `${on ? 'Add to' : 'Remove from'} "${g}"`);
                  },
                }),
                g,
              ),
            ),
          )
        : h('p', { class: 'hint' }, 'No groups yet.'),
      // Memberships stay visible above; only the "new group" form folds.
      h(
        'details',
        {
          class: 'grp-new',
          open: sectionOpen(nk, nDflt),
          ontoggle: (e: Event) => {
            const o = openOf(e);
            if (o === nDflt) S.sections.delete(nk);
            else S.sections.set(nk, o);
          },
        },
        h('summary', { class: 'btn sm ghost', 'data-fk': 'grp-new-open' }, icon('plus', 'sm'), 'New group…'),
        h(
          'form',
          {
            class: 'line',
            onsubmit: (e: Event) => {
              e.preventDefault();
              const g = input.value.trim();
              if (g)
                void pref({ operation: 'group', key: id, enabled: true, group: g }, `Add #${id.issue.value} to "${g}"`).then((ok) => {
                  if (ok) grpDraft.delete(wk);
                });
            },
          },
          input,
          h('button', { class: 'btn sm', type: 'submit', disabled: !S.prefs }, icon('plus', 'sm'), 'Add'),
        ),
      ),
    ),
  );
}

type OverrideKind = 'branch' | 'mr' | 'tag';
const isOverrideKind = (s: string): s is OverrideKind => s === 'branch' || s === 'mr' || s === 'tag';

// Typed text of the item side forms, per item, in browser memory: a
// re-render, closing a section or leaving the page never loses it.
interface OvDraft {
  readonly kind: OverrideKind;
  readonly value: string;
  readonly reason: string;
}
const ovDraft = new Map<string, OvDraft>();
const grpDraft = new Map<string, string>();

/**
 * A rarely used item tool folded behind its heading. `dflt` opens it while
 * it holds something (a result, an error, an entry or typed text); the
 * reader's own toggle is kept in browser memory (S.sections).
 */
function sideSection(key: string, dflt: boolean, title: string, ico: IconName, note: string | null, body: Kid): HTMLDetailsElement {
  const sk = `item:${key}`;
  return h(
    'details',
    {
      class: 'sec side-d',
      open: sectionOpen(sk, dflt),
      ontoggle: (e: Event) => {
        const o = openOf(e);
        if (o === dflt) S.sections.delete(sk);
        else S.sections.set(sk, o);
      },
    },
    h(
      'summary',
      { class: 'sec-h side-s', 'data-fk': `side-${key}` },
      icon(ico, 'sm'),
      h('h2', null, title),
      note ? h('span', { class: 'muted side-n' }, note) : null,
    ),
    body,
  );
}

function overrideSection(v: ItemView): HTMLElement {
  const id = v.item.identity;
  const wk = wkStr(id);
  const items = (S.prefs?.overrides ?? []).filter((o) => sameKey(o.key, id));
  const dr: OvDraft = ovDraft.get(wk) ?? { kind: 'branch', value: '', reason: '' };
  const setDr = (patch: Partial<OvDraft>): void => {
    ovDraft.set(wk, { ...(ovDraft.get(wk) ?? dr), ...patch });
  };
  const kind = h(
    'select',
    {
      class: 'select',
      'aria-label': 'Override kind',
      'data-fk': 'ov-kind',
      onchange: (e: Event) => {
        const k = controlValue(e);
        if (isOverrideKind(k)) setDr({ kind: k });
      },
    },
    (['branch', 'mr', 'tag'] as const).map((x) => h('option', { value: x, selected: dr.kind === x }, x === 'mr' ? 'MR IID' : x)),
  );
  const value = h('input', {
    class: 'input mono grow',
    placeholder: 'Name, IID or tag',
    title: 'Branch name, MR IID or tag name',
    'aria-label': 'Override value: branch name, MR IID or tag name',
    required: true,
    maxlength: '200',
    'data-fk': 'ov-val',
    autocomplete: 'off',
    value: dr.value,
    oninput: (e: Event) => setDr({ value: controlValue(e) }),
  });
  const reason = h('input', {
    class: 'input',
    placeholder: 'Reason (required)',
    'aria-label': 'Override reason',
    required: true,
    maxlength: '500',
    'data-fk': 'ov-reason',
    autocomplete: 'off',
    value: dr.reason,
    oninput: (e: Event) => setDr({ reason: controlValue(e) }),
  });
  const run = async (enabled: boolean, k: OverrideKind, val: string, why: string, label: string): Promise<boolean> => {
    if (await pref({ operation: 'override', key: id, enabled, override_kind: k, override_value: val, reason: why }, label)) {
      await reloadItemData(id, 'Override');
      return true;
    }
    return false;
  };
  const typed = !!(dr.value.trim() || dr.reason.trim());
  return sideSection(
    `overrides:${wk}`,
    items.length > 0 || typed,
    'Association overrides',
    'link',
    items.length ? `${items.length} recorded` : typed ? 'draft not recorded' : 'none',
    h(
      'div',
      { class: 'box pad lines' },
      items.length
        ? h(
            'ul',
            { class: 'list' },
            items.map((o) =>
              h(
                'li',
                null,
                h('span', { class: 'chip' }, o.kind),
                h('code', { class: 'mono grow' }, o.value),
                h('span', { class: 'reason muted' }, o.reason),
                h(
                  'button',
                  {
                    class: 'btn sm danger',
                    type: 'button',
                    disabled: !S.prefs,
                    onclick: () => void run(false, o.kind, o.value, o.reason, `Remove ${o.kind} override ${o.value}`),
                  },
                  'Remove',
                ),
              ),
            ),
          )
        : h('p', { class: 'hint' }, 'No local overrides for this item.'),
      h(
        'form',
        {
          class: 'lines',
          onsubmit: (e: Event) => {
            e.preventDefault();
            const k = kind.value;
            const val = value.value.trim();
            const why = reason.value.trim();
            if (!val || !why || !isOverrideKind(k)) return;
            // The typed text is cleared only after the override was recorded.
            void run(true, k, val, why, `Add ${k} override ${val}`).then((ok) => {
              if (ok) ovDraft.delete(wk);
            });
          },
        },
        h('div', { class: 'line ov-in' }, kind, value),
        reason,
        h('button', { class: 'btn sm', type: 'submit', disabled: !S.prefs }, icon('plus', 'sm'), 'Record override'),
      ),
      h(
        'p',
        { class: 'hint' },
        'Overrides change how GSpace attaches evidence to this item, never GitLab. They appear as "Override" provenance and never create a process link on their own.',
      ),
    ),
  );
}

/** Milestone catalog key from the typed filter, for screens that link into it. */
export const selectedMilestoneKey = (): string | null => {
  const m = S.ui.work_items.filters.milestone;
  return m.mode === 'selected' ? msKeyStr(m.selected) : null;
};
