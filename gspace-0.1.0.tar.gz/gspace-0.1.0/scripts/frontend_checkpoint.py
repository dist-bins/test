"""Create a local-only Git checkpoint of the independent frontend.

No remotes, global configuration, hooks, signing, source checkout changes or
network operations are used. This is the sole permitted Git wrapper for Claude.
"""

from __future__ import annotations

import argparse
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend-new"
PATHS = (
    "index.html",
    "styles.css",
    "app.js",
    "theme.js",
    "icon.svg",
    "gspace-wolf.svg",
    "gspace-wolf-gray.svg",
    "API.md",
    "sample-dashboard.json",
    "docs",
    "contracts",
    "src",
    "scripts",
    "package.json",
    "package-lock.json",
    "bun.lock",
    "bunfig.toml",
    "tsconfig.json",
    "biome.json",
    ".gitignore",
)


def run_git(*arguments: str) -> str:
    result = subprocess.run(
        [
            "/usr/bin/git",
            "-C",
            str(FRONTEND),
            "-c",
            "core.hooksPath=/dev/null",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "credential.helper=",
            "-c",
            "user.name=GSpace local snapshots",
            "-c",
            "user.email=gspace@localhost",
            *arguments,
        ],
        env={
            "PATH": "/usr/bin:/bin",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_CONFIG_SYSTEM": "/dev/null",
            "GIT_TERMINAL_PROMPT": "0",
        },
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--message", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 .,:_-]{0,119}", args.message):
        parser.error("Message must be 1-120 plain English characters")
    if FRONTEND.is_symlink() or not FRONTEND.is_dir():
        parser.error("Frontend must be the fixed local directory")
    metadata = FRONTEND / ".git"
    if metadata.is_symlink() or (metadata.exists() and not metadata.is_dir()):
        parser.error("Linked or external Git metadata is not permitted")
    for relative in PATHS:
        candidate = FRONTEND / relative
        if candidate.is_symlink() or (
            candidate.is_dir() and any(path.is_symlink() for path in candidate.rglob("*"))
        ):
            parser.error("Frontend checkpoint paths cannot contain symlinks")
    if not metadata.exists():
        run_git("init", "--template=", "--initial-branch=frontend-checkpoints")
    existing = [relative for relative in PATHS if (FRONTEND / relative).exists()]
    run_git("add", "--all", "--", *existing)
    if run_git("diff", "--cached", "--name-only"):
        print(run_git("commit", "--no-verify", "-m", args.message))
    else:
        print("No frontend changes to checkpoint")
    print("Checkpoint " + run_git("rev-parse", "HEAD"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
