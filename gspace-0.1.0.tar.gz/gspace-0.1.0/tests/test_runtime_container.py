"""Finite fixture-driver safety contracts; actual Docker acceptance is separate."""

import copy
import json
from pathlib import Path
from zipfile import ZipFile

import pytest

from scripts import runtime_container_check as runtime


def test_fixture_resource_guard_does_not_weaken_gitlab_guard():
    from scripts import gitlab_lab

    runtime.budget(8 * runtime.GIB, 2 * runtime.GIB, 2)
    for free, memory, cpus in (
        (8 * runtime.GIB - 1, 2 * runtime.GIB, 2),
        (8 * runtime.GIB, 2 * runtime.GIB - 1, 2),
        (8 * runtime.GIB, 2 * runtime.GIB, 1),
    ):
        with pytest.raises(runtime.RuntimeCheckError):
            runtime.budget(free, memory, cpus)
    assert gitlab_lab.MIN_FREE == 60 * runtime.GIB


def test_only_pinned_platform_digest_can_be_used():
    manifest = json.loads((runtime.ROOT / "integration/fixture-runtime-images.json").read_text())
    for architecture, platform in (("aarch64", "arm64"), ("x86_64", "amd64")):
        selected, base = runtime.base_image(architecture, manifest)
        assert selected == "linux/" + platform
        assert base == "docker.io/library/python@" + manifest["platforms"][platform]
    with pytest.raises(runtime.RuntimeCheckError):
        runtime.base_image("riscv64", manifest)
    manifest["platforms"]["arm64"] = "latest"
    with pytest.raises(runtime.RuntimeCheckError):
        runtime.base_image("aarch64", manifest)


def test_frozen_context_excludes_repository_operator_auth_and_unrelated_files(tmp_path):
    root = tmp_path / "source"
    context = tmp_path / "context"
    context.mkdir()
    for directory in ("integration", "dist", ".state", ".repos", ".docker"):
        (root / directory).mkdir(parents=True)
    for name in ("pyproject.toml", "uv.lock"):
        (root / name).write_text("public tooling")
    for name in ("fixture-runtime.Dockerfile", "runtime_container_probe.py"):
        (root / "integration" / name).write_text("public probe")
    for name in (".state/operator.toml", ".docker/config.json", ".repos/private", "secret.env"):
        (root / name).write_text("excluded private marker")
    with ZipFile(root / "dist" / runtime.WHEEL, "w") as wheel:
        for name in ("index.html", "app.js", "styles.css", "theme.js"):
            wheel.writestr("gspace/static/" + name, "public compiled asset")
    hashes = runtime.freeze_context(root, context)
    assert set(hashes) == runtime.CONTEXT_FILES
    assert {path.name for path in context.iterdir()} == runtime.CONTEXT_FILES
    assert all(b"excluded private marker" not in path.read_bytes() for path in context.iterdir())
    (root / "uv.lock").unlink()
    (root / "uv.lock").symlink_to(root / ".docker/config.json")
    with pytest.raises(runtime.RuntimeCheckError):
        runtime.freeze_context(root, context)


def test_runtime_argv_has_no_mount_or_privileged_escape():
    argv = runtime.container_argv("owned-name", "owned-run", "sha256:owned-image")
    assert argv[:2] == ["docker", "create"]
    for flag, value in (
        ("--network", "none"),
        ("--cap-drop", "ALL"),
        ("--security-opt", "no-new-privileges"),
        ("--memory", str(runtime.MEMORY)),
        ("--memory-swap", str(runtime.MEMORY)),
        ("--cpus", "1"),
        ("--pids-limit", str(runtime.PIDS)),
        ("--user", "65534:65534"),
    ):
        assert argv[argv.index(flag) + 1] == value
    assert "--read-only" in argv
    assert not set(argv) & {"--privileged", "--volume", "-v", "--mount", "--pid", "-p", "-P"}
    assert "noexec,nosuid,nodev" in argv[argv.index("--tmpfs") + 1]
    assert argv[-1] == "sha256:owned-image"


def owned_inspection():
    return {
        "Id": "container-id",
        "Image": "image-id",
        "Config": {
            "Labels": {runtime.LABEL: runtime.MARKER, f"{runtime.LABEL}.run": "run-id"},
            "User": "65534:65534",
            "Volumes": None,
        },
        "HostConfig": {
            "NetworkMode": "none",
            "ReadonlyRootfs": True,
            "CapDrop": ["ALL"],
            "SecurityOpt": ["no-new-privileges"],
            "Memory": runtime.MEMORY,
            "MemorySwap": runtime.MEMORY,
            "NanoCpus": runtime.NANO_CPUS,
            "PidsLimit": runtime.PIDS,
            "Privileged": False,
            "PidMode": "",
            "Binds": None,
            "PortBindings": {},
            "PublishAllPorts": False,
            "Tmpfs": {"/tmp": "rw,noexec,nosuid,nodev,size=67108864,mode=1777"},
        },
    }


def test_cleanup_requires_all_owned_identity_dimensions():
    observed = owned_inspection()
    assert runtime.owned_container(observed, "container-id", "run-id", "image-id")
    for dimension in ("Id", "Image", "label", "run-label"):
        changed = copy.deepcopy(observed)
        if dimension in ("Id", "Image"):
            changed[dimension] = "foreign"
        else:
            key = runtime.LABEL if dimension == "label" else f"{runtime.LABEL}.run"
            changed["Config"]["Labels"][key] = "foreign"
        assert not runtime.owned_container(changed, "container-id", "run-id", "image-id")


@pytest.mark.parametrize(
    ("key", "unsafe"),
    [
        ("NetworkMode", "bridge"),
        ("ReadonlyRootfs", False),
        ("CapDrop", []),
        ("SecurityOpt", []),
        ("Memory", 0),
        ("MemorySwap", -1),
        ("NanoCpus", 0),
        ("PidsLimit", 0),
        ("Privileged", True),
        ("PidMode", "host"),
        ("Binds", ["/private:/host"]),
        ("Mounts", [{"Source": "/var/run/docker.sock"}]),
        ("PortBindings", {"80/tcp": [{"HostPort": "8080"}]}),
        ("PublishAllPorts", True),
        ("Tmpfs", {}),
        ("Tmpfs", {"/tmp": "rw,size=67108864"}),
    ],
)
def test_actual_enforcement_inspection_rejects_escape_or_missing_limit(key, unsafe):
    observed = owned_inspection()
    assert all(runtime.verify_enforcement(observed).values())
    observed["HostConfig"][key] = unsafe
    with pytest.raises(runtime.RuntimeCheckError):
        runtime.verify_enforcement(observed)


def test_runtime_image_contains_no_uv_or_build_context():
    source = (Path(runtime.ROOT) / "integration/fixture-runtime.Dockerfile").read_text()
    final = source.split(" AS runtime\n", 1)[1]
    assert "COPY --from=dependencies /app/.venv /app/.venv" in final
    assert "uv==" not in final and ".whl" not in final and "uv.lock" not in final
    assert "UV_NO_BUILD=1" in source
    assert "uv sync --locked --no-dev --no-install-project" in source
