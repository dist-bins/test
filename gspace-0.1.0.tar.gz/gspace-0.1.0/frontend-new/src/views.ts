// View toolbar (orientation, fields, sort, saved views), generic resource
// matrices with overflow cues, and saved-view conversion. Saved views are
// shared preferences scoped by host and projects.

import type { Column, SavedView } from './api';
import type { Kid, Tone } from './dom';
import { checkedOf, controlValue, h, icon, plural } from './dom';
import { projectPath } from './model';
import { render } from './render';
import type { ListUi, Scope, Sort, UiKey, ViewState } from './state';
import {
  colLabel,
  colsFor,
  defaultUi,
  ENV_PREFIX,
  normMs,
  pref,
  report,
  S,
  SCOPE_LABEL,
  SCOPE_ROUTE,
  SORT_LABEL,
  SORTS,
  STATES,
  say,
  sectionOpen,
  setMode,
  to,
  toggleSection,
} from './state';
import { dialog, emptyState, go, menu } from './ui';
import { msModeLabel, persistWorkFilters } from './work';

export const mobileQuery = window.matchMedia('(max-width: 759px)');

/* ---------------------------------------------------- saved views */

export function viewProjectsLabel(v: Pick<SavedView, 'projects'>): string {
  return v.projects.length ? v.projects.map((p) => projectPath(p.value)).join(', ') : 'all configured projects';
}

const isSort = (scope: Scope, s: string): s is Sort => SORTS[scope].some((x) => x === s);
const validState = (scope: Scope, s: ViewState): boolean => STATES[scope].includes(s);
// Saved custom-environment columns stay valid even while the current scope
// does not report that environment (the server validates configured scope).
const keepCol = (scope: Scope, c: Column): boolean => colsFor(scope).includes(c) || (scope === 'work_items' && c.startsWith(ENV_PREFIX));

export function uiFromView(v: SavedView): ListUi {
  const scope = v.scope;
  const d = defaultUi(scope);
  const f = v.filters;
  let cols: Column[] = v.columns.filter((c, i, a) => c !== 'identity' && keepCol(scope, c) && a.indexOf(c) === i);
  if (!cols.length) cols = d.columns;
  return {
    filters: {
      state: validState(scope, f.state) ? f.state : STATES[scope].includes('all') ? 'all' : (STATES[scope][0] ?? 'all'),
      search: f.search,
      assigned: f.assigned,
      group: f.group,
      show_hidden: f.show_hidden,
      milestone: normMs(f.milestone),
    },
    sort: isSort(scope, v.sort) ? v.sort : d.sort,
    descending: v.descending,
    columns: cols,
    orientation: v.orientation,
    view: v.name,
    projectSet: v.projects.length > 1 ? new Set(v.projects.map((p) => p.value)) : null,
    autoEnv: false,
  };
}

const viewScopeProjects = (): { value: number }[] => (S.scope.project != null ? [{ value: S.scope.project }] : []);

export function toSavedView(scope: Scope, ui: ListUi, name: string, host: string): SavedView {
  const f = ui.filters;
  return {
    name,
    host,
    scope,
    projects: ui.projectSet ? [...ui.projectSet].map((value) => ({ value })) : viewScopeProjects(),
    filters: {
      state: validState(scope, f.state) ? f.state : 'all',
      search: f.search.slice(0, 200),
      assigned: f.assigned,
      group: f.group.slice(0, 80),
      show_hidden: f.show_hidden,
      authored: true, // the server rejects authored:false by design
      // Milestones exist only for work items; other scopes store "all".
      milestone: scope === 'work_items' ? normMs(f.milestone) : { mode: 'all', selected: null },
    },
    sort: isSort(scope, ui.sort) ? ui.sort : (SORTS[scope][0] ?? 'identity'),
    descending: ui.descending,
    columns: ['identity', ...ui.columns.filter((c) => keepCol(scope, c))],
    orientation: ui.orientation,
  };
}

function viewDirty(scope: Scope, ui: ListUi): boolean {
  const host = S.host;
  const v = host ? S.prefs?.saved_views.find((x) => x.name === ui.view && x.scope === scope && x.host === host) : undefined;
  if (!v || !host) return false;
  return JSON.stringify(toSavedView(scope, ui, v.name, host)) !== JSON.stringify(toSavedView(scope, uiFromView(v), v.name, host));
}

export function applyView(v: SavedView): void {
  if (v.host !== S.host) {
    report('view', `Cannot open view "${v.name}"`, `It was saved for host ${v.host}, not ${S.host ?? 'the current host'}.`, { tone: 'warn' });
    return;
  }
  S.ui[v.scope] = uiFromView(v);
  if (v.scope === 'work_items') {
    // Work-item filters are the shared persisted filters; applying the view saves them.
    S.filterSeq++;
    persistWorkFilters(0);
  }
  const only = v.projects.length === 1 ? (v.projects[0]?.value ?? null) : null;
  // A view carries its own repository scope; a change is announced, never silent.
  const before = S.scope.project;
  if (only !== before) {
    const name = (p: number | null): string => (p == null ? 'all configured projects' : projectPath(p));
    const text = `Opened view “${v.name}”: repository scope changed from ${name(before)} to ${name(only)}${v.projects.length > 1 ? `, limited to ${viewProjectsLabel(v)}` : ''}.`;
    S.scopeNotice = { text, screen: SCOPE_ROUTE[v.scope] };
    say(text);
  }
  go(to(`#/${SCOPE_ROUTE[v.scope]}`, only));
}

/* -------------------------------------------------------- toolbar */

export interface ViewControlOpts {
  readonly saveable?: boolean;
  readonly rowsLabel?: string;
  readonly colsLabel?: string;
  readonly lanes?: boolean;
}

export function viewControls(scope: Scope, uiKey: UiKey, opts: ViewControlOpts = {}): HTMLDivElement {
  const saveable = opts.saveable ?? true;
  const rowsLabel = opts.rowsLabel ?? 'Rows';
  const colsLabel = opts.colsLabel ?? 'Columns';
  const ui = S.ui[uiKey];
  const host = S.host;
  const vs = (S.prefs?.saved_views ?? []).filter((v) => v.scope === scope && v.host === host);
  const dirty = viewDirty(scope, ui);
  const set = (patch: Partial<ListUi>): void => {
    Object.assign(ui, patch);
    render();
  };
  const mob = mobileQuery.matches;
  const wide = mob ? null : 'lbl-wide';
  const viewSel =
    saveable && vs.length
      ? h(
          'select',
          {
            class: 'select',
            'aria-label': 'Apply saved view',
            'data-fk': `view-${uiKey}`,
            onchange: (e: Event) => {
              const v = vs.find((x) => x.name === controlValue(e));
              if (v) applyView(v);
              else {
                ui.view = null;
                ui.projectSet = null;
                render();
              }
            },
          },
          h('option', { value: '' }, 'No saved view'),
          vs.map((v) => h('option', { value: v.name, selected: v.name === ui.view }, v.name)),
        )
      : null;
  const marks = [
    dirty ? h('span', { class: 'chip st t-warn', title: 'Current settings differ from the saved view' }, 'Modified') : null,
    ui.projectSet ? h('span', { class: 'chip', title: 'The saved view limits records to these projects' }, `${ui.projectSet.size} projects`) : null,
  ];
  const orient = h(
    'div',
    { class: 'seg', role: 'group', 'aria-label': 'Orientation' },
    h(
      'button',
      {
        type: 'button',
        'aria-pressed': String(ui.orientation === 'columns'),
        'aria-label': colsLabel,
        'data-fk': `or-c-${uiKey}`,
        onclick: () => set({ orientation: 'columns' }),
        title: 'One column per record; fields or process stages as rows',
      },
      icon(opts.lanes ? 'lanes' : 'columns', 'sm'),
      h('span', { class: wide, 'aria-hidden': 'true' }, colsLabel),
    ),
    h(
      'button',
      {
        type: 'button',
        'aria-pressed': String(ui.orientation === 'rows'),
        'aria-label': rowsLabel,
        'data-fk': `or-r-${uiKey}`,
        onclick: () => set({ orientation: 'rows' }),
        title: 'One row per record',
      },
      icon('rows', 'sm'),
      h('span', { class: wide, 'aria-hidden': 'true' }, rowsLabel),
    ),
  );
  const offered = colsFor(scope);
  const fieldList: Kid[] = [
    h('div', { class: 'menu-title' }, 'Visible fields'),
    offered.map((c) =>
      h(
        'label',
        { class: 'check bare' },
        h('input', {
          type: 'checkbox',
          checked: c === 'identity' || ui.columns.includes(c),
          disabled: c === 'identity',
          'data-fk': `col-${uiKey}-${c}`,
          onchange: (e: Event) => {
            const cols = ui.columns.filter((x) => x !== c);
            if (checkedOf(e)) {
              const rank = offered.indexOf(c);
              const at = cols.findIndex((x) => offered.indexOf(x) > rank);
              cols.splice(at < 0 ? cols.length : at, 0, c);
            }
            set({ columns: cols, autoEnv: false });
          },
        }),
        colLabel(scope, c),
      ),
    ),
    scope === 'work_items'
      ? [
          h('div', { class: 'menu-title' }, 'Jobs in cells'),
          h(
            'label',
            { class: 'check bare', title: 'Off: cells list operator-marked important jobs and link to the pipeline for the rest' },
            h('input', {
              type: 'checkbox',
              checked: S.allJobs,
              'data-fk': 'all-jobs',
              onchange: (e: Event) => {
                S.allJobs = checkedOf(e);
                render();
              },
            }),
            'Show all jobs, not only important ones',
          ),
        ]
      : null,
  ];
  const sortSel = h(
    'select',
    {
      class: 'select',
      'aria-label': 'Sort by',
      'data-fk': `sort-${uiKey}`,
      onchange: (e: Event) => {
        const v = controlValue(e);
        if (isSort(scope, v)) set({ sort: v });
      },
    },
    SORTS[scope].map((s) => h('option', { value: s, selected: s === ui.sort }, `Sort: ${SORT_LABEL[s]}`)),
  );
  // Direction reads from the icon and name; no pressed fill, so it looks the
  // same on every screen whichever direction is the default.
  const dirBtn = h(
    'button',
    {
      class: 'btn icon dir',
      type: 'button',
      'aria-pressed': String(ui.descending),
      'data-fk': `desc-${uiKey}`,
      'aria-label': ui.descending ? 'Sort descending (activate for ascending)' : 'Sort ascending (activate for descending)',
      title: ui.descending ? 'Descending' : 'Ascending',
      onclick: () => set({ descending: !ui.descending }),
    },
    icon(ui.descending ? 'sort_desc' : 'sort_asc'),
  );
  const saveBtn = saveable
    ? h(
        'button',
        {
          class: 'btn',
          type: 'button',
          'data-fk': `save-${uiKey}`,
          disabled: !S.prefs || !host,
          'aria-label': 'Save view',
          title: !host ? 'Host unknown; a view must be saved for a specific host' : 'Save these settings as a shared view for this host and repository scope',
          onclick: () => saveViewDialog(scope, uiKey),
        },
        icon('save'),
        h('span', { class: wide, 'aria-hidden': 'true' }, 'Save view'),
      )
    : null;
  // Fields, orientation and sort apply in the Overview and in Detailed alike
  // (Overview cards show the chosen fields; rows lay cards out as a list).
  // Built only for the layout that uses it (a node has one parent).
  const fieldsMenu = (): HTMLDetailsElement =>
    menu(
      `cols-${uiKey}`,
      h(
        'summary',
        { class: 'btn', 'data-fk': `colsbtn-${uiKey}`, 'aria-label': 'Visible fields' },
        icon('columns'),
        h('span', { class: 'lbl-wide' }, 'Fields'),
        h('span', { class: 'nav-count' }, String(ui.columns.length + 1)),
      ),
      fieldList,
    );

  if (mob) {
    // Narrow screens: one "View" menu instead of a toolbar that pushes content down.
    return h(
      'div',
      { class: 'toolbar' },
      modeSwitch(),
      viewSel,
      marks,
      menu(
        `vopts-${uiKey}`,
        h('summary', { class: 'btn', 'data-fk': `vopts-${uiKey}`, 'aria-label': 'View options: layout, fields, sort and save' }, icon('views'), 'View'),
        h(
          'div',
          { class: 'menu-stack' },
          h('div', { class: 'menu-title' }, 'Layout'),
          orient,
          h('div', { class: 'menu-title' }, 'Sort'),
          h('div', { class: 'line' }, sortSel, dirBtn),
          fieldList,
          saveBtn ? h('div', { class: 'menu-sep' }, saveBtn) : null,
        ),
      ),
    );
  }
  return h('div', { class: 'toolbar' }, modeSwitch(), viewSel, marks, orient, fieldsMenu(), sortSel, dirBtn, saveBtn);
}

// The one switch between the Overview (stored value "visual") and the
// Detailed evidence views. Same data, filters and selection either way. It
// is shown only on screens where the two readings differ.
export function modeSwitch(): HTMLDivElement {
  const b = (mode: 'visual' | 'detailed', label: string, ico: 'layers' | 'rows', title: string): HTMLButtonElement =>
    h(
      'button',
      { type: 'button', 'aria-pressed': String(S.mode === mode), 'data-fk': `mode-${mode}`, onclick: () => setMode(mode), title },
      icon(ico, 'sm'),
      h('span', null, label),
    );
  return h(
    'div',
    { class: 'seg mode-seg', role: 'group', 'aria-label': 'Reading: Overview or Detailed (this browser only)' },
    b('visual', 'Overview', 'layers', 'Overview: the facts that answer this page first; evidence opens in place (this browser only)'),
    b('detailed', 'Detailed', 'rows', 'Detailed: full evidence tables and process cells (this browser only)'),
  );
}

function saveViewDialog(scope: Scope, uiKey: UiKey): void {
  const host = S.host;
  if (!host) return;
  const ui = S.ui[uiKey];
  const existing = new Set((S.prefs?.saved_views ?? []).filter((v) => v.host === host).map((v) => v.name));
  const input = h('input', { class: 'input', name: 'name', required: true, maxlength: '80', value: ui.view ?? '', autocomplete: 'off' });
  const f = ui.filters;
  const sv = toSavedView(scope, ui, 'x', host);
  const summary = [
    `Scope: ${SCOPE_LABEL[scope]} on ${host} · ${viewProjectsLabel(sv)}`,
    `State: ${sv.filters.state}`,
    f.search ? `Search: "${f.search}"` : null,
    scope === 'work_items'
      ? `Assigned only: ${f.assigned ? 'yes' : 'no'} · Hidden shown: ${f.show_hidden ? 'yes' : 'no'}${f.group ? ` · Group: ${f.group}` : ''}`
      : null,
    scope === 'work_items' ? `Milestone: ${msModeLabel(normMs(sv.filters.milestone))}` : null,
    scope === 'mrs' ? 'Authored by me (the only MR scope the server accepts)' : null,
    `Sort: ${SORT_LABEL[sv.sort]} ${ui.descending ? 'descending' : 'ascending'} · ${sv.columns.length} fields · ${ui.orientation === 'columns' ? 'records as columns' : 'records as rows'}`,
  ].filter((x): x is string => x !== null);
  dialog(
    'Save view',
    [
      h('label', { class: 'field' }, h('span', null, 'Name'), input),
      h(
        'ul',
        { class: 'hint' },
        summary.map((s) => h('li', null, s)),
      ),
      h('p', { class: 'hint' }, 'Stored in the shared preferences file. Saving a name that already exists replaces that view.'),
    ],
    {
      okLabel: 'Save view',
      onOk: async () => {
        const name = input.value.trim();
        if (!name) return 'Enter a name.';
        const replaced = existing.has(name);
        const ok = await pref({ operation: 'saved_view_set', view: toSavedView(scope, ui, name, host) }, `${replaced ? 'Replace' : 'Save'} view "${name}"`);
        if (!ok) return 'Not saved — see the problem list.';
        ui.view = name;
        render();
        return null;
      },
    },
  );
  input.focus();
}

/* ------------------------------------------------------- overflow */

// Horizontal overflow cue for matrices: edge fades and an "n more →" button
// that scrolls; nothing is clipped without a visible signal.
export function updateOverflow(only: HTMLElement | null = null): void {
  const frames = only ? [only] : [...document.querySelectorAll('.mx-frame')];
  for (const frame of frames) {
    const wrap = frame.querySelector('.mx-wrap');
    const more = frame.querySelector('.mx-more');
    if (!(wrap instanceof HTMLElement)) continue;
    const max = wrap.scrollWidth - wrap.clientWidth;
    const right = max > 2 && wrap.scrollLeft < max - 2;
    frame.classList.toggle('ov-r', right);
    frame.classList.toggle('ov-l', max > 2 && wrap.scrollLeft > 2);
    if (!(more instanceof HTMLElement)) continue;
    let n = 0;
    if (right) {
      const edge = wrap.getBoundingClientRect().right;
      for (const th of wrap.querySelectorAll(':scope > table > thead > tr > th:not(.rh)')) if (th.getBoundingClientRect().left + 24 > edge) n++;
    }
    more.hidden = !right;
    const text = n ? `${n} more` : 'More';
    if (more.dataset.text !== text) {
      more.dataset.text = text;
      more.replaceChildren(h('span', null, text), icon('next', 'sm'));
      more.setAttribute('aria-label', n ? `${n} more columns to the right; scroll right` : 'Scroll right');
    }
  }
}

export function mxFrame(wrap: HTMLElement, label: string): HTMLDivElement {
  const frame = h(
    'div',
    { class: 'mx-frame' },
    wrap,
    h(
      'button',
      {
        class: 'mx-more',
        type: 'button',
        hidden: true,
        'aria-label': `Scroll ${label} right`,
        onclick: () =>
          wrap.scrollBy({
            left: Math.max(200, wrap.clientWidth * 0.8),
            behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
          }),
      },
      icon('next', 'sm'),
    ),
  );
  wrap.addEventListener('scroll', () => updateOverflow(frame), { passive: true });
  return frame;
}

/* --------------------------------------------------------- matrix */

// While a details drawer is open the list keeps identity, status and ref and
// drops these lower-priority fields instead of squeezing every column.
const DRAWER_DROP: Readonly<Record<Scope, readonly Column[]>> = {
  work_items: [],
  mrs: ['project', 'pipeline', 'updated_at'],
  branches: ['project', 'mr', 'pipeline'],
  pipelines: ['project', 'jobs', 'publish'],
};

export interface MatrixOpts<R> {
  readonly id: string;
  readonly label: string;
  readonly scope: Scope;
  readonly records: readonly R[];
  readonly columns: readonly Column[];
  readonly orientation: 'rows' | 'columns';
  readonly head: (r: R, inverted: boolean) => Kid;
  readonly cell: (r: R, c: Column) => Kid;
  readonly keyOf: (r: R) => string;
  readonly selectedKey: string | null;
  readonly emptyText: string;
  readonly drawer: boolean;
  /** Overview card (same records, same order) showing the chosen fields. */
  readonly visualCard?: (r: R, cols: readonly Column[]) => HTMLElement;
  /** Overview groups by the state that answers the page's question; order inside a group follows the sort. */
  readonly groups?: (records: readonly R[]) => readonly MatrixGroup<R>[];
}

export interface MatrixGroup<R> {
  readonly key: string;
  readonly label: string;
  readonly tone: Tone | null;
  readonly hint: string;
  readonly records: readonly R[];
  /** Open by default (the user's toggle is kept in browser memory). */
  readonly open: boolean;
}

export function matrix<R>(o: MatrixOpts<R>): Kid {
  if (!o.records.length) return emptyState({ title: o.emptyText });
  const label = (c: Column): string => colLabel(o.scope, c);
  if (S.mode === 'visual' && o.visualCard) {
    const card = o.visualCard;
    const grid = (recs: readonly R[], name: string): HTMLUListElement =>
      h(
        'ul',
        { class: `vgrid${o.orientation === 'rows' ? ' as-rows' : ''}`, 'aria-label': name },
        recs.map((r) => h('li', { class: `vcard${o.keyOf(r) === o.selectedKey ? ' sel' : ''}` }, card(r, o.columns))),
      );
    const groups = o.groups ? o.groups(o.records).filter((g) => g.records.length) : [];
    if (!groups.length) return grid(o.records, `${o.label} (overview)`);
    return h(
      'div',
      { class: 'vgroups', 'data-scroll': `${o.id}-groups` },
      groups.map((g) => {
        const key = `${o.id}:${g.key}`;
        const open = sectionOpen(key, g.open);
        return h(
          'section',
          { class: 'vgroup', 'aria-label': `${g.label}, ${g.records.length}` },
          h(
            'button',
            {
              class: `vgroup-h${g.tone ? ` st t-${g.tone}` : ''}`,
              type: 'button',
              'aria-expanded': String(open),
              'data-fk': `grp-${key}`,
              title: g.hint,
              onclick: () => toggleSection(key, g.open),
            },
            icon(open ? 'down' : 'next', 'sm'),
            h('span', { class: 'vgroup-l' }, g.label),
            h('span', { class: 'nav-count' }, String(g.records.length)),
            h('span', { class: 'muted vgroup-hint' }, g.hint),
          ),
          open ? grid(g.records, g.label) : null,
        );
      }),
    );
  }
  let columns = o.columns;
  let note: Kid = null;
  if (o.drawer && o.orientation === 'rows' && !mobileQuery.matches) {
    const drop = DRAWER_DROP[o.scope];
    const kept = columns.filter((c) => !drop.includes(c));
    const gone = columns.filter((c) => drop.includes(c));
    if (gone.length) {
      note = h('p', { class: 'hint mx-note' }, `${plural(gone.length, 'field')} hidden while details are open: ${gone.map(label).join(', ')}.`);
      columns = kept;
    }
  }
  // Narrow screens: one card per record instead of a clipped table.
  if (o.orientation === 'rows' && mobileQuery.matches) {
    return h(
      'ul',
      { class: 'cards', 'aria-label': o.label },
      o.records.map((r) =>
        h(
          'li',
          { class: `card${o.keyOf(r) === o.selectedKey ? ' sel' : ''}` },
          // The row head (not the column head) so a title shown as a field is
          // not repeated in the card heading.
          h('div', { class: 'card-h' }, o.head(r, false)),
          h(
            'dl',
            { class: 'card-kv' },
            columns.map((c) => [h('dt', null, label(c)), h('dd', null, o.cell(r, c))]),
          ),
        ),
      ),
    );
  }
  const wrap = h('div', { class: 'mx-wrap', tabindex: '0', role: 'region', 'aria-label': o.label, 'data-scroll': o.id });
  if (o.orientation === 'columns') {
    wrap.append(
      h(
        'table',
        { class: 'mx inv' },
        h('caption', { class: 'sr' }, `${o.label}: records as columns, fields as rows`),
        h(
          'thead',
          null,
          h(
            'tr',
            null,
            h('th', { class: 'rh', scope: 'col' }, 'Field'),
            o.records.map((r) => h('th', { class: `colh${o.keyOf(r) === o.selectedKey ? ' sel' : ''}`, scope: 'col' }, o.head(r, true))),
          ),
        ),
        h(
          'tbody',
          null,
          columns.map((c) =>
            h(
              'tr',
              null,
              h('th', { class: 'rh', scope: 'row' }, label(c)),
              o.records.map((r) => h('td', { class: `c-${c}${o.keyOf(r) === o.selectedKey ? ' sel' : ''}` }, o.cell(r, c))),
            ),
          ),
        ),
      ),
    );
  } else {
    wrap.append(
      h(
        'table',
        { class: 'mx' },
        h('caption', { class: 'sr' }, `${o.label}: one row per record`),
        h(
          'thead',
          null,
          h(
            'tr',
            null,
            h('th', { class: 'rh', scope: 'col' }, label('identity')),
            columns.map((c) => h('th', { scope: 'col' }, label(c))),
          ),
        ),
        h(
          'tbody',
          null,
          o.records.map((r) =>
            h(
              'tr',
              { class: o.keyOf(r) === o.selectedKey ? 'sel' : null },
              h('th', { class: 'rh', scope: 'row' }, o.head(r, false)),
              columns.map((c) => h('td', { class: `c-${c}` }, o.cell(r, c))),
            ),
          ),
        ),
      ),
    );
  }
  return [note, mxFrame(wrap, o.label)];
}

export type SortKey = readonly (string | number | null)[];

export function sortRecords<R>(
  items: readonly R[],
  ui: Pick<ListUi, 'sort' | 'descending'>,
  keyFn: (r: R, sort: Sort) => SortKey,
  pinnedFirst: ((r: R) => boolean) | null = null,
): R[] {
  const dir = ui.descending ? -1 : 1;
  const cmp = (a: R, b: R): number => {
    if (pinnedFirst) {
      const p = Number(pinnedFirst(b)) - Number(pinnedFirst(a));
      if (p) return p;
    }
    const ka = keyFn(a, ui.sort);
    const kb = keyFn(b, ui.sort);
    for (let i = 0; i < Math.max(ka.length, kb.length); i++) {
      const x = ka[i] ?? null;
      const y = kb[i] ?? null;
      if (x === y) continue;
      if (x === null) return 1; // missing values last regardless of direction
      if (y === null) return -1;
      const r = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), 'en', { numeric: true });
      if (r) return r * dir;
    }
    return 0;
  };
  return [...items].sort(cmp);
}
