"""Render the fixed, inert proposed brand asset in a local browser."""

from __future__ import annotations

import argparse
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=("color", "gray"), default="color")
    args = parser.parse_args()
    name = "gspace-wolf-gray" if args.variant == "gray" else "gspace-wolf"
    asset = ROOT / "frontend-new" / f"{name}.svg"
    url = f"http://127.0.0.1:8877/assets/{name}.svg"
    output = ROOT / "output/brand"
    output.mkdir(parents=True, exist_ok=True)
    document = ET.fromstring(asset.read_bytes())
    allowed = {
        "svg": {"width", "height", "viewBox", "role", "aria-labelledby"},
        "title": {"id"},
        "desc": {"id"},
        "path": {"fill", "d"},
    }
    for element in document.iter():
        name = element.tag.rsplit("}", 1)[-1]
        assert name in allowed and set(element.attrib) <= allowed[name]
    if args.variant == "gray":
        original = ET.fromstring((ROOT / "frontend-new/gspace-wolf.svg").read_bytes())
        assert len(list(original.iter())) == len(list(document.iter()))
        for colored, gray in zip(original.iter(), document.iter(), strict=True):
            assert colored.tag == gray.tag
            assert {key: value for key, value in colored.attrib.items() if key != "fill"} == {
                key: value for key, value in gray.attrib.items() if key != "fill"
            }
            if "fill" in gray.attrib:
                fill = gray.attrib["fill"]
                assert len(fill) == 7 and fill[1:3] == fill[3:5] == fill[5:7]
    name = asset.stem
    with urlopen(url, timeout=5) as response:
        assert response.status == 200 and response.read() == asset.read_bytes()
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        page = browser.new_page(viewport={"width": 400, "height": 400})
        for size in (32, 64, 256):
            page.set_content(
                '<body style="margin:0;background:transparent">'
                f'<img alt="GSpace wolf" width="{size}" height="{size}" src="{url}">'
            )
            page.wait_for_function("document.querySelector('img').complete")
            assert page.locator("img").evaluate("image => image.naturalWidth") == 256
            page.locator("img").screenshot(
                path=str(output / f"{name}-{size}.png"),
                omit_background=True,
            )
            for appearance, background in (("light", "#FAFAFA"), ("dark", "#111111")):
                page.locator("body").evaluate(
                    "(body, color) => body.style.background = color", background
                )
                page.screenshot(
                    path=str(output / f"{name}-{size}-{appearance}.png"),
                    clip={"x": 0, "y": 0, "width": size, "height": size},
                )
        browser.close()
    report = {
        "result": "passed",
        "url": url,
        "variant": args.variant,
        "sizes_px": [32, 64, 256],
        "inert_svg": True,
        "current_icon_replaced": False,
        "appearances": ["transparent", "light", "dark"],
        "geometry_matches_color": True if args.variant == "gray" else None,
    }
    report_name = "gray-report.json" if args.variant == "gray" else "report.json"
    (output / report_name).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
