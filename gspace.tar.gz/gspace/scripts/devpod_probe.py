"""Bounded, configuration-free read diagnostics using the operator's native glab."""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
from collections.abc import Callable, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import TextIO
from urllib.parse import quote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from gspace.access import ProfileTransport  # noqa: E402
from gspace.access_models import GlabProfile  # noqa: E402
from gspace.config import ProjectConfig  # noqa: E402
from gspace.glab import AdapterError, RunResult, run_argv  # noqa: E402
from gspace.models import PipelineId, PipelineKey, ProjectId  # noqa: E402

MAX_REQUESTS = 15
TOTAL_SECONDS = 120.0
REQUEST_SECONDS = 10.0
MAX_BYTES = 5_000_000
Runner = Callable[[list[str], float], RunResult]


def origin(value: str) -> str:
    """Accept an explicit HTTPS origin without credentials or URL extras."""
    try:
        parsed = urlsplit(value)
        port = parsed.port
        if (
            value != value.strip()
            or re.search(r"[\s\\\x00-\x1f\x7f]", value)
            or parsed.scheme != "https"
            or not parsed.hostname
            or parsed.username is not None
            or parsed.password is not None
            or parsed.path not in ("", "/")
            or parsed.query
            or parsed.fragment
            or "?" in value
            or "#" in value
            or parsed.netloc.endswith(":")
            or (port is not None and not 1 <= port <= 65535)
            or not re.fullmatch(r"[A-Za-z0-9.:[\]-]+", parsed.netloc)
        ):
            raise ValueError
    except ValueError:
        raise ValueError(
            "Host must be an HTTPS origin, without credentials, path or query"
        ) from None
    return f"https://{parsed.netloc}"


def positive_id(value: object) -> int | None:
    return value if type(value) is int and 0 < value <= 2**63 - 1 else None


def project_path(value: object) -> str | None:
    if not isinstance(value, str) or len(value) > 1024:
        return None
    parts = value.split("/")
    if len(parts) < 2 or any(
        not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*", part) or part in (".", "..")
        for part in parts
    ):
        return None
    return value


def project_selector(value: str) -> int | str:
    if re.fullmatch(r"[0-9]{1,19}", value):
        numeric = positive_id(int(value))
        if numeric is not None:
            return numeric
    path = project_path(value)
    if path is None:
        raise ValueError("Project must be a positive numeric ID or group/project path")
    return path


@dataclass(frozen=True)
class Check:
    capability: str
    status: str
    reason: str
    http_status: int | None = None


class NativeRunner:
    """Bound every native request, retaining only the numeric HTTP status for reports."""

    def __init__(self, runner: Runner = run_argv) -> None:
        self.runner = runner
        self.started = time.monotonic()
        self.requests = 0
        self.http_status: int | None = None

    def __call__(self, argv: list[str], timeout: float) -> RunResult:
        self.http_status = None
        remaining = TOTAL_SECONDS - (time.monotonic() - self.started)
        if self.requests >= MAX_REQUESTS or remaining <= 0:
            raise AdapterError("budget", "Probe budget exhausted")
        self.requests += 1
        result = self.runner([*argv, "--include"], min(timeout, REQUEST_SECONDS, remaining))
        if len(result.stdout) > MAX_BYTES:
            raise AdapterError("limit", "Response exceeds byte limit")
        raw = result.stdout.replace(b"\r\n", b"\n")
        header, separator, body = raw.partition(b"\n\n")
        matched = re.match(rb"HTTP/[0-9.]+ ([0-9]{3})(?:\s|$)", header)
        if matched is None or not separator:
            raise AdapterError("transport", "HTTP response status unavailable")
        self.http_status = int(matched.group(1))
        return RunResult(code=result.code if 200 <= self.http_status < 300 else 1, stdout=body)


def failure(capability: str, native: NativeRunner, error: Exception) -> Check:
    status = native.http_status
    if status in (401, 403):
        return Check(capability, "unavailable", "access_denied", status)
    if status == 404:
        return Check(capability, "unavailable", "not_found_or_hidden", status)
    code = error.code if isinstance(error, AdapterError) else "transport"
    reasons = {
        "unavailable": "native_glab_unavailable",
        "timeout": "request_timeout",
        "budget": "request_budget_exhausted",
        "limit": "response_limit",
        "validation": "unexpected_response",
        "scope": "scope_validation_failed",
    }
    return Check(capability, "unknown", reasons.get(code, "request_failed"), status)


def execute(
    host: str,
    selected: int | str,
    *,
    runner: Runner = run_argv,
    transport_factory: Callable[..., ProfileTransport] = ProfileTransport,
) -> dict[str, object]:
    """Run fixed reads. Authentication stays in glab; no configuration is read or written."""
    host = origin(host)
    selected = project_selector(str(selected))
    native = NativeRunner(runner)
    checks: list[Check] = []
    identity: dict[str, object] = {"host": host, "project_id": None, "user_id": None}
    report: dict[str, object] = {
        "schema": "gspace.devpod-read-probe.v1",
        "identity": identity,
        "gitlab_version": "unknown",
        "edition": "unknown",
        "write_permission": "not_tested",
        "coverage": "one_page_sample_only",
        "redirect_policy": "native_glab_default",
        "limits": {"requests": MAX_REQUESTS, "total_seconds": TOTAL_SECONDS},
    }

    def finish() -> dict[str, object]:
        report["requests"] = native.requests
        report["checks"] = [asdict(check) for check in checks]
        return report

    path: str | None = selected if isinstance(selected, str) else None
    project_id: int
    if isinstance(selected, str):
        try:
            response = native(
                [
                    "glab",
                    "api",
                    "--hostname",
                    urlsplit(host).netloc,
                    "--method",
                    "GET",
                    "projects/" + quote(selected, safe=""),
                ],
                REQUEST_SECONDS,
            )
            if response.code:
                raise AdapterError("remote", "Project resolution failed")
            raw = json.loads(response.stdout)
            resolved = positive_id(raw.get("id")) if isinstance(raw, dict) else None
            if resolved is None or raw.get("path_with_namespace") != selected:
                raise AdapterError("validation", "Project resolution identity mismatch")
            project_id = resolved
            checks.append(Check("project_resolution", "readable", "selected_path_resolved", 200))
        except (AdapterError, ValueError, OSError, RecursionError) as error:
            checks.append(failure("project_resolution", native, error))
            return finish()
    else:
        project_id = selected
    identity["project_id"] = project_id
    project = ProjectId(value=project_id)
    profile = GlabProfile(name="devpod-probe", host=host, projects=(project,))
    transport = transport_factory(profile, runner=native)
    base = f"projects/{project_id}"

    def read(name: str, endpoint: str, *, collection: bool = False) -> object | None:
        native.http_status = None
        try:
            raw = transport.request(
                "GET", endpoint, query={"per_page": "1", "page": "1"} if collection else None
            )
            if not isinstance(raw, list if collection else dict):
                raise AdapterError("validation", "Unexpected response shape")
            checks.append(
                Check(
                    name,
                    "readable",
                    "empty_sample" if raw == [] else "read_succeeded",
                    native.http_status,
                )
            )
            return raw
        except (AdapterError, ValueError, OSError, RecursionError) as error:
            checks.append(failure(name, native, error))
            return None

    version = read("version", "version")
    user = read("user", "user")
    metadata = read("metadata", "metadata")
    detail = read("project", base)
    if isinstance(user, dict):
        identity["user_id"] = positive_id(user.get("id"))
    for source in (version, metadata):
        if isinstance(source, dict):
            value = source.get("version")
            if isinstance(value, str) and re.fullmatch(
                r"\d{1,4}\.\d{1,4}\.\d{1,4}(?:-(?:ee|ce))?", value
            ):
                report["gitlab_version"] = value
                if value.endswith(("-ee", "-ce")):
                    report["edition"] = "EE" if value.endswith("-ee") else "CE"
            enterprise = source.get("enterprise")
            if type(enterprise) is bool:
                report["edition"] = "EE" if enterprise else "CE"
    if isinstance(detail, dict) and positive_id(detail.get("id")) == project_id:
        path = project_path(detail.get("path_with_namespace"))
    elif detail is not None:
        checks[-1] = Check("project", "unknown", "project_identity_mismatch", native.http_status)
        return finish()
    issues = read("issues", base + "/issues", collection=True)
    read("merge_requests", base + "/merge_requests", collection=True)
    read("branches", base + "/repository/branches", collection=True)
    read("tags", base + "/repository/tags", collection=True)
    pipelines = read("pipelines", base + "/pipelines", collection=True)
    read("deployments", base + "/deployments", collection=True)
    read("milestones", base + "/milestones", collection=True)

    def sample_id(rows: object, key: str) -> int | None:
        if isinstance(rows, list) and rows and isinstance(rows[0], dict):
            return positive_id(rows[0].get(key))
        return None

    pipeline_id = sample_id(pipelines, "id")
    issue_iid = sample_id(issues, "iid")
    if pipeline_id is None:
        checks.append(Check("jobs", "not_tested", "not_tested_no_resource"))
    else:
        read("jobs", base + f"/pipelines/{pipeline_id}/jobs", collection=True)
    if issue_iid is None:
        checks.append(Check("related_merge_requests", "not_tested", "not_tested_no_resource"))
    else:
        read(
            "related_merge_requests",
            base + f"/issues/{issue_iid}/related_merge_requests",
            collection=True,
        )
    if pipeline_id is None or path is None:
        checks.append(Check("native_pipeline_graphql", "not_tested", "not_tested_no_resource"))
    else:
        native.http_status = None
        try:
            graph = transport.pipeline_graphql(
                ProjectConfig(id=project, path=path),
                PipelineKey(project=project, pipeline=PipelineId(value=pipeline_id)),
                None,
            )
            data = graph.get("data") if isinstance(graph, dict) else None
            node = data.get("project") if isinstance(data, dict) else None
            pipeline = node.get("pipeline") if isinstance(node, dict) else None
            if not isinstance(graph, dict) or graph.get("errors") or not isinstance(pipeline, dict):
                checks.append(
                    Check(
                        "native_pipeline_graphql",
                        "unknown",
                        "graphql_data_unavailable",
                        native.http_status,
                    )
                )
            elif (
                pipeline.get("id") != f"gid://gitlab/Ci::Pipeline/{pipeline_id}"
                or node.get("id") != f"gid://gitlab/Project/{project_id}"
                or node.get("fullPath") != path
            ):
                checks.append(
                    Check(
                        "native_pipeline_graphql",
                        "unknown",
                        "graph_identity_mismatch",
                        native.http_status,
                    )
                )
            else:
                checks.append(
                    Check(
                        "native_pipeline_graphql", "readable", "read_succeeded", native.http_status
                    )
                )
        except (AdapterError, ValueError, OSError, RecursionError) as error:
            checks.append(failure("native_pipeline_graphql", native, error))
    return finish()


def main(
    argv: Sequence[str] | None = None,
    *,
    input_fn: Callable[[str], str] = input,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    runner: Runner = run_argv,
) -> int:
    parser = argparse.ArgumentParser(
        description="Read-only DevPod diagnostics. No GSpace config or frontend build required.",
        epilog="Uses existing native glab authentication. Never tests writes or reads auth files. "
        "At most 15 requests, 10 seconds each and 120 seconds total; no retries. "
        "Collections use one page of one row; GraphQL uses one canonical bounded page.",
    )
    parser.add_argument("--host", "-H", help="GitLab HTTPS origin, e.g. https://gitlab.example.org")
    parser.add_argument("--project", "-p", help="Project numeric ID or group/project path")
    parser.add_argument("--json", "-j", action="store_true", help="Print sanitized JSON")
    parser.add_argument("--output", "-o", type=Path, help="Save sanitized JSON to a new file")
    args = parser.parse_args(argv)
    source = stdin if stdin is not None else sys.stdin
    destination = stdout if stdout is not None else sys.stdout
    try:
        # Validate every supplied argument before prompting or invoking native glab.
        host = origin(args.host) if args.host is not None else None
        selected = project_selector(args.project) if args.project is not None else None
        if (host is None or selected is None) and not source.isatty():
            raise ValueError("Supply --host and --project when standard input is not a terminal")
        if host is None:
            host = origin(input_fn("GitLab HTTPS origin: "))
        if selected is None:
            selected = project_selector(input_fn("Project ID or group/project: "))
        if args.output is not None and (args.output.exists() or not args.output.parent.is_dir()):
            raise ValueError("Output must name a new file in an existing directory")
        report = execute(host, selected, runner=runner)
        encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
        if args.output is not None:
            with args.output.open("x", encoding="utf-8") as handle:
                handle.write(encoded)
        if args.json:
            destination.write(encoded)
        else:
            identity = report["identity"]
            destination.write(f"GitLab {report['gitlab_version']} ({report['edition']})\n")
            destination.write(f"Scope: {identity}\n")
            for check in report["checks"]:
                status = f" HTTP {check['http_status']}" if check["http_status"] else ""
                destination.write(
                    f"{check['capability']}: {check['status']} ({check['reason']}{status})\n"
                )
            destination.write(
                f"Requests: {report['requests']}/{MAX_REQUESTS}. "
                "One-page samples. Write permission: not tested.\n"
            )
        return 0
    except (EOFError, KeyboardInterrupt):
        destination.write("Probe cancelled. No automatic retry.\n")
        return 130
    except ValueError as error:
        parser.error(str(error))
    except OSError:
        parser.error("Cannot create the requested output file; existing files are preserved")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
