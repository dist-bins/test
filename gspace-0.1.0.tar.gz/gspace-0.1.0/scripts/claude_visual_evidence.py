"""Verify image tool access using public metadata from this task's own Claude output."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stream", type=Path)
    parser.add_argument("--phase", choices=["before", "after", "visual-mode"], required=True)
    parser.add_argument("--recover-denied-document", action="store_true")
    args = parser.parse_args()
    stream = args.stream.resolve()
    if not stream.is_relative_to(ROOT / "output/claude"):
        raise ValueError("Only task-owned Claude output may be read")
    manifest = ROOT / "frontend-new/review-input" / args.phase / "manifest.json"
    capture = json.loads(manifest.read_text())
    expected = [str((ROOT / "frontend-new" / row["image"]).resolve()) for row in capture["images"]]
    calls = {}
    images = set()
    models = []
    denials = []
    recovered = None
    allowed_document = ROOT / f"frontend-new/docs/visual-review-{args.phase}.md"
    for line in stream.read_text().splitlines():
        row = json.loads(line)
        if row.get("type") == "assistant":
            for block in row.get("message", {}).get("content", []):
                if block.get("type") == "tool_use":
                    calls[block["id"]] = block
        elif row.get("type") == "user":
            for block in row.get("message", {}).get("content", []):
                if block.get("type") != "tool_result":
                    continue
                call = calls.get(block.get("tool_use_id"), {})
                path = call.get("input", {}).get("file_path")
                content = block.get("content")
                if isinstance(content, list) and any(c.get("type") == "image" for c in content):
                    images.add(path)
                if block.get("is_error"):
                    denials.append({"tool": call.get("name"), "file": path})
                    if (
                        args.recover_denied_document
                        and call.get("name") == "Write"
                        and path == str(allowed_document)
                    ):
                        # Preserve the exact Claude-authored review, without fabricating findings.
                        allowed_document.write_text(call["input"]["content"])
                        recovered = str(allowed_document)
        elif row.get("type") == "result":
            models = list(row.get("modelUsage", {}))
    report = {
        "phase": args.phase,
        "models": models,
        "expected_images": len(expected),
        "image_tool_results": len(images),
        "missing_images": sorted(set(expected) - images),
        "denials": denials,
        "recovered_exact_claude_document": recovered,
    }
    hashes = capture.get("asset_hashes", {})
    assets_match = bool(hashes) and all(
        hashlib.sha256((ROOT / "frontend-new" / name).read_bytes()).hexdigest() == digest
        for name, digest in hashes.items()
    )
    compiled_phase = args.phase in ("after", "visual-mode")
    report["assets_match_capture"] = assets_match if compiled_phase else None
    image_hashes_match = all(
        hashlib.sha256((ROOT / "frontend-new" / row["image"]).read_bytes()).hexdigest()
        == row["sha256"]
        for row in capture["images"]
    )
    report["image_hashes_match_capture"] = image_hashes_match
    report["passed"] = (
        not report["missing_images"]
        and models == ["claude-opus-5-5"]
        and allowed_document.is_file()
        and (not compiled_phase or assets_match)
        and image_hashes_match
        and all(
            denial["tool"] == "Write"
            and denial["file"] == str(allowed_document)
            and recovered == str(allowed_document)
            for denial in denials
        )
    )
    output = ROOT / f"output/verification/claude-visual-{args.phase}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
