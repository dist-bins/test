"""Build a minimal frozen wheel context and verify an owned network-none fixture.

Only the ephemeral container created by this invocation is removed. Images and
public reports are retained. Operator Docker auth, contexts and mounts are unused.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path
from zipfile import ZipFile

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.gitlab_lab import docker_run

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output/verification/backend-closure-20261020/container"
GIB = 1024**3
MIN_FREE = 8 * GIB
MEMORY = 512 * 1024**2
NANO_CPUS = 1_000_000_000
PIDS = 96
TMPFS = {"/tmp": "rw,noexec,nosuid,nodev,size=67108864,mode=1777"}
LABEL = "org.gspace.fixture-runtime"
MARKER = "local-network-denial-v1"
WHEEL = "gspace-0.1.0-py3-none-any.whl"
CONTEXT_FILES = frozenset(
    {
        "Dockerfile",
        "pyproject.toml",
        "uv.lock",
        WHEEL,
        "runtime_container_probe.py",
        "asset-hashes.json",
    }
)


class RuntimeCheckError(Exception):
    """Finite local-container precondition or enforcement failure."""


def budget(free_bytes: int, memory_bytes: int, cpus: int) -> None:
    if free_bytes < MIN_FREE:
        raise RuntimeCheckError("Fixture requires 8 GiB free host storage; no automatic cleanup")
    if memory_bytes < 2 * GIB or cpus < 2:
        raise RuntimeCheckError("Fixture requires at least 2 GiB Docker memory and 2 CPUs")


def base_image(architecture: str, manifest: dict) -> tuple[str, str]:
    platform = {"aarch64": "arm64", "arm64": "arm64", "x86_64": "amd64", "amd64": "amd64"}.get(
        architecture
    )
    if platform is None:
        raise RuntimeCheckError("Only pinned Linux arm64/amd64 Python bases are supported")
    digest = manifest["platforms"][platform]
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", digest):
        raise RuntimeCheckError("Invalid pinned Python digest")
    return f"linux/{platform}", "docker.io/library/python@" + digest


def freeze_context(root: Path, destination: Path) -> dict[str, str]:
    """Copy an allowlist, never the repository tree or operator state."""
    sources = {
        "Dockerfile": root / "integration/fixture-runtime.Dockerfile",
        "pyproject.toml": root / "pyproject.toml",
        "uv.lock": root / "uv.lock",
        WHEEL: root / "dist" / WHEEL,
        "runtime_container_probe.py": root / "integration/runtime_container_probe.py",
    }
    if any(path.is_symlink() or not path.is_file() for path in sources.values()):
        raise RuntimeCheckError(
            "Frozen context requires ordinary local source files and built wheel"
        )
    for name, source in sources.items():
        shutil.copyfile(source, destination / name)
    with ZipFile(destination / WHEEL) as archive:
        assets = {
            Path(name).name: hashlib.sha256(archive.read(name)).hexdigest()
            for name in archive.namelist()
            if name.startswith("gspace/static/")
            and "/" not in name.removeprefix("gspace/static/")
            and name.endswith((".js", ".css", ".html", ".svg"))
        }
    if not {"index.html", "app.js", "styles.css", "theme.js"}.issubset(assets):
        raise RuntimeCheckError("Wheel lacks required compiled fixture assets")
    (destination / "asset-hashes.json").write_text(json.dumps(assets, indent=2) + "\n")
    if {path.name for path in destination.iterdir()} != CONTEXT_FILES:
        raise RuntimeCheckError("Unexpected frozen Docker context content")
    return {
        name: hashlib.sha256((destination / name).read_bytes()).hexdigest()
        for name in sorted(CONTEXT_FILES)
    }


def container_argv(name: str, run_id: str, image: str) -> list[str]:
    return [
        "docker",
        "create",
        "--name",
        name,
        "--label",
        f"{LABEL}={MARKER}",
        "--label",
        f"{LABEL}.run={run_id}",
        "--network",
        "none",
        "--read-only",
        "--cap-drop",
        "ALL",
        "--security-opt",
        "no-new-privileges",
        "--memory",
        str(MEMORY),
        "--memory-swap",
        str(MEMORY),
        "--cpus",
        "1",
        "--pids-limit",
        str(PIDS),
        "--tmpfs",
        "/tmp:" + TMPFS["/tmp"],
        "--user",
        "65534:65534",
        "--env",
        "HOME=/tmp",
        image,
    ]


def owned_container(observed: dict, container_id: str, run_id: str, image_id: str) -> bool:
    labels = observed.get("Config", {}).get("Labels") or {}
    return (
        observed.get("Id") == container_id
        and observed.get("Image") == image_id
        and labels.get(LABEL) == MARKER
        and labels.get(f"{LABEL}.run") == run_id
    )


def verify_enforcement(observed: dict) -> dict:
    host = observed["HostConfig"]
    checks = {
        "network_none": host["NetworkMode"] == "none",
        "readonly_root": host["ReadonlyRootfs"] is True,
        "all_capabilities_dropped": host["CapDrop"] == ["ALL"],
        "no_new_privileges": "no-new-privileges" in host["SecurityOpt"],
        "memory_bounded": host["Memory"] == MEMORY and host["MemorySwap"] == MEMORY,
        "cpu_bounded": host["NanoCpus"] == NANO_CPUS,
        "pids_bounded": host["PidsLimit"] == PIDS,
        "unprivileged": host["Privileged"] is False,
        "no_host_pid": host["PidMode"] != "host",
        "no_bind_mounts": not host["Binds"]
        and not host.get("Mounts")
        and not observed.get("Mounts"),
        "no_published_ports": not host["PortBindings"] and not host["PublishAllPorts"],
        "tmpfs_only": host["Tmpfs"] == TMPFS,
        "nonroot_user": observed["Config"]["User"] == "65534:65534",
        "no_volumes": not observed["Config"].get("Volumes"),
    }
    if not all(checks.values()):
        raise RuntimeCheckError(f"Container isolation inspection failed: {checks}")
    return checks


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    run_id = uuid.uuid4().hex
    output = args.output.resolve() / run_id
    output.mkdir(parents=True, exist_ok=False)
    report: dict[str, object] = {"passed": False, "run_id": run_id}

    def command(argv: list[str], label: str, timeout: int = 30) -> str:
        try:
            result = docker_run(argv, timeout=timeout)
        except subprocess.TimeoutExpired as error:
            for stream in ("stdout", "stderr"):
                content = getattr(error, stream) or ""
                if isinstance(content, bytes):
                    content = content.decode(errors="replace")
                (output / f"{label}.{stream}.log").write_text(content)
            raise RuntimeCheckError(f"Docker {label} exceeded its {timeout}s bound") from error
        (output / f"{label}.stdout.log").write_text(result.stdout)
        (output / f"{label}.stderr.log").write_text(result.stderr)
        if result.returncode:
            raise RuntimeCheckError(f"Docker {label} failed; see this run's public logs")
        return result.stdout.strip()

    container_id = None
    image_id = None
    try:
        info = command(
            ["docker", "info", "--format", "{{.MemTotal}} {{.NCPU}} {{.Architecture}} {{.OSType}}"],
            "preflight",
        ).split()
        memory, cpus, architecture, os_type = info
        free = shutil.disk_usage(ROOT).free
        budget(free, int(memory), int(cpus))
        if os_type != "linux":
            raise RuntimeCheckError("Fixture requires a Linux Docker engine")
        manifest = json.loads((ROOT / "integration/fixture-runtime-images.json").read_text())
        platform, base = base_image(architecture, manifest)
        report["resources"] = {"free_bytes": free, "docker_memory": int(memory), "cpus": int(cpus)}
        report["platform"] = platform
        report["python_base"] = base
        with tempfile.TemporaryDirectory(prefix="gspace-fixture-build-") as temporary:
            context = Path(temporary)
            hashes = freeze_context(ROOT, context)
            report["context_sha256"] = hashes
            image = "gspace-fixture-runtime:" + run_id
            command(
                [
                    "docker",
                    "build",
                    "--platform",
                    platform,
                    "--network",
                    "default",
                    "--build-arg",
                    f"PYTHON_BASE={base}",
                    "--label",
                    f"{LABEL}={MARKER}",
                    "--tag",
                    image,
                    str(context),
                ],
                "build",
                timeout=600,
            )
        image_id = command(["docker", "image", "inspect", "--format", "{{.Id}}", image], "image")
        report["image_id"] = image_id
        report["image_tag"] = image
        name = "gspace-fixture-" + run_id
        container_id = command(container_argv(name, run_id, image_id), "create")
        observed = json.loads(command(["docker", "inspect", container_id], "inspect-before"))[0]
        if not owned_container(observed, container_id, run_id, image_id):
            raise RuntimeCheckError("Created container identity does not match owned run")
        report["enforcement"] = verify_enforcement(observed)
        result = command(["docker", "start", "--attach", container_id], "run", timeout=90)
        probe = json.loads(result)
        assert probe["passed"] is True
        report["probe"] = probe
        final = json.loads(command(["docker", "inspect", container_id], "inspect-after"))[0]
        if not owned_container(final, container_id, run_id, image_id):
            raise RuntimeCheckError("Finished container identity changed")
        assert final["State"]["ExitCode"] == 0 and not final["State"]["OOMKilled"]
        report["passed"] = True
    except (RuntimeCheckError, OSError, ValueError, AssertionError) as error:
        report["error"] = str(error)
    finally:
        if container_id is not None and image_id is not None:
            try:
                current = json.loads(
                    command(["docker", "inspect", container_id], "inspect-cleanup")
                )[0]
                if not owned_container(current, container_id, run_id, image_id):
                    raise RuntimeCheckError("Refusing cleanup of container with different identity")
                command(["docker", "rm", "--force", container_id], "cleanup")
                report["owned_container_removed"] = True
            except (RuntimeCheckError, OSError, ValueError) as error:
                report["cleanup_error"] = str(error)
                report["passed"] = False
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "report": str(output / "report.json")}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
