"""Common application services. Web and CLI render domain data independently."""

from __future__ import annotations

import os
import tempfile
import threading
import tomllib
from collections.abc import Callable
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path
from typing import Annotated, Literal, Self, assert_never
from urllib.parse import parse_qsl, urlsplit
from zoneinfo import ZoneInfo

from pydantic import Field, model_validator

from gspace.access import ProfileTransport
from gspace.avatars import AvatarResource, ProjectAvatarDTO, ProjectAvatars
from gspace.catalog import MRCatalog, MRCatalogCache, fetch_catalog, fixture_catalog
from gspace.config import AppConfig, Endpoint, ProjectConfig
from gspace.fixture import synthetic_snapshot
from gspace.glab import GlabAdapter, RunResult, UserDTO
from gspace.milestones import MilestoneCatalog, catalog, matches
from gspace.models import (
    ApplicationTestEvidence,
    ApplicationTestRecord,
    Comparison,
    Environment,
    EnvironmentLabel,
    JobId,
    Model,
    Observation,
    Observed,
    PipelineGraph,
    PipelineId,
    PipelineKey,
    ProjectId,
    Snapshot,
    Unknown,
    Version,
    WorkItem,
    WorkKey,
    compare_version,
)
from gspace.navigation import (
    DECORATION_COLORS,
    DECORATION_ICONS,
    Bookmark,
    BookmarkTarget,
    Column,
    NavigationCatalog,
    NavigationDecoration,
    NavigationTarget,
    ResourceReference,
    SavedView,
    SavedViewTarget,
    reference_project,
)
from gspace.observation import observe
from gspace.operator_settings import (
    OperatorSettings,
    OperatorStore,
    SettingsChange,
    SettingsResponse,
)
from gspace.preferences import (
    Checklist,
    Filters,
    Group,
    Override,
    Preferences,
    PreferenceStore,
    StoredPreferences,
)
from gspace.resource_catalog import BranchCatalog, PipelineCatalog, resources
from gspace.test_history import ApplicationTestHistory, TestHistoryEntry, matches_version


class EnvironmentComparison(Model, frozen=True):
    name: EnvironmentLabel
    result: Comparison
    reason: str


class JobConfiguration(Model, frozen=True):
    project: ProjectId
    pipeline: PipelineId
    job: JobId
    important: bool
    role: Literal["normal", "publish", "deploy"]
    environment: EnvironmentLabel | None
    stage_order: int | None
    depends_on: tuple[str, ...]
    dependency_evidence: Literal["operator_expectation"] = "operator_expectation"


class ItemView(Model, frozen=True):
    item: WorkItem
    pinned: bool
    hidden: bool
    selected: bool
    groups: tuple[str, ...]
    checklist: Checklist
    comparisons: tuple[EnvironmentComparison, ...]
    application_tests: tuple[ApplicationTestEvidence, ...] = ()
    job_configuration: tuple[JobConfiguration, ...] = ()


class EnvironmentColumn(Model, frozen=True):
    project: ProjectId
    name: EnvironmentLabel
    label: str
    column: Column

    @model_validator(mode="after")
    def coherent_column(self) -> Self:
        expected = self.name if self.name in ("dev", "preprod") else f"environment:{self.name}"
        if self.column != expected:
            raise ValueError("Environment column key differs from its environment name")
        return self


class Dashboard(Model, frozen=True):
    snapshot_source: Literal["fixture", "glab"]
    gitlab_version: str
    fetched_at: str
    cache_state: Literal["fresh", "cached", "fixture"]
    preference_revision: int
    total: int
    views: tuple[ItemView, ...]
    preferences: Preferences
    warnings: tuple[str, ...]
    host: str
    projects: tuple[ProjectConfig, ...]
    selected_project: ProjectId | None = None
    coverage: Literal["configured_projects"] = "configured_projects"
    orientation: Literal["rows", "columns"] = "rows"
    columns: tuple[Column, ...] = ("identity", "branch", "mr", "pipeline", "dev", "preprod")
    environment_columns: tuple[EnvironmentColumn, ...] = ()


class PreviewBase(Model, frozen=True):
    executed: Literal[False] = False
    remote_mutation_available: Literal[False] = False
    description: str
    blockers: tuple[str, ...]


class TagPreview(PreviewBase, frozen=True):
    action: Literal["tag"] = "tag"
    suggestion: str
    previous_tag: str


class ActionPreview(PreviewBase, frozen=True):
    action: Literal["deploy-dev", "deploy-preprod", "rebase", "retry", "ready", "merge"]


type Preview = Annotated[TagPreview | ActionPreview, Field(discriminator="action")]


class SnapshotCache(Model, frozen=True):
    configuration_fingerprint: str
    snapshot: Snapshot


class Change(Model, frozen=True):
    revision: int = Field(strict=True, ge=0)


class FlagChange(Change, frozen=True):
    operation: Literal["pin", "hide", "select"]
    key: WorkKey
    enabled: bool = Field(strict=True)


class GroupChange(Change, frozen=True):
    operation: Literal["group"] = "group"
    key: WorkKey
    enabled: bool = Field(strict=True)
    group: str = Field(min_length=1, max_length=80)


class ChecklistChange(Change, frozen=True):
    operation: Literal["checklist"] = "checklist"
    key: WorkKey
    enabled: bool = Field(strict=True)
    checklist_field: Literal["local_test", "dev_test", "preprod_test", "work_confirmed"]


class FilterChange(Change, frozen=True):
    operation: Literal["filters"] = "filters"
    filters: Filters


class OverrideChange(Change, frozen=True):
    operation: Literal["override"] = "override"
    key: WorkKey
    enabled: bool = Field(strict=True)
    override_kind: Literal["branch", "mr", "tag"]
    override_value: str = Field(min_length=1, max_length=200)
    reason: str = Field(min_length=1, max_length=500)


class SavedViewSet(Change, frozen=True):
    operation: Literal["saved_view_set"] = "saved_view_set"
    view: SavedView


class SavedViewDelete(Change, frozen=True):
    operation: Literal["saved_view_delete"] = "saved_view_delete"
    name: str = Field(min_length=1, max_length=500)


class BookmarkSet(Change, frozen=True):
    operation: Literal["bookmark_set"] = "bookmark_set"
    bookmark: Bookmark


class BookmarkDelete(Change, frozen=True):
    operation: Literal["bookmark_delete"] = "bookmark_delete"
    reference: ResourceReference


class NavigationDecorationSet(Change, frozen=True):
    operation: Literal["navigation_decoration_set"] = "navigation_decoration_set"
    decoration: NavigationDecoration


class NavigationDecorationDelete(Change, frozen=True):
    operation: Literal["navigation_decoration_delete"] = "navigation_decoration_delete"
    target: NavigationTarget


class ApplicationTestChange(Change, frozen=True):
    operation: Literal["application_test"] = "application_test"
    record: ApplicationTestRecord


type PreferenceChange = Annotated[
    FlagChange
    | GroupChange
    | ChecklistChange
    | FilterChange
    | OverrideChange
    | SavedViewSet
    | SavedViewDelete
    | BookmarkSet
    | BookmarkDelete
    | NavigationDecorationSet
    | NavigationDecorationDelete
    | ApplicationTestChange,
    Field(discriminator="operation"),
]


class Service:
    def __init__(
        self, config: AppConfig, adapter: GlabAdapter | None = None, config_path: Path | None = None
    ) -> None:
        self.config = config
        self.operator_store = OperatorStore(
            config_path or config.preferences_path.parent / "operator-settings.toml", config
        )
        if config_path is None and self.operator_store.path.exists():
            self.config = self.operator_store.read()
        config = self.config
        self.preferences = PreferenceStore(config.preferences_path, instance_origin=self.host)
        self._profile_transport: ProfileTransport | None = None
        self._effective_live = config.live
        if config.mode == "live" and config.active_profile is not None and config.live:
            profile = next(p for p in config.access_profiles if p.name == config.active_profile)
            self._profile_transport = ProfileTransport(profile)
            live_data = config.live.model_dump()
            live_data["projects"] = tuple(
                p for p in config.live.projects if p.id in profile.projects
            )
            self._effective_live = type(config.live).model_validate(live_data)
        self.adapter = adapter
        if self.adapter is None and self._profile_transport and self._effective_live:
            self.adapter = GlabAdapter(
                self._effective_live, self._profile_runner, self._profile_graph_runner
            )
        self._lock = threading.RLock()
        self._snapshot: Snapshot | None = None
        self._mr_catalog: MRCatalog | None = None
        self._cache_state: Literal["fresh", "cached", "fixture"] = "fixture"
        self._settings_refresh_required = False
        self._operator_revision: str | None = None
        self._operator_error: str | None = None
        self._avatars = ProjectAvatars(
            self.host,
            self.config.avatars,
            fixture=self.config.mode == "fixture",
            provider=self._avatar_metadata,
        )

    def _avatar_metadata(self, project: ProjectId) -> ProjectAvatarDTO:
        if project not in {p.id for p in self.projects()} or self._effective_live is None:
            raise ValueError("Project avatar exceeds configured scope")
        adapter = self.adapter or GlabAdapter(self._effective_live)
        return adapter.single(f"projects/{project.value}", ProjectAvatarDTO)

    def project_avatar(self, project: ProjectId) -> AvatarResource:
        configured = next((p for p in self.projects() if p.id == project), None)
        if configured is None:
            raise ValueError("Project avatar exceeds configured scope")
        return self._avatars.get(project, configured.path)

    def settings(self) -> SettingsResponse:
        with self._lock:
            self._synchronize_settings(strict=True)
            assert self._operator_revision is not None
            return SettingsResponse(
                revision=self._operator_revision,
                settings=OperatorSettings.from_config(self.config),
                effective=tuple(self.config.effective_pipeline(p.id) for p in self.projects()),
                refresh_required=self._settings_refresh_required,
            )

    def _validate_operator_config(self, candidate: AppConfig) -> None:
        public = set(OperatorSettings.model_fields)
        if candidate.model_dump(exclude=public) != self.config.model_dump(exclude=public):
            raise ValueError(
                "Connection, scope or paths changed in the operator file; restart GSpace "
                "explicitly to apply them. Last valid rules remain active."
            )
        snapshot = self._snapshot
        if snapshot is None and candidate.mode == "fixture":
            snapshot = synthetic_snapshot()
        if snapshot is not None:
            for item in snapshot.items:
                rules = candidate.effective_pipeline(item.identity.project).rules
                for pipeline in item.pipelines:
                    for job in pipeline.jobs:
                        rules.classify(job.name)

    def _synchronize_settings(self, *, strict: bool = False) -> None:
        """Adopt only validated public file edits; never reload connections or fetch remotely."""
        with self._lock:
            try:
                config, revision = self.operator_store.snapshot()
                if revision == self._operator_revision:
                    # Restoring the exact last-good file also clears a rejected-edit warning.
                    self._operator_error = None
                    return
                self._validate_operator_config(config)
            except (OSError, UnicodeError, tomllib.TOMLDecodeError) as error:
                self._operator_error = (
                    "Operator file could not be read or parsed; last valid rules remain active. "
                    "Correct the file and reload Settings."
                )
                if strict:
                    raise ValueError(self._operator_error) from error
                return
            except ValueError as error:
                # Do not echo validation inputs, URLs or arbitrary file contents.
                self._operator_error = (
                    str(error)
                    if str(error).startswith("Connection, scope or paths changed")
                    else "Operator rules are invalid or ambiguous; last valid rules remain "
                    "active. Correct the file and reload Settings."
                )
                if strict:
                    raise ValueError(self._operator_error) from error
                return
            changed = OperatorSettings.from_config(config) != OperatorSettings.from_config(
                self.config
            )
            self.config = config
            self._operator_revision = revision
            self._operator_error = None
            if changed and config.mode == "live":
                self._settings_refresh_required = True

    def update_settings(self, change: SettingsChange) -> SettingsResponse:
        with self._lock:
            config = self.operator_store.update(change, validate=self._validate_operator_config)
            # No automatic network calls; explicit refresh hydrates remote classification.
            self.config = config
            self._settings_refresh_required = config.mode == "live"
            return self.settings()

    @property
    def host(self) -> str:
        return (
            self.config.live.web_origin.rstrip("/")
            if self.config.mode == "live" and self.config.live
            else "fixture"
        )

    def _profile_runner(self, argv: list[str], _timeout: float) -> RunResult:
        if self._profile_transport is None:
            raise ValueError("Profile transport is unavailable")
        parsed = urlsplit(argv[-1])
        response = self._profile_transport.request(
            "GET", parsed.path, query=dict(parse_qsl(parsed.query))
        )
        import json

        return RunResult(code=0, stdout=json.dumps(response).encode())

    def _profile_graph_runner(
        self, project: ProjectConfig, key: PipelineKey, cursor: str | None
    ) -> bytes:
        if self._profile_transport is None:
            raise ValueError("Profile transport is unavailable")
        import json

        return json.dumps(self._profile_transport.pipeline_graphql(project, key, cursor)).encode()

    def projects(self) -> tuple[ProjectConfig, ...]:
        if self.config.mode == "live" and self._effective_live:
            return self._effective_live.projects
        return fixture_catalog().projects

    def navigation(self) -> NavigationCatalog:
        prefs = self.preferences.read()
        projects = tuple(project.id for project in self.projects())
        bookmarks = tuple(
            b
            for b in prefs.bookmarks
            if b.host == self.host and reference_project(b.reference) in projects
        )
        views = tuple(
            v
            for v in prefs.saved_views
            if v.host == self.host and all(p in projects for p in v.projects)
        )
        visible = {
            *(BookmarkTarget(host=b.host, reference=b.reference) for b in bookmarks),
            *(SavedViewTarget(host=v.host, name=v.name) for v in views),
        }
        decorations = tuple(
            sorted(
                (d for d in prefs.navigation_decorations if d.target in visible),
                key=lambda d: (not d.pinned, d.order, d.target.model_dump_json()),
            )
        )
        return NavigationCatalog(
            host=self.host,
            projects=projects,
            revision=prefs.revision,
            bookmarks=bookmarks,
            saved_views=views,
            decorations=decorations,
            icons=DECORATION_ICONS,
            colors=DECORATION_COLORS,
        )

    def resource_catalog(
        self,
        kind: Literal["branches", "pipelines"],
        project: ProjectId | None = None,
        search: str = "",
    ) -> BranchCatalog | PipelineCatalog:
        projects = self.projects()
        if project is not None:
            if project not in {p.id for p in projects}:
                raise KeyError("Project is not configured")
            projects = tuple(p for p in projects if p.id == project)
        adapter = None
        if self.config.mode == "live" and self._effective_live:
            adapter = self.adapter or GlabAdapter(self._effective_live)
        catalog = resources(kind, projects, adapter)
        if not search:
            return catalog
        needle = search.casefold()
        if isinstance(catalog, BranchCatalog):
            branches = tuple(
                r
                for r in catalog.rows
                if needle in (r.project_path + " " + r.branch.name).casefold()
            )
            return BranchCatalog.model_validate(
                {
                    **catalog.model_dump(),
                    "rows": branches,
                    "total": len(branches),
                    "display_filter": search,
                }
            )
        pipelines = tuple(
            r
            for r in catalog.rows
            if needle
            in (
                f"{r.project_path} {r.pipeline.id.value} {r.pipeline.ref} {r.pipeline.status}"
            ).casefold()
        )
        return PipelineCatalog.model_validate(
            {
                **catalog.model_dump(),
                "rows": pipelines,
                "total": len(pipelines),
                "display_filter": search,
            }
        )

    def application_test_history(
        self, key: WorkKey, environment: EnvironmentLabel | None = None
    ) -> ApplicationTestHistory:
        view = self.view(self.item(key), self.preferences.read())
        if environment is not None and environment not in {e.name for e in view.item.environments}:
            raise ValueError("Environment is not configured for this work item")
        entries: list[TestHistoryEntry] = []
        for evidence in view.application_tests:
            if environment is not None and evidence.environment != environment:
                continue
            for record in evidence.history:
                target = evidence.target
                state: Literal["current", "superseded", "stale", "unknown"] = "unknown"
                if target is not None and (target.sha is not None or target.version is not None):
                    state = (
                        ("current" if evidence.current == record else "superseded")
                        if matches_version(record, target)
                        else "stale"
                    )
                entries.append(TestHistoryEntry(record=record, target=target, state=state))
        return ApplicationTestHistory(
            key=key,
            environment=environment,
            timezone=self.config.timezone,
            checked_at=datetime.now(UTC),
            entries=tuple(sorted(entries, key=lambda e: e.record.checked_at, reverse=True)),
        )

    def mr_catalog(self, refresh: bool = False, project: ProjectId | None = None) -> MRCatalog:
        with self._lock:
            if project is not None and project not in {p.id for p in self.projects()}:
                raise KeyError("Project is not configured")
            path = self.config.cache_path.with_name(self.config.cache_path.stem + "-mrs.json")
            if (
                self._mr_catalog is None
                and not refresh
                and self.config.mode == "live"
                and path.exists()
            ):
                cached = MRCatalogCache.model_validate_json(path.read_bytes())
                if cached.configuration_fingerprint != self._fingerprint():
                    raise ValueError("MR cache configuration differs; refresh explicitly")
                if cached.catalog.host != self.host or cached.catalog.source != "glab":
                    raise ValueError("MR cache belongs to another instance")
                self._mr_catalog = cached.catalog
            if self._mr_catalog is None or refresh:
                if self.config.mode == "live" and self.config.live:
                    catalog = fetch_catalog(self.adapter or GlabAdapter(self.config.live))
                    self._write_json(
                        path,
                        MRCatalogCache(
                            configuration_fingerprint=self._fingerprint(), catalog=catalog
                        ).model_dump_json(indent=2),
                    )
                else:
                    catalog = fixture_catalog()
                self._mr_catalog = catalog
            catalog = self._mr_catalog
            if project is None:
                return catalog
            data = catalog.model_dump()
            data["projects"] = tuple(p for p in catalog.projects if p.id == project)
            data["rows"] = tuple(row for row in catalog.rows if row.mr.project == project)
            return MRCatalog.model_validate(data)

    def snapshot(self) -> Snapshot:
        with self._lock:
            self._synchronize_settings()
            if self._snapshot is not None:
                return self._snapshot
            if self.config.mode == "fixture":
                self._snapshot = synthetic_snapshot()
                self._cache_state = "fixture"
            elif self.config.cache_path.exists():
                cached = SnapshotCache.model_validate_json(self.config.cache_path.read_bytes())
                if cached.configuration_fingerprint != self._fingerprint():
                    raise ValueError("Cache configuration differs; run an explicit refresh")
                if cached.snapshot.source != "glab":
                    raise ValueError("Live cache must come from glab")
                self._snapshot = cached.snapshot
                self._cache_state = "cached"
            else:
                return self.refresh()
            return self._snapshot

    def refresh(self) -> Snapshot:
        with self._lock:
            self._synchronize_settings()
            if self.config.mode == "fixture":
                snapshot = synthetic_snapshot()
                self._cache_state = "fixture"
            else:
                live = self.config.live
                if live is None:
                    raise ValueError("Missing live configuration")
                adapter = self.adapter or GlabAdapter(live)
                snapshot = adapter.snapshot(self.config, self.preferences.read())
                self._write_cache(snapshot)
                self._cache_state = "fresh"
            self._snapshot = snapshot
            self._settings_refresh_required = False
            return snapshot

    def _write_cache(self, snapshot: Snapshot) -> None:
        path = self.config.cache_path
        self._write_json(
            path,
            SnapshotCache(
                configuration_fingerprint=self._fingerprint(), snapshot=snapshot
            ).model_dump_json(indent=2),
        )

    def _write_json(self, path: os.PathLike[str], payload: str) -> None:
        from pathlib import Path

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(dir=path.parent, prefix=".snapshot-")
        try:
            with os.fdopen(descriptor, "w") as file:
                file.write(payload)
                file.flush()
                os.fsync(file.fileno())
            os.replace(temporary, path)
            directory = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def _fingerprint(self) -> str:
        profile_scope = ""
        if self._profile_transport:
            identity = self._profile_transport.get("user", UserDTO).id
            profile_scope = self._profile_transport.profile.model_dump_json() + str(identity)
        live = self.config.live.model_dump_json() if self.config.live else "fixture"
        endpoints = "".join(endpoint.model_dump_json() for endpoint in self.config.endpoints)
        pipeline = self.config.pipeline.model_dump_json() + "".join(
            o.model_dump_json() for o in self.config.project_pipeline_overrides
        )
        return sha256(
            (live + endpoints + self.config.branch_template + pipeline + profile_scope).encode()
        ).hexdigest()

    def item(self, key: WorkKey) -> WorkItem:
        found = next((i for i in self.snapshot().items if i.identity == key), None)
        if found is None:
            raise KeyError("Work item not found in this snapshot")
        return found

    def pipeline_graph(self, key: WorkKey) -> PipelineGraph:
        from gspace.pipeline_graph import read_pipeline_graph, synthetic_pipeline_graph

        item = self.item(key)
        if self.config.mode == "fixture":
            return synthetic_pipeline_graph(item)
        if self._effective_live is None:
            raise ValueError("Missing live configuration")
        adapter = self.adapter or GlabAdapter(self._effective_live)
        return read_pipeline_graph(adapter, item)

    def view(self, item: WorkItem, prefs: Preferences) -> ItemView:
        key = item.identity
        rules = self.config.effective_pipeline(key.project).rules
        definitions = rules.environments
        configured_jobs: list[JobConfiguration] = []
        for pipeline in item.pipelines:
            for job in pipeline.jobs:
                rule = rules.classify(job.name)
                stage = next((s for s in rules.stages if s.name == job.stage), None)
                configured_jobs.append(
                    JobConfiguration(
                        project=key.project,
                        pipeline=pipeline.id,
                        job=job.id,
                        important=rules.important(job.name),
                        role=rule.role if rule else "normal",
                        environment=rule.environment if rule else None,
                        stage_order=rules.stages.index(stage) if stage else None,
                        depends_on=stage.depends_on if stage else (),
                    )
                )
        envs: list[Environment] = []
        tests: list[ApplicationTestEvidence] = []
        for definition in definitions:
            environment = next((e for e in item.environments if e.name == definition.name), None)
            endpoint = next(
                (e for e in self.config.endpoints if e.key == key and e.name == definition.name),
                None,
            )
            configured_expected = endpoint.expected if endpoint else None
            if environment is None:
                expected = (
                    configured_expected
                    if configured_expected is not None
                    else Version(branch=item.branches[0].name, sha=item.branches[0].sha)
                    if definition.ref_source == "branch" and len(item.branches) == 1
                    else Version(tag=item.tags[0].name, sha=item.tags[0].sha)
                    if definition.ref_source == "tag" and len(item.tags) == 1
                    else None
                )
                environment = Environment(
                    name=definition.name,
                    expected=expected,
                    observation=Unknown(reason="No evidence for this configured environment"),
                )
            elif configured_expected is not None:
                configured = environment.model_dump()
                configured["expected"] = configured_expected.model_dump()
                environment = Environment.model_validate(configured)
            target = environment.expected
            if target is None and isinstance(environment.observation, Observed):
                target = environment.observation.value
            history = tuple(
                sorted(
                    (
                        r
                        for r in (*self.snapshot().application_tests, *prefs.application_tests)
                        if r.key == key and r.environment == definition.name
                    ),
                    key=lambda r: r.checked_at,
                    reverse=True,
                )
            )

            current = next((r for r in history if matches_version(r, target)), None)
            outcome = current.outcome if current else "not_tested"
            tests.append(
                ApplicationTestEvidence(
                    environment=definition.name,
                    outcome=outcome,
                    target=target,
                    current=current,
                    history=history,
                    reason="Manual result for this exact version"
                    if current
                    else "No manual result for this exact SHA/version; "
                    "branch or tag alone is insufficient",
                )
            )
            data = environment.model_dump()
            data["application_test"] = outcome if outcome != "not_tested" else "unconfirmed"
            envs.append(Environment.model_validate(data))
        item_data = item.model_dump()
        item_data["environments"] = envs
        item = WorkItem.model_validate(item_data)
        checklist = next((c for c in prefs.checklists if c.key == key), Checklist(key=key))
        return ItemView(
            item=item,
            pinned=key in prefs.pinned,
            hidden=key in prefs.hidden,
            selected=key in prefs.selected,
            groups=tuple(g.name for g in prefs.groups if key in g.members),
            checklist=checklist,
            application_tests=tuple(tests),
            job_configuration=tuple(configured_jobs),
            comparisons=tuple(
                EnvironmentComparison(name=e.name, result=result, reason=reason)
                for e in item.environments
                for result, reason in [compare_version(e.expected, e.observation)]
            ),
        )

    def milestones(self, project: ProjectId | None = None) -> MilestoneCatalog:
        dashboard = self.dashboard(project=project)
        return catalog(
            self.snapshot(),
            self.host,
            tuple(p.id for p in self.projects() if project is None or p.id == project),
            dashboard.preferences.filters.milestone,
            tuple(v.item for v in dashboard.views),
            self.config.timezone,
        )

    def dashboard(
        self,
        filters: Filters | None = None,
        selected_only: bool = False,
        project: ProjectId | None = None,
        saved_view: str | None = None,
        orientation: Literal["rows", "columns"] | None = None,
    ) -> Dashboard:
        snapshot = self.snapshot()
        prefs = self.preferences.read()
        if project is not None and project not in {p.id for p in self.projects()}:
            raise KeyError("Project is not configured")
        navigation = None
        if saved_view is not None:
            navigation = next(
                (v for v in prefs.saved_views if v.host == self.host and v.name == saved_view), None
            )
            if navigation is None:
                raise KeyError("Saved view not found in this instance")
            if navigation.scope != "work_items":
                raise ValueError("This command requires a work-item saved view")
            saved_filters = navigation.filters.model_dump(exclude={"authored"})
            applied = filters or Filters.model_validate(saved_filters)
        else:
            applied = filters or prefs.filters
        members = next((g.members for g in prefs.groups if g.name == applied.group), ())
        views: list[ItemView] = []
        for item in snapshot.items:
            key = item.identity
            if project is not None and key.project != project:
                continue
            if navigation and navigation.projects and key.project not in navigation.projects:
                continue
            if applied.state != "all" and item.state != applied.state:
                continue
            if not matches(
                item,
                applied.milestone,
                snapshot,
                datetime.now(UTC).astimezone(ZoneInfo(self.config.timezone)).date(),
            ):
                continue
            if applied.assigned and not item.assigned_to_me:
                continue
            if not applied.show_hidden and key in prefs.hidden:
                continue
            if applied.group and key not in members:
                continue
            if selected_only and key not in prefs.selected:
                continue
            haystack = " ".join(
                (
                    f"#{key.issue.value} {key.key}",
                    item.title,
                    item.project_path,
                    *item.labels,
                    *(b.name for b in item.branches),
                    *(f"!{m.iid.value} {m.title}" for m in item.merge_requests),
                    *(t.name for t in item.tags),
                    *(g.name for g in prefs.groups if key in g.members),
                )
            ).casefold()
            if not all(token in haystack for token in applied.search.casefold().split()):
                continue
            views.append(self.view(item, prefs))
        views.sort(
            key=lambda view: (
                not view.pinned,
                view.item.identity.project.value,
                view.item.identity.issue.value,
            )
        )
        if navigation:

            def sort_key(view: ItemView) -> str:
                match navigation.sort:
                    case "title":
                        return view.item.title.casefold()
                    case "state":
                        return str(view.item.state)
                    case "project":
                        return view.item.project_path.casefold()
                    case "updated_at":
                        raise ValueError("Work items do not provide updated-at evidence")
                    case "identity":
                        return (
                            f"{view.item.identity.project.value:012}:"
                            f"{view.item.identity.issue.value:012}"
                        )

            views.sort(key=sort_key, reverse=navigation.descending)
            views.sort(key=lambda view: not view.pinned)
        environment_columns = tuple(
            EnvironmentColumn(
                project=p.id,
                name=e.name,
                label=e.label,
                column=e.name if e.name in ("dev", "preprod") else f"environment:{e.name}",
            )
            for p in self.projects()
            if project is None or p.id == project
            for e in self.config.effective_pipeline(p.id).rules.environments
        )
        custom_columns = tuple(
            dict.fromkeys(e.column for e in environment_columns if e.name not in ("dev", "preprod"))
        )
        return Dashboard(
            environment_columns=environment_columns,
            orientation=orientation or (navigation.orientation if navigation else "rows"),
            columns=navigation.columns
            if navigation
            else ("identity", "branch", "mr", "pipeline", "dev", "preprod", *custom_columns),
            snapshot_source=snapshot.source,
            gitlab_version=snapshot.gitlab_version,
            fetched_at=snapshot.fetched_at.isoformat(),
            cache_state=self._cache_state,
            preference_revision=prefs.revision,
            total=len(snapshot.items),
            views=tuple(views),
            preferences=prefs,
            warnings=snapshot.warnings
            + ((self._operator_error,) if self._operator_error else ())
            + (
                (
                    "Pipeline settings changed; explicit refresh is required "
                    "for remote classifications",
                )
                if self._settings_refresh_required
                else ()
            ),
            host=self.host,
            projects=self.projects(),
            selected_project=project,
        )

    def change(self, change: PreferenceChange) -> Preferences:
        if isinstance(change, ApplicationTestChange):
            item = self.item(change.record.key)
            if change.record.source != "operator":
                raise ValueError("Only operator records may be submitted")
            if change.record.environment not in {
                e.name
                for e in self.config.effective_pipeline(item.identity.project).rules.environments
            }:
                raise ValueError("Application test environment is not configured")
        if isinstance(change, (FlagChange, GroupChange, ChecklistChange, OverrideChange)):
            self.item(change.key)
        if (
            isinstance(change, FilterChange)
            and change.filters.milestone.mode == "selected"
            and change.filters.milestone.selected not in {m.key for m in self.snapshot().milestones}
        ):
            raise ValueError("Selected milestone is not in this configured snapshot")
        if isinstance(change, SavedViewSet):
            if change.view.host != self.host:
                raise ValueError("Saved view belongs to another instance")
            if any(
                p not in {project.id for project in self.projects()} for p in change.view.projects
            ):
                raise ValueError("Saved view exceeds configured project scope")
            configured_environments = {
                e.name
                for p in self.projects()
                if not change.view.projects or p.id in change.view.projects
                for e in self.config.effective_pipeline(p.id).rules.environments
            }
            if any(
                c.startswith("environment:")
                and c.removeprefix("environment:") not in configured_environments
                for c in change.view.columns
            ):
                raise ValueError("Saved view environment column is not configured in its scope")
        if isinstance(change, (BookmarkSet, BookmarkDelete)):
            reference = (
                change.bookmark.reference if isinstance(change, BookmarkSet) else change.reference
            )
            if reference_project(reference) not in {project.id for project in self.projects()}:
                raise ValueError("Bookmark exceeds configured project scope")
            if isinstance(change, BookmarkSet) and change.bookmark.host != self.host:
                raise ValueError("Bookmark belongs to another instance")

        if isinstance(change, (NavigationDecorationSet, NavigationDecorationDelete)):
            target = (
                change.decoration.target
                if isinstance(change, NavigationDecorationSet)
                else change.target
            )
            if target.host != self.host:
                raise ValueError("Navigation target belongs to another instance")
            if isinstance(target, BookmarkTarget) and reference_project(target.reference) not in {
                p.id for p in self.projects()
            }:
                raise ValueError("Navigation target exceeds configured project scope")

        def transform(old: StoredPreferences) -> Preferences:
            data = old.model_dump(mode="json")
            match change:
                case ApplicationTestChange(record=record):
                    data["application_tests"] = [
                        r.model_dump(mode="json") for r in old.application_tests
                    ] + [record.model_dump(mode="json")]
                case FilterChange(filters=filters):
                    data["filters"] = filters.model_dump(mode="json")
                case FlagChange(key=key, operation=operation, enabled=enabled):
                    field = {"pin": "pinned", "hide": "hidden", "select": "selected"}[operation]
                    values: list[WorkKey] = [v for v in getattr(old, field) if v != key]
                    if enabled:
                        values.append(key)
                    data[field] = [v.model_dump(mode="json") for v in values]
                case GroupChange(key=key, group=name, enabled=enabled):
                    group = next((g for g in old.groups if g.name == name), Group(name=name))
                    members = tuple(k for k in group.members if k != key)
                    if enabled:
                        members += (key,)
                    replacement = Group(name=group.name, members=members)
                    data["groups"] = [
                        g.model_dump(mode="json") for g in old.groups if g.name != name
                    ] + [replacement.model_dump(mode="json")]
                case ChecklistChange(key=key, checklist_field=field, enabled=enabled):
                    checklist = next(
                        (c for c in old.checklists if c.key == key), Checklist(key=key)
                    )
                    row = checklist.model_dump(mode="json")
                    row[field] = enabled
                    replacement_checklist = Checklist.model_validate(row)
                    data["checklists"] = [
                        c.model_dump(mode="json") for c in old.checklists if c.key != key
                    ] + [replacement_checklist.model_dump(mode="json")]
                case OverrideChange(
                    key=key,
                    override_kind=kind,
                    override_value=value,
                    reason=reason,
                    enabled=enabled,
                ):
                    replacement_override = Override(key=key, kind=kind, value=value, reason=reason)
                    overrides = [
                        o
                        for o in old.overrides
                        if not (o.key == key and o.kind == kind and o.value == value)
                    ]
                    if enabled:
                        overrides.append(replacement_override)
                    data["overrides"] = [o.model_dump(mode="json") for o in overrides]
                case SavedViewSet(view=view):
                    data["saved_views"] = [
                        v.model_dump(mode="json")
                        for v in old.saved_views
                        if (v.host, v.name) != (view.host, view.name)
                    ] + [view.model_dump(mode="json")]
                case SavedViewDelete(name=name):
                    data["saved_views"] = [
                        v.model_dump(mode="json")
                        for v in old.saved_views
                        if not (v.host == self.host and v.name == name)
                    ]
                    data["navigation_decorations"] = [
                        d.model_dump(mode="json")
                        for d in old.navigation_decorations
                        if d.target != SavedViewTarget(host=self.host, name=name)
                    ]
                case BookmarkSet(bookmark=bookmark):
                    data["bookmarks"] = [
                        b.model_dump(mode="json")
                        for b in old.bookmarks
                        if (b.host, b.reference) != (bookmark.host, bookmark.reference)
                    ] + [bookmark.model_dump(mode="json")]
                case BookmarkDelete(reference=reference):
                    data["bookmarks"] = [
                        b.model_dump(mode="json")
                        for b in old.bookmarks
                        if not (b.host == self.host and b.reference == reference)
                    ]
                    data["navigation_decorations"] = [
                        d.model_dump(mode="json")
                        for d in old.navigation_decorations
                        if d.target != BookmarkTarget(host=self.host, reference=reference)
                    ]
                case NavigationDecorationSet(decoration=decoration):
                    if isinstance(decoration.target, SavedViewTarget):
                        view = next(
                            (
                                v
                                for v in old.saved_views
                                if (v.host, v.name)
                                == (decoration.target.host, decoration.target.name)
                            ),
                            None,
                        )
                        if view is None or any(
                            p not in {project.id for project in self.projects()}
                            for p in view.projects
                        ):
                            raise ValueError(
                                "Navigation view is absent or outside configured project scope"
                            )
                    data["navigation_decorations"] = [
                        d.model_dump(mode="json")
                        for d in old.navigation_decorations
                        if d.target != decoration.target
                    ] + [decoration.model_dump(mode="json")]
                case NavigationDecorationDelete(target=target):
                    if isinstance(target, SavedViewTarget):
                        view = next(
                            (
                                v
                                for v in old.saved_views
                                if (v.host, v.name) == (target.host, target.name)
                            ),
                            None,
                        )
                        if view is not None and any(
                            p not in {project.id for project in self.projects()}
                            for p in view.projects
                        ):
                            raise ValueError("Navigation view is outside configured project scope")
                    data["navigation_decorations"] = [
                        d.model_dump(mode="json")
                        for d in old.navigation_decorations
                        if d.target != target
                    ]
                case _ as unreachable:  # pyright: ignore[reportUnnecessaryComparison]
                    assert_never(unreachable)
            return StoredPreferences.model_validate(data)

        return self.preferences.update(transform, change.revision)

    def preview(self, key: WorkKey, action: str, previous_tag: str | None = None) -> Preview:
        item = self.item(key)
        checklist = self.view(item, self.preferences.read()).checklist
        descriptions = {
            "tag": "Create a tag from a confirmed branch SHA, then run its "
            "tag pipeline for preprod.",
            "deploy-dev": "Run the manual dev deployment after the branch/MR "
            "pipeline Nexus publish.",
            "deploy-preprod": "Run the manual preprod deployment from a confirmed tag pipeline.",
            "rebase": "Rebase the chosen source branch after independently "
            "verifying its target ancestry.",
            "retry": "Investigate the failed job and choose a retry manually; "
            "cause is not assumed.",
            "ready": "An operator may remove draft after all tests and work have been confirmed.",
            "merge": "Review approvals, tests and observed runtime versions before a manual merge.",
        }
        if action not in descriptions:
            raise ValueError("Unsupported preview action")
        if action == "tag":
            previous = previous_tag or (item.tags[0].name if item.tags else None)
            if previous is None:
                raise ValueError("Provide a previous tag for the suggestion")
            suggestion = self.config.tag_convention.suggest(previous)
            return TagPreview(
                description=descriptions[action],
                suggestion=suggestion,
                previous_tag=previous,
                blockers=("Remote mutations are unavailable in this version",),
            )
        blockers = ["Remote mutations are unavailable in this version"]
        if action in ("ready", "merge") and not checklist.complete:
            blockers.append("Manual local/dev/preprod tests and work confirmation are incomplete")
        return ActionPreview.model_validate(
            {"action": action, "description": descriptions[action], "blockers": tuple(blockers)}
        )

    def observe_environment(
        self,
        key: WorkKey,
        name: EnvironmentLabel,
        observer: Callable[[Endpoint], Observation] = observe,
    ) -> WorkItem:
        endpoint = next((e for e in self.config.endpoints if e.key == key and e.name == name), None)
        if endpoint is None:
            raise ValueError("No endpoint configured for this work item and environment")
        with self._lock:
            item = self.item(key)
            observation = observer(endpoint)
            data = item.model_dump(mode="json")
            envs: list[dict[str, object]] = []
            for env in item.environments:
                row = env.model_dump(mode="json")
                if env.name == name:
                    row["observation"] = observation.model_dump(mode="json")
                envs.append(row)
            if not any(env.name == name for env in item.environments):
                # A newly configured environment may exist only in the derived
                # view until its first observation. Persist that observation,
                # without copying manual test outcomes into remote evidence.
                configured = next(
                    env
                    for env in self.view(item, self.preferences.read()).item.environments
                    if env.name == name
                )
                envs.append(
                    Environment(
                        name=name, expected=configured.expected, observation=observation
                    ).model_dump(mode="json")
                )
            data["environments"] = envs
            changed = WorkItem.model_validate(data)
            snap = self.snapshot().model_dump(mode="json")
            snap["items"] = [
                changed.model_dump(mode="json") if i.identity == key else i.model_dump(mode="json")
                for i in self.snapshot().items
            ]
            snapshot = Snapshot.model_validate(snap)
            if self.config.mode == "live":
                self._write_cache(snapshot)
            self._snapshot = snapshot
            return changed
