# GSpace

Python 3.12 only. Use Pydantic v2, BasedPyright strict and Ruff. Do not execute upstream GitLab scripts. Never read authentication files or contact corporate services in development. Default and ordinary live operations are remote read-only. Finite writes are disabled by default and restricted to the explicitly approved synthetic loopback lab; ready/merge/rebase writes remain deferred. Preserve `.repos/gitlabhq` at v18.11.12.

## Current iteration

`.workmemory/05-application-recovery` is the current active iteration after the 9October user-approved whole-application audit recovery; `04-requirements-parity` is the previous implementation stream; 02 delivered ba7ee8c. `01-real-gitlab-lab` has started the exact CE server and passed credential-free actual health/browser checks; authenticated seed/runner/scenarios await approved manual bootstrap. `00-readonly-cockpit` is complete. Read global PLAN/DECISIONS, then relevant iteration REQUIREMENTS, PLAN, TASKS, IMPLEMENTATION and DECISIONS before substantial work. Update task/block status and evidence at checkpoints. All iterations: `00-readonly-cockpit`, `01-real-gitlab-lab`, `02-claude-web-redesign`, `03-access-and-write-2.0`, `04-requirements-parity`. The access/action backend has synthetic verification; real tests and Claude UI integration remain blocked independently. Templates: `.workmemory/example`.

The user approved the isolated synthetic GitLab lab bootstrap credentials, short-lived non-admin PAT, locked runner and local scenario mutations. The lab driver and finite ActionService may perform explicitly authorized isolated lab actions only; GSpace corporate capabilities remain remote read-only. The dedicated CE server has started; no authenticated seed/runner/scenarios or application effects have run. Never extend lab approval to corporate hosts, global glab configuration, privileged execution or disk cleanup. Recheck actual resource guards before heavy starts.

Claude CLI is the sole frontend writer in `frontend-new`; root owns backend/Docker/tests and integration. Read the reference UI only as authorized, never its sessions/logs/auth or other data. Preserve original UI snapshots outside the clean frontend context. Do not use bypass permissions or attach unrelated Claude sessions.

The user explicitly authorized Codex to implement CLI presentation without Claude at14:37UTC on2026-10-06, superseding prior Claude-only CLI ownership. Codex owns CLI presentation and verification; Claude remains sole web frontend writer and paused until16:10UTC. Never launch Claude for the CLI or create concurrent renderer writers. Preserve NO_COLOR/non-TTY/JSON/stderr semantics; inspect actual renders. `scripts/cli_checkpoint.py` preserves finite local CLI source snapshots before/after edits.

At18:18UTC on2026-10-06 the user explicitly authorized Codex to finish the remaining finite TypeScript/Biome/build/runtime integration fixes while preserving Claude's design. This supersedes sole-Claude ownership for that bounded correction pass, including mechanical formatting. No broad redesign or blanket suppressions. Claude has actually exited on quota and must not be retried before22:30UTC6October(00:30Zurich7October). Preserve00c55a8 and the original1TS/28Biome diagnostic reports. In-progress EE/native graph work is checkpointed independently; do not expose a half-complete graph contract while preparing the current UI preview.

## Canonical workmemory file roles

Keep every file in its canonical role and declare its document purpose. Do not change these roles unless the user changes them explicitly.

- REQUIREMENTS.md: granular requirements, rationale, provenance and verification; no plans or tasks.
- Iteration PLAN.md: strategy, sequencing, assumptions and constraints linked to requirements; no detailed tasks or historical decisions.
- Global PLAN.md: cross-iteration streams, priorities, dependencies and summary status.
- TASKS.md: actionable granular tasks with graph fields and verifiable exit criteria.
- IMPLEMENTATION.md: executable checkpoint blocks derived solely from source tasks.
- Iteration DECISIONS.md: explicit decisions, status and impact; no open questions.
- Global DECISIONS.md: accepted decisions useful across iterations, selectively promoted with canonical references.

## Workmemory gate

Use global `workmemory-diagnose` >=0.20.0. Check version/help first. Before and after substantial workmemory edits and completion run `workmemory-diagnose analyze-project . --text --graph --all-iterations`. No substitute checker.

## Documentation index

- `docs/architecture/`: domain model, source compatibility, HTTP safety and renderer separation.
- `docs/verification/`: actual check outcomes and browser captures.
- `docs/runbook.md`: local demo, operator configuration, recovery and limitations.
- `docs/integration/`: exact official lab images, resource/credential gates, scenarios and execution limits.
- `frontend-new/API.md`: minimal clean functional contract for the independent frontend implementation.

## Scripts index

- `scripts/frontend_checkpoint.py`: fixed local-only frontend Git snapshots; no remotes/global configuration/hooks. Claude may use only this finite wrapper when explicitly permitted.
- `scripts/export_openapi.py`: deterministic fixture-only schema export and drift check.
- `scripts/frontend_review.py`: read-only new-asset browser/contract and repeated-refresh reproduction.
- `scripts/render_brand.py`: inert proposed SVG verification and local browser renders.
- `scripts/browser_check.py`: local-only browser acceptance and responsive screenshots.
- `scripts/package_check.py`: offline noneditable wheel installation and CLI/web launch from an unrelated working directory; excludes upstream clone content.
- `scripts/lab_loopback.py`: fixed localhost-only TCP relay into the exact owned internal lab; no auth-file reads or payload logs.
- `scripts/lab_readonly_check.py`: actual credential-free package version, health, isolation and login browser evidence; no CI/effect claims.
- `scripts/gitlab_lab.py`: approval-gated real local GitLab preflight, seed, runner, exercise, verification and recoverable stop.

## Repositories index

- `.repos/gitlabhq`: pinned GitLab 18.11.12 reference for GET API compatibility; see `docs/architecture/gitlab-compatibility.md`. Use targeted `rg` searches. Never re-clone or change ref.

- `.repos/glab`: official CLI source at 80d3449c6bf1915a32cd8c029117e51c2e3dc9ee, analyzed for API GET transport and pagination; see GitLab compatibility documentation.

## Recovery iteration — 9October2026

Read `.workmemory/05-application-recovery` canonical files and docs/verification/application-requirements-audit-20261009.md. The user approved reliable running Settings, discoverable Settings and manual exact-version test/history from Visual, web profile comparison and whole-application contextual hierarchy. One exact Claude Opus5.5/high or xhigh frontend writer must first produce the cross-page hierarchy; Codex owns backend/config/tests and finite integration. No concurrent frontend edits, new live credentials or remote writes. Preserve original operator files and accepted5549698 assets; use isolated synthetic mutations and actual both-theme/mobile/repeated/interrupted journeys before preview replacement. This approval does not close independent live/lab/network/license gates.
