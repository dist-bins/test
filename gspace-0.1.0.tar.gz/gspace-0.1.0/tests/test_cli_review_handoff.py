import hashlib
import json
import sys
from datetime import UTC, datetime

import pytest

from scripts import claude_corrective, cli_checkpoint


class BeforeReset(datetime):
    @classmethod
    def now(cls, tz=None):
        return datetime(2026, 10, 6, 15, 59, tzinfo=UTC)


class AfterReset(datetime):
    @classmethod
    def now(cls, tz=None):
        return datetime(2026, 10, 6, 16, 11, tzinfo=UTC)


class BeforeVisualReviewReset(datetime):
    @classmethod
    def now(cls, tz=None):
        return datetime(2026, 10, 7, 3, 29, tzinfo=UTC)


class AfterVisualReviewReset(datetime):
    @classmethod
    def now(cls, tz=None):
        return datetime(2026, 10, 7, 3, 31, tzinfo=UTC)


@pytest.mark.parametrize("clock", [BeforeReset, AfterReset])
def test_cli_writer_scope_is_withdrawn_without_launch_or_status_write(tmp_path, monkeypatch, clock):
    monkeypatch.setattr(claude_corrective, "datetime", clock)
    monkeypatch.setattr(claude_corrective, "OUTPUT", tmp_path / "not-created")
    monkeypatch.setattr(sys, "argv", ["controller", "--typescript", "--cli-review"])
    monkeypatch.setattr(
        claude_corrective.subprocess, "Popen", lambda *a, **kw: pytest.fail("withdrawn CLI launch")
    )
    with pytest.raises(ValueError, match="Codex owns CLI"):
        claude_corrective.main()
    assert not (tmp_path / "not-created").exists()


def test_web_controller_excludes_cli_writes_without_launch(tmp_path, monkeypatch):
    monkeypatch.setattr(claude_corrective, "datetime", AfterVisualReviewReset)
    monkeypatch.setattr(claude_corrective, "OUTPUT", tmp_path / "status")
    monkeypatch.setattr(claude_corrective, "PREFIX", tmp_path / "status/test")
    monkeypatch.setattr(sys, "argv", ["controller", "--typescript"])
    calls = []

    class BoundaryStop(Exception):
        pass

    def stop(argv, **kwargs):
        calls.append(argv)
        raise BoundaryStop

    monkeypatch.setattr(claude_corrective.subprocess, "Popen", stop)
    with pytest.raises(BoundaryStop):
        claude_corrective.main()
    argv = calls[0]
    assert argv[argv.index("--model") + 1] == "claude-opus-5-5"
    assert argv[argv.index("--effort") + 1] == "high"
    permissions = json.loads(argv[argv.index("--settings") + 1])["permissions"]
    source = claude_corrective.ROOT / "src/gspace"
    for name in ("cli.py", "cli_render.py", "cli_models.py"):
        assert f"Edit({source / name})" in permissions["deny"]
        assert f"Write({source / name})" in permissions["deny"]
        assert f"Edit({source / name})" not in permissions["allow"]
    assert "--dangerously-skip-permissions" not in argv
    assert not list((tmp_path / "status").glob("*.status.json"))


@pytest.mark.parametrize("options", [[], ["--typescript"], ["--visual-overview-review"]])
def test_current_visual_quota_blocks_all_launches_and_status_writes(tmp_path, monkeypatch, options):
    monkeypatch.setattr(claude_corrective, "datetime", BeforeVisualReviewReset)
    monkeypatch.setattr(claude_corrective, "OUTPUT", tmp_path / "not-created")
    monkeypatch.setattr(sys, "argv", ["controller", *options])
    monkeypatch.setattr(
        claude_corrective.subprocess, "Popen", lambda *a, **kw: pytest.fail("early quota retry")
    )
    with pytest.raises(ValueError, match="observed task-owned quota reset"):
        claude_corrective.main()
    assert not (tmp_path / "not-created").exists()


def test_cli_snapshot_copies_only_finite_source_and_does_not_change_original(tmp_path, monkeypatch):
    source = tmp_path / "src/gspace"
    source.mkdir(parents=True)
    original = b'# Synthetic source, never executed\nprint("literal")\n'
    (source / "cli.py").write_bytes(original)
    (source / "models.py").write_text("unrelated backend must not be copied")
    monkeypatch.setattr(cli_checkpoint, "ROOT", tmp_path)
    monkeypatch.setattr(cli_checkpoint, "SOURCE", source)
    snapshot = tmp_path / ".state/cli-source-checkpoints"
    monkeypatch.setattr(cli_checkpoint, "SNAPSHOT", snapshot)
    monkeypatch.setattr(sys, "argv", ["checkpoint", "--message", "Synthetic finite scope test"])
    assert cli_checkpoint.main() == 0
    assert (source / "cli.py").read_bytes() == original
    assert (snapshot / "cli.py").read_bytes() == original
    assert not (snapshot / "models.py").exists()
    manifest = json.loads((snapshot / "source-manifest.json").read_text())
    assert manifest["sha256"] == {"cli.py": hashlib.sha256(original).hexdigest()}
    head = cli_checkpoint.git("rev-parse", "HEAD")
    assert cli_checkpoint.main() == 0
    assert cli_checkpoint.git("rev-parse", "HEAD") == head


def test_cli_snapshot_rejects_symlink_without_reading_target(tmp_path, monkeypatch):
    source = tmp_path / "src/gspace"
    source.mkdir(parents=True)
    (source / "cli.py").symlink_to(tmp_path / "unread-private-file")
    monkeypatch.setattr(cli_checkpoint, "ROOT", tmp_path)
    monkeypatch.setattr(cli_checkpoint, "SOURCE", source)
    monkeypatch.setattr(cli_checkpoint, "SNAPSHOT", tmp_path / ".state/cli-source-checkpoints")
    monkeypatch.setattr(sys, "argv", ["checkpoint", "--message", "Reject synthetic symlink"])
    with pytest.raises(ValueError, match="symlink"):
        cli_checkpoint.main()
