# GSpace

A local GitLab work item cockpit with an independent browser dashboard and Rich CLI. An issue is the central work item: `42:791` means project ID 42, issue IID 791; its MR may be `!154`, never implicitly `!791`.

The default is synthetic data with **no remote access or mutations**. The ordinary live adapter is read-only. A separate finite action service is restricted to explicitly configured, marker-owned synthetic projects at loopback `127.0.0.1:8929`. The exact CE server previously passed credential-free checks. After the Mac reboot it is stopped; restart is blocked by the unchanged storage guard, independently of the pending approved private bootstrap. The demo does not read authentication configuration or contact corporate services. The pinned GitLab reference and official CLI source are preserved under `.repos/`.

## Run the synthetic demo

For the current frontend, generated types and user-global CLI, run `poe install`
(or bootstrap with `python3.12 scripts/install.py`). Prerequisites:
Python 3.12, uv and Node.js/npm/Bun. `poe devpod-package` creates
`dist/gspace-devpod.tar.gz` with source and lockfiles, without installed dependencies
or operator state. See [DevPod installation and repository configuration](docs/devpod.md).

Python dependencies, development tools, Ruff/BasedPyright rules and all Poe recipes
are defined in `pyproject.toml`; `uv.lock` fixes their versions. Poe tasks live
directly under `[tool.poe.tasks]`, with no external task or requirements file.

Python **3.12** is required. With `uv` installed:

```sh
uv sync --locked --python python3.12
.venv/bin/poe serve --config gspace.example.toml
```

Open [http://127.0.0.1:8876](http://127.0.0.1:8876). The server binds only to loopback. Work items open as aligned process columns; use **Rows** for the normal list. Select four issues and use **Compare**; open an issue for branches, MRs, job attempts, deployment history, version observations, manual confirmations and action previews.

```sh
uv run --no-sync gspace dashboard --config gspace.example.toml --no-color --width 140
uv run --no-sync gspace show --config gspace.example.toml 42:791
uv run --no-sync gspace pipelines --config gspace.example.toml 42:793
uv run --no-sync gspace environments --config gspace.example.toml 42:792
uv run --no-sync gspace select --config gspace.example.toml 42:791
uv run --no-sync gspace compare --config gspace.example.toml --json
uv run --no-sync gspace preview --config gspace.example.toml 42:791 tag
```

`pin`, `hide`, `select`, `group`, `filters`, `checklist` and `override` save shared local preferences. Scoped saved views and resource bookmarks use the same revisioned TOML. `projects` lists configured coverage; `mrs` includes all authored states and unlinked history within that scope. `dashboard`, `list` and `compare` accept `--project`, `--view` and `--orientation columns`. `--off` reverses a flag or membership. Options belong after the command. `--json` writes only JSON to stdout; errors go to stderr with exit code 2. With Poe use `poe -q dashboard --json` to suppress the runner's own command announcement. `--no-color` and `NO_COLOR` disable ANSI colors. Rich detects terminal width unless `--width` is supplied.

## Integrated process UI

Claude Opus5.5/high implemented the independent strict TypeScript renderer and
additional graphical mode in `frontend-new`, preserved through finite local Git
checkpoints. The integrated compiled checkpoint is `5549698`; the verified
[fixture preview on port8877](http://127.0.0.1:8877/#/work) preserves existing demo
preferences. Port8876 remains the original recovery UI; port8878 serves frozen
previous `ab1d5d2` assets; port8879 serves the frozen corrected candidate. Prior renderer assets and checkpoints are preserved.

Choose **Visual** for adjacent work-item process columns, compact MR/branch/pipeline
cards and the actual-date milestone timeline. **Detailed** retains normal tables
and full evidence. Work-item detail includes the native scoped pipeline graph,
with separate application/config SHAs and trigger provenance. Configured custom
environments have independent saved-view fields. Deploy record, deploy job,
runtime and application-test outcomes remain separate in every environment.
Saved views/bookmarks offer shared curated icon/color/pin/order controls and top-bar
shortcuts; project images use a safe same-origin fallback. Light/dark/system themes,
responsive strips and scoped inspectors remain available. Mode/theme are browser-local
appearance; shared filters/selection/views/navigation remain atomic TOML.
See [finite text acceptance and unchanged limits](docs/verification/finite-text-acceptance-20261007.md).
Claude reviewed all57 images of the prior40bab537 design. Codex applied its two
finite text fixes under explicit integration authorization;24focused checks and
31browser regressions pass, with all16affected screenshots inspected. No Claude retry occurred.
See [MR source correction](docs/verification/mr-source-followup-20261006.md) and
[integrated verification and limits](docs/verification/integrated-20261006.md).

Saved views are host scoped and persisted in shared TOML: one project, all
configured projects, or an explicit project subset supported by the API/CLI.
The current UI selector chooses one repository or all configured repositories;
it can open a saved subset but does not provide a subset editor. Bookmarks identify
one typed resource in one project; collections may span projects. Typed project/group
milestones, complete/unknown counts, timezone date-current and explicit milestone
filters are implemented in the shared backend/API/CLI. The updated Milestones/Settings
screens and version-bound application-test editor passed browser gates at `007d1b3`.
The subsequent TypeScript conversion remains partial at `f7aeeee`; the sole Claude
writer is paused until18:10Europe/Zurich(16:10UTC). Both demo ports retain stable
`ba7ee8c` assets. Timeline and custom-environment web columns remain pending.
Use `gspace milestones`, `settings`, `settings-set`, `app-test`, `app-history`,
`branches`, `pipeline-catalog`, `probe` and `probe-compare` for verified CLI behavior;
see the runbook and requirement matrix for precise boundaries.

## Evidence and workflow

The matrix separates pipeline result, Nexus publish evidence, deployment record, expected/observed version and application test. The fixture includes a failed pipeline alongside a successful related dev deployment, a matching branch with an older observed commit, retried historical jobs, multiple MRs/branches, and the same issue IID in a second project.

Dev follows a branch/MR pipeline and Nexus publish, then a manual deployment. Preprod follows a tag created from the confirmed branch SHA, its tag pipeline, then a manual deployment. Tag suggestions increment the configured numeric component, rightmost by default. All action previews explicitly report `executed: false`.

Manual application results now store exact SHA/version, environment and aware timestamp
in shared preferences, separate from runtime/deploy/checklist. Changed commits do not
inherit a pass; branch/tag alone is insufficient. Custom environments and ordinary
composed operator pipeline rules have atomic conflict-checked TOML updates.

Local, dev, preprod and work confirmations remain manual. Completing the checklist never changes MR draft, triggers a retry/deploy, marks a release ready or merges anything. A matching branch name alone cannot prove a new commit. Missing or conflicting evidence stays unknown.

## Verification

```sh
.venv/bin/poe check
.venv/bin/poe browser-qa
.venv/bin/poe package-qa
workmemory-diagnose analyze-project . --text --graph --all-iterations
```

The browser check starts its own temporary fixture server, exercises desktop and mobile, checks shared CLI persistence, blocks external requests and saves captures in `output/playwright/`. It uses installed Chrome on macOS by default; supply `--browser /path/to/chromium` elsewhere. The local network bind and browser launch may need the execution environment's approval.

The independent backend checkpoint passed 151 Python 3.12 tests, strict BasedPyright,
Ruff, both OpenAPI drift checks, 31 stable-renderer browser checks and 12 offline
installed-package checks. The draft frontend is not included in those UI claims.
Evidence: [independent gates](docs/verification/backend-independent-20261006.md).

The package check builds `dist/gspace-0.1.0-py3-none-any.whl`, installs the locked runtime dependencies and wheel offline into an isolated environment, then runs the installed CLI and web server from an unrelated directory. It requires dependencies already cached by `uv sync`. The wheel includes local web assets and excludes both upstream repositories. See the runbook for installing the delivered wheel.

See [the runbook](docs/runbook.md), [development/Poe guide](docs/development.md),
[access and actions](docs/architecture/access-and-actions.md),
[model rationale](docs/architecture/modeling.md),
[source compatibility analysis](docs/architecture/gitlab-compatibility.md),
[baseline verification](docs/verification/results.md), and
[workmemory](.workmemory/PLAN.md). The deterministic public schema is
[OpenAPI JSON](docs/contracts/openapi.json), checked by `poe contract-check`.
Live configuration is left to the operator; no corporate instance, Nexus
repository or real deployment has been tested or changed.

The current CLI opens concise help with `uv run gspace`; use `list` for a compact scan and `dashboard --orientation columns` for the full process. Nested resource commands such as `pipelines show 42:791` preserve older aliases and explicit `--json` contracts. [CLI verification](docs/verification/cli-ux-redesign-20261006.md) records235Python3.12tests and26offline installed checks; final TypeScript web acceptance remains separate.
