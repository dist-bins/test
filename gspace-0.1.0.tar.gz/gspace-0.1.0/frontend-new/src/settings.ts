// Operator settings live in the local operator TOML (GET/POST /api/settings).
// The form edits a mutable SettingsDraft, separate from the validated
// SettingsResponse DTO. Only the OperatorSettings DTO is sent: no URL, auth,
// scope or path field exists here. A 409 keeps every edit and waits for an
// explicit reload or reapply. Saved rules are operator expectations and
// apply locally at once (job_configuration is recomputed from the saved
// file; views re-read the local snapshot). Remote evidence stays as fetched
// until an explicit Refresh; a save never triggers one.

import type { EnvironmentDefinition, JobRule, OperatorSettings, PipelineRules, ProjectPipelineOverride, SettingsResponse, StageRule } from './api';
import { check, errorMessage, errorStatus, http } from './api';
import type { Kid, Props } from './dom';
import { checkedOf, controlValue, fmtTime, h, icon, none, plural, tone } from './dom';
import { refreshSnapshot, reloadLocalViews } from './load';
import { derive, invalidateProcess, projectPath, scopeLabel } from './model';
import { pressInProgress, render, renderAfterPress } from './render';
import type { EnvDraft, JobDraft, JobRole, OverrideDraft, RulesDraft, SettingsDraft, StageDraft } from './state';
import { report, resolve, S, say, sectionOpen, toggleSection } from './state';
import { emptyState, sec, tinyBtn } from './ui';
import { mobileQuery } from './views';

type RuleField = keyof RulesDraft;
const RULE_FIELDS: readonly RuleField[] = ['stages', 'important_job_patterns', 'jobs', 'environments'];
const RULE_LABEL: Readonly<Record<RuleField, string>> = {
  stages: 'Stage order and dependencies',
  important_job_patterns: 'Important-job patterns',
  jobs: 'Publish and deploy jobs',
  environments: 'Environments',
};
const EDIT_ORDER: readonly RuleField[] = ['environments', 'jobs', 'important_job_patterns', 'stages'];
const RULE_PURPOSE: Readonly<Record<RuleField, string>> = {
  environments: 'Which environment rows appear in the process, and whether each deploys a branch or a tag.',
  jobs: 'Which job publishes the artifact, and which job deploys to which environment.',
  important_job_patterns: 'Which jobs are named first in process cells; every job stays reachable in its pipeline.',
  stages: 'Reading order of stages and the predecessors you expect. Operator expectations, not the observed CI DAG.',
};
const ROLES: readonly JobRole[] = ['normal', 'publish', 'deploy'];
const isRole = (x: string): x is JobRole => ROLES.some((r) => r === x);
const ENV_RE = /^[a-z][a-z0-9_-]{0,63}$/;
const JOB_RE = /^[A-Za-z0-9_.*? /:-]+$/;

/* ---------------------------------------------------- DTO <-> draft */
// Validators prove shape but do not populate defaults, so list fields that
// the schema defaults are read defensively when building a draft.

const list = <T>(x: readonly T[] | null | undefined): readonly T[] => (Array.isArray(x) ? x : []);
const stageDraft = (s: StageRule): StageDraft => ({ name: s.name, depends_on: [...list(s.depends_on)] });
const jobDraft = (j: JobRule): JobDraft => ({ pattern: j.pattern, role: isRole(j.role) ? j.role : 'normal', environment: j.environment ?? null });
const envDraft = (e: EnvironmentDefinition): EnvDraft => ({ name: e.name, label: e.label, ref_source: e.ref_source });

function rulesDraft(r: PipelineRules): RulesDraft {
  return {
    stages: list(r.stages).map(stageDraft),
    important_job_patterns: [...list(r.important_job_patterns)],
    jobs: list(r.jobs).map(jobDraft),
    environments: list(r.environments).map(envDraft),
  };
}

function overrideDraft(o: ProjectPipelineOverride): OverrideDraft {
  return {
    project: o.project.value,
    stages: o.stages ? o.stages.map(stageDraft) : null,
    important_job_patterns: o.important_job_patterns ? [...o.important_job_patterns] : null,
    jobs: o.jobs ? o.jobs.map(jobDraft) : null,
    environments: o.environments ? o.environments.map(envDraft) : null,
  };
}

function settingsDraft(s: OperatorSettings): SettingsDraft {
  return {
    timezone: s.timezone,
    branch_template: s.branch_template,
    tag_convention: {
      component_from_right: s.tag_convention.component_from_right,
      increment: s.tag_convention.increment,
      preserve_padding: s.tag_convention.preserve_padding,
    },
    pipeline: rulesDraft(s.pipeline),
    project_pipeline_overrides: list(s.project_pipeline_overrides).map(overrideDraft),
  };
}

const cloneDraft = (d: SettingsDraft): SettingsDraft => ({
  ...d,
  tag_convention: { ...d.tag_convention },
  pipeline: cloneRules(d.pipeline),
  project_pipeline_overrides: d.project_pipeline_overrides.map((o) => ({
    project: o.project,
    stages: o.stages ? o.stages.map((s) => ({ name: s.name, depends_on: [...s.depends_on] })) : null,
    important_job_patterns: o.important_job_patterns ? [...o.important_job_patterns] : null,
    jobs: o.jobs ? o.jobs.map((j) => ({ ...j })) : null,
    environments: o.environments ? o.environments.map((e) => ({ ...e })) : null,
  })),
});
function cloneRules(r: RulesDraft): RulesDraft {
  return {
    stages: r.stages.map((s) => ({ name: s.name, depends_on: [...s.depends_on] })),
    important_job_patterns: [...r.important_job_patterns],
    jobs: r.jobs.map((j) => ({ ...j })),
    environments: r.environments.map((e) => ({ ...e })),
  };
}

// Outgoing copy: trimmed names, dependencies renamed with their stages.
const t = (s: string): string => s.trim();
const stagesOut = (x: readonly StageDraft[]): StageRule[] => x.map((s) => ({ name: t(s.name), depends_on: s.depends_on.map(t) }));
const jobsOut = (x: readonly JobDraft[]): JobRule[] =>
  x.map((j) => ({ pattern: t(j.pattern), role: j.role, environment: j.role === 'deploy' ? j.environment : null }));
const envsOut = (x: readonly EnvDraft[]): EnvironmentDefinition[] => x.map((e) => ({ name: t(e.name), label: t(e.label), ref_source: e.ref_source }));

function overridesOut(d: SettingsDraft): ProjectPipelineOverride[] {
  return d.project_pipeline_overrides.map((o) => ({
    project: { value: o.project },
    stages: o.stages ? stagesOut(o.stages) : null,
    important_job_patterns: o.important_job_patterns ? o.important_job_patterns.map(t) : null,
    jobs: o.jobs ? jobsOut(o.jobs) : null,
    environments: o.environments ? envsOut(o.environments) : null,
  }));
}

function settingsOut(d: SettingsDraft): OperatorSettings {
  return {
    timezone: t(d.timezone),
    branch_template: d.branch_template,
    tag_convention: {
      component_from_right: d.tag_convention.component_from_right,
      increment: d.tag_convention.increment,
      preserve_padding: d.tag_convention.preserve_padding,
    },
    pipeline: {
      stages: stagesOut(d.pipeline.stages),
      important_job_patterns: d.pipeline.important_job_patterns.map(t),
      jobs: jobsOut(d.pipeline.jobs),
      environments: envsOut(d.pipeline.environments),
    },
    project_pipeline_overrides: overridesOut(d),
  };
}

/* -------------------------------------------------------------- model */

export function settingsDirty(): boolean {
  const st = S.set;
  return !!(st.draft && st.base && JSON.stringify(st.draft) !== JSON.stringify(st.base));
}

export function adoptSettings(r: SettingsResponse, replaceDraft = false): void {
  const st = S.set;
  const dirty = settingsDirty();
  st.resp = r;
  st.error = null;
  st.errorStatus = null;
  st.base = settingsDraft(r.settings);
  if (replaceDraft || !st.draft || !dirty) st.draft = cloneDraft(st.base);
  invalidateProcess(); // configured environments may have changed
}

export type LoadMode = 'auto' | 'keep' | 'discard';

// mode: 'auto' keeps unsaved edits, 'keep' rebases edits onto the latest
// file revision (after a conflict), 'discard' replaces them.
// A successful read means the running service now uses that valid file
// revision. When it differs from the one shown, the local views are re-read
// (a plain GET of the snapshot, never /api/refresh), even while unsaved
// edits wait for an explicit choice. A failed read (400: the file is
// invalid) leaves the service on its last valid rules and the form as it is.
export async function loadSettings(mode: LoadMode = 'auto'): Promise<void> {
  const st = S.set;
  if (st.loading) return;
  st.loading = true;
  render();
  const before = st.resp?.revision ?? null;
  try {
    const r = await http.settings();
    if (before !== null && r.revision !== before) {
      st.saved = { at: Date.now(), origin: 'external', revision: r.revision, refresh_required: r.refresh_required, refreshed: false, views: 'pending' };
      say(`The operator file changed to revision ${r.revision.slice(0, 8)}; it is in use locally and the views are re-read. Remote evidence is unchanged.`);
      void reloadLocalViews().then((ok) => {
        if (st.saved?.revision === r.revision) {
          st.saved = { ...st.saved, views: ok };
          render();
        }
      });
    }
    if (mode === 'auto' && settingsDirty()) {
      // Never move unsaved edits onto a newer revision silently: that would
      // bypass the server's conflict check. Ask for an explicit choice.
      if (r.revision !== st.resp?.revision) {
        st.conflict = {
          message: `The file is now at revision ${r.revision.slice(0, 8)}; your edits started from ${(st.resp?.revision ?? '?').slice(0, 8)}.`,
          at: Date.now(),
        };
      }
    } else if (mode === 'keep') {
      const mine = st.draft;
      adoptSettings(r, true);
      if (mine) st.draft = mine;
      st.rebased = true;
      st.conflict = null;
    } else {
      adoptSettings(r, mode === 'discard');
      if (mode === 'discard') {
        st.conflict = null;
        st.rebased = false;
        st.adv = null;
      }
    }
    st.error = null;
    st.errorStatus = null;
    st.saveError = null;
    resolve('settings-load');
    derive();
  } catch (e) {
    st.error = errorMessage(e);
    st.errorStatus = errorStatus(e);
    // The Settings screen states the failure inline (status bar and panel),
    // so the problem tray would only repeat it there and cover the form.
    // Elsewhere (a reload on window focus) the tray reports it, with the same
    // "Reload" verb as the screen; nothing is retried automatically.
    if (S.route.screen === 'settings') resolve('settings-load');
    else
      report(
        'settings-load',
        st.errorStatus === 400 ? 'Operator file not applied' : 'Settings unavailable',
        st.errorStatus === 400 ? `${st.error} The service keeps its last valid rules.` : st.error,
        { retry: () => void loadSettings(mode), retryLabel: 'Reload' },
      );
  } finally {
    st.loading = false;
    render();
  }
}

interface Problems {
  readonly errs: string[];
  readonly warns: string[];
}

/** A global rule set (every list present) or a project override (null = inherited). */
interface RuleLists {
  readonly stages: readonly StageDraft[] | null;
  readonly important_job_patterns: readonly string[] | null;
  readonly jobs: readonly JobDraft[] | null;
  readonly environments: readonly EnvDraft[] | null;
}

function validateRules(r: RuleLists, where: string, jobEnvs: readonly string[], p: Problems): void {
  if (r.stages) {
    const seen: string[] = [];
    r.stages.forEach((s, i) => {
      const at = `${where} · stage ${i + 1}`;
      const nm = s.name.trim();
      if (!nm) p.errs.push(`${at}: enter a name.`);
      else if (nm.length > 500) p.errs.push(`${at}: the name is longer than 500 characters.`);
      else if (seen.includes(nm)) p.errs.push(`${at}: "${nm}" is listed twice.`);
      for (const d of s.depends_on) if (!seen.includes(d.trim())) p.errs.push(`${at}: depends on "${d}", which is not an earlier stage.`);
      if (nm) seen.push(nm);
    });
  }
  if (r.important_job_patterns) {
    r.important_job_patterns.forEach((x, i) => {
      if (!x.trim()) p.errs.push(`${where} · important-job pattern ${i + 1}: enter a pattern or remove it.`);
      else if (x.length > 500) p.errs.push(`${where} · important-job pattern ${i + 1}: longer than 500 characters.`);
    });
  }
  if (r.environments) {
    const seen = new Set<string>();
    r.environments.forEach((e, i) => {
      const at = `${where} · environment ${i + 1}`;
      const nm = e.name.trim();
      if (!ENV_RE.test(nm)) p.errs.push(`${at}: the name must start with a lowercase letter and use only a–z, 0–9, "_" or "-" (max 64).`);
      else if (seen.has(nm)) p.errs.push(`${at}: "${nm}" is listed twice.`);
      seen.add(nm);
      if (!e.label.trim()) p.errs.push(`${at}: enter a label.`);
      else if (e.label.length > 500) p.errs.push(`${at}: the label is longer than 500 characters.`);
    });
  }
  if (r.jobs) {
    r.jobs.forEach((j, i) => {
      const at = `${where} · job rule ${i + 1}`;
      const x = j.pattern.trim();
      if (!x) p.errs.push(`${at}: enter a job-name pattern.`);
      else if (x.length > 100) p.errs.push(`${at}: the pattern is longer than 100 characters.`);
      else if (!JOB_RE.test(x)) p.errs.push(`${at}: the pattern may use letters, digits, space and _ . * ? / : - only.`);
      if (j.role === 'deploy') {
        if (!j.environment) p.errs.push(`${at}: a deploy job needs an environment.`);
        else if (!jobEnvs.includes(j.environment)) p.errs.push(`${at}: environment "${j.environment}" is not configured here.`);
      }
    });
  }
}

const knownTimezones = (): readonly string[] => (typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : []);

function validateSettings(d: SettingsDraft): Problems {
  const p: Problems = { errs: [], warns: [] };
  const tz = d.timezone.trim();
  const zones = knownTimezones();
  if (!tz) p.errs.push('Timezone: enter an IANA timezone such as Europe/Zurich.');
  else if (zones.length && !zones.includes(tz) && tz !== 'UTC')
    p.warns.push(`Timezone "${tz}" is not known to this browser; the server decides whether it is valid.`);
  if (!d.branch_template.trim()) p.errs.push('Branch template: enter a template such as issue-{iid}.');
  else if (!d.branch_template.includes('{iid}')) p.warns.push('Branch template has no {iid} placeholder, so every issue maps to the same branch name.');
  const tc = d.tag_convention;
  if (!Number.isInteger(tc.component_from_right) || tc.component_from_right < 0 || tc.component_from_right > 10)
    p.errs.push('Tag convention: the component from the right must be a whole number from 0 to 10.');
  if (!Number.isInteger(tc.increment) || tc.increment < 1) p.errs.push('Tag convention: the increment must be a whole number of at least 1.');
  validateRules(
    d.pipeline,
    'Global',
    d.pipeline.environments.map((e) => e.name.trim()),
    p,
  );
  const seen = new Set<number>();
  for (const o of d.project_pipeline_overrides) {
    const pid = o.project;
    const where = `Override for ${Number.isInteger(pid) && pid > 0 ? projectPath(pid) : 'an invalid project'}`;
    if (!Number.isInteger(pid) || pid < 1) p.errs.push(`${where}: the project ID must be a positive whole number.`);
    else if (seen.has(pid)) p.errs.push(`${where}: listed twice.`);
    else if (S.projects.length && !S.projects.some((x) => x.id.value === pid)) p.warns.push(`${where}: project ${pid} is not one of the configured projects.`);
    seen.add(pid);
    validateRules(
      o,
      where,
      (o.environments ?? d.pipeline.environments).map((e) => e.name.trim()),
      p,
    );
    if (RULE_FIELDS.every((f) => o[f] == null)) p.warns.push(`${where}: overrides nothing; it can be removed.`);
  }
  return p;
}

/**
 * The last read found the operator file invalid (400). The form was built from
 * an earlier valid revision, so saving over a file that is known to be broken
 * is not offered until a successful Reload clears this (adoptSettings).
 */
const fileInvalid = (): boolean => S.set.error !== null && S.set.errorStatus === 400;

async function saveSettings(): Promise<void> {
  const st = S.set;
  if (st.saving || !st.resp || !st.draft || fileInvalid()) return;
  const { errs } = validateSettings(st.draft);
  if (errs.length) {
    st.saveError = `Not saved: ${plural(errs.length, 'problem')} listed below.`;
    render();
    return;
  }
  st.saving = true;
  st.saveError = null;
  render();
  try {
    const r = await http.saveSettings({ revision: st.resp.revision, settings: settingsOut(st.draft) });
    adoptSettings(r, true);
    st.conflict = null;
    st.rebased = false;
    st.adv = null;
    st.saved = { at: Date.now(), origin: 'save', revision: r.revision, refresh_required: r.refresh_required, refreshed: false, views: 'pending' };
    derive();
    say('Settings saved to the local operator file and in use locally. Remote evidence is unchanged until you refresh.');
    // Local re-read only; never /api/refresh.
    void reloadLocalViews().then((ok) => {
      if (st.saved) {
        st.saved = { ...st.saved, views: ok };
        render();
      }
    });
  } catch (e) {
    // Edits stay in the form whatever happened; nothing is retried.
    if (errorStatus(e) === 409) st.conflict = { message: errorMessage(e), at: Date.now() };
    else st.saveError = errorMessage(e);
  } finally {
    st.saving = false;
    render();
  }
}

// Number of form sections whose draft differs from the revision it started from.
function changedSections(d: SettingsDraft, b: SettingsDraft | null): number {
  if (!b) return 0;
  const parts = (x: SettingsDraft): unknown[] => [
    x.timezone,
    x.branch_template,
    x.tag_convention,
    x.pipeline.environments,
    x.pipeline.jobs,
    x.pipeline.important_job_patterns,
    x.pipeline.stages,
    x.project_pipeline_overrides,
  ];
  const a = parts(d);
  const c = parts(b);
  return a.filter((v, i) => JSON.stringify(v) !== JSON.stringify(c[i])).length;
}

/* ------------------------------------------------- editing interaction */

// Mutate the draft. The status region (dirty state, problem count, Save)
// is refreshed in place at once, so typing updates Save promptly without
// replacing the field being typed in. A full re-render (labels that depend
// on names, rename propagation) follows in a later task when `rerender` is
// set: by then a Tab has moved focus, so focus restoration keeps the Tab
// order, and a pressed button is protected by the click hold in render().
function setDraft(fn: (d: SettingsDraft) => void, rerender = true): void {
  const d = S.set.draft;
  if (!d) return;
  fn(d);
  S.set.saveError = null;
  updateSettingsStatus();
  if (rerender) window.setTimeout(() => render(), 0);
}

// Replaces only the status region of the Settings screen. While a pointer
// is pressed (for example on Save, whose press just blurred a text field),
// the region is left alone so the pressed button survives until its click;
// the held full render after the click brings the status up to date.
function updateSettingsStatus(): void {
  if (pressInProgress()) {
    renderAfterPress();
    return;
  }
  const box = document.getElementById('set-status');
  if (box && S.set.draft) box.replaceChildren(...settingsStatus().filter((x): x is HTMLElement => x !== null));
}

// Name before the current edit began (text fields write the draft on every
// keystroke, so references are renamed once the edit settles).
const editFrom = new WeakMap<StageDraft | EnvDraft, string>();
function renamed(obj: StageDraft | EnvDraft, val: string, settle: boolean): string | null {
  if (!editFrom.has(obj)) editFrom.set(obj, obj.name.trim());
  obj.name = val;
  if (!settle) return null;
  const old = editFrom.get(obj);
  editFrom.delete(obj);
  return old && old !== val.trim() ? old : null;
}

type Settle = (val: string, settle: boolean) => void;

function textIn(value: string, onset: Settle, attrs: Props, mono = false): HTMLInputElement {
  return h('input', {
    class: `input${mono ? ' mono' : ''}`,
    value,
    autocomplete: 'off',
    spellcheck: 'false',
    ...attrs,
    oninput: (e: Event) => onset(controlValue(e), false),
    onchange: (e: Event) => onset(controlValue(e), true),
  });
}

// Number field: the draft follows every keystroke (status only); the form
// re-renders when the edit settles. Empty or non-numeric input is NaN and is
// reported by validation instead of being guessed.
function numIn(value: number, onset: (n: number, settle: boolean) => void, attrs: Props): HTMLInputElement {
  const parse = (v: string): number => (v === '' ? Number.NaN : Number(v));
  return h('input', {
    class: 'input num-in',
    type: 'number',
    step: '1',
    ...attrs,
    value: Number.isNaN(value) ? '' : String(value),
    oninput: (e: Event) => onset(parse(controlValue(e)), false),
    onchange: (e: Event) => onset(parse(controlValue(e)), true),
  });
}

function moveIn<T>(items: T[], i: number, d: number): void {
  const j = i + d;
  const a = items[i];
  const b = items[j];
  if (a === undefined || b === undefined) return;
  items[i] = b;
  items[j] = a;
}

/* ------------------------------------------------------------ editors */
// Structured editor for one PipelineRules set (global, or one field of a
// project override). `fk` keeps focus keys unique per rule set.

function stagesEditor(stages: StageDraft[], fk: string): HTMLDivElement {
  return h(
    'div',
    { class: 'ed' },
    stages.length
      ? h(
          'ol',
          { class: 'ed-list' },
          stages.map((s, i) => {
            const earlier = stages
              .slice(0, i)
              .map((x) => x.name.trim())
              .filter(Boolean);
            const bad = s.depends_on.filter((d) => !earlier.includes(d.trim()));
            return h(
              'li',
              { class: 'ed-row' },
              h('span', { class: 'ed-n', 'aria-hidden': 'true' }, String(i + 1)),
              h(
                'label',
                { class: 'field ed-name' },
                h('span', { class: 'sr' }, `Stage ${i + 1} name`),
                textIn(
                  s.name,
                  (val, settle) =>
                    setDraft(() => {
                      const old = renamed(s, val, settle);
                      // Keep later dependencies pointing at the renamed stage.
                      if (old) for (const x of stages) x.depends_on = x.depends_on.map((d) => (d.trim() === old ? val.trim() : d));
                    }, settle),
                  { maxlength: '500', placeholder: 'stage name', 'data-fk': `${fk}-st-${i}`, 'aria-label': `Stage ${i + 1} name` },
                  true,
                ),
              ),
              h(
                'div',
                { class: 'ed-deps', role: 'group', 'aria-label': `Stage ${i + 1} expected predecessors` },
                h('span', { class: 'muted' }, 'after'),
                earlier.length
                  ? earlier.map((nm) =>
                      h(
                        'label',
                        { class: 'check bare dep' },
                        h('input', {
                          type: 'checkbox',
                          checked: s.depends_on.map((d) => d.trim()).includes(nm),
                          'data-fk': `${fk}-dep-${i}-${nm}`,
                          onchange: (e: Event) =>
                            setDraft(() => {
                              s.depends_on = checkedOf(e) ? [...s.depends_on, nm] : s.depends_on.filter((d) => d.trim() !== nm);
                            }),
                        }),
                        h('span', { class: 'mono' }, nm),
                      ),
                    )
                  : none('first stage'),
                bad.map((d) =>
                  h(
                    'span',
                    { class: 'chip st t-fail', title: 'Not an earlier stage; remove it or reorder the stages' },
                    h('span', { class: 'mono' }, d),
                    h(
                      'button',
                      {
                        class: 'chip-x',
                        type: 'button',
                        'aria-label': `Remove dependency ${d}`,
                        onclick: () =>
                          setDraft(() => {
                            s.depends_on = s.depends_on.filter((x) => x !== d);
                          }),
                      },
                      icon('close', 'sm'),
                    ),
                  ),
                ),
              ),
              h(
                'div',
                { class: 'ed-tools' },
                tinyBtn('up', `Move stage ${i + 1} up`, () => setDraft(() => moveIn(stages, i, -1)), { disabled: i === 0, fk: `${fk}-up-${i}` }),
                tinyBtn('down', `Move stage ${i + 1} down`, () => setDraft(() => moveIn(stages, i, 1)), {
                  disabled: i === stages.length - 1,
                  fk: `${fk}-dn-${i}`,
                }),
                tinyBtn(
                  'trash',
                  `Remove stage ${i + 1}`,
                  () =>
                    setDraft(() => {
                      const nm = s.name.trim();
                      stages.splice(i, 1);
                      for (const x of stages) x.depends_on = x.depends_on.filter((d) => d.trim() !== nm);
                    }),
                  { danger: true, fk: `${fk}-rm-${i}` },
                ),
              ),
            );
          }),
        )
      : h('p', { class: 'muted' }, 'No stages configured.'),
    h(
      'button',
      {
        class: 'btn sm',
        type: 'button',
        'data-fk': `${fk}-st-add`,
        onclick: () =>
          setDraft(() => {
            stages.push({ name: '', depends_on: [] });
          }),
      },
      icon('plus', 'sm'),
      'Add stage',
    ),
    h(
      'p',
      { class: 'hint' },
      'Order is the reading order of stages in process cells and the pipeline drawer. "After" records which earlier stages you expect to finish first. These are operator expectations, not the observed CI DAG.',
    ),
  );
}

function patternsEditor(items: string[], fk: string): HTMLDivElement {
  return h(
    'div',
    { class: 'ed' },
    items.length
      ? h(
          'ul',
          { class: 'ed-list' },
          items.map((x, i) =>
            h(
              'li',
              { class: 'ed-row' },
              h(
                'label',
                { class: 'field ed-name' },
                h('span', { class: 'sr' }, `Important-job pattern ${i + 1}`),
                textIn(
                  x,
                  (val, settle) =>
                    setDraft(() => {
                      items[i] = val;
                    }, settle),
                  { maxlength: '500', placeholder: 'e.g. unit-*', 'data-fk': `${fk}-ip-${i}`, 'aria-label': `Important-job pattern ${i + 1}` },
                  true,
                ),
              ),
              h(
                'div',
                { class: 'ed-tools' },
                tinyBtn(
                  'trash',
                  `Remove pattern ${i + 1}`,
                  () =>
                    setDraft(() => {
                      items.splice(i, 1);
                    }),
                  { danger: true, fk: `${fk}-iprm-${i}` },
                ),
              ),
            ),
          ),
        )
      : h('p', { class: 'muted' }, 'No important-job patterns: process cells list every job.'),
    h(
      'button',
      {
        class: 'btn sm',
        type: 'button',
        'data-fk': `${fk}-ip-add`,
        onclick: () =>
          setDraft(() => {
            items.push('');
          }),
      },
      icon('plus', 'sm'),
      'Add pattern',
    ),
    h(
      'p',
      { class: 'hint' },
      'Job names matching a pattern (* and ? wildcards) are marked ★ and summarised in process cells. Every job stays one click away in the pipeline.',
    ),
  );
}

const ROLE_LABEL: Readonly<Record<JobRole, string>> = { normal: 'Normal job', publish: 'Publish job', deploy: 'Deploy job' };

function jobsEditor(jobs: JobDraft[], envs: readonly string[], fk: string): HTMLDivElement {
  return h(
    'div',
    { class: 'ed' },
    jobs.length
      ? h(
          'ul',
          { class: 'ed-list' },
          jobs.map((j, i) =>
            h(
              'li',
              { class: 'ed-row' },
              h(
                'label',
                { class: 'field ed-name' },
                h('span', { class: 'sr' }, `Job rule ${i + 1} pattern`),
                textIn(
                  j.pattern,
                  (val, settle) =>
                    setDraft(() => {
                      j.pattern = val;
                    }, settle),
                  { maxlength: '100', placeholder: 'job name or pattern', 'data-fk': `${fk}-jp-${i}`, 'aria-label': `Job rule ${i + 1} pattern` },
                  true,
                ),
              ),
              h(
                'label',
                { class: 'field' },
                h('span', { class: 'sr' }, `Job rule ${i + 1} role`),
                h(
                  'select',
                  {
                    class: 'select',
                    'data-fk': `${fk}-jr-${i}`,
                    'aria-label': `Job rule ${i + 1} role`,
                    // Switching to deploy never picks an environment for you.
                    onchange: (e: Event) =>
                      setDraft(() => {
                        const v = controlValue(e);
                        if (!isRole(v)) return;
                        j.role = v;
                        j.environment = v === 'deploy' ? j.environment : null;
                      }),
                  },
                  ROLES.map((r) => h('option', { value: r, selected: j.role === r }, ROLE_LABEL[r])),
                ),
              ),
              j.role === 'deploy'
                ? h(
                    'label',
                    { class: 'field' },
                    h('span', { class: 'sr' }, `Job rule ${i + 1} environment`),
                    h(
                      'select',
                      {
                        class: 'select',
                        'data-fk': `${fk}-je-${i}`,
                        'aria-label': `Job rule ${i + 1} environment`,
                        onchange: (e: Event) =>
                          setDraft(() => {
                            j.environment = controlValue(e) || null;
                          }),
                      },
                      h('option', { value: '', selected: !j.environment }, 'Choose environment…'),
                      envs.map((n) => h('option', { value: n, selected: j.environment === n }, `→ ${n}`)),
                      j.environment && !envs.includes(j.environment)
                        ? h('option', { value: j.environment, selected: true }, `→ ${j.environment} (not configured)`)
                        : null,
                    ),
                  )
                : null,
              h(
                'div',
                { class: 'ed-tools' },
                tinyBtn(
                  'trash',
                  `Remove job rule ${i + 1}`,
                  () =>
                    setDraft(() => {
                      jobs.splice(i, 1);
                    }),
                  { danger: true, fk: `${fk}-jrm-${i}` },
                ),
              ),
            ),
          ),
        )
      : h('p', { class: 'muted' }, 'No job rules: no job is classified as publish or deploy.'),
    h(
      'button',
      {
        class: 'btn sm',
        type: 'button',
        'data-fk': `${fk}-j-add`,
        onclick: () =>
          setDraft(() => {
            jobs.push({ pattern: '', role: 'normal', environment: null });
          }),
      },
      icon('plus', 'sm'),
      'Add job rule',
    ),
    h('p', { class: 'hint' }, 'A deploy job names one configured environment; other roles name none. A job status is never a deployment record.'),
  );
}

function envsEditor(envs: EnvDraft[], fk: string, onRename: (old: string, nu: string) => void): HTMLDivElement {
  return h(
    'div',
    { class: 'ed' },
    envs.length
      ? h(
          'ul',
          { class: 'ed-list' },
          envs.map((e, i) =>
            h(
              'li',
              { class: 'ed-row' },
              h(
                'label',
                { class: 'field ed-name' },
                h('span', { class: 'sr' }, `Environment ${i + 1} name`),
                textIn(
                  e.name,
                  (val, settle) =>
                    setDraft(() => {
                      const old = renamed(e, val, settle);
                      if (old) onRename(old, val.trim());
                    }, settle),
                  { maxlength: '64', placeholder: 'name', 'data-fk': `${fk}-en-${i}`, 'aria-label': `Environment ${i + 1} name` },
                  true,
                ),
              ),
              h(
                'label',
                { class: 'field ed-name' },
                h('span', { class: 'sr' }, `Environment ${i + 1} label`),
                textIn(
                  e.label,
                  (val, settle) =>
                    setDraft(() => {
                      e.label = val;
                    }, settle),
                  { maxlength: '500', placeholder: 'Label', 'data-fk': `${fk}-el-${i}`, 'aria-label': `Environment ${i + 1} label` },
                ),
              ),
              h(
                'label',
                { class: 'field' },
                h('span', { class: 'sr' }, `Environment ${i + 1} deploys`),
                h(
                  'select',
                  {
                    class: 'select',
                    'data-fk': `${fk}-er-${i}`,
                    'aria-label': `Environment ${i + 1} deploys a`,
                    onchange: (ev: Event) =>
                      setDraft(() => {
                        const v = controlValue(ev);
                        if (v === 'branch' || v === 'tag') e.ref_source = v;
                      }),
                  },
                  h('option', { value: 'branch', selected: e.ref_source === 'branch' }, 'deploys a branch ref'),
                  h('option', { value: 'tag', selected: e.ref_source === 'tag' }, 'deploys a tag ref'),
                ),
              ),
              h(
                'div',
                { class: 'ed-tools' },
                tinyBtn('up', `Move environment ${i + 1} up`, () => setDraft(() => moveIn(envs, i, -1)), { disabled: i === 0, fk: `${fk}-eup-${i}` }),
                tinyBtn('down', `Move environment ${i + 1} down`, () => setDraft(() => moveIn(envs, i, 1)), {
                  disabled: i === envs.length - 1,
                  fk: `${fk}-edn-${i}`,
                }),
                tinyBtn(
                  'trash',
                  `Remove environment ${i + 1}`,
                  () =>
                    setDraft(() => {
                      envs.splice(i, 1);
                    }),
                  { danger: true, fk: `${fk}-erm-${i}` },
                ),
              ),
            ),
          ),
        )
      : h('p', { class: 'muted' }, 'No environments configured.'),
    h(
      'button',
      {
        class: 'btn sm',
        type: 'button',
        'data-fk': `${fk}-e-add`,
        onclick: () =>
          setDraft(() => {
            envs.push({ name: '', label: '', ref_source: 'branch' });
          }),
      },
      icon('plus', 'sm'),
      'Add environment',
    ),
    h(
      'p',
      { class: 'hint' },
      'Branch-ref environments follow Publish in the process; tag-ref environments follow the tag pipeline. Each gets deployment, runtime and application-test rows. Runtime endpoints stay operator configuration outside this page.',
    ),
  );
}

function ruleEditor(f: RuleField, r: RulesDraft, fk: string, envNames: readonly string[], onEnvRename: (old: string, nu: string) => void): HTMLDivElement {
  switch (f) {
    case 'stages':
      return stagesEditor(r.stages, fk);
    case 'important_job_patterns':
      return patternsEditor(r.important_job_patterns, fk);
    case 'jobs':
      return jobsEditor(r.jobs, envNames, fk);
    case 'environments':
      return envsEditor(r.environments, fk, onEnvRename);
  }
}

// The same editors for one overridden list of a project override.
function overrideEditor(f: RuleField, o: OverrideDraft, fk: string, envNames: readonly string[]): Kid {
  const rename = (old: string, nu: string): void => {
    for (const j of o.jobs ?? []) if (j.environment === old) j.environment = nu;
  };
  switch (f) {
    case 'stages':
      return o.stages ? stagesEditor(o.stages, fk) : null;
    case 'important_job_patterns':
      return o.important_job_patterns ? patternsEditor(o.important_job_patterns, fk) : null;
    case 'jobs':
      return o.jobs ? jobsEditor(o.jobs, envNames, fk) : null;
    case 'environments':
      return o.environments ? envsEditor(o.environments, fk, rename) : null;
  }
}

// Rule values wrap only at spaces: each word (job name, pattern) stays whole,
// so "publish-*" or "deploy-dev" is never split at its hyphen.
const words = (s: string): Kid[] => s.split(' ').map((w, i) => [i ? ' ' : '', h('span', { class: 'nowrap' }, w)]);

function summary(f: RuleField, r: Readonly<PipelineRules> | RulesDraft): HTMLSpanElement {
  switch (f) {
    case 'stages': {
      const v = list(r.stages);
      return v.length
        ? h(
            'span',
            { class: 'mono' },
            words(v.map((s) => `${s.name}${list(s.depends_on).length ? ` (after ${list(s.depends_on).join(', ')})` : ''}`).join(' → ')),
          )
        : none('none');
    }
    case 'important_job_patterns': {
      const v = list(r.important_job_patterns);
      return v.length ? h('span', { class: 'mono' }, words(v.join(', '))) : none('none');
    }
    case 'jobs': {
      const v = list(r.jobs);
      return v.length
        ? h('span', { class: 'mono' }, words(v.map((j) => `${j.pattern}: ${j.role}${j.environment ? ` → ${j.environment}` : ''}`).join('; ')))
        : none('none');
    }
    case 'environments': {
      const v = list(r.environments);
      return v.length ? h('span', null, v.map((e) => `${e.label} (${e.name}, ${e.ref_source} ref)`).join(', ')) : none('none');
    }
  }
}

type Effective = NonNullable<SettingsResponse['effective']>[number];

function effTable(x: Effective): HTMLTableElement {
  return h(
    'table',
    { class: 'tbl eff' },
    h('thead', null, h('tr', null, h('th', { scope: 'col' }, 'Rule'), h('th', { scope: 'col' }, 'Source'), h('th', { scope: 'col' }, 'Effective value'))),
    h(
      'tbody',
      null,
      RULE_FIELDS.map((f) => {
        const src = x.sources[f];
        return h(
          'tr',
          null,
          h('td', { 'data-label': 'Rule' }, RULE_LABEL[f]),
          h(
            'td',
            { 'data-label': 'Source' },
            src === 'global'
              ? h('span', { class: 'chip' }, 'Global')
              : src === 'project_override'
                ? h('span', { class: 'chip st t-manual' }, h('span', null, 'Project override'))
                : src === 'legacy_live_override'
                  ? h(
                      'span',
                      { class: 'chip st t-warn', title: 'The server reports this value from a legacy live override' },
                      h('span', null, 'Legacy live override'),
                    )
                  : h('span', { class: 'chip st t-unknown' }, h('span', null, 'Source not reported')),
          ),
          h('td', { 'data-label': 'Value' }, summary(f, x.rules)),
        );
      }),
    ),
  );
}

// One table for several projects only when every rule of every one of them
// is reported as Global and the effective values are identical; any
// override, other source or difference keeps one table per project.
function allGlobalSame(eff: readonly Effective[]): boolean {
  const first = eff[0];
  if (!first || eff.length < 2) return false;
  const same = JSON.stringify(first.rules);
  return eff.every((x) => RULE_FIELDS.every((f) => x.sources[f] === 'global') && JSON.stringify(x.rules) === same);
}

function effectiveSection(): HTMLElement {
  const R = S.set.resp;
  const eff = (R?.effective ?? []).filter((x) => S.scope.project == null || x.project.value === S.scope.project);
  const merged = allGlobalSame(eff) ? eff[0] : undefined;
  const everyConfigured = S.projects.length > 0 && S.projects.every((p) => eff.some((x) => x.project.value === p.id.value));
  return sec(
    'Rules in use per project',
    'views',
    h(
      'div',
      { class: 'lines' },
      h(
        'p',
        { class: 'hint' },
        `What the running service applies after overrides, from the last file revision read here${settingsDirty() ? ' (your unsaved edits are not included)' : ''}. Dependencies are operator expectations, not the observed CI DAG.`,
      ),
      merged
        ? h(
            'div',
            { class: 'box' },
            h(
              'div',
              { class: 'eff-h' },
              icon('repo', 'sm'),
              h('strong', null, `${everyConfigured ? 'All configured projects' : 'These projects'} (${eff.length}) use the global rules`),
            ),
            h(
              'div',
              { class: 'chips eff-projects' },
              eff.map((x) => h('span', { class: 'chip mono', title: `Project ${x.project.value}` }, `${projectPath(x.project.value)} · id ${x.project.value}`)),
            ),
            effTable(merged),
          )
        : eff.length
          ? eff.map((x) =>
              h(
                'div',
                { class: 'box' },
                h(
                  'div',
                  { class: 'eff-h' },
                  icon('repo', 'sm'),
                  h('strong', null, projectPath(x.project.value)),
                  h('span', { class: 'muted mono' }, `id ${x.project.value}`),
                ),
                effTable(x),
              ),
            )
          : h('p', { class: 'muted' }, R ? 'The server reported no effective rules for this repository scope.' : 'Not loaded.'),
    ),
  );
}

function overridesSection(d: SettingsDraft): HTMLElement {
  const used = new Set(d.project_pipeline_overrides.map((o) => o.project));
  const free = S.projects.filter((p) => !used.has(p.id.value));
  const cards = d.project_pipeline_overrides.map((o, oi) => {
    const pid = o.project;
    const envNames = (o.environments ?? d.pipeline.environments).map((e) => e.name.trim()).filter(Boolean);
    const fk = `ov${pid}`;
    return h(
      'div',
      { class: 'box pad lines ov-card' },
      h(
        'div',
        { class: 'line' },
        icon('repo', 'sm'),
        h('strong', null, projectPath(pid)),
        h('span', { class: 'muted mono' }, `id ${pid}`),
        h('span', { class: 'spacer' }),
        h(
          'button',
          {
            class: 'btn sm danger',
            type: 'button',
            'data-fk': `${fk}-rm`,
            onclick: () =>
              setDraft((x) => {
                x.project_pipeline_overrides.splice(oi, 1);
              }),
          },
          icon('trash', 'sm'),
          'Remove override',
        ),
      ),
      RULE_FIELDS.map((f) => {
        const on = o[f] != null;
        return h(
          'div',
          { class: `ov-field${on ? ' on' : ''}` },
          h(
            'label',
            { class: 'check bare' },
            h('input', {
              type: 'checkbox',
              checked: on,
              'data-fk': `${fk}-on-${f}`,
              onchange: (e: Event) =>
                setDraft(() => {
                  const enable = checkedOf(e);
                  const g = cloneRules(d.pipeline);
                  switch (f) {
                    case 'stages':
                      o.stages = enable ? g.stages : null;
                      break;
                    case 'important_job_patterns':
                      o.important_job_patterns = enable ? g.important_job_patterns : null;
                      break;
                    case 'jobs':
                      o.jobs = enable ? g.jobs : null;
                      break;
                    case 'environments':
                      o.environments = enable ? g.environments : null;
                      break;
                  }
                }),
            }),
            h('span', null, h('strong', null, RULE_LABEL[f]), on ? ' · project value' : ' · uses the global value'),
          ),
          on ? overrideEditor(f, o, `${fk}-${f}`, envNames) : h('div', { class: 'ov-inherit' }, summary(f, d.pipeline)),
        );
      }),
    );
  });
  return sec(
    'Project overrides',
    'repo',
    h(
      'div',
      { class: 'lines' },
      h(
        'p',
        { class: 'hint' },
        'A project override replaces whole global rule lists for one configured project; unchecked rules inherit the global value. Deploy jobs in an override must name an environment configured for that project.',
      ),
      cards.length ? cards : h('p', { class: 'muted box pad' }, 'No project overrides. Every configured project uses the global rules.'),
      h(
        'div',
        { class: 'line' },
        h(
          'select',
          {
            class: 'select',
            'aria-label': 'Add an override for a project',
            'data-fk': 'ov-add',
            disabled: !free.length,
            onchange: (e: Event) => {
              const pid = Number(controlValue(e));
              if (pid > 0)
                setDraft((x) => {
                  x.project_pipeline_overrides.push({ project: pid, stages: null, important_job_patterns: null, jobs: null, environments: null });
                });
            },
          },
          h('option', { value: '' }, free.length ? 'Add override for project…' : 'Every configured project has an override'),
          free.map((p) => h('option', { value: String(p.id.value) }, p.path)),
        ),
      ),
      advancedEditor(d),
    ),
  );
}

// Advanced: the project_pipeline_overrides list as JSON. Each entry is
// checked by the generated ProjectPipelineOverride validator (which rejects
// unknown keys) before it replaces the form state; the form stays the
// source of truth and nothing is saved until "Save".
const overridesJson = (d: SettingsDraft): string => JSON.stringify(overridesOut(d), null, 2);

function advancedEditor(d: SettingsDraft): HTMLDetailsElement {
  const st = S.set;
  const adv = st.adv;
  return h(
    'details',
    {
      class: 'adv',
      open: !!adv,
      ontoggle: (e: Event) => {
        const t = e.target;
        if (!(t instanceof HTMLDetailsElement)) return;
        if (t.open && !st.adv) {
          st.adv = { text: overridesJson(d), error: null };
          render();
        }
        if (!t.open && st.adv) {
          st.adv = null;
          render();
        }
      },
    },
    h('summary', { class: 'btn sm ghost', 'data-fk': 'adv' }, icon('edit', 'sm'), 'Advanced: edit project overrides as JSON'),
    adv
      ? h(
          'div',
          { class: 'lines' },
          h(
            'textarea',
            {
              class: 'input mono adv-text',
              rows: '12',
              spellcheck: 'false',
              'data-fk': 'adv-text',
              'aria-label': 'Project overrides as JSON',
              oninput: (e: Event) => {
                adv.text = controlValue(e);
              },
            },
            adv.text,
          ),
          adv.error ? h('div', { class: 'inline-err', role: 'alert' }, icon('s_fail', 'sm'), h('div', null, adv.error)) : null,
          h(
            'div',
            { class: 'line' },
            h('button', { class: 'btn sm', type: 'button', 'data-fk': 'adv-apply', onclick: () => applyAdvanced() }, icon('check', 'sm'), 'Apply to form'),
            h(
              'button',
              {
                class: 'btn sm ghost',
                type: 'button',
                'data-fk': 'adv-reset',
                onclick: () => {
                  if (st.draft) st.adv = { text: overridesJson(st.draft), error: null };
                  render();
                },
              },
              'Reset from form',
            ),
          ),
          h(
            'p',
            { class: 'hint' },
            'An array of {project:{value}, stages, important_job_patterns, jobs, environments}; null inherits the global value. Unknown keys are rejected. Applying only changes the form; review it and choose Save.',
          ),
        )
      : null,
  );
}

function applyAdvanced(): void {
  const st = S.set;
  const adv = st.adv;
  if (!adv || !st.draft) return;
  let data: unknown;
  try {
    data = JSON.parse(adv.text);
  } catch (e) {
    adv.error = `Not valid JSON: ${errorMessage(e)}`;
    render();
    return;
  }
  if (!Array.isArray(data)) {
    adv.error = 'The top level must be an array.';
    render();
    return;
  }
  const problems: string[] = [];
  const accepted: OverrideDraft[] = [];
  data.forEach((entry: unknown, i: number) => {
    if (check.projectOverride(entry)) accepted.push(overrideDraft(entry));
    else problems.push(`Entry ${i + 1}: ${check.describe(check.projectOverride.errors)}.`);
  });
  if (problems.length) {
    adv.error = problems.join(' ');
    render();
    return;
  }
  st.draft.project_pipeline_overrides = accepted;
  adv.error = null;
  say('Project overrides applied to the form. They are not saved yet.');
  render();
}

/* ------------------------------------------------------------- screen */

export function settingsScreen(): HTMLElement {
  const st = S.set;
  const R = st.resp;
  const d = st.draft;
  const head = h(
    'div',
    { class: 'sh' },
    h(
      'div',
      { class: 'sh-title' },
      h('h1', null, 'Settings'),
      h(
        'span',
        { class: 'scope-chip', title: 'Settings are stored in the local operator file on the GSpace server' },
        icon('save', 'sm'),
        h('span', null, 'Local operator file'),
      ),
      R ? h('span', { class: 'count mono', title: `File revision ${R.revision}` }, `rev ${R.revision.slice(0, 8)}`) : null,
    ),
    h(
      'div',
      // Stays in the title row on narrow screens (see .set-tools).
      { class: 'toolbar set-tools' },
      h(
        'button',
        {
          class: 'btn',
          type: 'button',
          'data-fk': 'set-reload',
          'aria-label': 'Reload the operator file',
          disabled: st.loading || st.saving,
          title: settingsDirty() ? 'Reads the file again; your unsaved edits are kept' : 'Reads the file again',
          onclick: () => void loadSettings('auto'),
        },
        icon('refresh', st.loading ? 'spin' : ''),
        h('span', { class: 'lbl-wide' }, 'Reload'),
      ),
    ),
  );
  if (!R || !d) {
    return h(
      'div',
      { class: 'screen' },
      head,
      st.error
        ? emptyState({
            title: 'Settings unavailable',
            body: [st.error, 'Nothing can be edited until the current file revision is known.'],
            actions: h('button', { class: 'btn sm', type: 'button', onclick: () => void loadSettings('auto') }, icon('refresh', 'sm'), 'Reload'),
          })
        : emptyState({ title: 'Loading settings…', status: true }),
    );
  }
  const tzs = knownTimezones();
  const onEnvRename = (old: string, nu: string): void => {
    for (const j of d.pipeline.jobs) if (j.environment === old) j.environment = nu;
    for (const o of d.project_pipeline_overrides) if (o.environments == null) for (const j of o.jobs ?? []) if (j.environment === old) j.environment = nu;
  };
  const gEnvs = d.pipeline.environments.map((e) => e.name.trim()).filter(Boolean);

  // One scope statement instead of loose chips: what this page edits, what it
  // never touches, and where the other kinds of settings live.
  // Narrow screens show the first sentence and fold the rest into a
  // disclosure that opens by tap or keyboard (never hover only).
  const scopeRest =
    'Unrelated fields and comments in the file are preserved. Connection, credentials, project scope and paths are set by the operator, not here. Theme and reading are under Appearance (this browser only); filters, views and bookmarks are shared preferences.';
  const facts = h(
    'div',
    { class: 'set-scope' },
    icon('lock', 'sm'),
    h(
      'div',
      { class: 'lines' },
      h(
        'span',
        null,
        h('strong', null, 'Server operator rules'),
        ' in the shared local file, used by everyone on this GSpace server. Nothing is sent to GitLab.',
      ),
      mobileQuery.matches
        ? h(
            'details',
            {
              class: 'set-scope-more',
              open: sectionOpen('settings:scope', false),
              ontoggle: (e: Event) => {
                const t = e.target;
                if (t instanceof HTMLDetailsElement && t.open !== sectionOpen('settings:scope', false)) toggleSection('settings:scope', false);
              },
            },
            h('summary', { 'data-fk': 'set-scope-more' }, 'What else is and is not here'),
            h('span', null, scopeRest),
          )
        : h('span', null, scopeRest),
    ),
  );

  const conflict = st.conflict
    ? h(
        'div',
        { class: 'inline-err', role: 'alert' },
        icon('warning', 'sm'),
        h(
          'div',
          { class: 'lines' },
          h('strong', null, 'The operator file changed since your edits began. Nothing was saved.'),
          // The server's reason may lack a full stop; close it before our sentences.
          h('p', null, `${st.conflict.message.trim().replace(/([^.!?])$/, '$1.')} Your edits are kept here. Nothing is retried automatically.`),
          h(
            'div',
            { class: 'line' },
            h(
              'button',
              { class: 'btn sm primary', type: 'button', 'data-fk': 'set-reapply', onclick: () => void loadSettings('keep') },
              'Load latest and keep my edits',
            ),
            h(
              'button',
              { class: 'btn sm danger', type: 'button', 'data-fk': 'set-takelatest', onclick: () => void loadSettings('discard') },
              'Discard my edits and load latest',
            ),
          ),
          h(
            'p',
            { class: 'hint' },
            '"Keep my edits" loads the new revision, then your whole form replaces it when you save; it is not a per-field merge. Compare with "Rules in use" first.',
          ),
        ),
      )
    : null;

  const general = sec(
    'General',
    'settings',
    h(
      'div',
      { class: 'box pad' },
      h(
        'div',
        { class: 'form-grid' },
        h(
          'label',
          { class: 'field' },
          h('span', null, 'Timezone'),
          textIn(
            d.timezone,
            (val, settle) =>
              setDraft(() => {
                d.timezone = val;
              }, settle),
            { list: tzs.length ? 'tz-list' : null, maxlength: '64', placeholder: 'Europe/Zurich', 'data-fk': 'set-tz' },
          ),
          tzs.length
            ? h(
                'datalist',
                { id: 'tz-list' },
                tzs.map((z) => h('option', { value: z })),
              )
            : null,
          h('span', { class: 'hint' }, 'Local date for date-current milestones and displayed times.'),
        ),
        h(
          'label',
          { class: 'field' },
          h('span', null, 'Branch convention'),
          textIn(
            d.branch_template,
            (val, settle) =>
              setDraft(() => {
                d.branch_template = val;
              }, settle),
            { maxlength: '200', placeholder: 'issue-{iid}', 'data-fk': 'set-branch' },
            true,
          ),
          h(
            'span',
            { class: 'hint' },
            '{iid} is the issue IID; e.g. ',
            h('code', null, d.branch_template.replace('{iid}', '791') || '—'),
            '. A name match alone never proves a commit.',
          ),
        ),
        h(
          'fieldset',
          { class: 'field fs wide' },
          h('legend', null, 'Tag convention (next-tag suggestion in previews)'),
          h(
            'div',
            { class: 'line' },
            h(
              'label',
              { class: 'field' },
              h('span', null, 'Component from the right'),
              numIn(
                d.tag_convention.component_from_right,
                (n, settle) =>
                  setDraft(() => {
                    d.tag_convention.component_from_right = n;
                  }, settle),
                { min: '0', max: '10', 'data-fk': 'set-tc-comp' },
              ),
            ),
            h(
              'label',
              { class: 'field' },
              h('span', null, 'Increment'),
              numIn(
                d.tag_convention.increment,
                (n, settle) =>
                  setDraft(() => {
                    d.tag_convention.increment = n;
                  }, settle),
                { min: '1', 'data-fk': 'set-tc-inc' },
              ),
            ),
            h(
              'label',
              { class: 'check bare' },
              h('input', {
                type: 'checkbox',
                checked: d.tag_convention.preserve_padding,
                'data-fk': 'set-tc-pad',
                onchange: (e: Event) =>
                  setDraft(() => {
                    d.tag_convention.preserve_padding = checkedOf(e);
                  }),
              }),
              'Preserve zero padding',
            ),
          ),
          h('span', { class: 'hint' }, 'Which numeric tag component is incremented, counted from the right (0 = last). Tag previews are never executed.'),
        ),
      ),
    ),
  );

  // Rules in the order an operator changes them: what environments exist,
  // which jobs publish or deploy to them, which jobs are summarised, and the
  // expected stage order. Each starts with what it changes.
  const global = sec(
    'Global pipeline rules',
    'pipeline',
    h(
      'div',
      { class: 'lines' },
      EDIT_ORDER.map((f) =>
        h(
          'div',
          { class: 'box pad lines', id: `set-${f}` },
          h('h3', null, RULE_LABEL[f]),
          h('p', { class: 'hint' }, RULE_PURPOSE[f]),
          ruleEditor(f, d.pipeline, `g-${f}`, gEnvs, onEnvRename),
        ),
      ),
    ),
  );

  // The status region (saved notice, save bar, problems) is the only part
  // refreshed while typing; see setDraft(). It comes first, so what is in use,
  // unsaved, saving, conflicting or failing is clear before any field.
  const mob = mobileQuery.matches;
  return h(
    'div',
    { class: 'screen' },
    head,
    h('div', { id: 'set-status', class: 'set-status' }, settingsStatus()),
    conflict,
    facts,
    // Narrow screens: the rules in use come right after the status, folded.
    mob
      ? h(
          'details',
          {
            class: 'set-eff-m',
            open: sectionOpen('settings:effective', false),
            ontoggle: (e: Event) => {
              const t = e.target;
              if (t instanceof HTMLDetailsElement && t.open !== sectionOpen('settings:effective', false)) toggleSection('settings:effective', false);
            },
          },
          h('summary', { class: 'btn sm ghost', 'data-fk': 'set-eff' }, icon('views', 'sm'), 'Rules in use per project'),
          effectiveSection(),
        )
      : null,
    h(
      'div',
      { class: 'd-grid set-grid' },
      h('div', { class: 'd-main' }, global, general, overridesSection(d)),
      h(
        'div',
        { class: 'd-side' },
        mob ? null : effectiveSection(),
        sec(
          'About these settings',
          'info',
          h(
            'div',
            { class: 'box pad lines' },
            h('p', null, 'Saving writes the local operator file atomically and checks its revision. If someone else changed it, nothing is overwritten.'),
            h(
              'p',
              null,
              'Saved rules are operator expectations and apply locally at once: job roles, important jobs, stage order, dependencies and environments are recomputed from the saved file when the views reload.',
            ),
            h(
              'p',
              null,
              'Remote evidence (pipelines, jobs, publish, deployment records, runtime identity) stays as fetched in the current snapshot. Saving never contacts GitLab; only an explicit Refresh reads it again.',
            ),
            h('p', null, 'Important-job summaries never hide jobs: every pipeline keeps a link to all of its jobs and attempts.'),
            h(
              'p',
              { class: 'muted' },
              `Theme and the Overview/Detailed reading are in the top-bar Appearance menu and stay in this browser; keyboard help is on Sources. Rules in use follow the repository scope (${scopeLabel()}).`,
            ),
          ),
        ),
      ),
    ),
  );
}

// Saved notice, save bar and problem list, computed from the current draft.
function settingsStatus(): (HTMLElement | null)[] {
  const st = S.set;
  const d = st.draft;
  if (!d) return [];
  const dirty = settingsDirty();
  const { errs, warns } = validateSettings(d);
  const R = st.resp;
  const rev = R ? R.revision.slice(0, 8) : '?';
  // Exactly one state, in plain words. "In use locally" never implies that
  // remote evidence was refreshed.
  let state: HTMLElement;
  if (st.saving) state = tone('info', 's_pend', 'Saving…');
  else if (st.conflict) state = tone('warn', 'warning', 'File changed elsewhere — your edits are kept');
  else if (dirty) state = tone('warn', 'edit', `Unsaved changes in ${plural(changedSections(d, st.base), 'section')}`);
  else if (st.error && st.errorStatus === 400) state = tone('fail', 's_fail', 'Operator file invalid — the service keeps its last valid rules', st.error);
  else if (st.error) state = tone('fail', 's_fail', 'Could not re-read the operator file', st.error);
  else if (st.loading) state = tone('info', 's_pend', 'Reading the operator file…');
  else
    state = tone(
      'ok',
      's_ok',
      `In use locally · revision ${rev}`,
      'The running GSpace service applies this saved file locally. This says nothing about remote evidence, which changes only with an explicit Refresh.',
    );
  const saveBar = h(
    'div',
    { class: `savebar${dirty ? ' dirty' : ''}${st.error ? ' failed' : ''}`, role: 'region', 'aria-label': 'Settings status and save' },
    state,
    st.rebased
      ? h(
          'span',
          { class: 'chip st t-info', title: 'Your edits now target the latest file revision; review them before saving' },
          h('span', null, 'Edits reapplied on the latest revision'),
        )
      : null,
    errs.length ? h('span', { class: 'chip st t-fail' }, h('span', null, plural(errs.length, 'problem'))) : null,
    // With unsaved edits the state above names them; this says why Save is
    // off. The edits stay in the form; nothing is retried automatically.
    dirty && fileInvalid()
      ? h(
          'span',
          { class: 'chip st t-fail', title: 'The last read found the operator file invalid. Fix the file, then Reload; your edits are kept.' },
          h('span', null, 'Save unavailable: operator file invalid'),
        )
      : null,
    h('span', { class: 'spacer' }),
    h(
      'button',
      {
        class: 'btn',
        type: 'button',
        'data-fk': 'set-discard',
        disabled: !dirty || st.saving,
        onclick: () => {
          if (st.conflict) {
            void loadSettings('discard'); // the saved copy here is outdated
            return;
          }
          if (st.base) st.draft = cloneDraft(st.base);
          st.rebased = false;
          st.saveError = null;
          st.adv = null;
          render();
        },
      },
      'Discard changes',
    ),
    h(
      'button',
      {
        class: 'btn primary',
        type: 'button',
        'data-fk': 'set-save',
        disabled: !dirty || st.saving || !!st.conflict || errs.length > 0 || fileInvalid(),
        title: fileInvalid() ? 'Unavailable while the operator file is invalid; fix it, then Reload' : null,
        onclick: () => void saveSettings(),
      },
      icon('save', 'sm'),
      st.saving ? 'Saving…' : 'Save to operator file',
    ),
  );

  // Freshness, precisely: operator expectations are effective locally right
  // after the save; remote evidence is whatever the current snapshot fetched.
  const sv = st.saved;
  const fetched = fmtTime(S.dash?.fetched_at) ?? 'an unreported time';
  const loadErr =
    st.error && R
      ? h(
          'div',
          { class: 'inline-err', role: 'alert' },
          icon('s_fail', 'sm'),
          h(
            'div',
            { class: 'lines' },
            h('p', null, st.error),
            h(
              'p',
              { class: 'reason' },
              st.errorStatus === 400
                ? `Fix the file, then Reload. This form still shows revision ${rev}, the last one read here, with your edits; nothing is retried automatically.`
                : 'This form still shows the last revision read here, with your edits. Reload to try again; nothing is retried automatically.',
            ),
          ),
        )
      : null;
  const saved =
    sv && !dirty
      ? h(
          'div',
          { class: 'inline-err note', role: 'status' },
          icon(sv.refreshed ? 's_ok' : 'info', 'sm'),
          h(
            'div',
            { class: 'lines' },
            h(
              'p',
              null,
              h(
                'strong',
                null,
                st.error && st.errorStatus === 400
                  ? `Last valid revision ${sv.revision.slice(0, 8)} remains in use locally. `
                  : sv.origin === 'save'
                    ? `Saved; revision ${sv.revision.slice(0, 8)} is in use locally. `
                    : `The operator file changed elsewhere; revision ${sv.revision.slice(0, 8)} is in use locally. `,
              ),
              'No GitLab request was made.',
            ),
            h(
              'p',
              null,
              'Effective now: job roles, important jobs, stage order, expected dependencies and environments',
              sv.views === true
                ? '; the views were re-read from the local snapshot.'
                : sv.views === false
                  ? '; re-reading the views failed, see the problem list.'
                  : sv.views === 'pending'
                    ? '; re-reading the views…'
                    : '.',
            ),
            sv.refreshed
              ? h('p', null, `Remote evidence was refreshed after this revision (snapshot fetched ${fetched}).`)
              : h(
                  'p',
                  null,
                  `Unchanged until Refresh: pipelines, jobs, publish, deployment records and runtime identity, from the snapshot fetched ${fetched}${sv.refresh_required ? '. The server reports that a refresh is needed for them to reflect the new rules' : ''}. `,
                  h(
                    'button',
                    { class: 'btn sm', type: 'button', 'data-fk': 'set-refresh', disabled: S.sync.busy || !S.dash, onclick: () => void refreshSnapshot() },
                    icon('refresh', 'sm'),
                    'Refresh snapshot',
                  ),
                ),
          ),
        )
      : null;

  // Validation problems update with every keystroke, so they are not an
  // alert region (that would announce on each key); a failed save is.
  const problems =
    errs.length || warns.length || st.saveError
      ? h(
          'div',
          { class: 'lines' },
          st.saveError ? h('div', { class: 'inline-err', role: 'alert' }, icon('s_fail', 'sm'), h('div', null, st.saveError)) : null,
          errs.length
            ? h(
                'div',
                { class: 'inline-err err' },
                icon('s_fail', 'sm'),
                h(
                  'ul',
                  { class: 'bullets', 'aria-label': 'Problems that block saving' },
                  errs.map((x) => h('li', null, x)),
                ),
              )
            : null,
          warns.length
            ? h(
                'div',
                { class: 'inline-err' },
                icon('warning', 'sm'),
                h(
                  'ul',
                  { class: 'bullets', 'aria-label': 'Warnings' },
                  warns.map((x) => h('li', null, x)),
                ),
              )
            : null,
        )
      : null;

  return [saveBar, loadErr, saved, problems];
}
