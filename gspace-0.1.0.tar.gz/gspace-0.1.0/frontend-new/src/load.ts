// Loading: boot, repository-scope loads with abort + generation guards,
// catalogs, explicit refresh, item reloads, runtime reads and planning
// previews. Nothing here retries automatically.

import type { Dashboard, ItemView, MRCatalogResponse, WorkKey } from './api';
import { errorMessage, errorStatus, http, isStale } from './api';
import { fmtTime, plural } from './dom';
import { closeEv } from './evidence';
import { derive, envLabel, projectPath, scopeLabel } from './model';
import { render } from './render';
import { adoptSettings } from './settings';
import type { PreviewAction } from './state';
import { applyPrefs, reloadPrefs, report, resolve, S, say, scoped, wkStr } from './state';

export async function boot(): Promise<void> {
  const [projects, prefs, caps, profiles, settings] = await Promise.allSettled([
    http.projects(),
    http.preferences(),
    http.capabilities(),
    http.profiles(),
    http.settings(),
  ]);
  if (settings.status === 'fulfilled') adoptSettings(settings.value);
  else S.set.error = errorMessage(settings.reason);
  if (projects.status === 'fulfilled') {
    S.host = projects.value.host;
    S.projects = projects.value.projects;
    S.coverage = projects.value.coverage;
  } else {
    S.projectsError = errorMessage(projects.reason);
    report('projects', 'Repository list unavailable', `${S.projectsError} Only the all-configured-projects scope can be shown.`, {
      retry: () => void reloadProjects(),
    });
  }
  if (prefs.status === 'fulfilled') S.prefs = prefs.value;
  else
    report('prefs-load', 'Preferences unavailable', `${errorMessage(prefs.reason)} Saving views, bookmarks and flags is disabled until they load.`, {
      retry: () => void retryPrefs(),
    });
  if (caps.status === 'fulfilled') S.caps = caps.value;
  else S.capsError = errorMessage(caps.reason);
  if (profiles.status === 'fulfilled') S.profiles = profiles.value;
  else S.profilesError = errorMessage(profiles.reason);
  S.booting = false;
  document.getElementById('app')?.removeAttribute('aria-busy');
  S.scope.project = S.route.project;
  loadScope();
  void loadNavigation();
  loadPresentations();
}

// Shared navigation catalog (decorations, pins, order). A server without the
// route simply leaves bookmarks and views undecorated; the failure is shown
// where decorations are edited, not in the problem tray.
export async function loadNavigation(): Promise<void> {
  try {
    S.nav = await http.navigation();
    S.navError = null;
  } catch (e) {
    S.navError = errorMessage(e);
  }
  render();
}

// Safe project avatars: one presentation request per configured project,
// never a remote image URL. Missing routes or errors keep the packaged icon.
function loadPresentations(): void {
  for (const p of S.projects) {
    const id = p.id.value;
    if (S.presentations.has(id)) continue;
    S.presentations.set(id, { kind: 'loading' });
    http.presentation(id).then(
      (r) => {
        S.presentations.set(id, { kind: 'result', result: r });
        render();
      },
      (e: unknown) => {
        S.presentations.set(id, { kind: 'error', error: errorMessage(e), status: errorStatus(e) });
        render();
      },
    );
  }
}

// Native pipeline graph for one work item, read once per repository scope
// (and again after an explicit refresh). Read-only; never retried.
export async function loadGraph(p: string, i: string): Promise<void> {
  const k = `${p}/${i}`;
  const cur = S.graphs.get(k);
  if (cur && cur.kind !== 'error') return;
  S.graphs.set(k, { kind: 'loading' });
  render();
  try {
    S.graphs.set(k, { kind: 'result', result: await scoped((signal) => http.pipelineGraph(p, i, signal)) });
  } catch (e) {
    if (isStale(e)) return;
    S.graphs.set(k, { kind: 'error', error: errorMessage(e), status: errorStatus(e) });
  }
  render();
}

async function reloadProjects(): Promise<void> {
  try {
    const r = await http.projects();
    S.host = r.host;
    S.projects = r.projects;
    S.coverage = r.coverage;
    S.projectsError = null;
    resolve('projects');
    loadPresentations();
    derive();
    render();
  } catch (e) {
    report('projects', 'Repository list unavailable', `${errorMessage(e)} Only the all-configured-projects scope can be shown.`, {
      retry: () => void reloadProjects(),
    });
  }
}

async function retryPrefs(): Promise<void> {
  try {
    await reloadPrefs();
    derive();
    resolve('prefs-load');
    render();
  } catch (e) {
    report('prefs-load', 'Preferences unavailable', `${errorMessage(e)} Saving views, bookmarks and flags is disabled until they load.`, {
      retry: () => void retryPrefs(),
    });
  }
}

// Keeps only the selected project's items (never another project's data
// under this heading) and reports a host disagreement.
function sanitizeDash(d: Dashboard, p: number | null): Dashboard {
  if (!S.host) S.host = d.host;
  if (!S.projects.length) S.projects = d.projects;
  let out = d;
  if (p != null) {
    const kept = d.views.filter((v) => v.item.identity.project.value === p);
    const dropped = d.views.length - kept.length;
    if (dropped) {
      report(
        'scope-leak',
        'Out-of-scope items discarded',
        `${plural(dropped, 'work item')} from other projects arrived for ${projectPath(p)} and were not shown.`,
        { tone: 'warn' },
      );
      out = { ...d, views: kept };
    } else resolve('scope-leak');
  }
  if (S.host && d.host !== S.host) {
    report('host', 'Host mismatch', `The dashboard reports host ${d.host}, but the project list reports ${S.host}.`, { tone: 'warn' });
  }
  return out;
}

const fetchDash = (): Promise<Dashboard> => {
  const p = S.scope.project;
  return scoped((signal) => http.dashboard(p, signal)).then((d) => sanitizeDash(d, p));
};

function routeItem(): readonly [string, string] | null {
  const [p, i] = S.route.args;
  return S.route.screen === 'item' && p !== undefined && i !== undefined ? [p, i] : null;
}

// Repository switch: abort in-flight scoped requests, bump the generation so
// late responses are dropped, clear previous data and show loading.
export function loadScope(): void {
  S.gen++;
  S.ctrl?.abort();
  S.ctrl = new AbortController();
  S.dash = null;
  S.dashError = null;
  S.mrs = null;
  S.mrsError = null;
  S.ms = null;
  S.msError = null;
  S.items.clear();
  S.itemState.clear();
  S.previews.clear();
  S.observing.clear();
  S.atBusy.clear();
  S.atErr.clear();
  S.graphs.clear();
  S.sync.busy = false;
  closeEv(false);
  resolve('load', 'mrs', 'refresh', 'scope-leak', 'item', 'milestones', 'reload');
  const p = S.scope.project;
  if (p != null && S.projects.length && !S.projects.some((x) => x.id.value === p)) {
    S.scopeError = `Project ${p} is not one of the configured projects on ${S.host ?? 'this host'}.`;
    S.loading = false;
    S.mrsLoading = false;
    derive();
    render();
    return;
  }
  S.scopeError = null;
  S.loading = true;
  derive();
  render();
  const gen = S.gen;
  fetchDash()
    .then(
      async (d) => {
        S.dash = d;
        if (S.prefs && d.preference_revision > S.prefs.revision) await reloadPrefs().catch(() => undefined);
        S.dashError = null;
        resolve('load');
      },
      (e: unknown) => {
        if (isStale(e)) return;
        S.dashError = errorMessage(e);
        report('load', `Could not load ${scopeLabel()}`, S.dashError, { retry: loadScope });
      },
    )
    .finally(() => {
      if (gen !== S.gen) return;
      S.loading = false;
      applyPrefs();
      derive();
      render();
      const r = routeItem();
      if (r) void loadItem(r[0], r[1]);
    });
  void loadMrs(false);
  void loadMilestones();
}

// Milestone catalog for the selected repository scope. Counts are server
// facts: null means unknown, never zero.
export async function loadMilestones(): Promise<void> {
  const p = S.scope.project;
  const gen = S.gen;
  if (S.scopeError) return;
  S.msLoading = true;
  render();
  try {
    S.ms = await scoped((signal) => http.milestones(p, signal));
    S.msError = null;
    resolve('milestones');
  } catch (e) {
    if (isStale(e)) return;
    S.msError = errorMessage(e);
    report('milestones', 'Milestone catalog unavailable', `${S.msError} Milestone filters other than "all" cannot be evaluated.`, {
      retry: () => void loadMilestones(),
    });
  } finally {
    if (gen === S.gen) {
      S.msLoading = false;
      derive();
      render();
    }
  }
}

// After a preference write that changes item evidence (overrides, manual
// application tests), reload the item and dashboard. Nothing is retried.
export async function reloadItemData(id: WorkKey, what: string): Promise<void> {
  try {
    S.dash = await fetchDash();
    applyPrefs();
    derive();
    await loadItem(id.project.value, id.issue.value, true);
    resolve('reload');
  } catch (e) {
    if (!isStale(e)) report('reload', `${what} saved; data not reloaded`, errorMessage(e), { tone: 'warn', retry: () => void reloadItemData(id, what) });
  }
  render();
}

// Re-reads the local dashboard (and the open item) after an operator
// settings save, so ItemView.job_configuration recomputed from the saved
// rules is shown. A plain GET of the existing snapshot: it does not call
// /api/refresh, contact GitLab or change the remote evidence.
// Returns null when nothing was loaded, so nothing needed re-reading.
export async function reloadLocalViews(): Promise<boolean | null> {
  if (!S.dash || S.scopeError) return null;
  const gen = S.gen;
  try {
    S.dash = await fetchDash();
    // Work/Compare date-current filters consume this local catalog, too.
    // Do not keep evaluating the previous timezone/date after a settings save.
    S.ms = null;
    await loadMilestones();
    if (gen !== S.gen) return null;
    S.items.clear();
    S.itemState.clear();
    applyPrefs();
    derive();
    resolve('settings-views');
    const r = routeItem();
    if (r) void loadItem(r[0], r[1]);
    return S.msError === null;
  } catch (e) {
    if (!isStale(e))
      report('settings-views', 'Settings saved; views not reloaded', `${errorMessage(e)} The views still show the rules from before the save.`, {
        tone: 'warn',
        retry: () => void reloadLocalViews(),
      });
    return false;
  } finally {
    render();
  }
}

export async function loadMrs(refresh: boolean): Promise<void> {
  const p = S.scope.project;
  const gen = S.gen;
  S.mrsLoading = true;
  render();
  try {
    if (refresh) await scoped((signal) => http.refreshMergeRequests(signal));
    const c: MRCatalogResponse = await scoped((signal) => http.mergeRequests(p, signal));
    S.mrs = p != null ? { ...c, rows: c.rows.filter((r) => r.mr.project.value === p) } : c;
    S.mrsError = null;
    resolve('mrs');
    if (refresh) say(`Merge request catalog refreshed: ${plural(S.mrs.rows.length, 'row')}.`);
  } catch (e) {
    if (isStale(e)) return;
    // A failed refresh keeps the previous catalog, visibly marked as stale.
    S.mrsError = errorMessage(e);
    report('mrs', refresh ? 'Catalog refresh failed' : 'Authored MR catalog unavailable', S.mrsError, { retry: () => void loadMrs(refresh) });
  } finally {
    if (gen === S.gen) {
      S.mrsLoading = false;
      derive();
      render();
    }
  }
}

// Explicit remote refresh (the only path that re-reads GitLab).
export async function refreshSnapshot(): Promise<void> {
  if (S.sync.busy || S.booting || S.loading || S.scopeError) return;
  S.sync.busy = true;
  render();
  try {
    await scoped((signal) => http.refresh(signal));
    const d = await fetchDash();
    S.dash = d;
    S.dashError = null;
    S.graphs.clear(); // the native graph is read again after an explicit refresh
    S.items.clear();
    S.itemState.clear();
    if (S.prefs && d.preference_revision !== S.prefs.revision) await reloadPrefs();
    applyPrefs();
    derive();
    S.sync.okAt = Date.now();
    resolve('refresh', 'load');
    say(`Snapshot refreshed. Data fetched ${fmtTime(d.fetched_at) ?? 'at an unreported time'}.`);
    if (S.set.saved && !S.set.saved.refreshed) S.set.saved = { ...S.set.saved, refreshed: true };
    const r = routeItem();
    if (r) void loadItem(r[0], r[1]);
    void loadMilestones();
  } catch (e) {
    if (isStale(e)) return;
    const reason = errorMessage(e).trimEnd();
    report('refresh', 'Refresh failed', `${reason}${/[.!?]$/.test(reason) ? '' : '.'} The previous snapshot is still shown.`, {
      retry: () => void refreshSnapshot(),
    });
  } finally {
    S.sync.busy = false;
    render();
  }
}

export async function loadItem(p: number | string, i: number | string, rethrow = false): Promise<void> {
  const k = `${p}/${i}`;
  if (S.itemState.get(k)?.kind === 'loading') return;
  if (S.scope.project != null && Number(p) !== S.scope.project) return;
  S.itemState.set(k, { kind: 'loading' });
  render();
  try {
    const v = await scoped((signal) => http.item(p, i, signal));
    S.items.set(k, v);
    S.itemState.set(k, { kind: 'ok' });
    applyPrefs();
    derive();
  } catch (e) {
    if (isStale(e)) return;
    S.itemState.set(k, { kind: 'error', error: errorMessage(e), status: errorStatus(e) });
    if (rethrow) throw e;
  }
  render();
}

function replaceView(v: ItemView): void {
  const k = wkStr(v.item.identity);
  S.items.set(k, v);
  if (S.dash) S.dash = { ...S.dash, views: S.dash.views.map((x) => (wkStr(x.item.identity) === k ? v : x)) };
  applyPrefs();
  derive();
}

export async function observe(v: ItemView, env: string): Promise<void> {
  const id = v.item.identity;
  const tag = `${wkStr(id)}:${env}`;
  S.observing.add(tag);
  render();
  try {
    replaceView(await scoped((signal) => http.observe(id.project.value, id.issue.value, env, signal)));
    resolve(`observe:${tag}`);
    say(`${envLabel(env)} runtime read for #${id.issue.value}.`);
  } catch (e) {
    if (isStale(e)) return;
    report(`observe:${tag}`, `Could not read ${envLabel(env)} runtime for #${id.issue.value}`, errorMessage(e));
  } finally {
    S.observing.delete(tag);
    render();
  }
}

export async function preview(v: ItemView, action: PreviewAction): Promise<void> {
  const id = v.item.identity;
  const k = wkStr(id);
  const prev = (S.prevTag.get(k) ?? '').trim();
  const body = action === 'tag' && prev ? { action, previous_tag: prev } : { action };
  S.previews.set(k, { action, kind: 'loading' });
  render();
  try {
    S.previews.set(k, { action, kind: 'result', result: await scoped((signal) => http.itemPreview(id.project.value, id.issue.value, body, signal)) });
  } catch (e) {
    if (isStale(e)) return;
    S.previews.set(k, { action, kind: 'error', error: errorMessage(e) });
  }
  render();
}
