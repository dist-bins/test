// Native pipeline graph (GET /api/items/{project}/{issue}/pipeline-graph).
// Read-only. Nodes are scoped (project + pipeline ID); edges carry the native
// trigger evidence (source job or an explicit unknown). A trigger edge does
// not prove which application version a downstream pipeline deployed: the
// root's application SHA and a downstream config/deploy SHA stay separate.
// Deployments are linked only through the pipeline identity GitLab reports.

import type { PipelineEdge, PipelineGraph, PipelineKey, PipelineNode, ReadCoverage, Status } from './api';
import type { Kid } from './dom';
import { extLink, fmtTime, h, icon, none, plural, STATUS, sha, tone } from './dom';
import { envLabel, projectPath } from './model';
import { pipeHref, S, to } from './state';
import { sec } from './ui';

const keyStr = (k: PipelineKey): string => `${k.project.value}:${k.pipeline.value}`;
const keyLabel = (k: PipelineKey): string => `${projectPath(k.project.value)} #${k.pipeline.value}`;

function coverageText(c: ReadCoverage, what: string): Kid {
  return c.kind === 'complete' ? null : tone('unknown', 's_unknown', `${what} not fully read`, c.reason);
}

// Layers by distance from the roots along upstream → downstream edges.
// Nodes no edge reaches from a root are listed last, as unlinked.
function layers(g: PipelineGraph): { readonly linked: PipelineNode[][]; readonly unlinked: PipelineNode[] } {
  const byKey = new Map(g.nodes.map((n) => [keyStr(n.reference.key), n] as const));
  const depth = new Map<string, number>();
  const queue: string[] = [];
  for (const r of g.roots) {
    const k = keyStr(r.key);
    if (!depth.has(k)) {
      depth.set(k, 0);
      queue.push(k);
    }
  }
  while (queue.length) {
    const k = queue.shift();
    if (k === undefined) break;
    const d = depth.get(k) ?? 0;
    for (const e of g.edges) {
      if (keyStr(e.upstream) !== k) continue;
      const nk = keyStr(e.downstream);
      if (!depth.has(nk)) {
        depth.set(nk, d + 1);
        queue.push(nk);
      }
    }
  }
  const out: PipelineNode[][] = [];
  const unlinked: PipelineNode[] = [];
  for (const [k, n] of byKey) {
    const d = depth.get(k);
    if (d === undefined) {
      unlinked.push(n);
      continue;
    }
    while (out.length <= d) out.push([]);
    out[d]?.push(n);
  }
  return { linked: out, unlinked };
}

// Each native edge is written at both of its own nodes: "Triggers <downstream>"
// on the upstream node and "Triggered by <upstream>" on the downstream node,
// so no layout arrow has to suggest which root triggered what.
function edgeLine(e: PipelineEdge, dir: 'in' | 'out'): HTMLElement {
  const sj = e.source_job;
  return h(
    'div',
    { class: `pg-edge pg-${dir}` },
    h(
      'span',
      { class: 'pg-e-h' },
      icon(dir === 'out' ? 'next' : 'link', 'xs'),
      dir === 'out' ? 'Triggers ' : 'Triggered by ',
      h('span', { class: 'mono' }, keyLabel(dir === 'out' ? e.downstream : e.upstream)),
    ),
    sj.kind === 'source_job'
      ? h(
          'span',
          { class: 'muted' },
          ` via ${sj.job_kind === 'bridge' ? 'bridge' : sj.job_kind === 'build' ? 'build' : 'unknown-kind'} job #${sj.id.value}${sj.retried ? ' (retried attempt)' : ''}`,
        )
      : tone('unknown', 's_unknown', 'source job unknown', sj.reason),
    e.origin === 'fixture' ? h('span', { class: 'chip' }, 'fixture') : null,
  );
}

function nodeCard(g: PipelineGraph, n: PipelineNode): HTMLElement {
  const ref = n.reference;
  const k = ref.key;
  const root = g.roots.find((r) => keyStr(r.key) === keyStr(k)) ?? null;
  const incoming = g.edges.filter((e) => keyStr(e.downstream) === keyStr(k));
  const outgoing = g.edges.filter((e) => keyStr(e.upstream) === keyStr(k));
  const edges: Kid[] = [...incoming.map((e) => edgeLine(e, 'in')), ...outgoing.map((e) => edgeLine(e, 'out'))];
  const local = S.d?.pipes.get(`${k.project.value}/${k.pipeline.value}`);
  const idLink = local
    ? h('a', { class: 'mono strong', href: to(pipeHref(k.project.value, k.pipeline.value)) }, `#${k.pipeline.value}`)
    : h('span', { class: 'mono strong' }, `#${k.pipeline.value}`);
  const [t, ico, label] = STATUS[ref.status];
  const head = h(
    'div',
    { class: 'gn-h' },
    h('span', { class: 'gn-proj', title: `Project ${k.project.value}` }, ref.project_path),
    h(
      'div',
      { class: 'line' },
      idLink,
      tone(t, ico, label),
      ref.iid ? h('span', { class: 'muted' }, `iid ${ref.iid.value}`) : null,
      extLink(ref.link, 'GitLab'),
    ),
  );
  const shaLine = root
    ? h('div', { class: 'gn-sha' }, h('span', { class: 'muted' }, 'Application SHA '), sha(root.application_sha))
    : h(
        'div',
        { class: 'gn-sha', title: 'The SHA this pipeline ran on; it does not establish the upstream application version' },
        h('span', { class: 'muted' }, 'Config/deploy SHA '),
        sha(ref.sha ?? null, 'not reported'),
      );
  if (n.kind === 'unavailable') {
    return h(
      'article',
      { class: 'gnode unavailable', 'aria-label': `Pipeline ${keyLabel(k)} (unavailable)` },
      head,
      shaLine,
      edges,
      h('div', { class: 'reason' }, 'Not readable: ', n.reason),
    );
  }
  const jobs = n.pipeline.jobs;
  const counts = new Map<Status, number>();
  for (const j of jobs) counts.set(j.status, (counts.get(j.status) ?? 0) + 1);
  return h(
    'article',
    { class: `gnode${root ? ' root' : ''}`, 'aria-label': `Pipeline ${keyLabel(k)}` },
    head,
    shaLine,
    edges,
    h(
      'div',
      { class: 'gn-row' },
      h('span', { class: 'muted' }, 'Jobs'),
      n.jobs_coverage.kind === 'complete'
        ? jobs.length
          ? h(
              'span',
              { class: 'chips' },
              [...counts].map(([s, c]) => {
                const [ct, ci, cl] = STATUS[s];
                return tone(ct, ci, `${c} ${cl.toLowerCase()}`);
              }),
            )
          : none('none reported')
        : coverageText(n.jobs_coverage, 'Jobs'),
    ),
    h(
      'div',
      { class: 'gn-row' },
      h('span', { class: 'muted' }, 'Deployments'),
      n.deployments_coverage.kind !== 'complete'
        ? coverageText(n.deployments_coverage, 'Deployments')
        : n.deployments.length
          ? h(
              'span',
              { class: 'chips' },
              n.deployments.map((d) => {
                const [dt, di, dl] = STATUS[d.record.status];
                return tone(
                  dt,
                  di,
                  `${envLabel(d.environment)} ${dl.toLowerCase()} #${d.record.id}`,
                  `Linked by the reported pipeline ${keyLabel(d.pipeline)}`,
                );
              }),
            )
          : none('none reported for this pipeline'),
    ),
  );
}

export function graphSection(p: string, i: string): HTMLElement {
  const st = S.graphs.get(`${p}/${i}`) ?? null;
  let body: Kid;
  if (!st || st.kind === 'loading') body = h('p', { class: 'muted', role: 'status' }, 'Reading the native pipeline graph…');
  else if (st.kind === 'error') {
    body = h(
      'div',
      { class: 'inline-err' },
      icon('warning', 'sm'),
      h(
        'div',
        null,
        h('strong', null, 'Pipeline graph unavailable. '),
        st.error,
        h('div', { class: 'reason' }, 'The process above does not depend on it; nothing is inferred instead.'),
      ),
    );
  } else {
    const g = st.result;
    const ls = layers(g);
    body = h(
      'div',
      { class: 'lines' },
      h(
        'div',
        { class: 'filterbar' },
        h(
          'span',
          { class: `pill${g.source === 'fixture' ? ' st t-warn' : ''}` },
          icon('source', 'sm'),
          g.source === 'fixture' ? 'Synthetic fixture graph' : 'Native GitLab graph',
        ),
        h('span', { class: 'pill' }, 'Read ', fmtTime(g.fetched_at) ?? 'time unknown'),
        g.release
          ? h('span', { class: 'pill', title: g.release.raw }, `GitLab ${g.release.release}${g.release.edition !== 'unknown' ? ` ${g.release.edition}` : ''}`)
          : null,
        g.coverage.kind === 'complete'
          ? h('span', { class: 'pill' }, `${plural(g.nodes.length, 'pipeline')} · ${plural(g.edges.length, 'trigger')}`)
          : coverageText(g.coverage, 'Graph'),
      ),
      h(
        'p',
        { class: 'hint' },
        'A trigger edge does not prove which application version a downstream pipeline deployed; the application SHA and a downstream config/deploy SHA are separate facts.',
      ),
      g.nodes.length
        ? h(
            'div',
            { class: 'pgraph', role: 'list', 'aria-label': 'Pipelines by trigger depth, upstream first' },
            // Every layer is named; on narrow screens the layers stack vertically.
            ls.linked.map((layer, li) => {
              const name = li === 0 ? 'Root pipelines' : `Triggered · depth ${li}`;
              return h(
                'div',
                { class: 'glayer', role: 'listitem', 'aria-label': name },
                h('div', { class: 'gl-h' }, name),
                layer.map((n) => nodeCard(g, n)),
              );
            }),
            ls.unlinked.length
              ? h(
                  'div',
                  { class: 'glayer', role: 'listitem', 'aria-label': 'Not reached from a root by a trigger edge' },
                  h('div', { class: 'gl-h' }, 'Not reached from a root'),
                  ls.unlinked.map((n) => nodeCard(g, n)),
                )
              : null,
          )
        : none('The graph has no pipelines.'),
      g.unknown_relations.length
        ? h(
            'ul',
            { class: 'list box' },
            g.unknown_relations.map((u) =>
              h(
                'li',
                null,
                tone('unknown', 's_unknown', `${u.direction} relation unknown`),
                h('span', { class: 'mono' }, keyLabel(u.pipeline)),
                h('span', { class: 'reason' }, u.reason),
              ),
            ),
          )
        : null,
      g.warnings.length
        ? h(
            'div',
            { class: 'inline-err' },
            icon('warning', 'sm'),
            h(
              'div',
              null,
              g.warnings.map((w) => h('p', null, w)),
            ),
          )
        : null,
    );
  }
  return sec('Pipeline graph', 'pipeline', body);
}
