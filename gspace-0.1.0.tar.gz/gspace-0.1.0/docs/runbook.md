# GSpace runbook

## Local operation

Use Python 3.12 and the locked dependencies. Launch `uv run --no-sync gspace serve --config gspace.example.toml`; default URL is `http://127.0.0.1:8876`. `--port` accepts 1024–65535. Serve has no public bind option. HTTP access logging is disabled. UI assets are local; no CDN is required. The typed OpenAPI schema is available at `/openapi.json`.

CLI and web share the same configuration file. Relative preference/cache paths resolve against that file's directory. Without a configuration file they resolve against the current working directory. Use an explicit shared configuration when invoking renderers from different directories.

### CLI navigation and presentation

`uv run gspace` opens concise help and exits successfully without loading configuration or services. Daily commands are `dashboard`, `list`, `show PROJECT:IID` and `compare`. Use `gspace pipelines --help` for a resource group, `gspace pipelines list --help` for options, and `gspace help compatibility` for the unchanged older aliases.

```sh
uv run gspace list --config gspace.cli-demo.toml
uv run gspace dashboard --config gspace.cli-demo.toml --orientation columns
uv run gspace pipelines show 42:791 --config gspace.cli-demo.toml
uv run gspace settings show --config gspace.cli-demo.toml
```

Human `list` is a compact scan; `dashboard` and `compare` show complete process evidence in rows or adjacent work-item columns. They share filtering and preferences. At narrower widths the process columns paginate or fields wrap instead of dropping scoped identities. An observed pipeline failure, runtime mismatch and verified rebase need remain separate attention facts. Unknown evidence is not a pass.

`preferences filters` (legacy `filters`) changes the shared local filters and prints only their resulting state. `settings show` renders effective rules and their global/project sources; configured dependencies remain operator expectations. For exact metadata and automation, explicitly use `--json`: stdout contains only JSON, errors are JSON on stderr and exit2. Legacy JSON shapes are preserved. Human projects/profiles/views/bookmarks use labelled reports; callers needing their machine payload must also request `--json`.

`--no-color` and `NO_COLOR` suppress colors. Piped output and a dumb terminal are plain; `--color` never forces a TTY. Status words and textual cues remain meaningful without color. Use `--width 80`,120or160 for explicit layout width. The supplied CLI demo configuration has a separate local preference/cache path; use the same operator config as the web UI when shared state is desired.

## Install the delivered wheel

For the source development environment, use `uv sync --locked --python python3.12`. To install the wheel into a separate environment with network access to the Python package index:

```sh
python3.12 -m venv /tmp/gspace-runtime
uv pip install --python /tmp/gspace-runtime/bin/python /Users/else/Mega/8-Progetti/gspace/dist/gspace-0.1.0-py3-none-any.whl
cd /tmp
/tmp/gspace-runtime/bin/gspace dashboard --config /Users/else/Mega/8-Progetti/gspace/gspace.example.toml --no-color
/tmp/gspace-runtime/bin/gspace serve --config /Users/else/Mega/8-Progetti/gspace/gspace.example.toml
```

For reproducible offline verification of the exact lockfile, run `uv run --no-sync python scripts/package_check.py` from the source workspace after dependency synchronization. It creates and removes its own temporary environment and reports results in `docs/verification/package-report.json`. The installed package does not need the source workspace for code or static assets; copy an operator-owned configuration elsewhere to make its preference/cache paths independent as well.

## Shared preferences

Saved views carry host, configured project scope, typed filters, sort, selected
columns and row/column orientation. Bookmarks carry host and a discriminated
project-scoped resource reference, never an arbitrary URL. Views for authored MRs
retain that authored scope. Unavailable bookmarked resources remain explicit.
Preferences bind to an instance origin to prevent accidental cross-host reuse.
The separately fingerprinted MR cache includes the read identity and profile
descriptor; it never grants permission to write.

The preference TOML stores schema/revision, filters, pin/hide, selected rows, groups, manual checklists and association overrides. It contains no remote snapshot or observation. Readers see complete files; writers hold a POSIX lock, validate, write a mode-0600 temporary file, fsync, atomically replace and fsync the directory. A stale revision returns HTTP 409 or CLI exit 2. Reload, inspect the new state and reapply deliberately; there is no automatic retry.

```sh
uv run --no-sync gspace group --config gspace.example.toml 42:791 Release
uv run --no-sync gspace filters --config gspace.example.toml --group Release
uv run --no-sync gspace hide --config gspace.example.toml 42:791
uv run --no-sync gspace list --config gspace.example.toml --all
uv run --no-sync gspace hide --config gspace.example.toml 42:791 --off
uv run --no-sync gspace checklist --config gspace.example.toml 42:791 local_test
uv run --no-sync gspace override --config gspace.example.toml 42:791 branch passenger-followup --reason "Confirmed related branch"
```

Overrides support branch names, MR IIDs and tag names. They are local association evidence, require a reason, and take effect on an explicit live snapshot refresh. Fixture associations remain supplied by the fixture. Saved overrides are visible in preferences and the web association view.

## Future operator setup on DevPod

For a path-based DevPod browser proxy, configure `[web] public_url` with the full
external base URL (including `/proxy/PORT/`) and restart `gspace web --config
operator.toml --port PORT`. This adds one explicit public host/origin/prefix while
keeping the listener on loopback. It is separate from `[live]`, the GitLab scope.
See [the proxy configuration example](devpod.md#devpod-browser-proxy).

No real URLs or access credentials are needed for the delivered demo. Copy the example TOML to an operator-owned file, fill the live hostname, HTTPS web origin and project IDs/paths, and set `mode = "live"` only when the operator is ready to make GET requests with glab's already configured access. GSpace does not create PATs, start OAuth, log in, read token files or configure glab authentication. glab owns its existing access. Do not place secrets in GSpace configuration, URLs or override reasons.

Check the executable before installing it on the operator's host:

```sh
command -v glab || brew install glab
```

On DevPod, use its existing operator-managed glab installation and access. This command installs an executable only; authentication setup remains outside GSpace.

The installed CLI used during development is glab 1.120.0. The source reference is separately pinned in compatibility notes. Only GitLab **18.11.12** is accepted by the live version gate; any other version requires an explicit compatibility review and implementation change. The first live read without a cache fetches a snapshot. Subsequent startup uses the clearly labelled cache; use `gspace refresh --config operator.toml` or **Refresh snapshot** to fetch again. GET failures leave existing state intact and return a visible error. There is no retry loop or background polling.

API pages, process runtime/output and returned pipeline histories are bounded. Exceeding the page budget fails the snapshot rather than silently hiding issues. Returned pipeline histories are capped per ref; attempt numbers only describe available returned jobs. Deleted job history cannot be reconstructed. GitLab job names in `nexus_job_names` identify publish evidence; a successful job does not independently verify the artifact exists in Nexus. Real Nexus access is intentionally unavailable.

The cache is a separate atomic JSON envelope bound to a fingerprint of live scope, branch convention and environment configuration. A changed configuration rejects the old cache until an explicit refresh. Cached data may be old; snapshot and observation timestamps remain visible. Use one web server per configuration. Cache replacement is atomic and last-writer-wins; remote cache is disposable. Shared preference updates are protected across processes.

## Environment version observation

Configure one endpoint per project/issue/environment in TOML. Each requires its own exact allowed origins; internal, loopback, private or link-local addresses require explicit CIDRs. HTTPS verifies system trust and the original hostname. If an internal CA is needed, the operator must install it into system trust. There is no insecure TLS switch. HTTP is allowed only when explicitly enabled and its resolved addresses fall in explicitly permitted networks.

The resolver checks all returned addresses and pins one approved address to the connection. Redirects are capped and every destination is revalidated. Credentials, query strings, fragments and non-HTTP URLs are rejected. DNS, connection, headers and body have bounded deadlines; timed-out DNS workers never open a connection. Response size is bounded and compressed responses are rejected. The API accepts only a named configured environment, never an arbitrary URL.

Choose JSON extraction paths such as `info.version`, `info.x-build.branch`, `info.x-build.sha`. Paths traverse objects only; absent/non-string values produce an extraction error. HTML accepts one simple tag, `#id` or `.class` selector selecting exactly one node. Its pattern is literal text with exactly one `{value}` placeholder and a restricted 1–200 character capture; arbitrary regex and complex selectors are unavailable.

```sh
uv run --no-sync gspace observe --config operator.toml 42:791 dev --json
uv run --no-sync gspace observe --config operator.toml 42:791 preprod --json
```

`expected` in endpoint configuration can explicitly select a known branch/tag/version/SHA. Without it the live adapter derives an expectation only when the associated branch or tag is unambiguous. Multiple candidate branches/tags leave the expected version unknown. Observations record source, aware timestamp and either a bounded version value or a safe error. Known differences yield mismatch even if another expected field is unavailable. Missing fields yield unknown. Branch-only equality is unknown. Even a matching advertised version is evidence from the application endpoint, not an application test or cryptographic attestation.

## Recovery and limits

Malformed preferences/config/cache fail visibly; they are never silently reset. Back up preferences before a manual repair. To discard remote state, remove only the configured cache after confirming its path, then perform an explicit refresh. To reset the synthetic demo, stop the server and move the preference TOML aside; no remote state exists to reset.

The default and ordinary live adapter have no remote writes, background monitoring,
Nexus credential handling, automatic retries, corporate validation or deployment
orchestration. The separate finite action service is exclusively for the isolated
synthetic lab, disabled by default and not yet verified against a running server.
See [access and action limits](architecture/access-and-actions.md). Ready, merge
and rebase writes remain deferred. Fork MRs require an explicit MR override:
convention matching never associates a fork with a local branch just because the
names agree. Tag SHA equality is labelled candidate association and cannot
establish historical branch origin. Links are checked against configured
origin/project and pinned route shapes; they have not been HTTP-verified against
a live instance. Fixture links intentionally use `example.invalid`.

macOS/Linux POSIX locking is supported; Windows requires a lock implementation before use. Local API protections cover allowed hosts, same-origin JSON writes and restrictive content policy, but this is not a public multi-user service. Keep it on loopback. Model/API/effect tests use synthetic data, subprocesses and mock responses. No entrypoint from the reference clone was executed. The exact local CE server was pulled/started after resource guards passed; actual credential-free version/health/isolation/login browser checks pass. Authenticated seed, runner, pipelines and scenarios remain unexecuted pending the approved manual bootstrap. See [resumption evidence](verification/resumption-20261006.md).

## Access profiles and development preview

An operator may explicitly choose a controlled glab executable/launcher or a PAT
profile referring only to a named environment variable. GSpace never creates or
persists that PAT, reads an auth file, evaluates shell aliases or discovers
credentials automatically. `profiles` is redacted; `doctor PROFILE` is an
explicit read-only diagnostic. Current profile/permission/action details and
confirmation expiry are documented in
[access and actions](architecture/access-and-actions.md).

Use [the Poe guide](development.md) for setup, check, build, schema export and
lab operations. Default/help/check never start a service, pull images, create
credentials or clean disk. The integrated Claude renderer is served by the normal fixture server on
`http://127.0.0.1:8876`. The independent preview at `http://127.0.0.1:8877`
uses `.state/preview-new`. Both lightweight processes survive the current tool
turn but are not configured for automatic reboot recovery. Restart the fixture
server with the documented serve command after a machine reboot.

The stable served frontend checkpoint is `ba7ee8c`; the previous integrated assets
are preserved in `output/recovery/frontend-before-ba7ee8c` and original assets are preserved
in `output/recovery/frontend-before-054d1d1`. Browser acceptance and offline wheel
installation are documented in [integrated evidence](verification/integrated-20261006.md).

Repository selection changes UI scope and URLs. Shared saved views are host
bound; empty project scope means all configured projects, one ID means one
repository and multiple IDs mean an explicit subset. The browser selector offers
one/all; use the typed CLI/API to create an arbitrary subset. Opening a bookmark
from another repository switches the repository scope; absent resources remain
marked unavailable instead of being silently discarded. Preferences use the
same locked revisioned TOML in CLI and web. Theme choice is browser local.

Milestones are absent from the domain model, GET adapter and public UI/API; no
milestone totals or current milestone claims can be made. An eventual active
milestone state must be distinguished from a date-current milestone, including
missing dates and overlapping periods. Counts must state configured scope,
filters and pagination coverage rather than imply whole-instance totals.

After the Mac reboot the owned CE container is stopped. The existing exact image
and volumes are retained, but available free space is below the unchanged 60 GiB
start guard. See [restart budget evidence](verification/lab-restart-budget-20261006.md).
Approved private bootstrap and runner/scenario tests remain pending independently.
No authenticated GitLab effect test has run.

MR source correction and demo identity: the current fixture catalog has explicit
synthetic MR source commits, independent from branch heads. A missing real/legacy
MR source SHA remains unknown and prevents edits requiring expected SHA. Open
Evidence controls for raw provenance; the relationship legend starts collapsed.
The Demo label does not imply that real seed, runner or CI scenarios ran. See
[exact cause and private bootstrap steps](verification/mr-source-followup-20261006.md).


## Milestones, operator pipeline settings and manual application results

Milestones have project/group owner identity and separate ID/IID. The shared filter has
all, active, date-current, explicit selected and unassigned modes. Active is remote state;
date-current requires both dates in the configured timezone. Overlapping current milestones
remain candidates; no automatic single choice. Catalog totals cover all snapshot issues in
selected configured projects, while visible counts describe the filtered subset. Unknown
coverage gives null totals, not zero.

```sh
uv run --no-sync gspace milestones --config gspace.example.toml --json
uv run --no-sync gspace filters --config gspace.example.toml --milestone date_current
uv run --no-sync gspace filters --config gspace.example.toml --milestone-key group:9:702
uv run --no-sync gspace settings --config gspace.example.toml --json
uv run --no-sync gspace settings-set --config gspace.example.toml change.json --json
uv run --no-sync gspace app-test --config gspace.example.toml manual-result.json --json
```

A settings change JSON contains the GET settings revision and settings DTO. Settings is
ordinary composed Pydantic: stages/order/dependencies, important patterns, job roles,
custom environment definitions and project overrides. Dependencies are explicitly operator
expectations, never an observed GitLab DAG. Project fields replace global fields; the
response discloses their effective source. Settings writes the active shared operator TOML
atomically with a content revision and lock; unrelated comments/config survive. A conflict
requires explicit reload/reapply. No remote fetch or retry is automatic. Config/auth/URLs
and profile scope cannot be edited through the WebUI settings DTO. Configured probe endpoints
remain operator-owned TOML only. Legacy explicitly set live.nexus_job_names is disclosed as
an override; omit it to use the new publish rules.

A manual result JSON is an ApplicationTestRecord, for example:

```json
{
  "key": {"project": {"value": 42}, "issue": {"value": 791}},
  "environment": "dev",
  "version": {"sha": "054396c657447522ad2cc1f0b260bc34ebea0d6c"},
  "outcome": "passed",
  "checked_at": "2026-10-06T09:00:00+00:00",
  "source": "operator",
  "notes": "Manual synthetic application check"
}
```

Use passed, failed or not_tested, configured environment names and an aware timestamp.
Branch/tag alone cannot identify a tested immutable version. A new target SHA has no
inherited pass; history remains visible. A version-only record cannot prove a known target
SHA. Manual results do not change deployment/runtime facts, draft state or checklist.
The UI and CLI persist the same revisioned preference history. Submit no secrets in notes.

The typed CLI uses CliApp/CliSubCommand and RichHelpFormatter with CLI-only sources.
AppConfig is not BaseSettings. Existing command forms and no-color/width/JSON/stderr
behavior are preserved. Environment, dotenv and secret-file values are not config sources.


## Independent backend checkpoint and suspended draft

The latest 6 October independent checkpoint passed184 core tests, strict typing/lint/schema,
19 generated boundary cases and16 offline package checks. Existing UI evidence remains
31 stable browser regressions and31regression/12parity at pre-TypeScript007d1b3.
Both loopback ports retain stable bundled ba7ee8c assets. `scripts/serve_preview.py` defaults
to `--assets stable`; only explicit `--assets draft` serves frontend-new. Partial Claude
TypeScript remains preserved at f7aeeee and unserved. Resume its sole writer only after
18:10Europe/Zurich(16:10UTC), then complete TypeScript/timeline/custom columns and actual
compiled browser/image/package acceptance. Root has not taken over maintained UI design.

## General catalogs, profile comparison and manual history

```sh
gspace branches --config gspace.example.toml --project 42 --no-color --width 100
gspace pipeline-catalog --config gspace.example.toml --search main --json
gspace app-history 42:791 --config gspace.example.toml --environment dev --no-color
gspace pipelines 42:791 --config gspace.example.toml --json
```

General catalogs include resources without work-item associations. Pipeline summaries
include default and child sources and label jobs `not_loaded`. Coverage is the configured
identity's GET-visible project resources during bounded pagination, not an atomic snapshot.
Limits/errors never label partial results complete. Local search retains `scope_total`
alongside returned `total` in JSON. History keeps exact SHA/version, environment, outcome,
checked time/source/notes and current/superseded/stale/unknown relationship to the current
observed/expected target. Relationship states do not rewrite recorded outcomes.

For already operator-configured profiles, `probe action.json` reads one permission;
`probe-compare comparison.json` accepts this shape, adapted to actual configured names:

```json
{"action":{"kind":"create_tag","profile":"owner","project":{"value":42},"branch":"issue-791","expected_sha":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","tag":"demo-7"},"profiles":["owner","reader"]}
```

Profiles must cover identical host/project; comparison changes only the profile selector.
Results preserve fresh allowed/denied/unknown evidence, identity and checked time. No
confirmation or mutation is produced; no profiles/credentials are discovered or acquired.
Fixture mode has no remote profiles. Ready/merge/rebase remain deferred; corporate writes
remain disabled. API equivalents: `POST /api/access/compare`, `GET /api/branches`,
`GET /api/pipelines`, `GET /api/items/{project}/{issue}/application-tests?environment=dev`.

Custom environments use bounded saved-view column keys such as `environment:qa` and
project-scoped `Dashboard.environment_columns` descriptors. Rich supports them; web
integration is pending Claude. Configured unknown evidence and an environment absent
from another project's configuration remain distinct.

## Option aliases

Every public option has a long spelling and a case-sensitive short alias. Native Pydantic CLI aliases retain typed validation; a narrow argparse adapter gives negative boolean forms their own false-valued alias. Positional arguments are unchanged.

| Long option | Short | Negative long / short |
|---|---|---|
| config | -c | |
| json | -j | --no-json / -J |
| color | -C | --no-color / -N |
| width | -w | |
| all | -a | --no-all / -A |
| search | -s | |
| group | -g | |
| project | -p | |
| view | -v | |
| orientation | -o | |
| milestone | -m | |
| milestone-key | -M | |
| off | -f | --no-off / -F |
| state | -t | |
| unassigned | -u | --no-unassigned / -U |
| show-hidden | -H | --no-show-hidden / -I |
| reason | -r | |
| previous-tag | -T | |
| execute | -x | --no-execute / -X |
| confirm | -k | |
| refresh | -R | --no-refresh / -D |
| environment | -e | |
| port | -P | |
| help | -h | |
| version | -V | |

The first column denotes the corresponding `--long` form. Help/version are global discovery options; leaf help also accepts -h. Toggles use the last supplied spelling, so `-j -J` restores human output. `NO_COLOR` still takes precedence. No aliases collide across the registry. Example: `gspace pipelines list -c gspace.cli-demo.toml -p 42 -j -N`.

## Edition boundary

The user-confirmed target is GitLab EE. The preserved local lab is CE18.11.12; its health and fixture/synthetic checks do not establish full EE target parity. Images/volumes and licenses are unchanged. Multiproject deployment/GUI expansion awaits the separate matching-source assessment and decision.

## Native graph read

Run `gspace pipelines graph 42:791 --config gspace.cli-demo.toml` for the synthetic cross-project example; add `--json` for clean typed JSON or `--no-color --width 80`. Dedicated API is GET /api/items/{project}/{issue}/pipeline-graph on a freshly started backend. Existing8877 preview is deliberately not restarted by this checkpoint.

The additional visual integration supersedes that old-preview checkpoint: freshly started fixture8877 now includes the graph on work-item detail. Choose **Visual** for process columns, compact catalog cards and milestone timeline; choose **Detailed** for the retained full tables. On mobile, work items use strips and native graph layers scroll inside their own region. Mode/theme are browser appearance preferences; comparison, filters, saved-view fields and navigation styles remain shared TOML. Bookmark/saved-view Style controls curate icon/color/pin/order; configured environments appear in Fields and Sources. Save a work-item view to share its selected custom environment fields with CLI.

Verified development URL: http://127.0.0.1:8877/#/work. Recovery8876 retains original assets and8878 retains the frozen new candidate. All are synthetic loopback fixtures. See [actual visual acceptance](verification/visual-mode-acceptance-20261006.md) for exact gates, hashes, finite integration fixes and incomplete live/license/Claude-review evidence. A source or UI change invalidates the corresponding build/browser acceptance; do not overwrite recovery assets during a rebuild.

Optional `[live.pipeline_graph]` defaults are max_depth=4, max_nodes=64, max_pages=4, max_requests=128, timeout_seconds=30. Deadline prevents new requests but does not interrupt an in-flight bounded request. Unknown/partial evidence is deliberate; no automatic retry. Edges show triggers, and downstream config SHA is not deployed application proof. Real EE auth/scenarios remain operator work.

Runtime outbound-denial acceptance and recursive license inventory are newly required but not yet verified. Browser guards in current fixture acceptance show no external browser attempts; they do not isolate backend/glab networking. No global firewall/VPN/Docker settings may be changed for these tests. See docs/verification/runtime-network-acceptance.md.

## Offline evidence tasks

`poe dependency-inventory` builds the current wheel/source with the locked build group, reproduces the current frontend bytes and exact helper attribution, then collects local locked/installed license and NOTICE evidence without downloads. `output/verification/dependency-inventory` contains the reports, scope exports, deduplicated texts and deterministic archive. Exit 2 means unresolved evidence; inspect `report.json`. Python RECORD hashes, npm cached-tarball SRI/content and current wheel/source hashes must match. Install first to populate project-owned dependencies and caches.

macOS `poe runtime-network-qa` applies only a per-process loopback-only sandbox, proving blocked controls and allowed fixture API. Browser acceptance can run under integration/runtime-network-loopback.sb too. Temporary Unix IPC remains allowed; no global settings change. It does not establish production/DevPod network isolation. See verification/offline-runtime-inventory-20261006.md for exact limits.

## Shared navigation and project avatars

`gspace navigation list --config demo.toml --json` reads the dedicated scoped catalog. `gspace navigation set DECORATION.json --config demo.toml --json` updates an existing bookmark/saved-view target through the same atomic revision-checked preferences as web. `gspace navigation delete TARGET.json --config demo.toml --json` removes its decoration. The JSON file is positional. Icons/colors are curated semantic-independent choices; arbitrary content and foreign scope are rejected.

Optional operator `[avatars]` configuration defaults to `enabled = false`. To enable live PNG reads, explicitly configure approved `allowed_networks` CIDRs for the GitLab upload origin; TLS stays verified and redirects are disabled. No real host or credentials are supplied by development. Fixture mode always uses packaged fallback. Images are bounded to131072bytes/512px by default and cached for3600seconds with64entries; unsupported formats fall back. Browser receives only fixed same-origin project routes.

Live glab transport has an explicit acceptance gap: the installed CLI follows HTTP redirects beyond the initial allowed GET path/project; with a broader OS gate, another port is also reached. Synthetic exact-port denial blocks that port but cannot restrict paths in TLS. No supported no-redirect CLI option was found in pinned source. Existing corporate configuration/auth/proxy/CA files were not read and production isolation has not been certified. This is independent of fixture readiness and remote write capability restrictions.

## Current corrected fixture checkpoint

Document purpose: operational pointer to the verified7October compiled correction.

Preview http://127.0.0.1:8877/#/work serves compiled40bab537; select Visual or Detailed. Port8879 is the identical frozen candidate,8878 preservesab1d5d2 and8876 original recovery. Existing operator preferences are preserved. Actual installed wheel33checks and integrated asset/browser checks pass. Claude opened all57fresh final images; two minor text refinements remain quota-blocked until10:30Europe/Zurich7October. See [correction acceptance](verification/visual-corrections-acceptance-20261007.md) for exact evidence and independent live/license/lab gates.

## Finite text integration follow-up

Document purpose: point operators to the bounded7October text correction evidence.

Frontend5549698 wraps Preprod job statuses, separates refresh-error sentences and permits three collapsed detail lines only at desktop1100px+. Mobile remains two lines; retry is explicit and repeated errors do not accumulate. Current candidate is frozen at output/verification/finite-text-accepted-assets-20261007. Preview8877 is replaced only after strict/build/browser and installed package gates; older snapshots remain preserved. See [finite acceptance](verification/finite-text-acceptance-20261007.md) and output/verification/finite-text-final-checkpoint-20261007.json for actual served identity and remaining gates.

## Current application hierarchy — 11–12 October

Document purpose: operator entrypoint for the compiled contextual hierarchy;
process identity and dependent delivery status come from the actual evidence.

The current frontend Git checkpoint is `c97f508`. Work items and Compare default
to adjacent aligned process columns on desktop and coherent strips on mobile.
Detailed retains the full tables. Resource drawers show pipelines, jobs/attempts,
MR state/draft and independent publish evidence. Environment cards keep deployment
record, deploy job, running identity and exact application-test result separate.
Record result opens the editor; history stays reachable independently. Rare
planning/override/group tools are disclosures whose interrupted drafts survive.

The local demo URL is **http://127.0.0.1:61429/#/work**. Reload after a preview
replacement. Consult `output/verification/application-ux-20261011/preview.json`
and `preview-acceptance.json` for the actual running PID, frozen hashes and served
acceptance; before that replacement, the preceding verified N1/N2 preview record
is in `application-texts-20261011/preview.json`. Historical URLs and PIDs above do
not assert current listeners. All are isolated synthetic loopback fixtures.

Current strict/reproducible build, 82 whole-app checks, 28 focused correction
checks and 16 empty/error/back/close/mobile journeys pass on Python 3.12. The
same sole Claude Opus5.5/Extra writer reviewed the hierarchy and performed the
bounded simplification. Independent root checks preserve interrupted test notes,
inline invalid Settings guards and multiple Nexus artifacts from the same job.
The actual mobile document remains within the viewport after saves and navigation.

Valid public operator-file changes apply to the running service on local reads;
invalid/protected edits retain last-good and report a safe error. Settings does
not refresh remote evidence. Updated timezone rules apply to local milestone dates.
Manual tests record one exact version; a changed commit starts not tested and
never automatically changes the checklist, draft or runtime. Permission evidence
for a profile does not enable remote write capability.

The current wheel/source destination is
`output/verification/application-ux-20261011/package`; actual installed-package
outcomes and hashes are in that directory's sibling `package.json` and
`package.staging.json`. The staged wheel contains the corrected compiled UI.
Ordinary fixture commands using preserved workspace `src/gspace/static` still
serve the original accepted UI. Use the frozen corrected preview or the verified
corrected wheel for the new hierarchy. See
[current UX evidence](verification/application-ux-20261011.md), with historical
[N1/N2 evidence](verification/application-texts-20261011.md) and
[9October evidence](verification/application-recovery-20261009.md).

To reproduce a separate frozen preview, use a fresh owned state filename:

```sh
.venv/bin/python scripts/recovery_preview.py --state output/verification/recovery-preview-new.json
```

It verifies current assets against the build manifest, binds127.0.0.1 at a fresh
port, prints URL/PID, preserves copied assets and uses temporary synthetic state.
Stopping only that owned PID cleans up its own fixture. Keep original operator
configuration and recovery assets; never start a concurrent frontend writer.

Fixture profiles use inert GET-only transport and never read credentials or
contact the lab. Real DevPod/glab redirect/path/DNS isolation, authenticated CE
scenarios, actual EE graph and complete current license/attribution remain
independent gates. The CE lab is stopped and its latest actual preflight fails
the60GiB storage guard; no cleanup/start/seed/runner is implied. Optional visual
polish remains documented, with no new feature or broad redesign authorized.
