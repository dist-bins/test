"""Native glab compatibility and explicitly selected guarded transport."""

import json
import sys

import pytest

from gspace.glab import AdapterError, run_argv

IDENTITY = "glab 0.0.0-gspace-no-redirects.1 (synthetic fixture)"


def launcher(tmp_path, version=IDENTITY, delay=0):
    path = tmp_path / "controlled-launcher"
    calls = tmp_path / "api-calls.json"
    path.write_text(
        f"#!{sys.executable}\n"
        "import json,os,sys,time\n"
        f"time.sleep({delay!r})\n"
        "if sys.argv[-1:] == ['--version']:\n"
        f"    print({version!r})\n"
        "else:\n"
        f"    open({str(calls)!r},'w').write(json.dumps(sys.argv[1:]))\n"
        "    print(json.dumps({'argv':sys.argv[1:],'host':os.environ.get('GITLAB_API_HOST')}))\n"
    )
    path.chmod(0o700)
    return path, calls


@pytest.mark.parametrize("version", ["glab 1.120.0", "unrelated gspace-no-redirects.1", ""])
def test_unguarded_configured_launcher_is_rejected_before_api(tmp_path, version):
    path, calls = launcher(tmp_path, version)
    with pytest.raises(AdapterError, match="guarded"):
        run_argv(
            [str(path), "api", "--hostname", "gitlab.example.invalid", "version"],
            3,
            reject_redirects=True,
        )
    assert not calls.exists()


def test_guarded_controlled_launcher_keeps_arguments_and_original_authority(tmp_path):
    path, calls = launcher(tmp_path)
    result = run_argv(
        [
            str(path),
            "--profile",
            "team",
            "api",
            "--hostname",
            "gitlab.example.invalid:8443",
            "--method",
            "GET",
            "projects/42",
        ],
        3,
        reject_redirects=True,
    )
    payload = json.loads(result.stdout)
    assert result.code == 0 and payload["host"] == "gitlab.example.invalid:8443"
    assert json.loads(calls.read_text()) == [
        "--profile",
        "team",
        "api",
        "--hostname",
        "gitlab.example.invalid",
        "--method",
        "GET",
        "projects/42",
    ]


def test_default_glab_resolves_only_private_guarded_companion(tmp_path, monkeypatch):
    path, calls = launcher(tmp_path)
    monkeypatch.setattr("gspace.glab.sys.executable", str(tmp_path / "python"))
    monkeypatch.setattr(
        "gspace.glab.shutil.which", lambda name: str(path) if name == "gspace-glab" else None
    )
    result = run_argv(
        ["glab", "api", "--hostname", "gitlab.example.invalid", "version"], 3, reject_redirects=True
    )
    assert result.code == 0 and calls.exists()


def test_missing_private_companion_never_falls_back_to_system_glab(tmp_path, monkeypatch):
    path, calls = launcher(tmp_path)
    monkeypatch.setattr(
        "gspace.glab.shutil.which", lambda name: str(path) if name == "glab" else None
    )
    monkeypatch.setattr("gspace.glab.sys.executable", str(tmp_path / "python"))
    with pytest.raises(AdapterError, match="guarded"):
        run_argv(
            ["glab", "api", "--hostname", "gitlab.example.invalid", "version"],
            3,
            reject_redirects=True,
        )
    assert not calls.exists()


def test_identity_probe_is_inside_the_original_total_deadline(tmp_path):
    path, calls = launcher(tmp_path, delay=0.3)
    with pytest.raises(AdapterError, match="timed out"):
        run_argv(
            [str(path), "api", "--hostname", "gitlab.example.invalid", "version"],
            0.05,
            reject_redirects=True,
        )
    assert not calls.exists()


def test_native_default_uses_stock_launcher_without_identity_probe(tmp_path, monkeypatch):
    path, calls = launcher(tmp_path, version="glab 1.120.0")
    path.rename(tmp_path / "glab")
    monkeypatch.setenv("PATH", str(tmp_path))

    def unexpected_companion_lookup(name):
        raise AssertionError("Native mode must not search for a private companion")

    monkeypatch.setattr("gspace.glab.shutil.which", unexpected_companion_lookup)
    result = run_argv(["glab", "api", "--hostname", "gitlab.example.invalid", "version"], 3)
    assert result.code == 0 and calls.exists()


def test_native_explicit_wrapper_accepts_ordinary_version(tmp_path):
    path, calls = launcher(tmp_path, version="glab 1.120.0")
    result = run_argv([str(path), "api", "version"], 3)
    assert result.code == 0 and calls.exists()


@pytest.mark.parametrize("strict", [False, True])
def test_operator_toml_policy_reaches_live_and_profile_runners(monkeypatch, strict):
    import tomllib

    import gspace.access as access
    import gspace.glab as glab
    from gspace.access_models import GlabProfile
    from gspace.config import AppConfig
    from gspace.models import ProjectId

    text = """mode = "live"
[live]
hostname = "gitlab.example.invalid"
web_origin = "https://gitlab.example.invalid"
projects = [{ id = { value = 42 }, path = "demo/flight" }]
reject_redirects = STRICT
[[access_profiles]]
kind = "glab"
name = "operator"
host = "https://gitlab.example.invalid"
projects = [{ value = 42 }]
reject_redirects = STRICT
""".replace("STRICT", str(strict).lower())
    config = AppConfig.model_validate(tomllib.loads(text))
    observed = []

    def runner(argv, timeout, **policy):
        observed.append(policy["reject_redirects"])
        return glab.RunResult(code=0, stdout=b"{}")

    monkeypatch.setattr(glab, "run_argv", runner)
    monkeypatch.setattr(access, "run_argv", runner)
    monkeypatch.setattr(access.shutil, "which", lambda name: "/synthetic/glab")
    assert config.live is not None
    glab.GlabAdapter(config.live, runner=runner).get("version")
    profile = config.access_profiles[0]
    assert isinstance(profile, GlabProfile)
    assert profile.projects == (ProjectId(value=42),)
    access.ProfileTransport(profile, runner=runner).request("GET", "version")
    assert observed == [strict, strict]
