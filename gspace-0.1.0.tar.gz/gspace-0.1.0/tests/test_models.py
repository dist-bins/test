from datetime import UTC, datetime

import pytest
from pydantic import TypeAdapter, ValidationError

from gspace.config import AppConfig, TagConvention
from gspace.fixture import synthetic_snapshot
from gspace.models import (
    Comparison,
    IssueIid,
    Link,
    MrIid,
    Observed,
    ProjectId,
    RebaseVerified,
    Snapshot,
    Unknown,
    Version,
    WorkKey,
    compare_version,
)
from gspace.service import PreferenceChange


@pytest.mark.parametrize("bad", [0, -1, True, "791", 791.0])
def test_iid_rejects_coercion_and_invalid_range(bad):
    with pytest.raises(ValidationError):
        IssueIid(value=bad)


def test_runtime_nominal_identity():
    with pytest.raises(ValidationError):
        WorkKey(project=ProjectId(value=42), issue=MrIid(value=791))
    assert IssueIid(value=154) != MrIid(value=154)


def test_closed_immutable_domain():
    with pytest.raises(ValidationError):
        IssueIid.model_validate({"value": 791, "mr": 154})
    iid = IssueIid(value=791)
    with pytest.raises(ValidationError):
        iid.value = 5


def test_graph_rejects_cross_project_relationship_and_dangling_publish():
    snapshot = synthetic_snapshot().model_dump(mode="json")
    snapshot["items"][0]["branches"][0]["project"]["value"] = 999
    with pytest.raises(ValidationError, match="project boundary"):
        Snapshot.model_validate(snapshot)
    snapshot = synthetic_snapshot().model_dump(mode="json")
    snapshot["items"][0]["publishes"][0]["job"]["value"] = 98765
    with pytest.raises(ValidationError, match="existing pipeline job"):
        Snapshot.model_validate(snapshot)


def test_snapshot_roundtrip_preserves_discriminants():
    snapshot = synthetic_snapshot()
    assert Snapshot.model_validate_json(snapshot.model_dump_json()) == snapshot
    assert isinstance(snapshot.items[2].branches[0].rebase, Unknown)
    assert len(snapshot.items[0].merge_requests) == 2
    assert snapshot.items[0].identity.issue.value != snapshot.items[0].merge_requests[0].iid.value


def test_rebase_evidence_requires_coherence_and_aware_time():
    with pytest.raises(ValidationError):
        RebaseVerified(
            source_sha="a" * 40,
            target_branch="main",
            required=False,
            behind=5,
            source="test",
            checked_at=datetime.now(UTC),
        )
    with pytest.raises(ValidationError):
        RebaseVerified(
            source_sha="a" * 40,
            target_branch="main",
            required=False,
            behind=0,
            source="test",
            checked_at=datetime(2026, 10, 5),
        )


@pytest.mark.parametrize(
    "payload",
    [
        {"operation": "pin", "revision": 0},
        {
            "operation": "filters",
            "revision": 0,
            "key": {"project": {"value": 42}, "issue": {"value": 791}},
            "filters": {},
        },
        {
            "operation": "checklist",
            "revision": 0,
            "key": {"project": {"value": 42}, "issue": {"value": 791}},
            "enabled": True,
        },
        {"operation": "ready", "revision": 0},
    ],
)
def test_preference_operations_are_variants_not_optional_bags(payload):
    with pytest.raises(ValidationError):
        TypeAdapter(PreferenceChange).validate_python(payload)


def test_branch_match_never_proves_a_new_commit():
    observation = Observed(
        value=Version(branch="issue-791"), source="fixture", checked_at=datetime.now(UTC)
    )
    assert compare_version(Version(branch="issue-791"), observation)[0] == Comparison.UNKNOWN
    assert (
        compare_version(Version(branch="issue-791", sha="a" * 40), observation)[0]
        == Comparison.UNKNOWN
    )


def test_missing_evidence_does_not_hide_a_known_mismatch():
    observation = Observed(
        value=Version(branch="other"), source="fixture", checked_at=datetime.now(UTC)
    )
    assert (
        compare_version(Version(branch="issue-791", sha="a" * 40), observation)[0]
        == Comparison.MISMATCH
    )


def test_version_unknown_mismatch_and_match():
    assert compare_version(None, Unknown(reason="not observed"))[0] == Comparison.UNKNOWN
    observation = Observed(
        value=Version(sha="b" * 40), source="fixture", checked_at=datetime.now(UTC)
    )
    assert compare_version(Version(sha="a" * 40), observation)[0] == Comparison.MISMATCH
    assert compare_version(Version(sha="b" * 40), observation)[0] == Comparison.MATCH
    with pytest.raises(ValidationError):
        Version()


@pytest.mark.parametrize(
    "before,after",
    [("release-2.4.09", "release-2.4.10"), ("v9", "v10"), ("a2-b3-c009", "a2-b3-c010")],
)
def test_default_tag_rightmost_numeric_component(before, after):
    assert TagConvention().suggest(before) == after


def test_tag_convention_is_configurable_and_numeric_required():
    assert TagConvention(component_from_right=1, increment=2).suggest("v2.4.09") == "v2.6.09"
    with pytest.raises(ValueError):
        TagConvention().suggest("release")


def test_remote_auth_and_shared_cache_paths_are_rejected():
    with pytest.raises(ValidationError):
        AppConfig.model_validate({"token": "secret"})
    with pytest.raises(ValidationError):
        AppConfig(preferences_path="same.toml", cache_path="same.toml")


@pytest.mark.parametrize(
    "url",
    [
        "javascript:alert(1)",
        "https://user:secret@example.invalid/path",
        "https://example.invalid/?token=value",
        "https://example.invalid/#fragment",
        "https://example.invalid/\r\ninjected",
        "https://example.invalid\\other/path",
    ],
)
def test_links_reject_credentials_nonhttp_and_ambiguous_characters(url):
    with pytest.raises(ValidationError):
        Link(url=url)
