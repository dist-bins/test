"""Independent Rich terminal renderer. JSON stdout is never decorated."""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Literal

import uvicorn
from pydantic import BaseModel, JsonValue, TypeAdapter, ValidationError
from pydantic_settings.exceptions import SettingsError

from gspace import __version__, cli_commands, cli_render
from gspace.actions import (
    Action,
    ActionService,
    ConfirmablePlan,
    ConfirmAction,
    ProbeComparisonRequest,
)
from gspace.cli_models import early_toggle, parse
from gspace.config import load_config
from gspace.glab import AdapterError
from gspace.models import (
    ApplicationTestRecord,
    GroupId,
    GroupMilestoneKey,
    IssueIid,
    MilestoneFilter,
    MilestoneId,
    ProjectId,
    ProjectMilestoneKey,
    WorkKey,
)
from gspace.navigation import (
    Bookmark,
    NavigationDecoration,
    NavigationTarget,
    ResourceReference,
    SavedView,
)
from gspace.operator_settings import SettingsChange
from gspace.preferences import Filters, PreferenceConflict, Preferences
from gspace.service import (
    ApplicationTestChange,
    BookmarkDelete,
    BookmarkSet,
    ChecklistChange,
    FilterChange,
    FlagChange,
    GroupChange,
    NavigationDecorationDelete,
    NavigationDecorationSet,
    OverrideChange,
    SavedViewDelete,
    SavedViewSet,
    Service,
)

# Preserve imports used by callers; orchestration never consumes rendered output.
matrix = cli_render.matrix
details = cli_render.details


def parse_key(value: str) -> WorkKey:
    try:
        project, issue = value.split(":")
        return WorkKey(project=ProjectId(value=int(project)), issue=IssueIid(value=int(issue)))
    except (ValueError, ValidationError) as error:
        raise argparse.ArgumentTypeError("Use PROJECT_ID:ISSUE_IID, for example 42:791") from error


def parse_milestone(mode: str, value: str | None) -> MilestoneFilter:
    if value is None:
        return MilestoneFilter.model_validate({"mode": mode})
    try:
        kind, owner, ident = value.split(":")
        if kind == "project":
            key = ProjectMilestoneKey(
                project=ProjectId(value=int(owner)), id=MilestoneId(value=int(ident))
            )
        elif kind == "group":
            key = GroupMilestoneKey(
                group=GroupId(value=int(owner)), id=MilestoneId(value=int(ident))
            )
        else:
            raise ValueError("Unknown milestone scope")
        return MilestoneFilter(mode="selected", selected=key)
    except ValueError as error:
        raise ValueError(
            "Use project:PROJECT_ID:MILESTONE_ID or group:GROUP_ID:MILESTONE_ID"
        ) from error


def main() -> int:
    argv = sys.argv[1:]
    if argv in (["--version"], ["-V"]):
        sys.stdout.write(f"GSpace {__version__}\n")
        return 0
    try:
        normalized, topic, display_command = cli_commands.prepare(argv)
        if topic is not None:
            cli_commands.help_page(
                topic,
                cli_render.make_console(
                    no_color=not early_toggle(argv, "color", True) or "NO_COLOR" in os.environ
                ),
            )
            return 0
        args = parse(normalized, display_command=display_command)
        if hasattr(args, "key"):
            args.key = parse_key(args.key)
    except (ValueError, SettingsError, argparse.ArgumentTypeError) as error:
        message = "Invalid command arguments" if isinstance(error, ValidationError) else str(error)
        if early_toggle(argv, "json", False):
            sys.stderr.write(json.dumps({"error": message}) + "\n")
        else:
            errors = cli_render.make_console(
                stderr=True,
                no_color=not early_toggle(argv, "color", True) or "NO_COLOR" in os.environ,
            )
            errors.print(cli_render.literal(f"Error: {message}", "gs.error"))
            errors.print(cli_render.literal("Help: gspace --help", "gs.meta"))
        return 2
    no_color = args.no_color or "NO_COLOR" in os.environ
    console = cli_render.make_console(no_color=no_color, width=args.width)
    errors = cli_render.make_console(stderr=True, no_color=no_color, width=args.width)
    try:
        if args.width is not None and args.width < 40:
            raise ValueError("Terminal width must be at least 40")
        service = Service(load_config(args.config), config_path=args.config)
        result: BaseModel | None = None
        command = args.command
        if command == "serve":
            from gspace.api import create_app

            if args.json:
                raise ValueError("--json is unavailable for the web server")
            if not 1024 <= args.port <= 65535:
                raise ValueError("Server port must be between 1024 and 65535")
            uvicorn.run(
                create_app(service=service),
                host="127.0.0.1",
                port=args.port,
                access_log=False,
                proxy_headers=False,
            )
            return 0
        if command in ("dashboard", "list", "compare"):
            filters = service.preferences.read().filters.model_dump()
            if args.view:
                view = next(
                    (
                        v
                        for v in service.preferences.read().saved_views
                        if v.host == service.host and v.name == args.view
                    ),
                    None,
                )
                if view is None:
                    raise KeyError("Saved view not found")
                filters = view.filters.model_dump(exclude={"authored"})
            if args.all:
                filters.update(state="all", assigned=False, show_hidden=True)
            if args.search is not None:
                filters["search"] = args.search
            if args.group is not None:
                filters["group"] = args.group
            if args.milestone is not None or args.milestone_key is not None:
                filters["milestone"] = parse_milestone(args.milestone or "all", args.milestone_key)
            result = service.dashboard(
                Filters.model_validate(filters),
                selected_only=command == "compare",
                project=ProjectId(value=args.project) if args.project is not None else None,
                saved_view=args.view,
                orientation=args.orientation,
            )
            if not args.json:
                if command == "list":
                    cli_render.list_items(result, console)
                else:
                    matrix(result, console)
                return 0
        elif command in ("branches", "pipeline-catalog"):
            result = service.resource_catalog(
                "branches" if command == "branches" else "pipelines",
                ProjectId(value=args.project) if args.project else None,
                search=args.search,
            )
            if not args.json:
                cli_render.resource_catalog(result, console)
                return 0
        elif command == "app-history":
            result = service.application_test_history(args.key, args.environment)
            if not args.json:
                cli_render.history(result, console)
                return 0
        elif command == "pipeline-graph":
            result = service.pipeline_graph(WorkKey.model_validate(args.key))
            if not args.json:
                cli_render.pipeline_graph(result, console)
                return 0
        elif command in ("show", "pipelines", "environments"):
            key = WorkKey.model_validate(args.key)
            result = service.view(service.item(key), service.preferences.read())
            if not args.json:
                details(result, console, command)
                return 0
        elif command == "milestones":
            result = service.milestones(ProjectId(value=args.project) if args.project else None)
            if not args.json:
                cli_render.milestones(result, console)
                return 0
        elif command == "settings":
            result = service.settings()
        elif command == "settings-set":
            result = service.update_settings(
                SettingsChange.model_validate_json(args.file.read_bytes())
            )
        elif command == "app-test":
            record = ApplicationTestRecord.model_validate_json(args.file.read_bytes())
            result = service.change(
                ApplicationTestChange(revision=service.preferences.read().revision, record=record)
            )
        elif command == "projects":
            payload = {
                "host": service.host,
                "coverage": "configured_projects",
                "projects": [p.model_dump(mode="json") for p in service.projects()],
            }
            if args.json:
                sys.stdout.write(json.dumps(payload, indent=2) + "\n")
            else:
                cli_render.heading(console, "Configured projects", service.host)
                cli_render.json_report(
                    TypeAdapter[JsonValue](JsonValue).validate_python(payload), console
                )
            return 0
        elif command == "mrs":
            catalog = service.mr_catalog(
                refresh=args.refresh,
                project=ProjectId(value=args.project) if args.project is not None else None,
            )
            rows = [
                row for row in catalog.rows if args.state == "all" or row.mr.state == args.state
            ]
            if args.json:
                payload = {
                    **catalog.model_dump(mode="json"),
                    "rows": [row.model_dump(mode="json") for row in rows],
                    "total": len(rows),
                }
                sys.stdout.write(json.dumps(payload, indent=2) + "\n")
            else:
                cli_render.merge_requests(rows, service.host, console)
            return 0
        elif command in ("views", "bookmarks"):
            preferences = service.preferences.read()
            rows = preferences.saved_views if command == "views" else preferences.bookmarks
            payload = [row.model_dump(mode="json") for row in rows if row.host == service.host]
            if args.json:
                sys.stdout.write(json.dumps(payload, indent=2) + "\n")
            else:
                cli_render.heading(console, command.title(), service.host)
                cli_render.json_report(
                    TypeAdapter[JsonValue](JsonValue).validate_python(payload), console
                )
            return 0
        elif command == "navigation":
            result = service.navigation()
        elif command in ("navigation-set", "navigation-delete"):
            revision = service.preferences.read().revision
            if command == "navigation-set":
                result = service.change(
                    NavigationDecorationSet(
                        revision=revision,
                        decoration=NavigationDecoration.model_validate_json(args.file.read_bytes()),
                    )
                )
            else:
                result = service.change(
                    NavigationDecorationDelete(
                        revision=revision,
                        target=TypeAdapter[NavigationTarget](NavigationTarget).validate_json(
                            args.file.read_bytes()
                        ),
                    )
                )
        elif command in ("view-save", "view-delete", "bookmark-set", "bookmark-delete"):
            revision = service.preferences.read().revision
            if command == "view-save":
                result = service.change(
                    SavedViewSet(
                        revision=revision,
                        view=SavedView.model_validate_json(args.file.read_bytes()),
                    )
                )
            elif command == "view-delete":
                result = service.change(SavedViewDelete(revision=revision, name=args.name))
            elif command == "bookmark-set":
                result = service.change(
                    BookmarkSet(
                        revision=revision,
                        bookmark=Bookmark.model_validate_json(args.file.read_bytes()),
                    )
                )
            else:
                result = service.change(
                    BookmarkDelete(
                        revision=revision,
                        reference=TypeAdapter[ResourceReference](ResourceReference).validate_json(
                            args.file.read_bytes()
                        ),
                    )
                )
        elif command in ("profiles", "doctor", "action", "probe", "probe-compare"):
            actions = ActionService(
                service.config.access_profiles if service.config.mode == "live" else ()
            )
            if command == "profiles":
                payload = [profile.model_dump(mode="json") for profile in actions.summaries()]
                if args.json:
                    sys.stdout.write(json.dumps(payload, indent=2) + "\n")
                else:
                    cli_render.heading(console, "Configured access profiles")
                    cli_render.json_report(
                        TypeAdapter[JsonValue](JsonValue).validate_python(payload), console
                    )
                return 0
            if command == "doctor":
                result = actions.doctor(args.profile)
            elif command == "probe-compare":
                result = actions.compare(
                    ProbeComparisonRequest.model_validate_json(args.file.read_bytes())
                )
                if not args.json:
                    cli_render.probe_comparison(result, console)
                    return 0
            elif command == "probe":
                result = actions.probe(
                    TypeAdapter[Action](Action).validate_json(args.file.read_bytes())
                )
            else:
                action = TypeAdapter[Action](Action).validate_json(args.file.read_bytes())
                plan = actions.preview(action)
                if args.execute:
                    expected = (
                        f"{action.profile}:{action.project.value}:"
                        f"{action.kind}:{action.expected_sha}"
                    )
                    if args.confirm != expected:
                        raise ValueError(f"Exact explicit --confirm required: {expected}")
                    if not isinstance(plan, ConfirmablePlan):
                        raise ValueError("Action is blocked: " + plan.permission.reason)
                    result = actions.execute(
                        ConfirmAction(confirmation=plan.confirmation, confirmed=True)
                    )
                else:
                    result = plan
        elif command == "preferences":
            result = service.preferences.read()
        elif command == "refresh":
            service.refresh()
            result = service.dashboard()
        elif command == "preview":
            result = service.preview(args.key, args.action, args.previous_tag)
        elif command == "observe":
            observed = service.observe_environment(args.key, args.environment)
            result = service.view(observed, service.preferences.read())
        else:
            revision = service.preferences.read().revision
            if command in ("pin", "hide", "select"):
                operation = TypeAdapter[Literal["pin", "hide", "select"]](
                    Literal["pin", "hide", "select"]
                ).validate_python(command)
                change = FlagChange(
                    revision=revision, operation=operation, key=args.key, enabled=not args.off
                )
                result = service.change(change)
            elif command == "group":
                result = service.change(
                    GroupChange(
                        revision=revision, key=args.key, group=args.name, enabled=not args.off
                    )
                )
            elif command == "checklist":
                result = service.change(
                    ChecklistChange.model_validate(
                        {
                            "revision": revision,
                            "key": args.key,
                            "checklist_field": args.field,
                            "enabled": not args.off,
                        }
                    )
                )
            elif command == "filters":
                result = service.change(
                    FilterChange(
                        revision=revision,
                        filters=Filters.model_validate(
                            {
                                "state": args.state,
                                "assigned": not args.unassigned,
                                "search": args.search,
                                "group": args.group,
                                "show_hidden": args.show_hidden,
                                "milestone": parse_milestone(args.milestone, args.milestone_key),
                            }
                        ),
                    )
                )
            elif command == "override":
                result = service.change(
                    OverrideChange.model_validate(
                        {
                            "revision": revision,
                            "key": args.key,
                            "override_kind": args.kind,
                            "override_value": args.value,
                            "reason": args.reason,
                            "enabled": not args.off,
                        }
                    )
                )
        if result is None:
            raise ValueError("Unsupported command")
        if args.json:
            sys.stdout.write(result.model_dump_json(indent=2) + "\n")
        elif command == "filters" and isinstance(result, Preferences):
            cli_render.filters_report(result.filters, console)
        else:
            cli_render.model_report(result, command.replace("-", " ").title(), console)
        return 0
    except (ValueError, KeyError, OSError, AdapterError, PreferenceConflict) as error:
        message = (
            "Stored data or configuration is invalid"
            if isinstance(error, ValidationError)
            else str(error)
        )
        if args.json:
            sys.stderr.write(json.dumps({"error": message}) + "\n")
        else:
            errors.print(cli_render.literal(f"Error: {message}", "gs.error"))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
