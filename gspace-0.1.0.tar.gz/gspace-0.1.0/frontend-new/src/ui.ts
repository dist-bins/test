// Shared UI components used by every screen.

import type { IconName, Kid } from './dom';
import { h, icon, none, wolf } from './dom';
import { loadScope } from './load';
import { scopeLabel } from './model';
import { render } from './render';
import { S, to } from './state';

// One empty/unavailable/error component everywhere: gray wolf, title, the
// explanation inside the card and optional actions.
export function emptyState(o: { title: string; body?: Kid; actions?: Kid; status?: boolean; compact?: boolean }): HTMLDivElement {
  const bodies: readonly Kid[] = Array.isArray(o.body) ? o.body : [o.body];
  return h(
    'div',
    { class: `state-box${o.compact ? ' compact' : ''}`, role: o.status ? 'status' : null },
    wolf(true, o.compact ? '' : 'wolf-lg'),
    h(
      'div',
      { class: 'state-text' },
      h('strong', null, o.title),
      bodies.map((b) => (typeof b === 'string' ? h('p', null, b) : b)),
      o.actions ? h('div', { class: 'line state-actions' }, o.actions) : null,
    ),
  );
}

export function sec(title: string, ico: IconName, body: Kid, tools: Kid = null): HTMLElement {
  return h(
    'section',
    { class: 'sec', 'aria-label': title },
    h('div', { class: 'sec-h' }, icon(ico, 'sm'), h('h2', null, title), tools ? h('div', { class: 'toolbar' }, tools) : null),
    body,
  );
}

export interface TableRow {
  readonly sel: boolean;
  readonly cells: readonly Kid[];
}

// Rows are cell arrays or {sel, cells}. Cells carry their header as
// data-label, so narrow screens show each row as a labelled card.
export function simpleTable(
  headers: readonly string[],
  rows: readonly (readonly Kid[] | TableRow)[],
  empty: string,
  opts: { label?: string } = {},
): HTMLDivElement {
  if (!rows.length) return emptyState({ title: empty, compact: true });
  const label = opts.label ?? null;
  return h(
    'div',
    { class: 'box tbl-wrap', role: label ? 'region' : null, 'aria-label': label, tabindex: label ? '0' : null },
    h(
      'table',
      { class: 'tbl stack' },
      h(
        'thead',
        null,
        h(
          'tr',
          null,
          headers.map((x) => h('th', { scope: 'col' }, x || h('span', { class: 'sr' }, 'Actions'))),
        ),
      ),
      h(
        'tbody',
        null,
        rows.map((r) => {
          const row: TableRow = isTableRow(r) ? r : { sel: false, cells: r };
          return h(
            'tr',
            { class: row.sel ? 'sel' : null },
            row.cells.map((c, i) => h('td', { 'data-label': headers[i] || null }, c)),
          );
        }),
      ),
    ),
  );
}

function isTableRow(r: readonly Kid[] | TableRow): r is TableRow {
  return !Array.isArray(r);
}

export function kvList(entries: readonly (readonly [string, Kid])[]): HTMLDListElement {
  return h(
    'dl',
    { class: 'kv' },
    entries.map(([k, v]) => [h('dt', null, k), h('dd', null, v == null || v === '' ? none('Not reported') : v)]),
  );
}

// short: visible label on narrow screens (CSS); the full label stays the
// accessible name at every width.
export function toggleBtn(ico: IconName, on: boolean, label: string, onclick: () => void, short: string | null = null): HTMLButtonElement {
  return h(
    'button',
    { class: 'btn', type: 'button', 'aria-pressed': String(on), 'data-fk': `tg-${ico}`, disabled: !S.prefs, onclick },
    icon(ico),
    short ? [h('span', { class: 'lbl-full' }, label), h('span', { class: 'lbl-short', 'aria-hidden': 'true' }, short)] : label,
  );
}

export function tinyBtn(
  ico: IconName,
  label: string,
  onclick: () => void,
  opts: { danger?: boolean; disabled?: boolean; fk?: string } = {},
): HTMLButtonElement {
  return h(
    'button',
    {
      class: `btn sm icon ghost${opts.danger ? ' danger' : ''}`,
      type: 'button',
      'aria-label': label,
      title: label,
      disabled: opts.disabled ?? false,
      'data-fk': opts.fk ?? null,
      onclick,
    },
    icon(ico, 'sm'),
  );
}

export function scopeChip(): HTMLSpanElement {
  return h(
    'span',
    { class: 'scope-chip', title: `Repository scope on ${S.host ?? 'unknown host'}` },
    icon('repo', 'sm'),
    h('span', { class: 'trunc' }, scopeLabel()),
  );
}

/* ------------------------------------------------------------- menus */

export function menu(id: string, summary: HTMLElement, content: Kid): HTMLDetailsElement {
  return h(
    'details',
    {
      class: 'menu',
      open: S.openMenu === id,
      ontoggle: (e: Event) => {
        const t = e.target;
        if (!(t instanceof HTMLDetailsElement)) return;
        if (t.open) S.openMenu = id;
        else if (S.openMenu === id) S.openMenu = null;
      },
    },
    summary,
    h('div', { class: 'menu-pop' }, content),
  );
}

document.addEventListener('click', (e) => {
  // A re-render may already have replaced the clicked node (e.g. a column
  // checkbox inside the open menu); that click was inside, not outside.
  const t = e.target;
  if (!(t instanceof Node) || !t.isConnected) return;
  // The evidence layer sits outside every menu; using it keeps the menu open.
  if (t instanceof Element && t.closest('#ev-layer')) return;
  for (const d of document.querySelectorAll('details.menu[open]')) {
    if (d instanceof HTMLDetailsElement && !d.contains(t)) {
      d.open = false;
      S.openMenu = null;
    }
  }
});

/* ------------------------------------------------------------ dialogs */

export function dialog(
  title: string,
  body: Kid,
  o: { okLabel?: string; onOk: () => Promise<string | null> | string | null; danger?: boolean },
): HTMLDialogElement {
  const root = document.getElementById('sheet-root');
  const err = h('p', { class: 'hint', role: 'alert' });
  const dlg = h('dialog', { class: 'dlg', 'aria-label': title });
  const form = h(
    'form',
    { method: 'dialog' },
    h('h2', null, title),
    body,
    err,
    h(
      'div',
      { class: 'dlg-actions' },
      h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Cancel'),
      h('button', { class: `btn ${o.danger ? 'danger' : 'primary'}`, type: 'submit' }, o.okLabel ?? 'Save'),
    ),
  );
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    void Promise.resolve(o.onOk()).then((msg) => {
      if (typeof msg === 'string') {
        err.textContent = msg;
        return;
      }
      dlg.close();
    });
  });
  dlg.append(form);
  dlg.addEventListener('close', () => dlg.remove());
  (root ?? document.body).append(dlg);
  dlg.showModal();
  return dlg;
}

export function confirmDialog(title: string, text: string, okLabel: string): Promise<boolean> {
  return new Promise((done) => {
    let ok = false;
    const d = dialog(title, h('p', null, text), {
      okLabel,
      danger: true,
      onOk: () => {
        ok = true;
        return null;
      },
    });
    d.addEventListener('close', () => done(ok));
  });
}

// Shown instead of data when the repository scope is invalid, loading or failed,
// so the previous repository's data never appears under a new heading.
export function scopeGate(): HTMLElement | null {
  if (S.scopeError) {
    return emptyState({
      title: 'Repository unavailable',
      body: S.scopeError,
      actions: h('a', { class: 'btn sm', href: to('#/work', null) }, 'Show all configured projects'),
    });
  }
  if (!S.dash && S.loading) return emptyState({ title: `Loading ${scopeLabel()}…`, status: true });
  if (!S.dash && S.dashError) {
    return emptyState({
      title: `${scopeLabel()} could not be loaded`,
      body: S.dashError,
      actions: h('button', { class: 'btn sm', type: 'button', onclick: loadScope }, 'Try again'),
    });
  }
  return null;
}

/* -------------------------------------------------------------- theme */

export type ThemeChoice = 'system' | 'light' | 'dark';
export const THEMES: readonly ThemeChoice[] = ['system', 'light', 'dark'];
const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');

export function themeChoice(): ThemeChoice {
  const c = document.documentElement.getAttribute('data-theme-choice');
  return c === 'light' || c === 'dark' ? c : 'system';
}

export function applyTheme(): void {
  const c = themeChoice();
  const dark = c === 'dark' || (c === 'system' && darkQuery.matches);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
}
darkQuery.addEventListener('change', applyTheme);

export function setTheme(choice: ThemeChoice): void {
  try {
    window.localStorage.setItem('gspace.theme', choice);
  } catch {
    // browser storage unavailable: the choice lasts for this page only
  }
  document.documentElement.setAttribute('data-theme-choice', choice);
  applyTheme();
  render();
}

/** Navigates to an in-app address (re-renders when it is already current). */
export function go(hash: string): void {
  if (location.hash === hash) render();
  else location.hash = hash;
}
