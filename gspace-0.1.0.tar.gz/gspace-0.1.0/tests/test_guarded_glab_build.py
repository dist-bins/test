"""Pinned public-source builder safety; native HTTP journeys are tested separately."""

import io
import json
import tarfile
from pathlib import Path

import pytest

from scripts import build_guarded_glab as guarded


def archive(tmp_path, entries):
    target = tmp_path / "public.tar.gz"
    with tarfile.open(target, "w:gz") as bundle:
        for name, kind, content in entries:
            member = tarfile.TarInfo(name)
            member.type = kind
            if kind == tarfile.REGTYPE:
                member.size = len(content)
                bundle.addfile(member, io.BytesIO(content))
            else:
                member.linkname = content.decode()
                bundle.addfile(member)
    return target


def test_public_manifest_pins_official_exact_source_and_reviewed_client():
    manifest = guarded.source_manifest()
    assert manifest["commit"] == "80d3449c6bf1915a32cd8c029117e51c2e3dc9ee"
    assert (
        manifest["archive_sha256"]
        == "e1e0baf6626f4a25a5e3da190d4b166a365d2417794d475566376593eed3f6c6"
    )
    assert (
        manifest["client_sha256"]
        == "8f0f88cf3333b792f8f000212709269a89fdb284b9a2eb93e992d0383cc49e3c"
    )


@pytest.mark.parametrize(
    "key,value",
    [
        ("archive_url", "https://example.org/source"),
        ("archive_root", "../escape"),
        ("commit", "main"),
        ("archive_sha256", "latest"),
        ("client_sha256", "bad"),
    ],
)
def test_manifest_rejects_unpinned_source(tmp_path, key, value):
    manifest = guarded.source_manifest()
    manifest[key] = value
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(manifest))
    with pytest.raises(guarded.BuildError):
        guarded.source_manifest(path)


def test_archive_hash_must_match_before_source_can_be_used(tmp_path):
    target = tmp_path / "public.tar.gz"
    target.write_bytes(b"different public source")
    with pytest.raises(guarded.BuildError, match="SHA256"):
        guarded.verify_archive(target, "0" * 64)
    guarded.verify_archive(target, guarded.sha256(target.read_bytes()))
    linked = tmp_path / "linked.tar.gz"
    linked.symlink_to(target)
    with pytest.raises(guarded.BuildError, match="linked"):
        guarded.verify_archive(linked, guarded.sha256(target.read_bytes()))


@pytest.mark.parametrize(
    "name,kind",
    [
        ("/source/outside", tarfile.REGTYPE),
        ("source/../outside", tarfile.REGTYPE),
        ("source/./inside", tarfile.REGTYPE),
        ("source//inside", tarfile.REGTYPE),
        ("source\\outside", tarfile.REGTYPE),
        ("other/file", tarfile.REGTYPE),
        ("source/link", tarfile.SYMTYPE),
        ("source/hard", tarfile.LNKTYPE),
        ("source/device", tarfile.CHRTYPE),
        ("source/fifo", tarfile.FIFOTYPE),
    ],
)
def test_extraction_rejects_escape_links_and_special_files_before_writing(tmp_path, name, kind):
    target = archive(tmp_path, [(name, kind, b"content")])
    destination = tmp_path / "owned"
    with pytest.raises(guarded.BuildError):
        guarded.extract_source(target, destination, "source")
    assert not destination.exists()
    assert not (tmp_path / "outside").exists()


def test_extraction_rejects_duplicate_members(tmp_path):
    target = archive(
        tmp_path,
        [("source/file", tarfile.REGTYPE, b"one"), ("source/file", tarfile.REGTYPE, b"two")],
    )
    with pytest.raises(guarded.BuildError, match="duplicate"):
        guarded.extract_source(target, tmp_path / "owned", "source")


def test_extraction_has_finite_uncompressed_and_member_limits(tmp_path, monkeypatch):
    target = archive(tmp_path, [("source/file", tarfile.REGTYPE, b"12345")])
    monkeypatch.setattr(guarded, "MAX_SOURCE_BYTES", 4)
    with pytest.raises(guarded.BuildError, match="finite"):
        guarded.extract_source(target, tmp_path / "owned", "source")
    monkeypatch.setattr(guarded, "MAX_SOURCE_BYTES", 100)
    monkeypatch.setattr(guarded, "MAX_MEMBERS", 0)
    with pytest.raises(guarded.BuildError, match="finite"):
        guarded.extract_source(target, tmp_path / "owned", "source")


def test_archive_inflation_is_bounded_before_tar_metadata_parsing(tmp_path, monkeypatch):
    target = archive(tmp_path, [("source/file", tarfile.REGTYPE, b"12345")])
    monkeypatch.setattr(guarded, "MAX_TAR_BYTES", 100)
    with pytest.raises(guarded.BuildError, match="inflated"):
        guarded.extract_source(target, tmp_path / "owned", "source")
    assert not (tmp_path / "owned").exists()


def test_regular_source_content_is_extracted_without_archive_permissions(tmp_path):
    target = archive(
        tmp_path,
        [
            ("source/dir", tarfile.DIRTYPE, b""),
            ("source/dir/file.go", tarfile.REGTYPE, b"public source"),
        ],
    )
    extracted = guarded.extract_source(target, tmp_path / "owned", "source")
    assert (extracted / "dir/file.go").read_bytes() == b"public source"
    with pytest.raises(guarded.BuildError, match="new owned"):
        guarded.extract_source(target, tmp_path / "owned", "source")


def test_patch_is_unconditional_and_precedes_native_auth_initialization():
    original = (
        "prefix\n"
        + guarded.PATCH_ANCHOR
        + "\n\tauthSource, err := newAuthSource(client.httpClient)\n"
    ).encode()
    patched = guarded.patch_client(original, guarded.sha256(original)).decode()
    assert (
        patched.index("initializeHTTPClient")
        < patched.index("CheckRedirect")
        < patched.index("newAuthSource")
    )
    assert 'errors.New("gspace-no-redirects.1: redirects are disabled")' in patched
    assert "ErrUseLastResponse" not in patched
    assert "Getenv" not in patched
    with pytest.raises(guarded.BuildError, match="hash"):
        guarded.patch_client(original + b"changed", guarded.sha256(original))
    for source in (b"no anchor", original + guarded.PATCH_ANCHOR.encode()):
        with pytest.raises(guarded.BuildError, match="anchor"):
            guarded.patch_client(source, guarded.sha256(source))


def test_build_environment_does_not_inherit_auth_proxy_or_go_settings(tmp_path, monkeypatch):
    monkeypatch.setenv("GITLAB_TOKEN", "synthetic-secret")
    monkeypatch.setenv("HTTPS_PROXY", "http://untrusted.invalid")
    monkeypatch.setenv("GOFLAGS", "-overlay=untrusted")
    monkeypatch.setenv("HOME", "/not-the-build-home")
    environment = guarded.isolated_environment(
        tmp_path / "run", tmp_path / "cache", Path("/toolchain/bin/go")
    )
    assert (
        not {"GITLAB_TOKEN", "HTTPS_PROXY", "GOFLAGS", "SSH_AUTH_SOCK", "NETRC"}
        & environment.keys()
    )
    assert environment["HOME"] == str(tmp_path / "run/home")
    assert environment["GOENV"] == environment["GOAUTH"] == "off"
    assert environment["GOTOOLCHAIN"] == "local"
    assert environment["GOVCS"] == "*:off"
    assert environment["GOPROXY"] == "https://proxy.golang.org"
    assert environment["GOSUMDB"] == "sum.golang.org"
    assert environment["CGO_ENABLED"] == "0"


def test_output_cannot_replace_unowned_binary_or_traverse_link(tmp_path):
    target = tmp_path / "gspace-glab"
    assert guarded.checked_output(target) == target
    target.write_bytes(b"unrelated binary")
    with pytest.raises(guarded.BuildError, match="ownership"):
        guarded.checked_output(target)
    target.with_name("gspace-glab.manifest.json").write_text(
        json.dumps(
            {"identity": guarded.IDENTITY, "binary_sha256": guarded.sha256(target.read_bytes())}
        )
    )
    assert guarded.checked_output(target) == target
    target.write_bytes(b"changed binary")
    with pytest.raises(guarded.BuildError, match="differs"):
        guarded.checked_output(target)
    linked = tmp_path / "linked"
    linked.symlink_to(tmp_path, target_is_directory=True)
    with pytest.raises(guarded.BuildError, match="symbolic"):
        guarded.checked_output(linked / "gspace-glab")


@pytest.mark.parametrize("suffix", [".manifest.json", ".build.log", ".LICENSE"])
def test_output_sidecars_cannot_follow_symlinks(tmp_path, suffix):
    protected = tmp_path / "unrelated"
    protected.write_bytes(b"preserve")
    (tmp_path / ("gspace-glab" + suffix)).symlink_to(protected)
    with pytest.raises(guarded.BuildError, match="sidecars"):
        guarded.checked_output(tmp_path / "gspace-glab")
    assert protected.read_bytes() == b"preserve"
