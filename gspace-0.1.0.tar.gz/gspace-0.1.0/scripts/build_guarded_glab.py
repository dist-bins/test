"""Build a private redirect-refusing glab from verified public source only.

The pinned reference clone and operator authentication are never read or changed.
Only Go compilation and a credential-free version probe execute upstream code.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
SOURCE_MANIFEST = ROOT / "integration/glab-guard.json"
IDENTITY = "gspace-no-redirects.1"
VERSION = "0.0.0-" + IDENTITY
MAX_ARCHIVE_BYTES = 32_000_000
MAX_SOURCE_BYTES = 96_000_000
MAX_TAR_BYTES = 128_000_000
MAX_MEMBERS = 6000
PATCH_ANCHOR = """\tif err := client.initializeHTTPClient(); err != nil {
\t\treturn nil, err
\t}
"""
PATCH = """
\t// GSpace private build: refuse redirects before any API or OAuth request.
\tclient.httpClient.CheckRedirect = func(_ *http.Request, _ []*http.Request) error {
\t\treturn errors.New("gspace-no-redirects.1: redirects are disabled")
\t}
"""


class BuildError(ValueError):
    """A pinned-source, extraction, build or ownership precondition failed."""


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def source_manifest(path: Path = SOURCE_MANIFEST) -> dict[str, str]:
    raw = json.loads(path.read_text())
    keys = {"commit", "archive_url", "archive_sha256", "archive_root", "client_sha256"}
    if not isinstance(raw, dict) or set(raw) != keys:
        raise BuildError("Invalid public glab source manifest")
    if any(not isinstance(value, str) for value in raw.values()):
        raise BuildError("Public glab source manifest must contain strings")
    commit = raw["commit"]
    if not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise BuildError("Invalid pinned glab commit")
    expected_root = "cli-" + commit
    expected_url = (
        "https://gitlab.com/gitlab-org/cli/-/archive/" + commit + "/" + expected_root + ".tar.gz"
    )
    if raw["archive_url"] != expected_url or raw["archive_root"] != expected_root:
        raise BuildError("Only the exact official pinned glab archive is allowed")
    if any(
        not re.fullmatch(r"[0-9a-f]{64}", raw[key]) for key in ("archive_sha256", "client_sha256")
    ):
        raise BuildError("Invalid pinned glab source hash")
    return raw


def isolated_environment(work: Path, cache: Path, executable: Path) -> dict[str, str]:
    """Never inherit credentials, proxy settings, host HOME or Go configuration."""
    home = work / "home"
    home.mkdir(parents=True, exist_ok=True)
    return {
        "PATH": str(executable.parent) + os.pathsep + "/usr/bin:/bin",
        "HOME": str(home),
        "XDG_CONFIG_HOME": str(home / "config"),
        "GLAB_CONFIG_DIR": str(home / "glab"),
        "GOCACHE": str(cache / "go-build"),
        "GOMODCACHE": str(cache / "modules"),
        "GOPATH": str(cache / "gopath"),
        "GOENV": "off",
        "GOTOOLCHAIN": "local",
        "GOVCS": "*:off",
        "GOPROXY": "https://proxy.golang.org",
        "GOSUMDB": "sum.golang.org",
        "GOAUTH": "off",
        "CGO_ENABLED": "0",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": os.devnull,
        "GLAB_CHECK_UPDATE": "false",
        "CHECK_UPDATE": "false",
        "GLAB_SEND_TELEMETRY": "false",
        "GLAB_NO_PROMPT": "true",
        "LANG": "C",
        "TZ": "UTC",
    }


def verify_archive(archive: Path, expected_hash: str) -> None:
    if archive.is_symlink() or not archive.is_file() or archive.stat().st_size > MAX_ARCHIVE_BYTES:
        raise BuildError("Public source archive is missing, linked or oversized")
    if sha256(archive.read_bytes()) != expected_hash:
        raise BuildError("Public source archive SHA256 differs from the pinned manifest")


def extract_source(archive: Path, destination: Path, prefix: str) -> Path:
    """Extract only bounded regular files/directories, without tar extraction APIs."""
    if destination.exists():
        raise BuildError("Source extraction requires a new owned directory")
    with tempfile.TemporaryFile(dir=destination.parent) as unpacked:
        # Bound gzip inflation before tarfile parses variable-size metadata.
        with gzip.open(archive, "rb") as compressed:
            remaining = MAX_TAR_BYTES + 1
            while block := compressed.read(min(65536, remaining)):
                remaining -= len(block)
                if remaining == 0:
                    raise BuildError("Public source archive inflated beyond finite limits")
                unpacked.write(block)
        unpacked.seek(0)
        with tarfile.open(fileobj=unpacked, mode="r:") as bundle:
            return _extract_members(bundle, destination, prefix)


def _extract_members(bundle: tarfile.TarFile, destination: Path, prefix: str) -> Path:
    members = []
    total = 0
    seen = set()
    for member in bundle:
        parts = PurePosixPath(member.name).parts
        if (
            not parts
            or parts[0] != prefix
            or member.name.startswith("/")
            or any(part in ("", ".", "..") for part in member.name.rstrip("/").split("/"))
            or "\\" in member.name
            or not (member.isfile() or member.isdir())
            or member.name.rstrip("/") in seen
        ):
            raise BuildError("Unsafe or duplicate public source archive member")
        seen.add(member.name.rstrip("/"))
        total += member.size
        members.append(member)
        if len(members) > MAX_MEMBERS or total > MAX_SOURCE_BYTES or member.size < 0:
            raise BuildError("Public source extraction exceeds finite limits")
    destination.mkdir()
    for member in members:
        target = destination.joinpath(*PurePosixPath(member.name).parts)
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        content = bundle.extractfile(member)
        if content is None:
            raise BuildError("Public source archive member has no regular content")
        with content, target.open("xb") as output:
            remaining = member.size
            while remaining:
                block = content.read(min(65536, remaining))
                if not block:
                    raise BuildError("Public source archive member is truncated")
                output.write(block)
                remaining -= len(block)
    return destination / prefix


def patch_client(original: bytes, expected_hash: str) -> bytes:
    if sha256(original) != expected_hash:
        raise BuildError("Pinned native HTTP client source differs from the reviewed hash")
    source = original.decode("utf-8")
    if source.count(PATCH_ANCHOR) != 1 or IDENTITY in source:
        raise BuildError("Pinned native HTTP client patch anchor is ambiguous")
    return source.replace(PATCH_ANCHOR, PATCH_ANCHOR + PATCH, 1).encode()


def checked_output(path: Path) -> Path:
    target = Path(os.path.abspath(path))
    if target.name != "gspace-glab":
        raise BuildError("Private tool output must be named gspace-glab")
    for parent in (target, *target.parents):
        if parent.is_symlink():
            raise BuildError("Private tool output must not traverse symbolic links")
    if target.is_relative_to(ROOT / ".repos"):
        raise BuildError("Reference clones cannot contain build output")
    for suffix in (".manifest.json", ".LICENSE", ".build.log"):
        sidecar = target.with_name(target.name + suffix)
        if sidecar.is_symlink() or (sidecar.exists() and not sidecar.is_file()):
            raise BuildError("Private tool sidecars must be regular owned files")
    manifest_path = target.with_name(target.name + ".manifest.json")
    if target.exists():
        if not manifest_path.is_file() or manifest_path.is_symlink():
            raise BuildError("Existing private tool has no ownership manifest")
        existing = json.loads(manifest_path.read_text())
        if existing.get("identity") != IDENTITY or existing.get("binary_sha256") != sha256(
            target.read_bytes()
        ):
            raise BuildError("Existing private tool differs from its ownership manifest")
    return target


def build(output: Path, archive_path: Path | None = None) -> dict:
    manifest = source_manifest()
    output = checked_output(output)
    go_name = shutil.which("go")
    curl_name = shutil.which("curl")
    if go_name is None or (archive_path is None and curl_name is None):
        raise BuildError(
            "An installed Go 1.27+ toolchain and curl are required; no automatic install"
        )
    go = Path(go_name).resolve()
    cache = ROOT / ".state/guarded-glab-build"
    if any(parent.is_symlink() for parent in (cache, *cache.parents)):
        raise BuildError("Build cache must not traverse symbolic links")
    cache.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="run-", dir=cache) as temporary:
        work = Path(temporary)
        env = isolated_environment(work, cache, go)
        toolchain = subprocess.run(
            [str(go), "version"], env=env, check=True, capture_output=True, text=True
        ).stdout.strip()
        match = re.search(r"go(\d+)\.(\d+)(?:\.(\d+))? ", toolchain)
        if match is None or (int(match[1]), int(match[2])) < (1, 27):
            raise BuildError("Pinned glab source requires an installed Go 1.27+ toolchain")
        archive = archive_path or work / "source.tar.gz"
        if archive_path is None:
            subprocess.run(
                [
                    str(curl_name),
                    "--disable",
                    "--noproxy",
                    "*",
                    "--fail",
                    "--silent",
                    "--show-error",
                    "--proto",
                    "=https",
                    "--max-time",
                    "120",
                    "--max-filesize",
                    str(MAX_ARCHIVE_BYTES),
                    "--output",
                    str(archive),
                    manifest["archive_url"],
                ],
                env=env,
                check=True,
                timeout=130,
            )
        verify_archive(archive, manifest["archive_sha256"])
        source = extract_source(archive, work / "source", manifest["archive_root"])
        client = source / "internal/api/client.go"
        original = client.read_bytes()
        patched = patch_client(original, manifest["client_sha256"])
        client.write_bytes(patched)
        staged = work / "gspace-glab"
        argv = [
            str(go),
            "build",
            "-trimpath",
            "-buildvcs=false",
            "-mod=readonly",
            "-p=2",
            "-ldflags",
            "-s -w -buildid= -X main.version=" + VERSION + " -X main.commit=" + manifest["commit"],
            "-o",
            str(staged),
            "./cmd/glab",
        ]
        output.parent.mkdir(parents=True, exist_ok=True)
        log_path = output.with_name(output.name + ".build.log")
        with log_path.open("w") as log:
            subprocess.run(
                argv,
                cwd=source,
                env=env,
                check=True,
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=900,
            )
        version = subprocess.run(
            [str(staged), "--version"],
            cwd=work,
            env=env,
            check=True,
            capture_output=True,
            text=True,
            timeout=10,
        ).stdout.strip()
        if VERSION not in version:
            raise BuildError("Private glab binary did not report its guarded build identity")
        result = {
            "purpose": "Private native glab build with unconditional redirect refusal",
            "identity": IDENTITY,
            "version": VERSION,
            "source": manifest,
            "patch_sha256": sha256(PATCH.encode()),
            "patched_client_sha256": sha256(patched),
            "binary_sha256": sha256(staged.read_bytes()),
            "toolchain": toolchain,
            "version_output": version,
            "build_arguments": argv[1:-2] + ["<private-output>", "./cmd/glab"],
            "authentication": "Unchanged upstream native authentication",
            "published": False,
        }
        output.with_name(output.name + ".LICENSE").write_bytes((source / "LICENSE").read_bytes())
        os.replace(staged, output)
        output.with_name(output.name + ".manifest.json").write_text(
            json.dumps(result, indent=2) + "\n"
        )
        return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "dist/tools/gspace-glab")
    parser.add_argument(
        "--source-archive",
        type=Path,
        help="Use an already downloaded exact pinned public source archive",
    )
    arguments = parser.parse_args()
    try:
        result = build(arguments.output, arguments.source_archive)
    except (BuildError, OSError, subprocess.SubprocessError, tarfile.TarError) as error:
        parser.exit(2, f"Guarded glab build failed: {error}\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
