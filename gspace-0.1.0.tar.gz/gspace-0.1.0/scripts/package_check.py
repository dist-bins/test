"""Verify an offline wheel install and real CLI/web launch outside the source directory."""

from __future__ import annotations

import argparse
import json
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import tomllib
from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile

from install import environment as installation_environment
from install import verify_notices


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--uv-cache", type=Path, default=Path(".state/install/uv-cache"))
    parser.add_argument("--no-build", action="store_true", help="Verify existing current artifacts")
    parser.add_argument(
        "--report", type=Path, default=Path("docs/verification/package-report.json")
    )
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    report_path = args.report.resolve()
    environment = {**installation_environment(), "UV_CACHE_DIR": str(args.uv_cache.resolve())}

    def run(argv: list[str], cwd: Path, environment_overrides: dict[str, str] | None = None) -> str:
        try:
            result = subprocess.run(
                argv,
                cwd=cwd,
                env={**environment, **(environment_overrides or {})},
                capture_output=True,
                text=True,
                timeout=600,
                check=True,
            )
        except subprocess.CalledProcessError as error:
            raise RuntimeError(
                error.stderr or error.stdout or "Packaging command failed"
            ) from error
        return result.stdout

    if not args.no_build:
        run([sys.executable, "scripts/build_current.py"], root)
    source_archive = root / "dist/gspace-0.1.0.tar.gz"
    with tarfile.open(source_archive) as source:
        source_entries = source.getnames()
        assert "gspace-0.1.0/poe_tasks.toml" not in source_entries
        assert "gspace-0.1.0/gspace.example.toml" in source_entries
        assert "gspace-0.1.0/frontend-new/src/app.ts" in source_entries
        assert "gspace-0.1.0/uv.lock" in source_entries
        assert "gspace-0.1.0/src/gspace/licenses/manifest.json" in source_entries
        assert not any(".repos/" in name or ".state/" in name for name in source_entries)
        task_file = source.extractfile("gspace-0.1.0/pyproject.toml")
        assert task_file is not None
        poe = tomllib.loads(task_file.read().decode())["tool"]["poe"]
        assert "include" not in poe and "check" in poe["tasks"]
    wheel = root / "dist/gspace-0.1.0-py3-none-any.whl"
    verify_notices(wheel, root)
    with ZipFile(wheel) as archive:
        entries = archive.namelist()
        assert all(name.startswith(("gspace/", "gspace-0.1.0.dist-info/")) for name in entries)
        assets = (
            "index.html",
            "app.js",
            "styles.css",
            "theme.js",
            "icon.svg",
            "gspace-wolf.svg",
            "gspace-wolf-gray.svg",
        )
        for asset in assets:
            assert f"gspace/static/{asset}" in entries
            assert (
                archive.read(f"gspace/static/{asset}")
                == (root / "frontend-new" / asset).read_bytes()
            )
        bundled_index = archive.read("gspace/static/index.html")
        assert not any(".repos/" in name or "__pycache__" in name for name in entries)
        assert "gspace/cli_render.py" in entries
        assert "gspace/cli_commands.py" in entries
    with tempfile.TemporaryDirectory(prefix="gspace-package-") as temporary:
        directory = Path(temporary)
        installed = directory / "environment"
        launch_directory = directory / "unrelated-working-directory"
        config_directory = directory / "operator-config"
        launch_directory.mkdir()
        config_directory.mkdir()
        configuration = config_directory / "demo.toml"
        configuration.write_text(
            'mode = "fixture"\npreferences_path = "preferences.toml"\ncache_path = "cache.json"\n'
        )
        run(["uv", "venv", "--python", sys.executable, str(installed)], launch_directory)
        python = installed / "bin/python"
        cli = installed / "bin/gspace"
        run(
            [
                "uv",
                "sync",
                "--locked",
                "--offline",
                "--no-dev",
                "--no-install-project",
                "--python",
                str(python),
                "--no-config",
            ],
            root,
            {"UV_PROJECT_ENVIRONMENT": str(installed)},
        )
        run(
            ["uv", "pip", "install", "--offline", "--no-deps", "--python", str(python), str(wheel)],
            root,
        )
        location = run(
            [str(python), "-c", "import gspace; print(gspace.__file__)"], launch_directory
        )
        assert str(installed) in location and str(root / "src") not in location
        assert run([str(cli), "--version"], launch_directory).strip() == "GSpace 0.1.0"
        data = json.loads(
            run([str(cli), "dashboard", "--config", str(configuration), "--json"], launch_directory)
        )
        assert len(data["views"]) == 4 and data["total"] == 7
        graph = json.loads(
            run(
                [str(cli), "pipelines", "graph", "42:791", "-c", str(configuration), "-j", "-N"],
                launch_directory,
            )
        )
        assert graph["source"] == "fixture" and len(graph["edges"]) == 1
        assert graph["nodes"][-1]["reference"]["key"]["project"]["value"] == 99
        assert graph["application_binding"] == "edge_does_not_prove_deployed_application_version"
        presentation_checks: list[str] = [
            "installed native graph with separate downstream project and application identity"
        ]
        concise_help = run([str(cli)], launch_directory)
        assert "Daily" in concise_help and "Compatibility aliases" not in concise_help
        assert "Subcommands" not in concise_help and "settings_set" not in concise_help
        presentation_checks.append("installed no-argument help from unrelated directory")
        nested_help = run([str(cli), "pipelines", "list", "--help"], launch_directory)
        assert "gspace pipelines list" in nested_help and "pipeline_catalog" not in nested_help
        presentation_checks.append("installed nested resource help")
        compact_list = run([str(cli), "list", "--config", str(configuration)], launch_directory)
        assert "Work-item list" in compact_list and "Merge requests" not in compact_list
        assert all(f"42:{iid}" in compact_list for iid in (791, 792, 793, 794))
        presentation_checks.append("installed compact list with full scoped identities")
        short_data = json.loads(
            run(
                [str(cli), "dashboard", "-c", str(configuration), "-j", "-N", "-p", "42"],
                launch_directory,
            )
        )
        assert len(short_data["views"]) == 4 and short_data["total"] == 7
        presentation_checks.append("installed short config JSON no-color and project aliases")
        plain = run(
            [str(cli), "dashboard", "-c", str(configuration), "-j", "-J", "-N", "-w", "80"],
            launch_directory,
        )
        assert "GSpace" in plain and "\x1b" not in plain
        presentation_checks.append("installed negative JSON alias with short width and no-color")
        catalog = json.loads(
            run(
                [str(cli), "pipelines", "list", "-c", str(configuration), "-p", "42", "-j"],
                launch_directory,
            )
        )
        assert catalog["source"] == "fixture"
        presentation_checks.append("installed nested pipeline aliases and clean JSON")
        for width in (80, 120, 160):
            for orientation in ("rows", "columns"):
                rendered = run(
                    [
                        str(cli),
                        "dashboard",
                        "--config",
                        str(configuration),
                        "--width",
                        str(width),
                        "--orientation",
                        orientation,
                        "--no-color",
                    ],
                    launch_directory,
                )
                assert "\x1b" not in rendered and "…" not in rendered
                assert all(len(line) <= width for line in rendered.splitlines())
                assert all(
                    view["item"]["identity"]["project"]["value"] == 42 for view in data["views"]
                )
                assert all(f"42:{iid}" in rendered for iid in (791, 792, 793, 794))
                assert "failed" in rendered and "success" in rendered and "mismatch" in rendered
                presentation_checks.append(
                    f"installed semantic {orientation} matrix at{width} columns"
                )
        help_text = run([str(cli), "dashboard", "--help"], launch_directory)
        assert "Raw JSON stdout" in help_text and "process columns" in help_text
        milestones = json.loads(
            run(
                [str(cli), "milestones", "--config", str(configuration), "--json"], launch_directory
            )
        )
        assert milestones["issue_coverage"] == "complete_configured_projects"
        assert len(milestones["entries"]) == 4
        settings = json.loads(
            run([str(cli), "settings", "--config", str(configuration), "--json"], launch_directory)
        )
        settings["settings"]["timezone"] = "UTC"
        settings["settings"]["pipeline"]["environments"].append(
            {"name": "qa", "label": "Quality assurance", "ref_source": "branch"}
        )
        settings_change = directory / "settings-change.json"
        settings_change.write_text(
            json.dumps(
                {
                    "revision": settings["revision"],
                    "settings": settings["settings"],
                }
            )
        )
        saved_settings = json.loads(
            run(
                [
                    str(cli),
                    "settings-set",
                    "--config",
                    str(configuration),
                    str(settings_change),
                    "--json",
                ],
                launch_directory,
            )
        )
        assert saved_settings["settings"]["timezone"] == "UTC"
        manual_result = directory / "manual-result.json"
        manual_result.write_text(
            json.dumps(
                {
                    "key": data["views"][0]["item"]["identity"],
                    "environment": "dev",
                    "version": data["views"][0]["application_tests"][0]["target"],
                    "outcome": "passed",
                    "checked_at": "2026-10-06T09:00:00+00:00",
                    "source": "operator",
                    "notes": "Isolated installed-package synthetic check",
                }
            )
        )
        run(
            [str(cli), "app-test", "--config", str(configuration), str(manual_result), "--json"],
            launch_directory,
        )
        branches = json.loads(
            run(
                [str(cli), "branches", "--config", str(configuration), "--project", "42", "--json"],
                launch_directory,
            )
        )
        assert branches["coverage_basis"] == "synthetic_fixture"
        assert any(row["branch"]["name"] == "main" for row in branches["rows"])
        pipelines = json.loads(
            run(
                [str(cli), "pipeline-catalog", "--config", str(configuration), "--json"],
                launch_directory,
            )
        )
        assert pipelines["pipeline_sources"] == "default_and_child"
        assert all(row["jobs_coverage"] == "not_loaded" for row in pipelines["rows"])
        history = json.loads(
            run(
                [
                    str(cli),
                    "app-history",
                    "42:791",
                    "--config",
                    str(configuration),
                    "--environment",
                    "dev",
                    "--json",
                ],
                launch_directory,
            )
        )
        assert history["entries"][0]["state"] == "current"
        rich_history = run(
            [
                str(cli),
                "app-history",
                "42:791",
                "--config",
                str(configuration),
                "--no-color",
                "--width",
                "100",
            ],
            launch_directory,
        )
        assert "current" in rich_history and "\x1b" not in rich_history
        run(
            [str(cli), "select", "--config", str(configuration), "42:791", "--json"],
            launch_directory,
        )
        bookmark = {
            "host": "fixture",
            "reference": {"kind": "work_item", "key": data["views"][0]["item"]["identity"]},
            "label": "Flight",
        }
        bookmark_file = directory / "bookmark.json"
        bookmark_file.write_text(json.dumps(bookmark))
        run(
            [str(cli), "bookmark-set", "-c", str(configuration), str(bookmark_file), "-j"],
            launch_directory,
        )
        decoration = {
            "target": {"kind": "bookmark", "host": "fixture", "reference": bookmark["reference"]},
            "icon": "rocket",
            "color": "teal",
            "pinned": True,
            "order": 4,
        }
        decoration_file = directory / "decoration.json"
        decoration_file.write_text(json.dumps(decoration))
        run(
            [
                str(cli),
                "navigation",
                "set",
                "-c",
                str(configuration),
                str(decoration_file),
                "-j",
                "-N",
            ],
            launch_directory,
        )
        navigation = json.loads(
            run([str(cli), "navigation", "list", "-c", str(configuration), "-j"], launch_directory)
        )
        assert navigation["decorations"] == [decoration]
        presentation_checks.append("installed scoped navigation CLI with shared atomic TOML")
        assert (config_directory / "preferences.toml").exists()
        assert not (launch_directory / "preferences.toml").exists()
        with socket.socket() as allocator:
            allocator.bind(("127.0.0.1", 0))
            port = allocator.getsockname()[1]
        server = subprocess.Popen(
            [str(cli), "serve", "--config", str(configuration), "--port", str(port)],
            cwd=launch_directory,
            env=environment,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            base = f"http://127.0.0.1:{port}"
            for _ in range(100):
                if server.poll() is not None:
                    raise RuntimeError("Installed web server exited")
                try:
                    with urlopen(base + "/api/dashboard", timeout=0.2) as response:
                        loaded = json.load(response)
                        assert loaded["preferences"]["selected"][0]["issue"]["value"] == 791
                        break
                except OSError:
                    time.sleep(0.1)
            else:
                raise RuntimeError("Installed web server did not start")
            with urlopen(base, timeout=2) as response:
                assert response.read() == bundled_index
            with urlopen(base + "/api/navigation", timeout=2) as response:
                assert json.load(response) == navigation
            assert "navigation_decorations" not in loaded["preferences"]
            with urlopen(base + "/api/projects/42/presentation", timeout=2) as response:
                presentation = json.load(response)
                assert presentation["avatar"]["kind"] == "fallback"
                assert presentation["avatar_src"] == "/api/projects/42/avatar"
            with urlopen(base + "/api/projects/42/avatar", timeout=2) as response:
                assert response.headers["Content-Type"].startswith("image/svg+xml")
                assert response.headers["Content-Security-Policy"] == "default-src 'none'; sandbox"
                assert response.read() == (root / "src/gspace/static/icon.svg").read_bytes()
            presentation_checks.extend(
                [
                    "installed navigation API and legacy preference projection",
                    "installed packaged avatar fallback and restrictive binary CSP",
                ]
            )
            with urlopen(base + "/api/merge-requests", timeout=2) as response:
                catalog = json.load(response)
                assert catalog["total"] == len(catalog["rows"])
                assert catalog["coverage"] == "configured_projects"
            with urlopen(base + "/api/capabilities", timeout=2) as response:
                assert json.load(response)["write_scope"] == "disabled"
            with urlopen(base + "/api/settings", timeout=2) as response:
                assert json.load(response)["revision"] == saved_settings["revision"]
            assert "environment:qa" in loaded["columns"]
            assert any(d["name"] == "qa" for d in loaded["environment_columns"])
            with urlopen(base + "/api/branches?project=42", timeout=2) as response:
                assert json.load(response)["total"] == branches["total"]
            with urlopen(base + "/api/pipelines", timeout=2) as response:
                assert json.load(response)["total"] == pipelines["total"]
            with urlopen(
                base + "/api/items/42/791/application-tests?environment=dev", timeout=2
            ) as response:
                assert json.load(response)["entries"] == history["entries"]
            with urlopen(base + "/openapi.json", timeout=2) as response:
                contract = json.load(response)
                assert "/api/access/compare" in contract["paths"]
                assert "ProbeComparisonRequest" in contract["components"]["schemas"]
            with urlopen(base + "/api/milestones", timeout=2) as response:
                assert json.load(response)["timezone"] == "UTC"
            with urlopen(base + "/api/items/42/791", timeout=2) as response:
                test = json.load(response)["application_tests"][0]
                assert test["outcome"] == "passed" and test["current"]["source"] == "operator"
            for asset in assets[1:]:
                with urlopen(base + "/assets/" + asset, timeout=2) as response:
                    assert response.status == 200
                    assert response.read() == (root / "frontend-new" / asset).read_bytes()
        finally:
            server.terminate()
            server.wait(timeout=10)
    report = {
        "result": "passed",
        "python": sys.version.split()[0],
        "wheel": wheel.name,
        "archive_entries": entries,
        "source_archive": source_archive.name,
        "source_archive_has_poe_tasks": True,
        "current_frontend_and_bundled_publisher_notices": True,
        "checks": [
            "offline isolated noneditable install",
            "no upstream content or bytecode",
            "source archive includes Poe tasks and operator example",
            "installed typed MR catalog and disabled default writes",
            "bundled static assets",
            "installed console entrypoint from unrelated cwd",
            "configuration-relative preference paths",
            "shared CLI/web selection",
            "installed loopback web/API/assets from unrelated cwd",
            "installed typed milestone catalog and complete coverage",
            "installed atomic settings command and shared API revision",
            "installed exact-version manual outcome shared with web API",
            "installed general branch and pipeline CLI/API catalogs",
            "installed Rich and JSON version-aware manual test history",
            "installed custom environment column descriptors",
            "installed typed GET-only comparison API contract",
            "installed pure presentation module and descriptive help",
            *presentation_checks,
        ],
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
