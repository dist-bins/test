FROM gitlab/gitlab-runner:v18.11.0@sha256:816e7c594a8c319856a710283ed7fba7a9f633cbfe6b167b0632ea3dec101fee
USER root
# Fail rather than silently adding packages or changing the base toolchain.
RUN command -v git && command -v bash && command -v sha256sum \
    && install -d -o gitlab-runner -g gitlab-runner /lab /lab/artifacts /lab/projects /lab/attempts
# The official entrypoint runs shell jobs as gitlab-runner, not host root.
# No Docker socket, privileged executor, host directory, or nested Docker.

