"""Reproduce current validator/app attribution without modifying delivered or recovery assets."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend-new"


def digest(path: Path) -> str:
    if path.is_symlink():
        raise ValueError("Bundle provenance refuses linked input files")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned_path(path: Path, root: Path) -> None:
    if not path.is_relative_to(root) or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Bundle provenance input escapes the owned project")
    for parent in (path, *path.parents):
        if parent == root:
            break
        if parent.is_symlink():
            raise ValueError("Bundle provenance refuses linked input files")


def source_inputs(root: Path, frontend: Path) -> dict[str, str]:
    paths = [
        path
        for name in ("src", "contracts")
        for path in (frontend / name).rglob("*")
        if path.is_file() and path.suffix in (".ts", ".js", ".json")
    ]
    paths.extend(frontend / name for name in ("package.json", "package-lock.json", "tsconfig.json"))
    paths.extend(
        root / name
        for name in ("scripts/generate_frontend_contract.mjs", "scripts/bundle_provenance.py")
    )
    for path in paths:
        owned_path(path, root)
    return {str(path.relative_to(root)): digest(path) for path in sorted(paths)}


def verify_inputs(root: Path, frozen: dict[str, str]) -> None:
    for name, expected in frozen.items():
        path = root / name
        owned_path(path, root)
        if digest(path) != expected:
            raise RuntimeError("Bundle provenance input changed during reproduction")


def run(arguments: list[str], cwd: Path) -> str:
    result = subprocess.run(
        arguments,
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
        timeout=120,
        env={"PATH": os.environ.get("PATH", os.defpath), "DO_NOT_TRACK": "1"},
    )
    return result.stdout.strip()


def canonical_metafile(payload: bytes, stage: Path, generated: Path) -> bytes:
    """Remove temporary and machine-specific prefixes, retaining module/input semantics."""
    roots = (
        (str(stage.resolve()) + "/", ""),
        (str(generated.resolve()) + "/", ""),
        (str(ROOT.resolve()) + "/", ""),
    )

    def normalize(value: object) -> object:
        if isinstance(value, dict):
            return {str(normalize(key)): normalize(item) for key, item in value.items()}
        if isinstance(value, list):
            return [normalize(item) for item in value]
        if isinstance(value, str):
            for prefix, replacement in roots:
                if value.startswith(prefix):
                    return replacement + value[len(prefix) :]
        return value

    return (json.dumps(normalize(json.loads(payload)), indent=2, sort_keys=True) + "\n").encode()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=FRONTEND)
    parser.add_argument("--toolchain", type=Path, default=FRONTEND)
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/dependency-inventory/bundled"
    )
    args = parser.parse_args()
    assets, toolchain, destination = (
        args.assets.absolute(),
        args.toolchain.absolute(),
        args.output.absolute(),
    )
    for path in (assets, toolchain, destination):
        try:
            owned_path(path, ROOT)
        except ValueError:
            parser.error("Use owned local project paths without symlinks")
    frozen = source_inputs(ROOT, FRONTEND)
    tools = {name: run([name, "--version"], ROOT) for name in ("bun", "node")}
    destination.mkdir(parents=True, exist_ok=True)
    validator = FRONTEND / "contracts/schema-validation.js"
    validator_hash = digest(validator)
    distributed_hash = digest(assets / "app.js")
    with tempfile.TemporaryDirectory(prefix=".gspace-attribution-", dir=toolchain) as generation:
        generated = Path(generation)
        run(
            [
                "node",
                str(ROOT / "scripts/generate_frontend_contract.mjs"),
                str(toolchain),
                str(FRONTEND / "contracts/openapi.json"),
                str(generated),
            ],
            ROOT,
        )
        validator_meta = generated / "accepted-validator.metafile.json"
        validator_output = generated / "schema-validation.js"
        run(
            [
                "bun",
                "build",
                str(generated / "validation.raw.js"),
                "--target=browser",
                "--format=esm",
                "--outfile=" + str(validator_output),
                "--metafile=" + str(validator_meta),
            ],
            generated,
        )
        if digest(validator_output) != validator_hash:
            raise RuntimeError("Current browser validator did not reproduce")
        validator_inputs = json.loads(validator_meta.read_bytes())["inputs"]
        for name in validator_inputs:
            if name.startswith("../node_modules/"):
                path = toolchain / name.removeprefix("../")
                owned_path(path, ROOT)
                frozen[str(path.relative_to(ROOT))] = digest(path)
        # Reproduce once more against frozen helper hashes, closing the same-size race.
        run(
            [
                "bun",
                "build",
                str(generated / "validation.raw.js"),
                "--target=browser",
                "--format=esm",
                "--outfile=" + str(validator_output),
                "--metafile=" + str(validator_meta),
            ],
            generated,
        )
        verify_inputs(ROOT, frozen)
        if digest(validator_output) != validator_hash:
            raise RuntimeError("Frozen npm helper inputs do not reproduce the current validator")
        with tempfile.TemporaryDirectory(prefix="gspace-current-bundle-") as temporary:
            stage = Path(temporary)
            for name in frozen:
                relative = Path(name)
                if relative.is_relative_to("frontend-new") and relative.parts[1] in (
                    "src",
                    "contracts",
                ):
                    target = stage / relative.relative_to("frontend-new")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(ROOT / name, target)
            shutil.copyfile(validator_output, stage / "contracts/schema-validation.js")
            app_meta = stage / "accepted-app.metafile.json"
            app_output = stage / "app.js"
            run(
                [
                    "bun",
                    "build",
                    str(stage / "src/app.ts"),
                    "--target=browser",
                    "--format=esm",
                    "--minify",
                    "--outfile=" + str(app_output),
                    "--metafile=" + str(app_meta),
                ],
                stage,
            )
            if digest(app_output) != distributed_hash:
                raise RuntimeError("Current source does not reproduce the delivered app")
            verify_inputs(ROOT, frozen)
            if digest(assets / "app.js") != distributed_hash:
                raise RuntimeError("Delivered app changed during attribution")
            report = {
                "purpose": "Current two-stage browser attribution bound to delivered bytes",
                "app_matches_served": True,
                "validator_matches_accepted_input": True,
                "accepted_validator_sha256": validator_hash,
                "app_sha256": distributed_hash,
                "served_app_sha256": distributed_hash,
                "inputs": frozen,
                "tools": tools,
                "frontend_assets_modified": False,
            }
            for name, path in (
                ("accepted-app.metafile.json", app_meta),
                ("accepted-validator.metafile.json", validator_meta),
            ):
                payload = canonical_metafile(path.read_bytes(), stage, generated)
                (destination / name).write_bytes(payload)
                report[name] = {
                    "sha256": hashlib.sha256(payload).hexdigest(),
                    "inputs": list(json.loads(payload)["inputs"]),
                }
            (destination / "report.json").write_text(
                json.dumps(report, indent=2, sort_keys=True) + "\n"
            )
    print(json.dumps({"reproduced": True, "app_sha256": distributed_hash, "inputs": len(frozen)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
