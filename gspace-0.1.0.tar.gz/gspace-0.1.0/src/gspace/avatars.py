"""Scoped project avatars: opt-in backend retrieval, bounded PNGs and packaged fallback."""

from __future__ import annotations

import hashlib
import http.client
import re
import struct
import threading
import time
import zlib
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated, Literal, Self
from urllib.parse import urlsplit

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, model_validator

from gspace.avatar_policy import AvatarPolicy
from gspace.models import Model, ProjectId, Text
from gspace.observation import ObservationFailure, fetch, validate_url


class ProjectAvatarDTO(BaseModel, frozen=True):
    model_config = ConfigDict(extra="ignore")
    id: int = Field(strict=True, gt=0)
    avatar_url: str | None = Field(default=None, strict=True, max_length=2000)


class FallbackAvatar(Model, frozen=True):
    kind: Literal["fallback"] = "fallback"
    reason: Literal["disabled", "fixture", "not_available", "rejected", "fetch_failed"]
    provenance: Literal["packaged_fallback"] = "packaged_fallback"


class CachedAvatar(Model, frozen=True):
    kind: Literal["cached_png"] = "cached_png"
    sha256: str = Field(strict=True, pattern=r"^[a-f0-9]{64}$")
    width: int = Field(strict=True, ge=1, le=1024)
    height: int = Field(strict=True, ge=1, le=1024)
    fetched_at: AwareDatetime
    provenance: Literal["gitlab_project_avatar_backend_get"] = "gitlab_project_avatar_backend_get"


type AvatarEvidence = Annotated[FallbackAvatar | CachedAvatar, Field(discriminator="kind")]


class ProjectPresentation(Model, frozen=True):
    host: Text
    project: ProjectId
    path: Text
    avatar_src: str = Field(strict=True, pattern=r"^/api/projects/[1-9][0-9]*/avatar$")
    avatar_alt: Text
    avatar: AvatarEvidence

    @model_validator(mode="after")
    def local_identity(self) -> Self:
        if (
            self.avatar_src != f"/api/projects/{self.project.value}/avatar"
            or self.avatar_alt != self.path
        ):
            raise ValueError("avatar route/alt differs from project identity")
        return self


class AvatarRequest(Model, frozen=True):
    url: str = Field(strict=True, min_length=1, max_length=2000)
    allowed_origins: tuple[str, ...]
    allowed_networks: tuple[str, ...]
    allow_http: bool
    timeout_seconds: float
    max_bytes: int
    max_redirects: Literal[0] = 0


def avatar_request(
    url: str, origin: str, project: ProjectId, policy: AvatarPolicy
) -> AvatarRequest:
    parts = urlsplit(url)
    path = rf"/uploads/-/system/project/avatar/{project.value}/[A-Za-z0-9_.-]+"
    if re.fullmatch(path, parts.path) is None or parts.path.endswith(("/.", "/..")):
        raise ObservationFailure(
            "configuration", "Project avatar path is outside fixed upload scope"
        )
    request = AvatarRequest(
        url=url,
        allowed_origins=(origin,),
        allowed_networks=policy.allowed_networks,
        allow_http=origin.startswith("http://127.0.0.1:"),
        timeout_seconds=policy.timeout_seconds,
        max_bytes=policy.max_bytes,
    )
    validate_url(url, request)
    return request


def sanitize_png(body: bytes, policy: AvatarPolicy) -> tuple[bytes, int, int]:
    """Validate bounded RGB/RGBA PNG and strip ancillary metadata."""
    if len(body) > policy.max_bytes or body[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("avatar requires a bounded PNG")
    cursor = 8
    kept = bytearray(body[:8])
    compressed = bytearray()
    width = height = channels = 0
    ended = False
    idat_ended = False
    for index in range(256):
        if cursor + 12 > len(body):
            raise ValueError("truncated PNG")
        length = int.from_bytes(body[cursor : cursor + 4], "big")
        end = cursor + 12 + length
        if end > len(body):
            raise ValueError("PNG chunk exceeds body")
        kind = body[cursor + 4 : cursor + 8]
        payload = body[cursor + 8 : cursor + 8 + length]
        crc = int.from_bytes(body[cursor + 8 + length : end], "big")
        if zlib.crc32(kind + payload) != crc:
            raise ValueError("PNG checksum mismatch")
        if index == 0:
            if kind != b"IHDR" or length != 13:
                raise ValueError("PNG must begin with IHDR")
            width, height, depth, color, compression, filtering, interlace = struct.unpack(
                ">IIBBBBB", payload
            )
            if not (1 <= width <= policy.max_dimension and 1 <= height <= policy.max_dimension):
                raise ValueError("PNG dimensions exceed limit")
            if depth != 8 or color not in (2, 6) or compression or filtering or interlace:
                raise ValueError("Unsupported PNG pixel format")
            channels = 3 if color == 2 else 4
        elif kind == b"IHDR":
            raise ValueError("duplicate PNG header")
        elif kind == b"IDAT":
            if idat_ended:
                raise ValueError("noncontiguous PNG image chunks")
            compressed.extend(payload)
        elif kind == b"IEND":
            if length or not compressed or end != len(body):
                raise ValueError("invalid PNG ending")
            ended = True
        elif not kind or not (kind[0] & 32):
            raise ValueError("unknown critical PNG chunk")
        elif compressed:
            idat_ended = True
        if kind in (b"IHDR", b"IDAT", b"IEND"):
            kept.extend(body[cursor:end])
        cursor = end
        if ended:
            break
    if not ended:
        raise ValueError("PNG chunk budget or ending invalid")
    expected = height * (width * channels + 1)
    decoder = zlib.decompressobj()
    pixels = decoder.decompress(bytes(compressed), expected + 1)
    if len(pixels) != expected or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
        raise ValueError("PNG decoded size differs from dimensions")
    if any(pixels[row * (width * channels + 1)] > 4 for row in range(height)):
        raise ValueError("invalid PNG filter")
    return bytes(kept), width, height


@dataclass(frozen=True)
class AvatarResource:
    presentation: ProjectPresentation
    body: bytes
    media_type: Literal["image/png", "image/svg+xml"]


class ProjectAvatars:
    def __init__(
        self,
        host: str,
        policy: AvatarPolicy,
        *,
        fixture: bool,
        provider: Callable[[ProjectId], ProjectAvatarDTO],
        getter: Callable[[AvatarRequest], bytes] = fetch,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.host, self.policy, self.fixture = host, policy, fixture
        self.provider, self.getter, self.clock = provider, getter, clock
        self._cache: OrderedDict[ProjectId, tuple[float, AvatarResource]] = OrderedDict()
        self._lock = threading.RLock()
        self._fallback = (Path(__file__).parent / "static/icon.svg").read_bytes()

    def get(self, project: ProjectId, path: str) -> AvatarResource:
        with self._lock:
            prior = self._cache.get(project)
            if prior is not None and self.clock() - prior[0] < self.policy.ttl_seconds:
                self._cache.move_to_end(project)
                return prior[1]
            evidence: AvatarEvidence = FallbackAvatar(
                reason="fixture" if self.fixture else "disabled"
            )
            body, media = self._fallback, "image/svg+xml"
            if self.policy.enabled and not self.fixture:
                try:
                    metadata = self.provider(project)
                    if metadata.id != project.value:
                        raise ValueError("avatar metadata project identity mismatch")
                    if metadata.avatar_url is None:
                        evidence = FallbackAvatar(reason="not_available")
                    else:
                        request = avatar_request(
                            metadata.avatar_url, self.host, project, self.policy
                        )
                        body, width, height = sanitize_png(self.getter(request), self.policy)
                        media = "image/png"
                        evidence = CachedAvatar(
                            sha256=hashlib.sha256(body).hexdigest(),
                            width=width,
                            height=height,
                            fetched_at=datetime.now(UTC),
                        )
                except (ObservationFailure, ValueError, zlib.error):
                    body, media = self._fallback, "image/svg+xml"
                    evidence = FallbackAvatar(reason="rejected")
                except (OSError, http.client.HTTPException):
                    body, media = self._fallback, "image/svg+xml"
                    evidence = FallbackAvatar(reason="fetch_failed")
            presentation = ProjectPresentation(
                host=self.host,
                project=project,
                path=path,
                avatar_src=f"/api/projects/{project.value}/avatar",
                avatar_alt=path,
                avatar=evidence,
            )
            resource = AvatarResource(presentation, body, media)
            self._cache[project] = self.clock(), resource
            self._cache.move_to_end(project)
            while len(self._cache) > self.policy.max_cached:
                self._cache.popitem(last=False)
            return resource
