"""Synthetic milestone calendar edges; original fixture and upstream dates stay intact."""

from datetime import UTC, date, datetime

from gspace.fixture import synthetic_snapshot
from gspace.milestones import MilestoneCatalog, catalog
from gspace.models import MilestoneFilter, ProjectId, Snapshot

TODAY = date(2026, 10, 7)
NOW = datetime(2026, 10, 7, 10, tzinfo=UTC)
CASES = (
    ("Start only", "2026-10-07", None, "active"),
    ("Due only", None, "2026-10-07", "active"),
    ("Missing dates", None, None, "active"),
    ("Exact start", "2026-10-07", "2026-10-09", "active"),
    ("Exact due", "2026-10-05", "2026-10-07", "active"),
    ("Same day", "2026-10-07", "2026-10-07", "active"),
    ("Not started", "2026-10-08", "2026-10-09", "active"),
    ("Past due", "2026-10-05", "2026-10-06", "active"),
    ("Closed range", "2026-10-05", "2026-10-09", "closed"),
)


def edge_snapshot() -> Snapshot:
    data = synthetic_snapshot().model_dump(mode="json")
    prototype = data["milestones"][0]
    milestones = []
    for index, (title, start, due, state) in enumerate(CASES):
        project = data["items"][index]["identity"]["project"]["value"] if index < 7 else 42
        path = "demo/flight-service" if project == 42 else "demo/ground-service"
        milestone = {
            **prototype,
            "key": {
                "kind": "project",
                "project": {"value": project},
                "id": {"value": 700001 + index},
            },
            "iid": {"value": 501 + index},
            "title": title,
            "start_date": start,
            "due_date": due,
            "state": state,
            "link": {
                "url": f"https://gitlab.example.invalid/{path}/-/milestones/{501 + index}",
                "verification": "fixture",
            },
        }
        milestones.append(milestone)
        if index < len(data["items"]):
            data["items"][index]["milestone"] = milestone["key"]
    data["milestones"] = milestones
    return Snapshot.model_validate(data)


def edge_catalog() -> MilestoneCatalog:
    snapshot = edge_snapshot()
    return catalog(
        snapshot,
        "fixture",
        (ProjectId(value=42), ProjectId(value=99)),
        MilestoneFilter(),
        tuple(item for item in snapshot.items if item.state == "opened" and item.assigned_to_me),
        "Europe/Zurich",
        now=NOW,
    )
