"""Actual uv TLS trust checks against an owned package index, without external traffic."""

import base64
import csv
import hashlib
import io
import shutil
import ssl
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from zipfile import ZipFile

import pytest

from scripts import install


def test_uv_rejects_unknown_issuer_then_installs_with_explicit_ca(tmp_path, monkeypatch):
    uv, openssl = shutil.which("uv"), shutil.which("openssl")
    if not uv or not openssl:
        pytest.skip("Actual installer trust check needs existing uv and OpenSSL")
    for name in ("SSL_CERT_FILE", "SSL_CERT_DIR", "UV_SYSTEM_CERTS", "UV_NATIVE_TLS"):
        monkeypatch.delenv(name, raising=False)
    cert, key = tmp_path / "public-ca.pem", tmp_path / "synthetic-ca-key.pem"
    subprocess.run(
        [
            openssl,
            "req",
            "-x509",
            "-newkey",
            "rsa:2048",
            "-nodes",
            "-days",
            "1",
            "-keyout",
            str(key),
            "-out",
            str(cert),
            "-subj",
            "/CN=GSpace Synthetic Test CA",
            "-addext",
            "basicConstraints=critical,CA:TRUE",
        ],
        check=True,
        capture_output=True,
        timeout=20,
    )
    server_cert, server_key = tmp_path / "server.pem", tmp_path / "synthetic-server-key.pem"
    csr, extensions = tmp_path / "server.csr", tmp_path / "server.ext"
    extensions.write_text(
        "basicConstraints=critical,CA:FALSE\n"
        "keyUsage=critical,digitalSignature,keyEncipherment\n"
        "extendedKeyUsage=serverAuth\nsubjectAltName=DNS:localhost,IP:127.0.0.1\n"
    )
    subprocess.run(
        [
            openssl,
            "req",
            "-new",
            "-newkey",
            "rsa:2048",
            "-nodes",
            "-keyout",
            str(server_key),
            "-out",
            str(csr),
            "-subj",
            "/CN=localhost",
        ],
        check=True,
        capture_output=True,
        timeout=20,
    )
    subprocess.run(
        [
            openssl,
            "x509",
            "-req",
            "-in",
            str(csr),
            "-CA",
            str(cert),
            "-CAkey",
            str(key),
            "-CAcreateserial",
            "-out",
            str(server_cert),
            "-days",
            "1",
            "-extfile",
            str(extensions),
        ],
        check=True,
        capture_output=True,
        timeout=20,
    )
    files = {
        "trust_fixture/__init__.py": b"# Inert synthetic distribution\n",
        "trust_fixture-1.0.dist-info/METADATA": (
            b"Metadata-Version: 2.1\nName: trust-fixture\nVersion: 1.0\n"
        ),
        "trust_fixture-1.0.dist-info/WHEEL": (
            b"Wheel-Version: 1.0\nGenerator: synthetic\nRoot-Is-Purelib: true\nTag: py3-none-any\n"
        ),
    }
    record = io.StringIO()
    writer = csv.writer(record)
    for name, payload in files.items():
        digest = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).decode().rstrip("=")
        writer.writerow([name, "sha256=" + digest, len(payload)])
    writer.writerow(["trust_fixture-1.0.dist-info/RECORD", "", ""])
    files["trust_fixture-1.0.dist-info/RECORD"] = record.getvalue().encode()
    output = io.BytesIO()
    with ZipFile(output, "w") as archive:
        for name, payload in files.items():
            archive.writestr(name, payload)
    wheel = output.getvalue()
    checksum = hashlib.sha256(wheel).hexdigest()
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            requests.append(self.path)
            if self.path == "/simple/trust-fixture/":
                body = (
                    f'<a href="/trust_fixture-1.0-py3-none-any.whl#sha256={checksum}">'
                    "trust_fixture-1.0-py3-none-any.whl</a>"
                ).encode()
                content_type = "text/html"
            elif self.path == "/trust_fixture-1.0-py3-none-any.whl":
                body, content_type = wheel, "application/octet-stream"
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(server_cert, server_key)
    server.socket = context.wrap_socket(server.socket, server_side=True)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    target = tmp_path / "environment"
    subprocess.run(
        [uv, "venv", "--python", str(Path(sys.executable).resolve()), str(target), "--no-config"],
        cwd=tmp_path,
        env=install.environment(),
        check=True,
        capture_output=True,
        timeout=20,
    )
    argv = [
        uv,
        "pip",
        "install",
        "--python",
        str(target / "bin/python"),
        "--no-deps",
        "--no-cache",
        "--no-config",
        "--index-url",
        f"https://127.0.0.1:{server.server_port}/simple",
        "trust-fixture==1.0",
    ]
    try:

        def request():
            env = {**install.environment(), "UV_HTTP_RETRIES": "0"}
            assert "UV_INSECURE_HOST" not in env
            return subprocess.run(
                argv, cwd=tmp_path, env=env, capture_output=True, text=True, timeout=30
            )

        rejected = request()
        assert rejected.returncode != 0
        assert "certificate" in rejected.stderr.lower(), rejected.stderr
        assert not requests
        monkeypatch.setenv("SSL_CERT_FILE", str(cert))
        accepted = request()
        assert accepted.returncode == 0, accepted.stderr
        assert "/trust_fixture-1.0-py3-none-any.whl" in requests
        installed = subprocess.run(
            [
                str(target / "bin/python"),
                "-I",
                "-c",
                "from importlib.metadata import version; print(version('trust-fixture'))",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert installed.stdout.strip() == "1.0"
    finally:
        server.shutdown()
        server.server_close()
