"""Pinned edition reads, immutable graph identity and fixed query transport boundaries."""

import json

import httpx
import pytest
from pydantic import ValidationError

from gspace.access import AccessError, ProfileTransport
from gspace.access_models import GlabProfile, PatProfile
from gspace.config import LiveConfig, ProjectConfig
from gspace.gitlab_release import GitLabRelease, read_release
from gspace.glab import AdapterError, GlabAdapter, RunResult
from gspace.models import PipelineEdge, PipelineId, PipelineKey, ProjectId, Unknown
from gspace.pipeline_query import PAGE_SIZE, PIPELINE_QUERY, pipeline_variables


def project(value=42, path="demo/application"):
    return ProjectConfig(id=ProjectId(value=value), path=path)


def key(value=42, pipeline=9201):
    return PipelineKey(project=ProjectId(value=value), pipeline=PipelineId(value=pipeline))


@pytest.mark.parametrize(
    "raw,edition", [("18.11.12", "unknown"), ("18.11.12-ce", "ce"), ("18.11.12-ee", "ee")]
)
def test_exact_release_accepts_editions_and_preserves_raw(raw, edition):
    parsed = read_release(raw)
    assert parsed.raw == raw and parsed.release == "18.11.12" and parsed.edition == edition
    with pytest.raises(ValidationError):
        GitLabRelease(raw=raw, release="18.11.12", edition="ee" if edition != "ee" else "ce")


@pytest.mark.parametrize(
    "raw", ["18.11.11-ee", "18.11.13", "18.11.12-rc1", "18.11.12-ee.1", "18.11.12-ee\n", "secret"]
)
def test_release_pin_is_not_relaxed(raw):
    with pytest.raises(ValueError, match="pinned"):
        read_release(raw)


def test_glab_query_is_fixed_bounded_and_has_no_shell_or_mutation():
    calls = []
    config = LiveConfig(
        hostname="gitlab.example.invalid",
        web_origin="https://gitlab.example.invalid",
        projects=(project(),),
    )
    body = {"data": {"project": None}, "errors": [{"message": "redacted remote failure"}]}

    def runner(argv, timeout):
        calls.append((argv, timeout))
        return RunResult(code=1, stdout=json.dumps(body).encode())

    adapter = GlabAdapter(config, runner)
    assert json.loads(adapter.graph_page(project(), key(), "cursor;$()")) == body
    argv, timeout = calls[0]
    assert argv[:7] == [
        "glab",
        "api",
        "--hostname",
        "gitlab.example.invalid",
        "--method",
        "POST",
        "graphql",
    ]
    assert "query=" + PIPELINE_QUERY in argv and "after=cursor;$()" in argv
    assert "first=" + str(PAGE_SIZE) in argv and "--paginate" not in argv
    assert "mutation" not in PIPELINE_QUERY.lower() and timeout == 10
    for bad in (project(99), project(42, "outside/project")):
        with pytest.raises(AdapterError, match="scope"):
            adapter.graph_page(bad, key(bad.id.value), None)
    assert len(calls) == 1


def test_fixed_query_cursor_and_identity_reject_before_transport():
    for cursor in ("", "x" * 513, "line\n", "\x1b", "界"):
        with pytest.raises(ValueError):
            pipeline_variables(project(), key(), cursor)
    with pytest.raises(ValueError):
        pipeline_variables(project(), key(99), None)


def test_profile_glab_preserves_launcher_and_project_scope(monkeypatch):
    monkeypatch.setattr("gspace.access.shutil.which", lambda _: "/synthetic/glab")
    calls = []
    profile = GlabProfile(
        name="devpod",
        host="https://gitlab.example.invalid",
        projects=(ProjectId(value=42),),
        executable="/synthetic/glab",
        launcher_arguments=("--no-color",),
    )

    def runner(argv, timeout):
        calls.append(argv)
        return RunResult(code=0, stdout=b'{"data":{"project":null}}')

    transport = ProfileTransport(profile, runner=runner)
    assert transport.pipeline_graphql(project(), key(), None) == {"data": {"project": None}}
    assert calls[0][:3] == ["/synthetic/glab", "--no-color", "api"]
    with pytest.raises(AccessError, match="scope"):
        transport.pipeline_graphql(project(99), key(99), None)
    assert len(calls) == 1


def test_pat_graphql_uses_explicit_secret_header_and_exact_endpoint_without_write_gate():
    calls = []
    profile = PatProfile(
        name="readonly",
        host="https://gitlab.example.invalid",
        projects=(ProjectId(value=42),),
        secret_env="GSPACE_SYNTHETIC_GRAPH_TOKEN",
    )

    def handler(request):
        calls.append(request)
        assert request.method == "POST" and request.url.path == "/api/graphql"
        assert request.headers["PRIVATE-TOKEN"] == "synthetic-secret"
        assert json.loads(request.content) == {
            "query": PIPELINE_QUERY,
            "variables": pipeline_variables(project(), key(), None),
        }
        assert "synthetic-secret" not in str(request.url)
        return httpx.Response(200, json={"data": {"project": None}})

    transport = ProfileTransport(
        profile, resolver=lambda _: "synthetic-secret", http_transport=httpx.MockTransport(handler)
    )
    assert transport.pipeline_graphql(project(), key(), None) == {"data": {"project": None}}
    with pytest.raises(AccessError):
        transport.request("POST", "projects/42/pipelines", body={"ref": "main"})
    assert len(calls) == 1


def test_native_edge_retains_hidden_source_job_and_scoped_identity():
    edge = PipelineEdge(
        upstream=key(),
        downstream=key(99, 9201),
        source_job=Unknown(reason="Source job not visible"),
    )
    assert edge.upstream.pipeline == edge.downstream.pipeline
    assert edge.upstream != edge.downstream and edge.source_job.kind == "unknown"
    assert edge.origin == "graphql_native"
