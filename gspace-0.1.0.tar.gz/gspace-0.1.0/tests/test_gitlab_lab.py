"""Unit safety/contract checks for prepared lab tooling, not live integration claims."""

import json
import subprocess
from pathlib import Path
from urllib.parse import urlsplit

import httpx
import pytest
from pydantic import ValidationError

from gspace.config import LiveConfig, ProjectConfig, load_config
from gspace.glab import GlabAdapter
from gspace.models import ProjectId
from scripts import gitlab_lab as lab
from scripts import lab_loopback


def test_compose_uses_anonymous_ephemeral_config_and_same_local_socket(monkeypatch, tmp_path):
    foreign = tmp_path / "operator-docker"
    foreign.mkdir()
    (foreign / "config.json").write_text('{"credsStore":"operator-private-helper"}')
    monkeypatch.setenv("DOCKER_CONFIG", str(foreign))
    monkeypatch.setenv("DOCKER_CONTEXT", "unrelated-remote-context")
    monkeypatch.setenv("DOCKER_HOST", "tcp://corporate.invalid:2376")
    monkeypatch.setenv("DOCKER_CERT_PATH", str(tmp_path / "private-certificates"))
    monkeypatch.setenv("DOCKER_AUTH_CONFIG", "synthetic-foreign-credential-configuration")
    configs = []

    def runner(argv, **kwargs):
        environment = kwargs["env"]
        assert environment["DOCKER_HOST"] == "unix:///var/run/docker.sock"
        assert "DOCKER_CONTEXT" not in environment
        assert "DOCKER_CERT_PATH" not in environment
        assert "DOCKER_AUTH_CONFIG" not in environment
        directory = Path(environment["DOCKER_CONFIG"])
        assert directory != foreign
        assert json.loads((directory / "config.json").read_text())["auths"] == {
            "https://index.docker.io/v1/": {}
        }
        assert "credsStore" not in (directory / "config.json").read_text()
        configs.append(directory)
        return subprocess.CompletedProcess(argv, 0, "synthetic-status", "")

    monkeypatch.setattr(lab.subprocess, "run", runner)
    assert lab.compose("ps", "--format", "json") == "synthetic-status"
    assert configs and all(not directory.exists() for directory in configs)
    assert (foreign / "config.json").read_text() == '{"credsStore":"operator-private-helper"}'


def test_loopback_bridge_refuses_foreign_image_project_or_stopped_container(monkeypatch):
    expected = f"{lab_loopback.IMAGE}|gspace-integration-181112-v1|true"
    observed = expected

    def inspect(argv, **kwargs):
        assert argv[:3] == ["docker", "inspect", lab_loopback.CONTAINER]
        assert "Env" not in argv[-1]  # No secrets are read to validate ownership.
        return subprocess.CompletedProcess(argv, 0, observed, "")

    monkeypatch.setattr(lab_loopback, "docker_run", inspect)
    lab_loopback.validate_container()
    for altered in (
        expected.replace(lab_loopback.IMAGE, "foreign:latest"),
        expected.replace("gspace-integration-181112-v1", "another-project"),
        expected.replace("|true", "|false"),
    ):
        observed = altered
        with pytest.raises(RuntimeError, match="Exact owned running"):
            lab_loopback.validate_container()


def config(**changes):
    data = {
        "hostname": "127.0.0.1:8929",
        "web_origin": "http://127.0.0.1:8929",
        "transport": "isolated_loopback_http",
        "projects": (ProjectConfig(id=ProjectId(value=1), path="gspace-lab-owner/flight"),),
    }
    return LiveConfig.model_validate({**data, **changes})


def test_isolated_http_requires_explicit_transport_and_loopback():
    assert config().transport == "isolated_loopback_http"
    for changes in (
        {"transport": "https"},
        {"hostname": "corporate.invalid:8929", "web_origin": "http://corporate.invalid:8929"},
        {"hostname": "localhost:8929", "web_origin": "http://localhost:8929"},
        {"hostname": "127.0.0.1", "web_origin": "http://127.0.0.1"},
        {"web_origin": "http://127.0.0.1:8929/other"},
        {"web_origin": "http://127.0.0.1:8930"},
        {"hostname": "127.0.0.1:80", "web_origin": "http://127.0.0.1:80"},
    ):
        with pytest.raises(ValidationError):
            config(**changes)


def test_test_links_and_glab_target_are_only_local():
    calls = []

    def runner(argv, timeout):
        from gspace.glab import RunResult

        calls.append(argv)
        return RunResult(code=0, stdout=b"{}")

    cfg = config()
    adapter = GlabAdapter(cfg, runner)
    for suffix in ("issues/791", "merge_requests/154", "jobs/55", "pipelines/10", "tags/v1"):
        link = adapter.link(cfg.projects[0], suffix)
        assert urlsplit(link.url).netloc == "127.0.0.1:8929"
    adapter.get("version")
    assert calls[0][calls[0].index("--hostname") + 1] == "127.0.0.1:8929"
    assert "--method" in calls[0] and calls[0][-2] == "GET"


def test_lab_api_outbound_allowlist_and_redirect_rejection():
    calls = []

    def transport(request):
        calls.append(request)
        assert request.url.host == "127.0.0.1" and request.url.port == 8929
        return httpx.Response(302, headers={"Location": "https://outside.invalid/secret"})

    client = lab.Client("synthetic-test", mutations=False, transport=httpx.MockTransport(transport))
    for path in ("https://outside.invalid", "//outside.invalid", "../version", "version?token=x"):
        with pytest.raises(lab.LabError, match="Unsafe"):
            client.call("GET", path)
    assert calls == []
    with pytest.raises(lab.LabError, match="read-only"):
        client.call("POST", "projects", {})
    with pytest.raises(lab.LabError, match="status 302"):
        client.call("GET", "version")
    assert len(calls) == 1
    client.close()


def test_resource_and_credential_gates_fail_closed():
    with pytest.raises(lab.LabError, match="Explicit approval"):
        lab.approved(False, "credential creation")
    with pytest.raises(lab.LabError, match="60 GiB"):
        lab.budget(18 * lab.GIB, 16 * lab.GIB, 6)
    with pytest.raises(lab.LabError, match="10 GiB"):
        lab.budget(60 * lab.GIB, 8 * lab.GIB, 4)
    lab.budget(60 * lab.GIB, 16 * lab.GIB, 6)


def test_generated_gspace_config_contains_only_local_urls(tmp_path, monkeypatch):
    monkeypatch.setattr(lab, "STATE", tmp_path)

    def transport(request):
        assert request.url.host == "127.0.0.1" and request.url.port == 8929
        if "/repository/branches/" in request.url.path:
            return httpx.Response(200, json={"commit": {"id": "a" * 40}})
        return httpx.Response(404)

    client = lab.Client("synthetic-test", mutations=False, transport=httpx.MockTransport(transport))
    state = {
        "projects": [
            {"id": 7, "path": "gspace-lab-owner/flight"},
            {"id": 8, "path": "gspace-lab-owner/ground"},
        ]
    }
    lab.configure(client, state)
    cfg = load_config(tmp_path / "gspace.toml")
    assert cfg.live.hostname == "127.0.0.1:8929"
    assert cfg.live.web_origin == lab.ORIGIN
    assert len(cfg.endpoints) == 8
    assert all(urlsplit(e.url).netloc == "127.0.0.1:8890" for e in cfg.endpoints)
    assert all(e.allowed_networks == ("127.0.0.1/32",) for e in cfg.endpoints)
    assert cfg.preferences_path.parent == tmp_path and cfg.cache_path.parent == tmp_path
    client.close()
