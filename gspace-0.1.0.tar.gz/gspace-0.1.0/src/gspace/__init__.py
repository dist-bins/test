"""GSpace: a local, read-only work item cockpit."""

__version__ = "0.1.0"
