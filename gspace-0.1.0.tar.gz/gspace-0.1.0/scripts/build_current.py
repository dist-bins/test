"""Offline native-lock wheel/source build from finite current sources and bundled notices."""

from __future__ import annotations

import argparse
import shutil
import sys
import tempfile
from pathlib import Path

from bundled_notices import generate
from devpod_package import CURRENT_STATIC, source_files
from install import ROOT, build_artifacts, verify_notices, verify_wheel


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    args = parser.parse_args()
    output = args.output.absolute()
    if not output.resolve().is_relative_to(ROOT.resolve()) or output.is_symlink():
        parser.error("Build output must stay in the owned project")
    output.mkdir(parents=True, exist_ok=True)
    generate(ROOT)
    with tempfile.TemporaryDirectory(prefix="gspace-current-source-") as temporary:
        project = Path(temporary) / "project"
        for path in source_files(ROOT):
            relative = str(path.relative_to(ROOT))
            target = project / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / CURRENT_STATIC.get(relative, relative), target)
        if (ROOT / "AGENTS.md").is_file() and not (ROOT / "AGENTS.md").is_symlink():
            shutil.copyfile(ROOT / "AGENTS.md", project / "AGENTS.md")
        wheel = build_artifacts(
            project, output, str(Path(sys.executable).resolve()), sdist=True, offline=True
        )
        verify_wheel(wheel, ROOT / "frontend-new")
        verify_notices(wheel, ROOT)
    print(wheel)


if __name__ == "__main__":
    main()
