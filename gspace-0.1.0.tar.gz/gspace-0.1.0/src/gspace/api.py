"""Loopback API with local preference writes and explicit configured GET refreshes."""

from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit, urlunsplit

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError
from starlette.middleware.base import RequestResponseEndpoint
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.responses import Response

from gspace.access import AccessError
from gspace.access_models import Permission
from gspace.actions import (
    Action,
    ActionPlan,
    ActionResult,
    ActionService,
    ConfirmAction,
    DoctorReport,
    ProbeComparison,
    ProbeComparisonRequest,
    ProfileSummary,
)
from gspace.api_contracts import (
    AdapterErrorResponse,
    CapabilitiesResponse,
    DetailError,
    MRCatalogResponse,
    ProjectCatalogResponse,
)
from gspace.avatars import ProjectPresentation
from gspace.config import AppConfig
from gspace.glab import AdapterError
from gspace.milestones import MilestoneCatalog
from gspace.models import EnvironmentLabel, IssueIid, Model, PipelineGraph, ProjectId, WorkKey
from gspace.navigation import NavigationCatalog
from gspace.operator_settings import SettingsChange, SettingsConflict, SettingsResponse
from gspace.preferences import Filters, PreferenceConflict, Preferences
from gspace.resource_catalog import BranchCatalog, PipelineCatalog
from gspace.service import Dashboard, ItemView, PreferenceChange, Preview, Service
from gspace.test_history import ApplicationTestHistory
from gspace.web_config import LOCAL_HOSTS

STATIC = Path(__file__).parent / "static"


class PreviewRequest(Model, frozen=True):
    action: Literal["tag", "deploy-dev", "deploy-preprod", "rebase", "retry", "ready", "merge"]
    previous_tag: str | None = None


class EmptyRequest(Model, frozen=True):
    pass


def create_app(
    config: AppConfig | None = None,
    service: Service | None = None,
    actions: ActionService | None = None,
    config_path: Path | None = None,
) -> FastAPI:
    core = service or Service(config or AppConfig(), config_path=config_path)
    access = actions or ActionService(
        core.config.access_profiles if core.config.mode == "live" else ()
    )
    web = core.config.web
    app = FastAPI(
        title="GSpace",
        version="0.1.0",
        docs_url=None,
        redoc_url=None,
        root_path=web.root_path,
        root_path_in_servers=False,
        responses={
            400: {"model": DetailError},
            404: {"model": DetailError},
            409: {"model": DetailError},
            403: {"model": DetailError | AdapterErrorResponse},
            422: {"model": DetailError},
            502: {"model": AdapterErrorResponse},
        },
    )
    hosts: list[str] = list(LOCAL_HOSTS)
    if web.public_host is not None:
        hosts.append(web.public_host)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)

    @app.middleware("http")
    async def local_guard(request: Request, call_next: RequestResponseEndpoint) -> Response:
        path = request.scope["path"]
        if web.root_path and path != web.root_path and not path.startswith(web.root_path + "/"):
            # Mounted static routes need the same full ASGI path for either proxy style.
            request.scope["path"] = web.root_path + path
            raw_path = request.scope.get("raw_path")
            if isinstance(raw_path, bytes):
                request.scope["raw_path"] = web.root_path.encode("ascii") + raw_path
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            origin = request.headers.get("origin")
            allowed = {web.public_origin} if web.public_origin else set[str | None]()
            if web.public_origin is None or request.url.hostname in (
                "localhost",
                "127.0.0.1",
                "::1",
                "testserver",
            ):
                allowed.add(f"{request.url.scheme}://{request.url.netloc}")
            if origin is not None and origin not in allowed:
                return JSONResponse(
                    {"detail": "Cross-origin writes are unavailable"}, status_code=403
                )
            if request.headers.get("content-type", "").split(";")[0] != "application/json":
                return JSONResponse({"detail": "JSON content type required"}, status_code=415)
        response = await call_next(request)
        if web.public_url and response.status_code in (301, 302, 303, 307, 308):
            target = urlsplit(response.headers.get("location", ""))
            if (
                target.scheme in ("http", "https")
                and target.netloc == request.url.netloc
                and target.path.startswith("/")
                and not target.path.startswith("//")
            ):
                response.headers["Location"] = urlunsplit(
                    ("", "", target.path, target.query, target.fragment)
                )
        response.headers.setdefault(
            "Content-Security-Policy",
            (
                "default-src 'self'; script-src 'self'; style-src 'self'; "
                "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"
            ),
        )
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.exception_handler(RequestValidationError)
    async def invalid_request(_request: Request, _error: RequestValidationError) -> JSONResponse:
        return JSONResponse(
            {"detail": "Request does not match the typed API contract"}, status_code=422
        )

    @app.exception_handler(PreferenceConflict)
    @app.exception_handler(SettingsConflict)
    async def conflict(
        _request: Request, error: PreferenceConflict | SettingsConflict
    ) -> JSONResponse:
        return JSONResponse({"detail": str(error)}, status_code=409)

    @app.exception_handler(AdapterError)
    async def adapter_error(_request: Request, error: AdapterError) -> JSONResponse:
        if isinstance(error, AccessError):
            if error.code == "confirmation":
                return JSONResponse({"detail": str(error)}, status_code=409)
            if error.code in ("denied", "scope", "disabled"):
                return JSONResponse({"detail": str(error), "code": error.code}, status_code=403)
        return JSONResponse({"detail": str(error), "code": error.code}, status_code=502)

    @app.exception_handler(ValueError)
    async def value_error(_request: Request, error: ValueError) -> JSONResponse:
        message = (
            "Stored data or configuration is invalid"
            if isinstance(error, ValidationError)
            else str(error)
        )
        return JSONResponse({"detail": message}, status_code=400)

    @app.exception_handler(KeyError)
    async def not_found(_request: Request, _error: KeyError) -> JSONResponse:
        return JSONResponse({"detail": "Work item not found"}, status_code=404)

    def key(project: int, issue: int) -> WorkKey:
        if project < 1 or issue < 1:
            raise HTTPException(422, "Positive project ID and issue IID required")
        return WorkKey(project=ProjectId(value=project), issue=IssueIid(value=issue))

    @app.get("/api/dashboard")
    def dashboard(
        selected: bool = False,
        project: int | None = None,
        all: bool = False,
        view: str | None = None,
    ) -> Dashboard:
        scoped = ProjectId(value=project) if project is not None else None
        filters = Filters(state="all", assigned=False, show_hidden=True) if all else None
        return core.dashboard(filters, selected_only=selected, project=scoped, saved_view=view)

    @app.get("/api/settings")
    def settings() -> SettingsResponse:
        return core.settings()

    @app.post("/api/settings")
    def update_settings(change: SettingsChange) -> SettingsResponse:
        return core.update_settings(change)

    @app.get("/api/milestones")
    def milestones(project: int | None = None) -> MilestoneCatalog:
        return core.milestones(ProjectId(value=project) if project is not None else None)

    @app.get("/api/projects")
    def projects() -> ProjectCatalogResponse:
        return ProjectCatalogResponse(host=core.host, projects=core.projects())

    @app.get("/api/navigation")
    def navigation() -> NavigationCatalog:
        return core.navigation()

    @app.get("/api/projects/{project}/presentation")
    def project_presentation(project: int) -> ProjectPresentation:
        return core.project_avatar(ProjectId(value=project)).presentation

    @app.get(
        "/api/projects/{project}/avatar",
        response_class=Response,
        responses={
            200: {
                "content": {
                    "image/png": {"schema": {"type": "string", "format": "binary"}},
                    "image/svg+xml": {"schema": {"type": "string", "format": "binary"}},
                }
            }
        },
    )
    def project_avatar(project: int) -> Response:
        resource = core.project_avatar(ProjectId(value=project))
        return Response(
            content=resource.body,
            media_type=resource.media_type,
            headers={"Content-Security-Policy": "default-src 'none'; sandbox"},
        )

    @app.get("/api/merge-requests")
    def merge_requests(project: int | None = None) -> MRCatalogResponse:
        catalog = core.mr_catalog(project=ProjectId(value=project) if project is not None else None)
        return MRCatalogResponse.from_catalog(catalog)

    @app.get("/api/branches")
    def branches(project: int | None = None) -> BranchCatalog:
        catalog = core.resource_catalog(
            "branches", ProjectId(value=project) if project is not None else None
        )
        assert isinstance(catalog, BranchCatalog)
        return catalog

    @app.get("/api/pipelines")
    def pipelines(project: int | None = None) -> PipelineCatalog:
        catalog = core.resource_catalog(
            "pipelines", ProjectId(value=project) if project is not None else None
        )
        assert isinstance(catalog, PipelineCatalog)
        return catalog

    @app.post("/api/merge-requests/refresh")
    def refresh_merge_requests(_body: EmptyRequest) -> MRCatalogResponse:
        catalog = core.mr_catalog(refresh=True)
        return MRCatalogResponse.from_catalog(catalog)

    @app.get("/api/items/{project}/{issue}")
    def item(project: int, issue: int) -> ItemView:
        return core.view(core.item(key(project, issue)), core.preferences.read())

    @app.get("/api/items/{project}/{issue}/pipeline-graph")
    def pipeline_graph(project: int, issue: int) -> PipelineGraph:
        return core.pipeline_graph(key(project, issue))

    @app.get("/api/items/{project}/{issue}/application-tests")
    def application_tests(
        project: int, issue: int, environment: EnvironmentLabel | None = None
    ) -> ApplicationTestHistory:
        return core.application_test_history(key(project, issue), environment)

    @app.get("/api/preferences")
    def preferences() -> Preferences:
        return core.preferences.read()

    @app.post("/api/preferences")
    def change(change: PreferenceChange) -> Preferences:
        return core.change(change)

    @app.post("/api/refresh")
    def refresh(_body: EmptyRequest) -> Dashboard:
        core.refresh()
        return core.dashboard()

    @app.post("/api/items/{project}/{issue}/preview")
    def preview(project: int, issue: int, body: PreviewRequest) -> Preview:
        return core.preview(key(project, issue), body.action, body.previous_tag)

    @app.post("/api/items/{project}/{issue}/observe/{environment}")
    def observe(
        project: int, issue: int, environment: EnvironmentLabel, _body: EmptyRequest
    ) -> ItemView:
        return core.view(
            core.observe_environment(key(project, issue), environment), core.preferences.read()
        )

    @app.get("/api/access/profiles")
    def profiles() -> tuple[ProfileSummary, ...]:
        return access.summaries()

    @app.post("/api/access/doctor/{profile}")
    def doctor(profile: str, _body: EmptyRequest) -> DoctorReport:
        return access.doctor(profile)

    @app.post("/api/actions/probe")
    def probe_action(body: Action) -> Permission:
        return access.probe(body)

    @app.post("/api/access/compare")
    def compare_profiles(body: ProbeComparisonRequest) -> ProbeComparison:
        return access.compare(body)

    @app.post("/api/actions/preview")
    def preview_action(body: Action) -> ActionPlan:
        return access.preview(body)

    @app.post("/api/actions/execute")
    def execute_action(body: ConfirmAction) -> ActionResult:
        return access.execute(body)

    @app.get("/api/capabilities")
    def capabilities() -> CapabilitiesResponse:
        enabled = core.config.mode == "live" and any(
            p.write_enabled and p.kind == "pat" and p.host.rstrip("/") == "http://127.0.0.1:8929"
            for p in core.config.access_profiles
        )
        return CapabilitiesResponse(
            remote_read_only=not enabled,
            remote_mutations=enabled,
            previews=("tag", "rebase", "retry", "deploy-dev", "deploy-preprod", "ready", "merge"),
            write_scope="isolated_synthetic_lab" if enabled else "disabled",
            actions=(
                "create_draft_mr",
                "edit_draft_mr",
                "create_tag",
                "run_pipeline",
                "change_pipeline",
                "change_job",
            )
            if enabled
            else (),
        )

    app.mount("/assets", StaticFiles(directory=STATIC), name="assets")

    @app.get("/", include_in_schema=False)
    def index() -> Response:
        if not web.root_path:
            return FileResponse(STATIC / "index.html")
        prefix = escape(web.root_path, quote=True)
        content = (STATIC / "index.html").read_text()
        content = content.replace('"/assets/', f'"{prefix}/assets/')
        content = content.replace(
            "</head>", f'<meta name="gspace-base-path" content="{prefix}">\n</head>'
        )
        return HTMLResponse(content)

    return app
