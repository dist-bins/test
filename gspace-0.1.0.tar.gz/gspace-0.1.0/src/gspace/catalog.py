"""Complete bounded authored-MR summaries within explicitly configured projects."""

from __future__ import annotations

from datetime import UTC, datetime
from hashlib import sha1
from typing import Literal, Self

from pydantic import AwareDatetime, model_validator

from gspace.config import ProjectConfig
from gspace.fixture import synthetic_snapshot
from gspace.glab import AdapterError, GlabAdapter, MrDTO, UserDTO, VersionDTO
from gspace.models import (
    Association,
    MergeRequest,
    Model,
    MrIid,
    MrState,
    Origin,
    ProjectId,
    Sha,
    Text,
    UserId,
)


class AuthoredMrDTO(MrDTO):
    author: UserDTO
    created_at: AwareDatetime
    updated_at: AwareDatetime


class AuthoredMr(Model, frozen=True):
    mr: MergeRequest
    author_id: UserId
    created_at: AwareDatetime
    updated_at: AwareDatetime
    source_sha: Sha | None = None
    project_path: Text

    @model_validator(mode="after")
    def coherent_source(self) -> Self:
        if (
            self.source_sha is not None
            and self.mr.source_sha is not None
            and self.source_sha != self.mr.source_sha
        ):
            raise ValueError("MR catalog source SHA differs from its MR source SHA")
        return self


class MRCatalog(Model, frozen=True):
    source: Literal["fixture", "glab"]
    host: Text
    scope: Literal["authored_by_me"] = "authored_by_me"
    coverage: Literal["configured_projects"] = "configured_projects"
    projects: tuple[ProjectConfig, ...]
    fetched_at: AwareDatetime
    rows: tuple[AuthoredMr, ...]

    @property
    def total(self) -> int:
        return len(self.rows)

    @model_validator(mode="after")
    def scoped(self) -> Self:
        identities = [(row.mr.project, row.mr.iid) for row in self.rows]
        if len(set(identities)) != len(identities):
            raise ValueError("duplicate authored MR identity")
        configured = {project.id for project in self.projects}
        if any(row.mr.project not in configured for row in self.rows):
            raise ValueError("MR catalog exceeds configured project scope")
        return self


class MRCatalogCache(Model, frozen=True):
    configuration_fingerprint: str
    catalog: MRCatalog


def fixture_catalog() -> MRCatalog:
    snapshot = synthetic_snapshot()
    projects = {
        item.identity.project: ProjectConfig(id=item.identity.project, path=item.project_path)
        for item in snapshot.items
    }
    unique = {
        (mr.project, mr.iid): (mr, item.project_path)
        for item in snapshot.items
        for mr in item.merge_requests
    }
    project = ProjectId(value=42)
    example = next(mr for mr, _ in unique.values() if mr.project == project)
    for iid, state, title in [
        (341, MrState.MERGED, "Archived synthetic migration"),
        (329, MrState.CLOSED, "Withdrawn synthetic experiment"),
        (355, MrState.OPEN, "Synthetic authored MR without a linked work item"),
    ]:
        data = example.model_dump()
        data.update(
            iid=MrIid(value=iid),
            title=title,
            state=state,
            draft=False,
            source_branch=f"unlinked-{iid}",
            source_sha=sha1(
                f"synthetic-authored-mr-{project.value}-{iid}".encode(), usedforsecurity=False
            ).hexdigest(),
            association=Association(
                origin=Origin.FIXTURE, reason="Synthetic authored history without an issue"
            ),
            link={
                "url": f"https://gitlab.example.invalid/{projects[project].path}/-/merge_requests/{iid}",
                "verification": "fixture",
            },
        )
        unique[(project, MrIid(value=iid))] = (
            MergeRequest.model_validate(data),
            projects[project].path,
        )
    return MRCatalog(
        source="fixture",
        host="fixture",
        projects=tuple(projects.values()),
        fetched_at=snapshot.fetched_at,
        rows=tuple(
            AuthoredMr(
                mr=mr,
                project_path=path,
                author_id=UserId(value=100),
                created_at=snapshot.fetched_at,
                updated_at=snapshot.fetched_at,
                source_sha=mr.source_sha,
            )
            for mr, path in unique.values()
        ),
    )


def fetch_catalog(adapter: GlabAdapter) -> MRCatalog:
    from gspace.gitlab_release import read_release

    version = adapter.single("version", VersionDTO).version
    try:
        read_release(version, adapter.config.supported_version)
    except ValueError as error:
        raise AdapterError(
            "compatibility", "GitLab version differs from pinned read contract"
        ) from error
    user = adapter.single("user", UserDTO)
    rows: list[AuthoredMr] = []
    for project in adapter.config.projects:
        raw = adapter.pages(
            f"projects/{project.id.value}/merge_requests",
            AuthoredMrDTO,
            {
                "scope": "created_by_me",
                "author_id": str(user.id),
                "state": "all",
                "order_by": "updated_at",
                "sort": "desc",
            },
        )
        for row in raw:
            if row.project_id != project.id.value or row.author.id != user.id:
                raise AdapterError(
                    "validation", "Authored MR response exceeds requested identity scope"
                )
            rows.append(
                AuthoredMr(
                    mr=adapter.merge_request(
                        project,
                        row,
                        Association(
                            origin=Origin.API,
                            reason="Authored MR summary in explicitly configured project",
                        ),
                    ),
                    author_id=UserId(value=row.author.id),
                    created_at=row.created_at,
                    updated_at=row.updated_at,
                    source_sha=row.sha,
                    project_path=project.path,
                )
            )
    return MRCatalog(
        source="glab",
        host=adapter.config.web_origin.rstrip("/"),
        projects=adapter.config.projects,
        fetched_at=datetime.now(UTC),
        rows=tuple(rows),
    )
