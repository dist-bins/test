"""Native npm configuration preserves a synthetic registry CA without disabling TLS."""

import base64
import hashlib
import io
import json
import shutil
import ssl
import subprocess
import tarfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from scripts import install


@pytest.mark.parametrize("declaration", ["devDependencies", "optionalDependencies"])
def test_native_npm_uses_operator_ca_configuration(tmp_path, monkeypatch, declaration):
    npm, openssl = shutil.which("npm"), shutil.which("openssl")
    if not npm or not openssl:
        pytest.skip("Actual npm trust check needs existing npm and OpenSSL")
    root = tmp_path / "project"
    monkeypatch.setattr(install, "ROOT", root)
    for name in (
        "HTTP_PROXY",
        "HTTPS_PROXY",
        "ALL_PROXY",
        "http_proxy",
        "https_proxy",
        "all_proxy",
        "SSL_CERT_FILE",
        "SSL_CERT_DIR",
        "NODE_EXTRA_CA_CERTS",
    ):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("NODE_OPTIONS", "")
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    config, empty = home / "native.npmrc", home / "empty.npmrc"
    empty.write_text("")
    monkeypatch.setenv("NPM_CONFIG_USERCONFIG", str(config))
    monkeypatch.setenv("NPM_CONFIG_GLOBALCONFIG", str(empty))
    ca, ca_key = tmp_path / "ca.pem", tmp_path / "synthetic-ca-key.pem"
    cert, key, csr = (
        tmp_path / "server.pem",
        tmp_path / "synthetic-key.pem",
        tmp_path / "server.csr",
    )
    extensions = tmp_path / "extensions"
    extensions.write_text(
        "basicConstraints=critical,CA:FALSE\nextendedKeyUsage=serverAuth\n"
        "subjectAltName=IP:127.0.0.1\n"
    )
    commands = [
        [
            "req",
            "-x509",
            "-newkey",
            "rsa:2048",
            "-nodes",
            "-days",
            "1",
            "-keyout",
            str(ca_key),
            "-out",
            str(ca),
            "-subj",
            "/CN=Synthetic npm CA",
            "-addext",
            "basicConstraints=critical,CA:TRUE",
        ],
        [
            "req",
            "-new",
            "-newkey",
            "rsa:2048",
            "-nodes",
            "-keyout",
            str(key),
            "-out",
            str(csr),
            "-subj",
            "/CN=127.0.0.1",
        ],
        [
            "x509",
            "-req",
            "-in",
            str(csr),
            "-CA",
            str(ca),
            "-CAkey",
            str(ca_key),
            "-CAcreateserial",
            "-out",
            str(cert),
            "-days",
            "1",
            "-extfile",
            str(extensions),
        ],
    ]
    for args in commands:
        subprocess.run([openssl, *args], check=True, capture_output=True, timeout=20)
    package = json.dumps({"name": "gspace-tls-fixture", "version": "1.0.0"}).encode()
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        member = tarfile.TarInfo("package/package.json")
        member.size = len(package)
        archive.addfile(member, io.BytesIO(package))
    payload = buffer.getvalue()
    integrity = "sha512-" + base64.b64encode(hashlib.sha512(payload).digest()).decode()
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            requests.append(self.path)
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, format, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls.load_cert_chain(cert, key)
    server.socket = tls.wrap_socket(server.socket, server_side=True)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f"https://127.0.0.1:{server.server_port}/"
    config.write_text(
        f"registry={url}\ncafile={ca}\nstrict-ssl=true\nomit=dev\nomit=optional\n"
        "fetch-retries=0\nfetch-timeout=5000\n"
    )
    monkeypatch.setenv("NODE_ENV", "production")
    root.mkdir()
    (root / "package.json").write_text(
        json.dumps(
            {
                "name": "owned-fixture",
                "version": "1.0.0",
                declaration: {"gspace-tls-fixture": "1.0.0"},
            }
        )
    )
    (root / "package-lock.json").write_text(
        json.dumps(
            {
                "name": "owned-fixture",
                "version": "1.0.0",
                "lockfileVersion": 3,
                "requires": True,
                "packages": {
                    "": {
                        "name": "owned-fixture",
                        "version": "1.0.0",
                        declaration: {"gspace-tls-fixture": "1.0.0"},
                    },
                    "node_modules/gspace-tls-fixture": {
                        "version": "1.0.0",
                        "resolved": url + "fixture.tgz",
                        "integrity": integrity,
                        "dev" if declaration == "devDependencies" else "optional": True,
                    },
                },
            }
        )
    )
    argv = [
        npm,
        "ci",
        "--ignore-scripts",
        "--no-audit",
        "--no-fund",
        "--fetch-retries=0",
        "--fetch-timeout=5000",
    ]
    try:
        isolated = install.environment()
        isolated.update(
            NPM_CONFIG_USERCONFIG=str(empty),
            NPM_CONFIG_GLOBALCONFIG=str(empty),
            NPM_CONFIG_REGISTRY=url,
        )
        denied = subprocess.run(
            argv, cwd=root, env=isolated, capture_output=True, text=True, timeout=20
        )
        assert denied.returncode != 0 and not requests
        install.install_frontend_dependencies(root)
        assert requests == ["/fixture.tgz"]
        assert (root / "node_modules/gspace-tls-fixture/package.json").read_bytes() == package
    finally:
        server.shutdown()
        server.server_close()
