"""Audit the actual public parsers and compare every long/short option pair."""

import argparse
import json
import sys

import pytest

from gspace import cli, cli_commands, cli_models

VALUES = {
    "PROJECT:IID": "42:791",
    "FILE": "/tmp/synthetic.json",
    "NAME": "sample",
    "FIELD": "local_test",
    "KIND": "branch",
    "VALUE": "issue-791",
    "ACTION": "tag",
}
OPTION_VALUES = {
    "config": "/tmp/operator.toml",
    "width": "80",
    "search": "airport",
    "group": "Release",
    "project": "42",
    "view": "Release",
    "orientation": "columns",
    "milestone": "active",
    "milestone-key": "project:42:700",
    "state": "closed",
    "reason": "synthetic",
    "previous-tag": "release-1.2.3",
    "confirm": "synthetic",
    "environment": "dev",
    "port": "8890",
}


def arguments(command):
    for group in cli_commands.GROUPS:
        for leaf in group.commands:
            if leaf.target == command:
                result = [VALUES[value] for value in leaf.arguments.split()]
                return result + (["--reason", "synthetic"] if command == "override" else [])
    return ["42:791"] if command == "show" else []


def test_all_public_options_have_unique_long_and_short_forms_and_equal_parsing(monkeypatch):
    sources = []
    original = cli_models.CliSettingsSource

    def capture(*args, **kwargs):
        source = original(*args, **kwargs)
        sources.append(source)
        return source

    monkeypatch.setattr(cli_models, "CliSettingsSource", capture)
    cli_models.parse(["dashboard"])
    root = sources[0].root_parser
    children = next(
        action for action in root._actions if isinstance(action, argparse._SubParsersAction)
    )
    aliases = {alias.name: alias for alias in cli_models.OPTION_ALIASES}
    shorts = [
        letter for alias in aliases.values() for letter in (alias.short, alias.negative) if letter
    ]
    assert len(shorts) == len(set(shorts))
    assert "h" not in shorts and "V" not in shorts
    audited = 0
    for command, parser in children.choices.items():
        seen = []
        for action in parser._actions:
            seen.extend(action.option_strings)
            for long in [flag for flag in action.option_strings if flag.startswith("--")]:
                if long == "--help":
                    assert "-h" in action.option_strings
                    continue
                name = long.removeprefix("--")
                negative = name.startswith("no-")
                alias = aliases[name.removeprefix("no-") if negative else name]
                short = "-" + (alias.negative if negative else alias.short)
                assert short in action.option_strings, (command, long, short)
                value = [] if action.nargs == 0 else [OPTION_VALUES[name]]
                baseline = arguments(command)
                assert cli_models.parse([command, *baseline, long, *value]) == cli_models.parse(
                    [command, *baseline, short, *value]
                )
                audited += 1
        assert len(seen) == len(set(seen)), command
    assert audited > 200


@pytest.mark.parametrize("flags", [["-j"], ["-j", "-J", "-j"], ["--no-json", "-j"]])
def test_short_json_errors_are_clean_and_ordered(monkeypatch, capsys, flags):
    monkeypatch.setattr(sys, "argv", ["gspace", "missing", *flags, "-N"])
    assert cli.main() == 2
    result = capsys.readouterr()
    assert not result.out and "error" in json.loads(result.err)
    assert "\x1b" not in result.err


def test_negative_json_alias_restores_human_error(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["gspace", "missing", "-j", "-J", "-N"])
    assert cli.main() == 2
    result = capsys.readouterr()
    assert result.err.startswith("Error:") and not result.out and "\x1b" not in result.err


def test_nested_aliases_and_help_and_version(monkeypatch, capsys):
    nested, _, display = cli_commands.prepare(
        ["pipelines", "list", "-p", "42", "-s", "issue", "-N"]
    )
    assert cli_models.parse(nested, display_command=display) == cli_models.parse(
        ["pipeline-catalog", "--project", "42", "--search", "issue", "--no-color"]
    )
    with pytest.raises(SystemExit) as error:
        cli_models.parse(["dashboard", "-h", "-N"])
    assert error.value.code == 0
    help_text = capsys.readouterr().out
    assert "--config, -c" in help_text and "-N" in help_text and "-J" in help_text
    for flag in ("--version", "-V"):
        monkeypatch.setattr(sys, "argv", ["gspace", flag])
        assert cli.main() == 0
        assert capsys.readouterr().out == "GSpace 0.1.0\n"
