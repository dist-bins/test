// Applies the browser-local theme before first paint (built as a classic
// script for <head>). Theme is the only browser-persisted setting; everything
// else lives in the preferences API or the operator settings file.

type ThemeChoice = 'system' | 'light' | 'dark';

const isChoice = (x: string | null): x is ThemeChoice => x === 'system' || x === 'light' || x === 'dark';

function storedChoice(): ThemeChoice {
  try {
    const stored = window.localStorage.getItem('gspace.theme');
    return isChoice(stored) ? stored : 'system';
  } catch {
    return 'system'; // storage unavailable: follow the system preference
  }
}

const choice = storedChoice();
const dark = choice === 'dark' || (choice === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
document.documentElement.setAttribute('data-theme-choice', choice);
