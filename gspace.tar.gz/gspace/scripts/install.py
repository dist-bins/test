"""Install the locked project/current UI globally using native operator npm configuration."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import tomllib
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
ASSETS = (
    "index.html",
    "app.js",
    "theme.js",
    "styles.css",
    "icon.svg",
    "gspace-wolf.svg",
    "gspace-wolf-gray.svg",
)


class InstallError(RuntimeError):
    """A concise installation failure without raw configuration or provider details."""


def environment() -> dict[str, str]:
    """Keep verified CA trust while excluding credentials and private registry settings."""
    trust = os.environ.get("UV_SYSTEM_CERTS", os.environ.get("UV_NATIVE_TLS", "true"))
    result = {
        "PATH": os.environ.get("PATH", os.defpath),
        "UV_CACHE_DIR": str(ROOT / ".state/install/uv-cache"),
        "UV_CREDENTIALS_DIR": str(ROOT / ".state/install/empty-credentials"),
        "UV_KEYRING_PROVIDER": "disabled",
        "UV_SYSTEM_CERTS": trust,
        "UV_NATIVE_TLS": trust,  # Compatibility with uv versions before 0.11.
        "NETRC": os.devnull,
        "NPM_CONFIG_USERCONFIG": str(ROOT / ".state/install/npm-user.conf"),
        "NPM_CONFIG_GLOBALCONFIG": str(ROOT / ".state/install/npm-global.conf"),
        "NPM_CONFIG_CACHE": str(ROOT / ".state/install/npm-cache"),
        "NPM_CONFIG_REGISTRY": "https://registry.npmjs.org",
        "NPM_CONFIG_UPDATE_NOTIFIER": "false",
        "DO_NOT_TRACK": "1",
    }
    for name in (
        "SSL_CERT_FILE",
        "SSL_CERT_DIR",
        "NODE_EXTRA_CA_CERTS",
        "NPM_CONFIG_CAFILE",
        "npm_config_cafile",
    ):
        if value := os.environ.get(name):
            result[name] = value
    return result


def npm_environment() -> dict[str, str]:
    """Let native npm own its operator configuration; never copy or parse auth files."""
    defaults = environment()
    for key in ("NPM_CONFIG_USERCONFIG", "NPM_CONFIG_GLOBALCONFIG", "NPM_CONFIG_REGISTRY"):
        defaults.pop(key)
    result = {**os.environ, **defaults}
    for key in ("NPM_CONFIG_CACHE", "npm_config_cache"):
        result[key] = str(ROOT / ".state/install/npm-cache")
    for key in ("NPM_CONFIG_LOGS_DIR", "npm_config_logs_dir"):
        result[key] = str(ROOT / ".state/install/npm-cache/_logs")
    for key in ("NPM_CONFIG_STRICT_SSL", "npm_config_strict_ssl"):
        result[key] = "true"
    result["NODE_TLS_REJECT_UNAUTHORIZED"] = "1"
    return result


def npm_failure_summary(since: float) -> str:
    """Read only current owned npm logs and retain recognized failure codes."""
    directory = ROOT / ".state/install/npm-cache/_logs"
    codes = set()
    allowed = (
        "EAI_AGAIN|ENOTFOUND|ECONNREFUSED|ECONNRESET|ETIMEDOUT|"
        "UNABLE_TO_GET_ISSUER_CERT_LOCALLY|UNABLE_TO_VERIFY_LEAF_SIGNATURE|"
        "SELF_SIGNED_CERT_IN_CHAIN|DEPTH_ZERO_SELF_SIGNED_CERT|CERT_HAS_EXPIRED|"
        "E401|E403|E404|EACCES|ENOSPC"
    )
    if directory.is_dir() and not any(p.is_symlink() for p in (directory, *directory.parents)):
        for path in sorted(directory.glob("*-debug-*.log"), reverse=True)[:3]:
            if path.is_symlink() or path.stat().st_mtime < since:
                continue
            with path.open("rb") as handle:
                handle.seek(max(0, path.stat().st_size - 131072))
                text = handle.read(131072).decode("utf-8", errors="replace")
            codes.update(
                re.findall(
                    r"(?:failed with|(?:error|verbose) (?:code|errno))\s+(" + allowed + r")\b", text
                )
            )
    detail = ", ".join(sorted(codes)) if codes else "cause unavailable in the current npm log"
    return (
        "npm dependency installation failed: "
        + detail
        + ". See .state/install/npm-cache/_logs. No automatic retry or TLS bypass."
    )


def run(
    arguments: list[str],
    cwd: Path = ROOT,
    *,
    environment_overrides: dict[str, str] | None = None,
    native_npm: bool = False,
) -> str:
    print("+ " + " ".join(arguments), flush=True)
    result = subprocess.run(
        arguments,
        cwd=cwd,
        env={
            **(npm_environment() if native_npm else environment()),
            **(environment_overrides or {}),
        },
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE if native_npm else None,
        timeout=600,
    )
    print(result.stdout, end="", flush=True)
    return result.stdout.strip()


def stage_project(root: Path, destination: Path) -> None:
    """Overlay the current UI only in a disposable wheel build tree."""
    destination.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / "pyproject.toml", destination / "pyproject.toml")
    shutil.copytree(
        root / "src", destination / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
    )
    for name in ASSETS:
        shutil.copyfile(root / "frontend-new" / name, destination / "src/gspace/static" / name)


def install_frontend_dependencies(frontend: Path) -> None:
    """Use native operator npm configuration without copying it into staged sources."""
    with tempfile.TemporaryDirectory(prefix="gspace-npm-") as temporary:
        stage = Path(temporary)
        for name in ("package.json", "package-lock.json"):
            shutil.copyfile(frontend / name, stage / name)
        started = time.time()
        try:
            run(
                [
                    "npm",
                    "ci",
                    "--include=dev",
                    "--include=optional",
                    "--ignore-scripts",
                    "--no-audit",
                    "--no-fund",
                ],
                stage,
                native_npm=True,
            )
        except subprocess.CalledProcessError:
            raise InstallError(npm_failure_summary(started)) from None
        target = frontend / "node_modules"
        if target.is_symlink():
            target.unlink()
        elif target.exists():
            shutil.rmtree(target)
        shutil.move(stage / "node_modules", target)


def verify_wheel(wheel: Path, frontend: Path) -> dict[str, str]:
    with ZipFile(wheel) as archive:
        hashes = {}
        for name in ASSETS:
            data = (frontend / name).read_bytes()
            if archive.read("gspace/static/" + name) != data:
                raise RuntimeError(f"Installed wheel has stale frontend asset: {name}")
            hashes[name] = hashlib.sha256(data).hexdigest()
        return hashes


def verify_notices(wheel: Path, root: Path) -> None:
    with ZipFile(wheel) as archive:
        expected = root / "src/gspace/licenses/manifest.json"
        if archive.read("gspace/licenses/manifest.json") != expected.read_bytes():
            raise RuntimeError("Packaged bundled-notice manifest differs from verified source")
        manifest = json.loads(expected.read_text())
        components = manifest["components"]
        if (
            len(components) != 2
            or {item["name"] for item in components} != {"ajv", "ajv-formats"}
            or any(item["file"] != item["name"] + ".LICENSE" for item in components)
        ):
            raise RuntimeError("Packaged notices must cover both bundled dependencies exactly once")
        for item in components:
            filename = item["file"]
            if filename not in ("ajv.LICENSE", "ajv-formats.LICENSE"):
                raise RuntimeError("Unexpected packaged notice path")
            payload = archive.read("gspace/licenses/" + filename)
            if (
                payload != (expected.parent / filename).read_bytes()
                or hashlib.sha256(payload).hexdigest() != item["sha256"]
            ):
                raise RuntimeError("Packaged bundled notice differs from publisher bytes")


def installed_packages(python: Path) -> dict[str, str]:
    packages = json.loads(
        run(["uv", "pip", "list", "--python", str(python), "--format", "json", "--no-config"])
    )
    return {package["name"]: package["version"] for package in packages}


def locked_runtime(interpreter: str) -> dict[str, str]:
    """Let uv select platform/marker-dependent runtime versions from the native lock."""
    with tempfile.TemporaryDirectory(prefix="gspace-locked-runtime-") as temporary:
        target = Path(temporary) / "environment"
        run(
            [
                "uv",
                "sync",
                "--locked",
                "--no-dev",
                "--no-install-project",
                "--python",
                interpreter,
                "--no-config",
            ],
            environment_overrides={"UV_PROJECT_ENVIRONMENT": str(target)},
        )
        return installed_packages(target / "bin/python")


def verify_runtime(expected: dict[str, str], installed: dict[str, str]) -> None:
    actual = {name: version for name, version in installed.items() if name != "gspace"}
    if actual != expected:
        raise RuntimeError("Installed global dependencies differ from uv.lock runtime selection")


def install_guarded_glab(source: Path, destination: Path) -> None:
    """Stage and recover the private companion as one verified installation."""
    suffixes = ("", ".LICENSE", ".manifest.json")
    sources = [source.with_name(source.name + suffix) for suffix in suffixes]
    targets = [destination.with_name(destination.name + suffix) for suffix in suffixes]
    if any(path.is_symlink() or not path.is_file() for path in sources):
        raise RuntimeError("Private guarded glab source bundle is incomplete or linked")
    metadata = json.loads(sources[-1].read_text())
    if metadata.get("identity") != "gspace-no-redirects.1" or hashlib.sha256(
        source.read_bytes()
    ).hexdigest() != metadata.get("binary_sha256"):
        raise RuntimeError("Private guarded glab differs from its build manifest")
    if any(path.is_symlink() for path in targets):
        raise RuntimeError("Private guarded glab destination cannot be linked")
    previous = destination.exists()
    if previous:
        if any(not path.is_file() for path in targets):
            raise RuntimeError("Refusing to replace an unowned private glab bundle")
        before = json.loads(targets[-1].read_text())
        if before.get("identity") != "gspace-no-redirects.1" or hashlib.sha256(
            destination.read_bytes()
        ).hexdigest() != before.get("binary_sha256"):
            raise RuntimeError("Refusing to replace an unverified private glab executable")
    elif any(path.exists() for path in targets):
        raise RuntimeError("Refusing to replace unowned private glab sidecars")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".gspace-glab-install-", dir=destination.parent))
    published = []
    restored = True
    try:
        for index, path in enumerate(sources):
            shutil.copyfile(path, temporary / f"new-{index}")
        (temporary / "new-0").chmod(0o755)
        for index, path in enumerate(targets):
            if previous:
                shutil.copyfile(path, temporary / f"old-{index}")
                (temporary / f"old-{index}").chmod(path.stat().st_mode & 0o777)
        try:
            for index, path in enumerate(targets):
                os.replace(temporary / f"new-{index}", path)
                published.append(index)
        except BaseException:
            for index in reversed(published):
                try:
                    if previous:
                        os.replace(temporary / f"old-{index}", targets[index])
                    else:
                        targets[index].unlink(missing_ok=True)
                except OSError:
                    restored = False
            if not restored:
                raise RuntimeError(f"Private tool recovery files retained at {temporary}") from None
            raise
    finally:
        if restored:
            shutil.rmtree(temporary)


def build_artifacts(
    project: Path, dist: Path, interpreter: str, *, sdist: bool = False, offline: bool = False
) -> Path:
    """Build with the exact native-lock build group and retain the actual environment proof."""
    inputs = {
        name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        for name in ("pyproject.toml", "uv.lock")
    }
    with tempfile.TemporaryDirectory(prefix="gspace-locked-build-") as temporary:
        target = Path(temporary) / "environment"
        run(
            [
                "uv",
                "sync",
                "--locked",
                "--only-group",
                "build",
                "--no-install-project",
                "--python",
                interpreter,
                "--no-config",
                *(["--offline"] if offline else []),
            ],
            environment_overrides={"UV_PROJECT_ENVIRONMENT": str(target)},
        )
        python = target / "bin/python"
        metadata_script = """
import hashlib, importlib.metadata, json, platform, sys
components = []
for distribution in importlib.metadata.distributions():
    files = distribution.files or ()
    data = {'name': distribution.metadata['Name'].lower().replace('_','-'),
            'version': distribution.version}
    for kind in ('METADATA', 'RECORD'):
        path = next(file for file in files
                    if file.name == kind and file.parent.name.endswith('.dist-info'))
        payload = distribution.locate_file(path).read_bytes()
        data[kind.lower() + '_sha256'] = hashlib.sha256(payload).hexdigest()
    components.append(data)
print(json.dumps({'components': sorted(components, key=lambda item: item['name']),
                  'python_version': platform.python_version(),
                  'interpreter_sha256': hashlib.sha256(
                      open(sys._base_executable, 'rb').read()).hexdigest()}))
"""
        before = json.loads(run([str(python), "-c", metadata_script]))
        run(
            [
                "uv",
                "build",
                *([] if sdist else ["--wheel"]),
                "--no-build-isolation",
                "--python",
                str(python),
                "--out-dir",
                str(dist),
                "--no-config",
                *(["--offline"] if offline else []),
            ],
            project,
        )
        after = json.loads(run([str(python), "-c", metadata_script]))
        if before != after:
            raise RuntimeError("Build environment changed during artifact creation")
    for name, checksum in inputs.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != checksum:
            raise RuntimeError("Native build inputs changed during artifact creation")
    version = tomllib.loads((project / "pyproject.toml").read_text())["project"]["version"]
    wheel = dist / f"gspace-{version}-py3-none-any.whl"
    with ZipFile(wheel) as archive:
        members = {
            name: hashlib.sha256(archive.read(name)).hexdigest()
            for name in sorted(archive.namelist())
        }
    report = {
        "purpose": "Exact native-lock build environment and current wheel provenance",
        "input_sha256": inputs,
        "build_group": "build",
        "build_isolation": "locked_uv_environment",
        **before,
        "uv_version": run(["uv", "--version"]),
        "wheel": {
            "path": str(wheel.relative_to(ROOT)),
            "sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
            "members": members,
        },
        "project_root_recovery_assets_modified": False,
    }
    if sdist:
        source = dist / f"gspace-{version}.tar.gz"
        with tarfile.open(source) as archive:
            source_members = {}
            for member in archive.getmembers():
                if member.isdir():
                    continue
                if (
                    not member.isfile()
                    or Path(member.name).is_absolute()
                    or ".." in Path(member.name).parts
                ):
                    raise RuntimeError("Source artifact contains an unsafe member")
                payload = archive.extractfile(member)
                if payload is None:
                    raise RuntimeError("Source artifact member is unavailable")
                source_members[member.name] = hashlib.sha256(payload.read()).hexdigest()
        report["sdist"] = {
            "path": str(source.relative_to(ROOT)),
            "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "members": source_members,
        }
    destination = ROOT / "output/verification/build-provenance.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return wheel


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--guarded-glab",
        action="store_true",
        help="Also install optional redirect-refusing glab (requires Go 1.27+ and curl)",
    )
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError("Run with Python 3.12: python3.12 scripts/install.py")
    commands = ("uv", "node", "npm", "bun") + (("go", "curl") if args.guarded_glab else ())
    for command in commands:
        if shutil.which(command) is None:
            raise RuntimeError(f"Install prerequisite {command} and add it to PATH")
    frontend = ROOT / "frontend-new"
    (ROOT / ".state/install").mkdir(parents=True, exist_ok=True)
    for name in ("npm-user.conf", "npm-global.conf"):
        (ROOT / ".state/install" / name).write_text("")
    interpreter = str(Path(sys.executable).resolve())
    run(["uv", "sync", "--locked", "--all-groups", "--python", interpreter, "--no-config"])
    python = str(ROOT / ".venv/bin/python")
    guarded_glab = ROOT / "dist/tools/gspace-glab"
    if args.guarded_glab:
        run([python, "scripts/build_guarded_glab.py"])
        install_guarded_glab(guarded_glab, ROOT / ".venv/bin/gspace-glab")
    install_frontend_dependencies(frontend)
    run([python, "scripts/export_openapi.py"])
    shutil.copyfile(ROOT / "docs/contracts/openapi.json", frontend / "contracts/openapi.json")
    run([python, "scripts/frontend_contract.py"])
    run([python, "scripts/frontend_build.py"])
    run([python, "scripts/bundled_notices.py"])
    runtime = locked_runtime(interpreter)
    dist = ROOT / "dist"
    dist.mkdir(exist_ok=True)
    version = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]["version"]
    with tempfile.TemporaryDirectory(prefix="gspace-install-") as temporary:
        staged = Path(temporary) / "project"
        stage_project(ROOT, staged)
        wheel = build_artifacts(staged, dist, interpreter)
    hashes = verify_wheel(wheel, frontend)
    verify_notices(wheel, ROOT)
    arguments = ["uv", "tool", "install", "--force", "--python", interpreter, "--no-config"]
    for name, package_version in sorted(runtime.items()):
        arguments.extend(("--with", f"{name}=={package_version}"))
    run([*arguments, str(wheel)])
    tool_bin = Path(run(["uv", "tool", "dir", "--bin", "--no-config"]))
    tool_dir = Path(run(["uv", "tool", "dir", "--no-config"]))
    if args.guarded_glab:
        install_guarded_glab(guarded_glab, tool_dir / "gspace/bin/gspace-glab")
    verify_runtime(runtime, installed_packages(tool_dir / "gspace/bin/python"))
    cli = tool_bin / "gspace"
    with tempfile.TemporaryDirectory(prefix="gspace-installed-check-") as temporary:
        actual = run([str(cli), "--version"], Path(temporary))
        if actual != f"GSpace {version}":
            raise RuntimeError("Unexpected globally installed CLI version")
    report = ROOT / "output/verification/install.json"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(
        json.dumps(
            {
                "purpose": "Local global CLI installation with staged current frontend",
                "cli": str(cli),
                "wheel": str(wheel),
                "assets": hashes,
                "python_dependency_sources": ["pyproject.toml", "uv.lock"],
                "locked_runtime": runtime,
                "installed_runtime_verified": True,
                "python": "3.12",
                "operator_files_read_by_installer": False,
                "npm_configuration": "native_operator_client",
                "remote_gitlab_requests": False,
                "guarded_glab": json.loads(
                    guarded_glab.with_name("gspace-glab.manifest.json").read_text()
                )
                if args.guarded_glab
                else None,
            },
            indent=2,
        )
        + "\n"
    )
    print(f"Installed {cli}. Add {tool_bin} to PATH if needed.")


if __name__ == "__main__":
    try:
        main()
    except InstallError as error:
        raise SystemExit(str(error)) from None
