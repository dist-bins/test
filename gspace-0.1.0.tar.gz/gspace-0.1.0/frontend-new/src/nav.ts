// Shared navigation: curated icon/colour decorations, pins and order for
// bookmarks and saved views (GET /api/navigation; changes through the
// revision-checked navigation_decoration_set/delete preference commands, the
// same shared TOML the CLI uses — never browser storage). Decorative colours
// are independent of semantic status colours. Project avatars come only from
// the server's fixed same-origin avatar route, with a packaged fallback.

import type { Bookmark, DecorationColor, DecorationIcon, NavigationDecoration, NavigationTarget, SavedView } from './api';
import { safeAvatarSrc } from './api';
import type { IconName, Kid } from './dom';
import { h, icon } from './dom';
import { resolveRef } from './resources';
import { pref, refKey, S, SCOPE_ICON, SCOPE_LABEL } from './state';
import { dialog, menu } from './ui';
import { applyView, mobileQuery } from './views';

/* ------------------------------------------------------------ icons */

const DECO_ICON: Readonly<Record<DecorationIcon, IconName>> = {
  bookmark: 'bookmark',
  star: 'star',
  flag: 'flag',
  folder: 'folder',
  calendar: 'calendar',
  list: 'list',
  code: 'code',
  rocket: 'rocket',
  issue: 'issue',
  branch: 'branch',
  mr: 'mr',
  pipeline: 'pipeline',
  job: 'job',
  tag: 'tag',
  layers: 'layers',
  clock: 'clock',
};
const COLOR_LABEL: Readonly<Record<DecorationColor, string>> = {
  neutral: 'Neutral',
  slate: 'Slate',
  blue: 'Blue',
  teal: 'Teal',
  green: 'Green',
  amber: 'Amber',
  orange: 'Orange',
  red: 'Red',
  purple: 'Purple',
  pink: 'Pink',
};

export const bookmarkTarget = (b: Bookmark): NavigationTarget => ({ kind: 'bookmark', host: b.host, reference: b.reference });
export const viewTarget = (v: SavedView): NavigationTarget => ({ kind: 'saved_view', host: v.host, name: v.name });

const targetKey = (t: NavigationTarget): string => (t.kind === 'bookmark' ? `b|${t.host}|${refKey(t.reference)}` : `v|${t.host}|${t.name}`);

export function decorationFor(t: NavigationTarget): NavigationDecoration | null {
  const k = targetKey(t);
  return S.nav?.decorations.find((d) => targetKey(d.target) === k) ?? null;
}

/** The decoration icon in its decorative colour, or the default icon. */
export function decoIcon(d: NavigationDecoration | null, fallback: IconName, cls = 'sm'): SVGSVGElement {
  if (!d) return icon(fallback, cls);
  return icon(DECO_ICON[d.icon], `${cls} deco deco-${d.color}`);
}

/* ------------------------------------------------------- style dialog */

// Icon, colour, pin and order for one bookmark or saved view. Saved through
// the shared preferences queue at the current revision; nothing is retried.
export function styleDialog(target: NavigationTarget, label: string): void {
  const cat = S.nav;
  if (!cat) return;
  const cur = decorationFor(target);
  let icn: DecorationIcon = cur?.icon ?? 'bookmark';
  let col: DecorationColor = cur?.color ?? 'neutral';
  const pinned = h('input', { type: 'checkbox', checked: cur?.pinned ?? false, 'data-fk': 'deco-pin' });
  const maxOrder = Math.max(-1, ...cat.decorations.filter((d) => d.pinned).map((d) => d.order));
  const order = h('input', {
    class: 'input num-in',
    type: 'number',
    min: '0',
    max: '1000',
    step: '1',
    value: String(cur?.order ?? Math.min(1000, maxOrder + 1)),
    'data-fk': 'deco-order',
  });
  const preview = h('span', { class: 'deco-preview' });
  const paint = (): void => {
    preview.replaceChildren(icon(DECO_ICON[icn], `deco deco-${col}`), h('span', null, label));
  };
  paint();
  const iconGrid = h(
    'div',
    { class: 'deco-grid', role: 'radiogroup', 'aria-label': 'Icon' },
    cat.icons.map((ic) =>
      h(
        'label',
        { class: 'deco-opt', title: ic },
        h('input', {
          type: 'radio',
          name: 'deco-icon',
          value: ic,
          checked: ic === icn,
          onchange: () => {
            icn = ic;
            paint();
          },
        }),
        icon(DECO_ICON[ic]),
        h('span', { class: 'sr' }, ic),
      ),
    ),
  );
  const colorGrid = h(
    'div',
    { class: 'deco-grid', role: 'radiogroup', 'aria-label': 'Colour' },
    cat.colors.map((c) =>
      h(
        'label',
        { class: 'deco-opt', title: COLOR_LABEL[c] },
        h('input', {
          type: 'radio',
          name: 'deco-color',
          value: c,
          checked: c === col,
          onchange: () => {
            col = c;
            paint();
          },
        }),
        h('span', { class: `deco-swatch deco-${c}`, 'aria-hidden': 'true' }),
        h('span', { class: 'sr' }, COLOR_LABEL[c]),
      ),
    ),
  );
  const dlg = dialog(
    `Icon & shortcut for “${label}”`,
    [
      h('div', { class: 'line' }, h('span', { class: 'muted' }, 'Preview'), preview),
      h('fieldset', { class: 'fs' }, h('legend', null, 'Icon'), iconGrid),
      h('fieldset', { class: 'fs' }, h('legend', null, 'Colour (decorative only, never a status)'), colorGrid),
      h('label', { class: 'check bare' }, pinned, 'Show as a shortcut in the top bar'),
      h('label', { class: 'field' }, h('span', null, 'Shortcut order (0 = first)'), order),
      h('p', { class: 'hint' }, 'Stored in the shared preferences file for this host, so the CLI and every browser see it.'),
      cur
        ? h(
            'button',
            {
              class: 'btn sm danger',
              type: 'button',
              'data-fk': 'deco-remove',
              onclick: () => {
                dlg.close();
                void pref({ operation: 'navigation_decoration_delete', target }, `Remove style of “${label}”`);
              },
            },
            'Remove style',
          )
        : null,
    ],
    {
      okLabel: 'Save style',
      onOk: async () => {
        const n = Number(order.value);
        if (!Number.isInteger(n) || n < 0 || n > 1000) return 'Order must be a whole number from 0 to 1000.';
        const ok = await pref(
          { operation: 'navigation_decoration_set', decoration: { target, icon: icn, color: col, pinned: pinned.checked, order: n } },
          `Style “${label}”`,
        );
        return ok ? null : 'Not saved — see the problem list.';
      },
    },
  );
}

/** "Icon & shortcut" button for a bookmark or saved view row (shows the current style). */
export function styleBtn(target: NavigationTarget, label: string, fallback: IconName): Kid {
  if (!S.nav) {
    return S.navError ? h('span', { class: 'muted', title: `Navigation styles unavailable: ${S.navError}` }, 'Styles unavailable') : null;
  }
  const d = decorationFor(target);
  return h(
    'button',
    {
      class: 'btn sm',
      type: 'button',
      disabled: !S.prefs,
      'data-fk': `style-${targetKey(target)}`,
      'aria-label': `Icon & shortcut for ${label}: icon, colour and top-bar shortcut`,
      onclick: () => styleDialog(target, label),
    },
    decoIcon(d, fallback),
    d?.pinned ? 'Icon & shortcut · pinned' : 'Icon & shortcut',
  );
}

/* ---------------------------------------------------- pinned shortcuts */

interface Shortcut {
  readonly deco: NavigationDecoration;
  readonly label: string;
  readonly fallback: IconName;
  readonly href: string | null;
  readonly view: SavedView | null;
  readonly note: string | null;
}

export function shortcuts(): Shortcut[] {
  const cat = S.nav;
  if (!cat) return [];
  const out: Shortcut[] = [];
  for (const d of cat.decorations) {
    if (!d.pinned) continue;
    const t = d.target;
    if (t.kind === 'bookmark') {
      const b = cat.bookmarks.find((x) => x.host === t.host && refKey(x.reference) === refKey(t.reference));
      if (!b) continue;
      const r = resolveRef(b);
      out.push({ deco: d, label: b.label || r.title, fallback: r.icon, href: r.href, view: null, note: r.state === 'available' ? null : r.note });
    } else {
      const v = cat.saved_views.find((x) => x.host === t.host && x.name === t.name);
      if (!v) continue;
      out.push({ deco: d, label: v.name, fallback: SCOPE_ICON[v.scope], href: null, view: v, note: `${SCOPE_LABEL[v.scope]} view` });
    }
  }
  return out.sort((a, b) => a.deco.order - b.deco.order || a.label.localeCompare(b.label));
}

function shortcutLink(s: Shortcut, cls: string): HTMLElement {
  const content = [decoIcon(s.deco, s.fallback), h('span', { class: 'trunc' }, s.label)];
  if (s.view) {
    const v = s.view;
    return h('button', { class: cls, type: 'button', title: s.note, onclick: () => applyView(v) }, content);
  }
  return s.href ? h('a', { class: cls, href: s.href, title: s.note }, content) : h('span', { class: `${cls} unavail`, title: s.note }, content);
}

/** Top-bar shortcuts: pinned bookmarks and views in their shared order. */
export function topShortcuts(): Kid {
  const list = shortcuts();
  if (!list.length) return null;
  if (mobileQuery.matches || list.length > 6) {
    return menu(
      'shortcuts',
      h(
        'summary',
        { class: 'btn', 'data-fk': 'shortcuts', 'aria-label': `Shortcuts (${list.length})` },
        icon('star'),
        h('span', { class: 'lbl-wide' }, 'Shortcuts'),
      ),
      [
        h('div', { class: 'menu-title' }, 'Pinned shortcuts'),
        h(
          'div',
          { class: 'menu-stack' },
          list.map((s) => shortcutLink(s, 'shortcut')),
        ),
      ],
    );
  }
  return h(
    'nav',
    { class: 'shortcuts', 'aria-label': 'Pinned shortcuts' },
    list.map((s) => shortcutLink(s, 'shortcut')),
  );
}

// Reordering pinned shortcuts swaps the order of two neighbours (two
// revision-checked commands in the shared queue).
function move(list: readonly Shortcut[], i: number, d: -1 | 1): void {
  const a = list[i];
  const b = list[i + d];
  if (!a || !b) return;
  const ao = a.deco.order === b.deco.order ? Math.max(0, Math.min(1000, b.deco.order + d)) : b.deco.order;
  void pref({ operation: 'navigation_decoration_set', decoration: { ...a.deco, order: ao } }, `Move “${a.label}”`);
  void pref({ operation: 'navigation_decoration_set', decoration: { ...b.deco, order: a.deco.order } }, `Move “${b.label}”`);
}

/** Section listing pinned shortcuts with reorder and unpin controls. */
export function shortcutManager(): HTMLElement | null {
  if (!S.nav) return null;
  const list = shortcuts();
  return h(
    'section',
    { class: 'sec', 'aria-label': 'Top-bar shortcuts' },
    h('div', { class: 'sec-h' }, icon('star', 'sm'), h('h2', null, 'Top-bar shortcuts')),
    list.length
      ? h(
          'ol',
          { class: 'list box' },
          list.map((s, i) =>
            h(
              'li',
              null,
              decoIcon(s.deco, s.fallback),
              h('span', { class: 'grow' }, s.label),
              // One non-wrapping group, so the controls never split across lines.
              h(
                'span',
                { class: 'sc-tools' },
                h('span', { class: 'muted mono' }, `order ${s.deco.order}`),
                h(
                  'button',
                  {
                    class: 'btn sm icon ghost',
                    type: 'button',
                    'aria-label': `Move ${s.label} earlier`,
                    disabled: i === 0 || !S.prefs,
                    onclick: () => move(list, i, -1),
                  },
                  icon('up', 'sm'),
                ),
                h(
                  'button',
                  {
                    class: 'btn sm icon ghost',
                    type: 'button',
                    'aria-label': `Move ${s.label} later`,
                    disabled: i === list.length - 1 || !S.prefs,
                    onclick: () => move(list, i, 1),
                  },
                  icon('down', 'sm'),
                ),
                h(
                  'button',
                  {
                    class: 'btn sm',
                    type: 'button',
                    disabled: !S.prefs,
                    onclick: () => void pref({ operation: 'navigation_decoration_set', decoration: { ...s.deco, pinned: false } }, `Unpin “${s.label}”`),
                  },
                  'Unpin',
                ),
              ),
            ),
          ),
        )
      : // Empty: one hint line instead of a boxed section.
        h('p', { class: 'hint sc-empty' }, 'No top-bar shortcuts yet: use “Icon & shortcut” on a row and tick “Show as a shortcut in the top bar”.'),
  );
}

/* ------------------------------------------------------------ avatars */

// The configured project's avatar from the fixed same-origin route, or the
// packaged repository icon. Decorative next to the project name (alt="").
// Loaded eagerly: these are tiny same-origin images, and lazy loading can
// leave an empty placeholder in a card rendered below the fold.
export function projectAvatar(project: number | null, cls = 'avatar'): Element {
  if (project == null) return icon('repo');
  const st = S.presentations.get(project);
  const src = st?.kind === 'result' ? safeAvatarSrc(st.result) : null;
  if (!src) return icon('repo');
  const img = h('img', { class: cls, src, alt: '', width: '16', height: '16', decoding: 'async' });
  img.addEventListener(
    'error',
    () => {
      img.replaceWith(icon('repo'));
    },
    { once: true },
  );
  return img;
}

/** Explains where the avatar came from (cached PNG or packaged fallback). */
export function avatarNote(project: number): string {
  const st = S.presentations.get(project);
  if (st?.kind !== 'result') return st?.kind === 'error' ? `Avatar unavailable: ${st.error}` : 'Avatar loading';
  const a = st.result.avatar;
  return a.kind === 'cached_png'
    ? `Cached project avatar (${a.width}×${a.height}, read ${a.fetched_at})`
    : `Packaged fallback avatar (${a.reason.replace('_', ' ')})`;
}
