import hashlib
import json
import tarfile
import tomllib
from pathlib import Path
from zipfile import ZipFile

import pytest

from scripts import devpod_package, install


def test_stage_packages_current_ui_without_replacing_recovery_assets(tmp_path):
    root = tmp_path / "source"
    static = root / "src/gspace/static"
    static.mkdir(parents=True)
    (root / "frontend-new").mkdir()
    (root / "pyproject.toml").write_text("[project]\nname='gspace'\n")
    for name in install.ASSETS:
        (static / name).write_bytes(b"recovery")
        (root / "frontend-new" / name).write_bytes(b"current:" + name.encode())
    stage = tmp_path / "stage"
    install.stage_project(root, stage)
    for name in install.ASSETS:
        assert (static / name).read_bytes() == b"recovery"
        assert (stage / "src/gspace/static" / name).read_bytes() == b"current:" + name.encode()
    wheel = tmp_path / "current.whl"
    with ZipFile(wheel, "w") as archive:
        for name in install.ASSETS:
            archive.write(stage / "src/gspace/static" / name, "gspace/static/" + name)
    assert (
        install.verify_wheel(wheel, root / "frontend-new")["app.js"]
        == hashlib.sha256(b"current:app.js").hexdigest()
    )
    (root / "frontend-new/app.js").write_bytes(b"newer")
    with pytest.raises(RuntimeError, match="stale frontend"):
        install.verify_wheel(wheel, root / "frontend-new")


def test_transfer_excludes_private_state_and_dependencies_and_is_reproducible(tmp_path):
    for name in devpod_package.FILES:
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(name)
    for tree in devpod_package.TREES:
        (tmp_path / tree).mkdir(parents=True, exist_ok=True)
    (tmp_path / "frontend-new/src/app.ts").write_text("export {}")
    for name in (
        ".state/token",
        ".repos/gitlabhq/config",
        ".venv/secret",
        "frontend-new/node_modules/package/token",
        "frontend-new/.git/config",
        "frontend-new/.npmrc",
        "tests/.env",
        "scripts/credentials.json",
        "src/gspace/__pycache__/private.pyc",
    ):
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("PRIVATE_SENTINEL")
    first, second = tmp_path / "first.tar.gz", tmp_path / "second.tar.gz"
    hashes = devpod_package.create_archive(tmp_path, first)
    devpod_package.create_archive(tmp_path, second)
    assert first.read_bytes() == second.read_bytes()
    assert "frontend-new/src/app.ts" in hashes
    with tarfile.open(first) as archive:
        for item in archive.getmembers():
            assert item.isfile() and item.name.startswith("gspace/")
            source = archive.extractfile(item)
            assert source is not None and b"PRIVATE_SENTINEL" not in source.read()
    assert not any("node_modules" in name or ".state" in Path(name).parts for name in hashes)


def test_transfer_rejects_source_symlinks(tmp_path):
    for name in devpod_package.FILES:
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("source")
    (tmp_path / "frontend-new/src").mkdir()
    (tmp_path / "frontend-new/src/secret.ts").symlink_to(tmp_path / "pyproject.toml")
    with pytest.raises(ValueError, match="Linked source"):
        devpod_package.source_files(tmp_path)


def test_transfer_has_current_static_assets_without_changing_recovery(tmp_path):
    for name in devpod_package.FILES:
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("current:" + name)
    original = tmp_path / "src/gspace/static/app.js"
    original.parent.mkdir(parents=True)
    original.write_text("preserved recovery")
    target = tmp_path / "transfer.tar.gz"
    devpod_package.create_archive(tmp_path, target)
    with tarfile.open(target) as archive:
        source = archive.extractfile("gspace/src/gspace/static/app.js")
        assert source is not None
        assert source.read() == b"current:frontend-new/app.js"
    assert original.read_text() == "preserved recovery"


def test_transfer_rejects_linked_tree_roots_and_parents(tmp_path):
    external = tmp_path / "external"
    external.mkdir()
    (external / "unexpected.py").write_text("PRIVATE")
    root = tmp_path / "root"
    root.mkdir()
    (root / "scripts").symlink_to(external, target_is_directory=True)
    with pytest.raises(ValueError, match="Linked source"):
        devpod_package.source_files(root)


def test_install_environment_excludes_auth_and_private_registry(monkeypatch):
    monkeypatch.setenv("NPM_TOKEN", "private")
    monkeypatch.setenv("UV_INDEX", "https://private.invalid")
    monkeypatch.setenv("PYTHONPATH", "/private")
    env = install.environment()
    assert not {"NPM_TOKEN", "UV_INDEX", "PYTHONPATH"}.intersection(env)
    assert env["NPM_CONFIG_USERCONFIG"] != env["NPM_CONFIG_GLOBALCONFIG"]
    assert env["NETRC"] == "/dev/null" and env["UV_KEYRING_PROVIDER"] == "disabled"


def test_frontend_lock_matches_manifest():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "frontend-new/package.json").read_text())
    lock = json.loads((root / "frontend-new/package-lock.json").read_text())
    assert lock["packages"][""]["devDependencies"] == manifest["devDependencies"]


def test_real_transfer_keeps_pyproject_poe_and_strict_rules_without_requirements(tmp_path):
    root = Path(__file__).resolve().parents[1]
    target = tmp_path / "source.tar.gz"
    devpod_package.create_archive(root, target)
    with tarfile.open(target) as archive:
        names = archive.getnames()
        assert "gspace/requirements.txt" not in names
        assert "gspace/poe_tasks.toml" not in names
        assert "gspace/uv.lock" in names
        source = archive.extractfile("gspace/pyproject.toml")
        assert source is not None
        project = tomllib.loads(source.read().decode())
        assert project["tool"]["basedpyright"]["typeCheckingMode"] == "strict"
        assert project["tool"]["ruff"]["target-version"] == "py312"
        assert {"E", "F", "B"} <= set(project["tool"]["ruff"]["lint"]["select"])
        dev = project["dependency-groups"]["dev"]
        assert all(
            any(dep.startswith(tool) for dep in dev)
            for tool in ("ruff", "basedpyright", "poethepoet")
        )
        assert "include" not in project["tool"]["poe"]
        recipes = project["tool"]["poe"]["tasks"]
        assert {"install", "lint", "typecheck", "test", "check"} <= recipes.keys()


@pytest.mark.parametrize(
    "installed",
    [
        {"gspace": "0.1.0", "fastapi": "1.0"},
        {"gspace": "0.1.0"},
        {"gspace": "0.1.0", "fastapi": "0.142.2", "ruff": "0.16.3"},
    ],
)
def test_global_runtime_must_match_native_lock_selection(installed):
    with pytest.raises(RuntimeError, match="uv.lock"):
        install.verify_runtime({"fastapi": "0.142.2"}, installed)
    install.verify_runtime({"fastapi": "0.142.2"}, {"fastapi": "0.142.2", "gspace": "0.1.0"})


@pytest.mark.parametrize("failure", ["empty", "duplicate", "missing", "tampered"])
def test_packaged_notices_require_both_complete_original_texts(tmp_path, failure):
    notices = tmp_path / "src/gspace/licenses"
    notices.mkdir(parents=True)
    components = []
    for name in ("ajv", "ajv-formats"):
        payload = b"Exact publisher text: " + name.encode()
        (notices / (name + ".LICENSE")).write_bytes(payload)
        components.append(
            {
                "name": name,
                "file": name + ".LICENSE",
                "sha256": hashlib.sha256(payload).hexdigest(),
            }
        )
    if failure == "empty":
        components = []
    elif failure == "duplicate":
        components = components[:1] * 2
    manifest = json.dumps({"components": components}).encode()
    (notices / "manifest.json").write_bytes(manifest)
    wheel = tmp_path / "notices.whl"
    with ZipFile(wheel, "w") as archive:
        archive.writestr("gspace/licenses/manifest.json", manifest)
        for path in notices.glob("*.LICENSE"):
            if failure == "missing" and path.name == "ajv.LICENSE":
                continue
            payload = b"changed" if failure == "tampered" else path.read_bytes()
            archive.writestr("gspace/licenses/" + path.name, payload)
    with pytest.raises((RuntimeError, KeyError)):
        install.verify_notices(wheel, tmp_path)


def guarded_bundle(tmp_path, name, body):
    source = tmp_path / name
    source.write_bytes(body)
    source.with_name(name + ".LICENSE").write_bytes(b"Exact upstream license")
    source.with_name(name + ".manifest.json").write_text(
        json.dumps(
            {
                "identity": "gspace-no-redirects.1",
                "binary_sha256": hashlib.sha256(body).hexdigest(),
            }
        )
    )
    return source


def test_private_companion_install_preserves_unowned_files_and_validates_hash(tmp_path):
    source = guarded_bundle(tmp_path, "source", b"verified")
    destination = tmp_path / "environment/gspace-glab"
    destination.parent.mkdir()
    destination.write_bytes(b"unrelated user executable")
    with pytest.raises(RuntimeError, match="unowned"):
        install.install_guarded_glab(source, destination)
    assert destination.read_bytes() == b"unrelated user executable"
    destination.unlink()
    source.write_bytes(b"modified")
    with pytest.raises(RuntimeError, match="manifest"):
        install.install_guarded_glab(source, destination)
    assert not destination.exists()


def test_private_companion_upgrade_stages_before_any_publication(tmp_path, monkeypatch):
    old = guarded_bundle(tmp_path, "old", b"old verified")
    new = guarded_bundle(tmp_path, "new", b"new verified")
    destination = tmp_path / "environment/gspace-glab"
    install.install_guarded_glab(old, destination)
    previous = {p.name: p.read_bytes() for p in destination.parent.iterdir()}
    actual = install.shutil.copyfile

    def fail_staging(source, target):
        if str(target).endswith("new-2"):
            raise OSError("synthetic staging failure")
        return actual(source, target)

    monkeypatch.setattr(install.shutil, "copyfile", fail_staging)
    with pytest.raises(OSError, match="staging failure"):
        install.install_guarded_glab(new, destination)
    assert {p.name: p.read_bytes() for p in destination.parent.iterdir()} == previous


def test_private_companion_publication_failure_restores_old_bundle(tmp_path, monkeypatch):
    old = guarded_bundle(tmp_path, "old", b"old verified")
    new = guarded_bundle(tmp_path, "new", b"new verified")
    destination = tmp_path / "environment/gspace-glab"
    install.install_guarded_glab(old, destination)
    previous = {p.name: p.read_bytes() for p in destination.parent.iterdir()}
    actual = install.os.replace
    failed = False

    def fail_once(source, target):
        nonlocal failed
        if not failed and str(source).endswith("new-2"):
            failed = True
            raise OSError("synthetic publication failure")
        return actual(source, target)

    monkeypatch.setattr(install.os, "replace", fail_once)
    with pytest.raises(OSError, match="publication failure"):
        install.install_guarded_glab(new, destination)
    assert {p.name: p.read_bytes() for p in destination.parent.iterdir()} == previous
    install.install_guarded_glab(new, destination)
    assert destination.read_bytes() == b"new verified"


def test_default_install_does_not_require_or_build_go(tmp_path, monkeypatch):
    import sys

    class ReachedFrontend(Exception):
        pass

    checked, commands = [], []

    def which(name):
        checked.append(name)
        return None if name in ("go", "curl") else "/synthetic/" + name

    def stop(frontend):
        raise ReachedFrontend

    monkeypatch.setattr(install, "ROOT", tmp_path)
    monkeypatch.setattr(sys, "argv", ["install.py"])
    monkeypatch.setattr(install.shutil, "which", which)
    monkeypatch.setattr(install, "run", lambda argv, *a, **kw: commands.append(argv))
    monkeypatch.setattr(install, "install_frontend_dependencies", stop)
    with pytest.raises(ReachedFrontend):
        install.main()
    assert set(checked) == {"uv", "node", "npm", "bun"}
    assert not any("scripts/build_guarded_glab.py" in command for command in commands)


def test_explicit_guarded_install_requires_go_before_mutation(tmp_path, monkeypatch):
    import sys

    monkeypatch.setattr(install, "ROOT", tmp_path)
    monkeypatch.setattr(sys, "argv", ["install.py", "--guarded-glab"])
    monkeypatch.setattr(install.shutil, "which", lambda name: None if name == "go" else name)
    with pytest.raises(RuntimeError, match="prerequisite go"):
        install.main()
    assert not (tmp_path / ".state").exists()


def test_installer_preserves_only_verified_certificate_settings(monkeypatch):
    expected = {
        "SSL_CERT_FILE": "/operator/public-ca.pem",
        "SSL_CERT_DIR": "/operator/ca-directory",
        "NODE_EXTRA_CA_CERTS": "/operator/node-ca.pem",
        "NPM_CONFIG_CAFILE": "/operator/npm-ca.pem",
    }
    for name, value in expected.items():
        monkeypatch.setenv(name, value)
    for name in ("UV_SYSTEM_CERTS", "UV_NATIVE_TLS"):
        monkeypatch.delenv(name, raising=False)
    for name in (
        "UV_INSECURE_HOST",
        "NODE_TLS_REJECT_UNAUTHORIZED",
        "NPM_CONFIG_STRICT_SSL",
        "UV_INDEX_PASSWORD",
        "UV_INDEX",
        "HTTPS_PROXY",
    ):
        monkeypatch.setenv(name, "UNSAFE_OR_PRIVATE")
    env = install.environment()
    assert {name: env.get(name) for name in expected} == expected
    assert env["UV_SYSTEM_CERTS"] == env["UV_NATIVE_TLS"] == "true"
    assert "UV_INSECURE_HOST" not in env and "NODE_TLS_REJECT_UNAUTHORIZED" not in env
    assert "NPM_CONFIG_STRICT_SSL" not in env
    assert not any(value == "UNSAFE_OR_PRIVATE" for value in env.values())


@pytest.mark.parametrize("setting", ["UV_SYSTEM_CERTS", "UV_NATIVE_TLS"])
def test_installer_respects_explicit_trust_store_selection(monkeypatch, setting):
    monkeypatch.delenv("UV_SYSTEM_CERTS", raising=False)
    monkeypatch.delenv("UV_NATIVE_TLS", raising=False)
    monkeypatch.setenv(setting, "false")
    env = install.environment()
    assert env["UV_SYSTEM_CERTS"] == env["UV_NATIVE_TLS"] == "false"
