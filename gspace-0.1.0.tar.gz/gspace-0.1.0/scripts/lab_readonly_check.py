"""Actual credential-free health, isolation and browser evidence for the local lab.

This does not create/read credentials or run seed, runner, pipelines or effects.
"""

from __future__ import annotations

import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.gitlab_lab import docker_run  # noqa: E402
from scripts.lab_loopback import CONTAINER, IMAGE, validate_container  # noqa: E402


def main() -> None:
    validate_container()
    output = ROOT / "output/lab"
    output.mkdir(parents=True, exist_ok=True)
    manifest = docker_run(
        [
            "docker",
            "exec",
            CONTAINER,
            "/usr/bin/head",
            "-n",
            "1",
            "/opt/gitlab/version-manifest.txt",
        ],
        timeout=15,
    )
    assert manifest.returncode == 0 and manifest.stdout.strip() == "gitlab-ce 18.11.12"
    inspect = docker_run(
        [
            "docker",
            "inspect",
            CONTAINER,
            "--format",
            "{{.State.Health.Status}}|{{.HostConfig.Memory}}|{{.HostConfig.NanoCpus}}|"
            "{{.HostConfig.Privileged}}",
        ],
        timeout=15,
    )
    assert (
        inspect.returncode == 0 and inspect.stdout.strip() == "healthy|8589934592|4000000000|false"
    )
    network = docker_run(
        [
            "docker",
            "network",
            "inspect",
            "gspace-integration-181112-v1_lab",
            "--format",
            "{{.Internal}}",
        ],
        timeout=15,
    )
    assert network.returncode == 0 and network.stdout.strip() == "true"
    statuses = {}
    with httpx.Client(trust_env=False, follow_redirects=False, timeout=10) as client:
        for path in ("/-/health", "/users/sign_in", "/api/v4/version"):
            response = client.get("http://127.0.0.1:8929" + path)
            assert len(response.content) < 1024 * 1024
            statuses[path] = response.status_code
            if path == "/-/health":
                assert response.status_code == 200 and response.text.strip() == "GitLab OK"
            elif path == "/users/sign_in":
                assert response.status_code == 200 and "Sign in" in response.text
            else:
                assert response.status_code == 401  # Real API needs approved operator access.
    outside = []
    errors = []
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(viewport={"width": 1440, "height": 960})

        def guard(route):
            parsed = urlsplit(route.request.url)
            if parsed.hostname != "127.0.0.1" or parsed.port != 8929:
                outside.append({"scheme": parsed.scheme, "host": parsed.hostname})
                route.abort()
            else:
                route.continue_()

        context.route("**/*", guard)
        page = context.new_page()
        page.on("pageerror", lambda error: errors.append(type(error).__name__))
        page.goto("http://127.0.0.1:8929/users/sign_in", wait_until="networkidle")
        assert page.locator('input[type="password"]').count() == 1
        page.screenshot(path=str(output / "gitlab-sign-in.png"), full_page=True)
        context.close()
        browser.close()
    assert not outside and not errors
    report = {
        "result": "passed",
        "checked_at": datetime.now(UTC).isoformat(),
        "actual_gitlab_version": "18.11.12",
        "image": IMAGE,
        "health": "healthy",
        "internal_network": True,
        "privileged": False,
        "memory_bytes": 8589934592,
        "cpus": 4,
        "browser": "installed Chrome",
        "loopback": "http://127.0.0.1:8929",
        "http_statuses": statuses,
        "external_browser_requests": outside,
        "javascript_errors": errors,
        "credentials_read_or_created_by_check": False,
        "authenticated_api_tests": "not_executed",
        "runner_pipeline_deployment_tests": "not_executed",
    }
    destination = ROOT / "docs/verification/lab-readonly-report.json"
    destination.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
