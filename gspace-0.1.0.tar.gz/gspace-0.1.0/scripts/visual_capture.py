"""Capture owned loopback fixture pages for the sole frontend writer's visual review."""

from __future__ import annotations

import argparse
import hashlib
import json
import socket
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def asset_hashes():
    return {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (ROOT / "frontend-new").iterdir()
        if path.suffix in (".html", ".js", ".css", ".svg") and path.is_file()
    }


@contextmanager
def fixture_server(assets: Path | None = None):
    """Independent state ensures captures never change the user's running demo preferences."""
    with tempfile.TemporaryDirectory(prefix="gspace-visual-fixture-") as temporary:
        directory = Path(temporary)
        config = directory / "config.toml"
        config.write_text(
            'mode="fixture"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n'
        )
        with socket.socket() as allocator:
            allocator.bind(("127.0.0.1", 0))
            port = allocator.getsockname()[1]
        source = (
            "import sys; from pathlib import Path; import uvicorn; import gspace.api as api; "
            "from gspace.config import load_config; api.STATIC=Path(sys.argv[1]); "
            "p=Path(sys.argv[2]); uvicorn.run(api.create_app(load_config(p),config_path=p), "
            "host='127.0.0.1',port=int(sys.argv[3]),access_log=False)"
        )
        server = subprocess.Popen(
            [
                sys.executable,
                "-c",
                source,
                str(assets or ROOT / "frontend-new"),
                str(config),
                str(port),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            for _ in range(100):
                if server.poll() is not None:
                    raise RuntimeError("Visual fixture server exited")
                try:
                    with urlopen(f"http://127.0.0.1:{port}/api/dashboard", timeout=0.2):
                        break
                except OSError:
                    time.sleep(0.1)
            else:
                raise RuntimeError("Visual fixture server startup timed out")
            yield port
        finally:
            server.terminate()
            server.wait(timeout=6)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=["before", "after"], default="before")
    parser.add_argument("--output", type=Path, help="Separate owned review-input harness probe")
    args = parser.parse_args()
    assets = asset_hashes()
    directory = (args.output or ROOT / "frontend-new/review-input" / args.phase).resolve()
    if not directory.is_relative_to((ROOT / "frontend-new/review-input").resolve()):
        raise ValueError("Capture output must remain in this frontend's review-input directory")
    directory.mkdir(parents=True, exist_ok=True)
    routes = [
        ("work-columns", "work"),
        ("compare", "compare"),
        ("merge-requests", "mrs"),
        ("branches", "branches"),
        ("pipelines", "pipelines"),
        ("bookmarks-empty", "bookmarks"),
        ("saved-views-empty", "views"),
        ("access-disabled", "access"),
        ("sources", "sources"),
        ("item-multiple-branches", "item/42/791"),
        ("item-rebase-runtime-mismatch", "item/42/792"),
        ("item-preprod-tested", "item/42/793"),
        ("mr-known-sha", "mrs/42/154"),
        ("mr-unlinked", "mrs/42/341"),
        ("branch-details", "branches/42/issue-791"),
        ("pipeline-failed", "pipelines/42/9201"),
        ("job-attempt", "pipelines/42/9201/job/92010"),
        ("item-missing", "item/42/99999"),
    ]
    if args.phase == "after":
        routes += [("milestones", "milestones"), ("settings", "settings")]
    manifest = []
    outbound = []
    errors = []
    with fixture_server() as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(viewport={"width": 1600, "height": 1100})

        def guard(route):
            parts = urlsplit(route.request.url)
            if parts.hostname == "127.0.0.1" and parts.port == port:
                route.continue_()
            else:
                outbound.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))

        def capture(name, route, theme, viewport):
            page.locator("img").evaluate_all(
                "imgs=>Promise.all(imgs.map(i=>i.decode().catch(()=>{})))"
            )
            path = directory / f"{name}-{theme}-{viewport[0]}.png"
            page.screenshot(path=str(path), full_page=True)
            manifest.append(
                {
                    "page": name,
                    "route": route,
                    "theme": theme,
                    "viewport": viewport,
                    "image": str(path.relative_to(ROOT / "frontend-new")),
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "heading": page.locator("main").inner_text()[:150],
                    "actual_theme": page.locator("html").get_attribute("data-theme"),
                }
            )

        def orientation(name):
            button = page.get_by_role("button", name=name, exact=True)
            if not button.is_visible():
                page.get_by_label("View options: layout, fields, sort and save").click()
            button.click()
            page.locator(".mx tbody tr").first.wait_for(state="visible")

        initial_settings = page.request.get(base + "/api/settings").json()["settings"]
        page.goto(base + "/#/work")
        page.wait_for_selector(".mx tbody tr")
        for theme, viewport in (
            ("light", (1600, 1100)),
            ("dark", (1600, 1100)),
            ("light", (390, 844)),
        ):
            latest_settings = page.request.get(base + "/api/settings").json()
            reset = page.request.post(
                base + "/api/settings",
                data={"revision": latest_settings["revision"], "settings": initial_settings},
            )
            assert reset.status == 200
            page.set_viewport_size({"width": viewport[0], "height": viewport[1]})
            page.evaluate("theme => { localStorage.setItem('gspace.theme', theme); }", theme)
            page.goto(base + "/#/work")
            page.reload()
            page.wait_for_selector(".mx tbody tr")
            assert page.locator("html").get_attribute("data-theme") == theme
            for name, route in routes:
                if (
                    args.phase == "before"
                    and viewport[0] == 390
                    and name in ("mr-known-sha", "mr-unlinked", "job-attempt")
                ):
                    continue
                if (
                    args.phase == "before"
                    and theme == "dark"
                    and name
                    not in (
                        "work-columns",
                        "compare",
                        "sources",
                        "pipeline-failed",
                        "settings",
                        "milestones",
                        "mr-known-sha",
                        "branch-details",
                        "item-rebase-runtime-mismatch",
                    )
                ):
                    continue
                page.goto(base + "/#/" + route)
                page.wait_for_timeout(450)
                capture(name, route, theme, viewport)
                if args.phase == "after" and name in (
                    "work-columns",
                    "merge-requests",
                    "branches",
                    "pipelines",
                    "item-multiple-branches",
                    "sources",
                    "mr-known-sha",
                    "branch-details",
                    "pipeline-failed",
                    "job-attempt",
                ):
                    trigger = page.locator(".inspector button[data-ev]:visible").first
                    if not trigger.count():
                        trigger = page.locator("main button[data-ev]:visible").first
                    if trigger.count():
                        trigger.scroll_into_view_if_needed()
                        trigger.click()
                        page.locator("#ev-pop").wait_for(state="visible")
                        capture(name + "-evidence-open", route, theme, viewport)
                        page.keyboard.press("Escape")
                if args.phase == "after" and name == "work-columns":
                    orientation("Rows")
                    capture("work-rows", route, theme, viewport)
                    orientation("Process columns")
                if args.phase == "after" and name == "item-multiple-branches":
                    controls = page.get_by_role(
                        "group", name="Record the Dev application test outcome"
                    )
                    with page.expect_response(base + "/api/preferences") as saved:
                        controls.get_by_role("button", name="Passed", exact=True).click()
                    assert saved.value.status == 200, (
                        f"Manual application record: {saved.value.status}: {saved.value.json()}"
                    )
                    page.wait_for_timeout(350)
                    history = page.locator("details.at-hist").first
                    history.locator("summary").click()
                    capture("item-manual-test-history", route, theme, viewport)
                    with page.expect_response(base + "/api/preferences") as saved:
                        controls.get_by_role(
                            "button", name="Reset to not tested", exact=True
                        ).click()
                    assert saved.value.status == 200
                    page.wait_for_timeout(350)
                if args.phase == "after" and name == "compare":
                    for issue in (791, 793):
                        prefs = page.request.get(base + "/api/preferences").json()
                        response = page.request.post(
                            base + "/api/preferences",
                            data={
                                "operation": "select",
                                "revision": prefs["revision"],
                                "key": {"project": {"value": 42}, "issue": {"value": issue}},
                                "enabled": True,
                            },
                        )
                        assert response.status == 200
                    page.reload()
                    page.wait_for_selector(".mx tbody tr")
                    capture("compare-populated", route, theme, viewport)
                    orientation("Rows")
                    capture("compare-populated-rows", route, theme, viewport)
                    orientation("Process columns")
                    for issue in (791, 793):
                        prefs = page.request.get(base + "/api/preferences").json()
                        response = page.request.post(
                            base + "/api/preferences",
                            data={
                                "operation": "select",
                                "revision": prefs["revision"],
                                "key": {"project": {"value": 42}, "issue": {"value": issue}},
                                "enabled": False,
                            },
                        )
                        assert response.status == 200
                    # The harness changed preferences outside the UI. Read the new
                    # revision before a later UI command; never silently replay a 409.
                    page.reload()
                    page.wait_for_load_state("networkidle")
                if args.phase == "after" and name == "settings":
                    latest = page.request.get(base + "/api/settings").json()
                    latest["settings"]["pipeline"]["environments"].append(
                        {"name": "qa", "label": "QA", "ref_source": "branch"}
                    )
                    latest["settings"]["project_pipeline_overrides"] = [
                        {
                            "project": {"value": 42},
                            "important_job_patterns": ["publish-*"],
                            "stages": None,
                            "jobs": None,
                            "environments": None,
                        }
                    ]
                    configured = page.request.post(
                        base + "/api/settings",
                        data={"revision": latest["revision"], "settings": latest["settings"]},
                    )
                    assert configured.status == 200
                    page.reload()
                    page.locator('[data-fk="set-branch"]').wait_for(state="visible")
                    capture("settings-custom-environment-override", route, theme, viewport)
                    page.locator('[data-fk="set-branch"]').fill("task-{iid}")
                    latest = page.request.get(base + "/api/settings").json()
                    latest["settings"]["timezone"] = "UTC"
                    external = page.request.post(
                        base + "/api/settings",
                        data={"revision": latest["revision"], "settings": latest["settings"]},
                    )
                    assert external.status == 200
                    with page.expect_response(base + "/api/settings") as conflict:
                        page.locator('[data-fk="set-save"]').click()
                    assert conflict.value.status == 409
                    page.locator('[data-fk="set-save"][disabled]').wait_for()
                    capture("settings-conflict-kept-edits", route, theme, viewport)
        browser.close()
    if asset_hashes() != assets:
        raise RuntimeError("Frontend assets changed during capture; repeat after the writer stops")
    report = {
        "source": "actual loopback synthetic browser",
        "phase": args.phase,
        "images": manifest,
        "outbound": outbound,
        "browser_errors": errors,
        "asset_hashes": assets,
    }
    (directory / "manifest.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"images": len(manifest), "outbound": len(outbound), "errors": errors}))


if __name__ == "__main__":
    main()
