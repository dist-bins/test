"""Verify compiled visual interactions on an isolated loopback fixture, without preview edits."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/claude-visual-interactions"
    )
    output = parser.parse_args().output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    checks = []
    outside = []
    errors = []
    measurements = []
    with fixture_server(ROOT / "frontend-new") as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(service_workers="block")

        def guard(route):
            u = urlsplit(route.request.url)
            if u.scheme == "http" and u.hostname == "127.0.0.1" and u.port == port:
                route.continue_()
            else:
                outside.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.set_default_timeout(5000)
        page.on("pageerror", lambda e: errors.append(str(e)))

        def go(path):
            page.goto(base + "/#/" + path)
            page.wait_for_load_state("networkidle")

        def check(name, operation):
            try:
                operation()
                checks.append({"name": name, "passed": True})
            except Exception as e:
                checks.append({"name": name, "passed": False, "error": str(e)[:1400]})
                page.keyboard.press("Escape")

        go("work")
        page.locator('[data-fk="mode-visual"]').click()
        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            page.set_viewport_size({"width": width, "height": 1100 if width > 500 else 844})
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            page.reload()
            go("work" if width > 500 else "item/42/791")

            def popover(theme=theme, width=width):
                trigger = page.locator(
                    ".flowt tbody button[data-ev]" if width > 500 else ".flow-lane button[data-ev]"
                ).first
                trigger.scroll_into_view_if_needed()
                before = trigger.bounding_box()
                assert before
                for _ in range(12):
                    trigger.click()
                    expect(page.locator("#ev-pop")).to_be_visible()
                    after = trigger.bounding_box()
                    assert after and max(abs(after[k] - before[k]) for k in before) < 0.75
                    pop = page.locator("#ev-pop").bounding_box()
                    assert pop and pop["x"] >= -0.5 and pop["x"] + pop["width"] <= width + 0.5
                    trigger.click()
                    expect(page.locator("#ev-pop")).not_to_be_visible()
                trigger.focus()
                page.keyboard.press("Enter")
                expect(page.locator("#ev-pop")).to_be_visible()
                expect(page.locator("#ev-pop")).to_contain_text("Reason:")
                page.screenshot(path=str(output / f"popover-{theme}-{width}.png"))
                page.keyboard.press("Escape")
                expect(trigger).to_be_focused()
                trigger.click()
                page.locator(".brand").click()
                expect(page.locator("#ev-pop")).not_to_be_visible()
                measurements.append({"theme": theme, "width": width, "toggles": 12})

            check(f"visual popover no-shift/containment/keyboard/outside {theme} {width}", popover)

            def repeated_navigation():
                for route in ("work", "pipelines", "mrs", "branches", "milestones", "work"):
                    go(route)
                    expect(page.locator('[data-fk="mode-visual"]')).to_have_attribute(
                        "aria-pressed", "true"
                    )
                for _ in range(4):
                    page.get_by_role("button", name="Refresh snapshot", exact=True).click()
                    page.wait_for_load_state("networkidle")
                    expect(page.locator("main")).to_contain_text("Preserve passenger")
                page.reload()
                expect(page.locator('[data-fk="mode-visual"]')).to_have_attribute(
                    "aria-pressed", "true"
                )

            check(f"visual route/refresh/reload stability {theme} {width}", repeated_navigation)

            def card_containment(theme=theme, width=width):
                go("branches")
                violations = page.locator(".vcard .vc-b .chip").evaluate_all(
                    "els=>els.flatMap(e=>{const a=e.getBoundingClientRect();"
                    "const b=e.closest('.vcard').getBoundingClientRect();"
                    "return a.right>b.right+0.5||a.left<b.left-0.5 ? "
                    "[{text:e.textContent,right:a.right,cardRight:b.right}]:[]})"
                )
                assert not violations, violations
                page.screenshot(path=str(output / f"contained-branches-{theme}-{width}.png"))

            check(f"visual resource badges stay within cards {theme} {width}", card_containment)

        def timeline_filter():
            go("milestones")
            with page.expect_response(base + "/api/preferences") as saved:
                page.locator('[data-fk^="ms-tl-"]').filter(has_text="Flight October").click()
            assert saved.value.status == 200
            expect(page).to_have_url(base + "/#/work")
            selected = page.request.get(base + "/api/preferences").json()["filters"]["milestone"]
            assert selected["mode"] == "selected" and selected["selected"] is not None
            page.reload()
            expect(page.locator('[data-fk="w-ms"]')).not_to_have_value("all")

        check("timeline selection applies typed shared filter and survives reload", timeline_filter)

        def graph_error():
            attempts = []

            def fail(route):
                attempts.append(route.request.url)
                route.fulfill(
                    status=503,
                    content_type="application/json",
                    body='{"detail":"Synthetic graph unavailable"}',
                )

            pattern = base + "/api/items/42/791/pipeline-graph"
            context.route(pattern, fail)
            go("item/42/791")
            expect(page.locator("main")).to_contain_text("Pipeline graph unavailable")
            expect(page.locator("main")).to_contain_text("nothing is inferred instead")
            expect(page.locator("main")).to_contain_text("issue-791")
            page.wait_for_timeout(600)
            assert len(attempts) == 1, attempts
            page.get_by_role("button", name="Refresh snapshot", exact=True).click()
            expect(page.locator("main")).to_contain_text("Pipeline graph unavailable")
            page.wait_for_timeout(600)
            assert len(attempts) == 2, attempts
            context.unroute(pattern, fail)
            page.get_by_role("button", name="Refresh snapshot", exact=True).click()
            expect(
                page.get_by_role("list", name="Pipelines by trigger depth, upstream first")
            ).to_be_visible()

        check(
            "graph unavailable preserves process, no auto retry, explicit refresh recovers",
            graph_error,
        )

        def inspector():
            page.set_viewport_size({"width": 1600, "height": 1100})
            go("work")
            page.locator('main a[href="#/pipelines/42/9201"]').first.click()
            expect(page.locator(".inspector")).to_contain_text("unit-tests")
            expect(page.locator(".inspector")).to_contain_text("attempt")
            page.keyboard.press("Escape")
            go("mrs")
            page.locator('main a[href="#/mrs/42/154"]').first.click()
            expect(page.locator(".inspector")).to_contain_text("Draft")

        check("visual pipeline/MR cards retain scoped inspector drilldown", inspector)

        def custom_saved_fields():
            page.keyboard.press("Escape")
            settings = page.request.get(base + "/api/settings").json()
            settings["settings"]["pipeline"]["environments"].append(
                {"name": "qa", "label": "QA", "ref_source": "branch"}
            )
            assert (
                page.request.post(
                    base + "/api/settings",
                    data={"revision": settings["revision"], "settings": settings["settings"]},
                ).status
                == 200
            )
            go("work")
            page.reload()
            expect(page.locator(".flowt tbody th").filter(has_text="QA")).to_be_visible()
            fields = page.get_by_label("Visible fields", exact=True)
            fields.click()
            checkbox = page.locator('[data-fk$="-environment:qa"]')
            checkbox.uncheck()
            if fields.locator("xpath=..").get_attribute("open") is not None:
                fields.click()
            expect(page.locator(".flowt tbody th").filter(has_text="QA")).not_to_be_visible()
            fields.click()
            checkbox.check()
            if fields.locator("xpath=..").get_attribute("open") is not None:
                fields.click()
            page.get_by_role("button", name="Save view", exact=True).click()
            dialog = page.get_by_role("dialog")
            dialog.locator('input[name="name"]').fill("Configured QA")
            with page.expect_response(base + "/api/preferences") as saved:
                dialog.get_by_role("button", name="Save view", exact=True).click()
            assert saved.value.status == 200
            actual = page.request.get(base + "/api/preferences").json()
            view = next(v for v in actual["saved_views"] if v["name"] == "Configured QA")
            assert "environment:qa" in view["columns"] and view["scope"] == "work_items"
            page.reload()
            expect(page.locator(".flowt tbody th").filter(has_text="QA")).to_be_visible()
            page.locator('[data-fk="mode-detailed"]').click()
            expect(page.locator("main")).to_contain_text("QA")
            go("views")
            expect(page.locator("main")).to_contain_text("Configured QA")
            go("sources")
            expect(page.locator("main")).to_contain_text("QA")

        check(
            "custom environment field selection/shared saved view/modes/Sources",
            custom_saved_fields,
        )
        browser.close()
    failed = sum(not c["passed"] for c in checks) + len(errors) + len(outside)
    report = {
        "purpose": __doc__,
        "checks": checks,
        "measurements": measurements,
        "js_errors": errors,
        "outside": outside,
        "failed": failed,
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps({"checks": len(checks), "failed": failed, "report": str(output / "report.json")})
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
