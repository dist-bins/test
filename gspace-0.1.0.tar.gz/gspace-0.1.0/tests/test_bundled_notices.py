import hashlib
import json

import pytest

from scripts.bundled_notices import generate


def test_packaged_notices_retain_exact_publisher_bytes_and_locked_identity(tmp_path):
    lock = {"packages": {}}
    expected = {}
    for name in ("ajv", "ajv-formats"):
        package = tmp_path / "frontend-new/node_modules" / name
        package.mkdir(parents=True)
        metadata = {"name": name, "version": "1.0", "license": "MIT"}
        (package / "package.json").write_text(json.dumps(metadata))
        body = (
            f"Copyright publisher {name}\r\nPermission is hereby granted for this fixture.\r\n"
        ).encode()
        (package / "LICENSE").write_bytes(body)
        expected[name] = body
        lock["packages"]["node_modules/" + name] = metadata
    (tmp_path / "frontend-new/package-lock.json").write_text(json.dumps(lock))
    report = generate(tmp_path)
    assert len(report["components"]) == 2
    for record in report["components"]:
        body = (tmp_path / "src/gspace/licenses" / record["file"]).read_bytes()
        assert body == expected[record["name"]]
        assert hashlib.sha256(body).hexdigest() == record["sha256"]
    metadata_path = tmp_path / "frontend-new/node_modules/ajv/package.json"
    metadata_path.write_text(json.dumps({"name": "ajv", "version": "other", "license": "MIT"}))
    with pytest.raises(ValueError, match="identity"):
        generate(tmp_path)


def test_notice_text_symlink_and_missing_publisher_grant_are_rejected(tmp_path):
    frontend = tmp_path / "frontend-new"
    package = frontend / "node_modules/ajv"
    package.mkdir(parents=True)
    metadata = {"name": "ajv", "version": "1", "license": "MIT"}
    (frontend / "package-lock.json").write_text(
        json.dumps({"packages": {"node_modules/ajv": metadata}})
    )
    (package / "package.json").write_text(json.dumps(metadata))
    outside = tmp_path / "unrelated"
    outside.write_text("private")
    (package / "LICENSE").symlink_to(outside)
    with pytest.raises(ValueError, match="linked"):
        generate(tmp_path)
    (package / "LICENSE").unlink()
    (package / "LICENSE").write_text("not a license grant")
    with pytest.raises(ValueError, match="grant"):
        generate(tmp_path)
