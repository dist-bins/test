"""Milestone date semantics and counts over an explicitly covered issue snapshot."""

from __future__ import annotations

from datetime import UTC, date, datetime
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import AwareDatetime

from gspace.models import (
    Milestone,
    MilestoneFilter,
    MilestoneKey,
    Model,
    ProjectId,
    Snapshot,
    WorkItem,
)


class MilestoneCount(Model, frozen=True):
    milestone: Milestone
    date_current: Literal["yes", "no", "unknown"]
    date_reason: str
    work_items: int | None
    opened_work_items: int | None
    visible_work_items: int


class MilestoneCatalog(Model, frozen=True):
    source: Literal["fixture", "glab"]
    host: str
    fetched_at: AwareDatetime
    timezone: str
    date: date
    projects: tuple[ProjectId, ...]
    issue_coverage: Literal["complete_configured_projects", "unknown"]
    count_scope: Literal["all_snapshot_issues_in_selected_configured_projects"] = (
        "all_snapshot_issues_in_selected_configured_projects"
    )
    selection: MilestoneFilter
    date_current_candidates: tuple[MilestoneKey, ...]
    entries: tuple[MilestoneCount, ...]
    unassigned_work_items: int | None
    warnings: tuple[str, ...]


def date_current(milestone: Milestone, today: date) -> tuple[Literal["yes", "no", "unknown"], str]:
    if milestone.state != "active":
        return "no", "Milestone is closed; date-current selection requires active state"
    if milestone.start_date is None or milestone.due_date is None:
        return "unknown", "Both start and due dates are needed; active state alone is insufficient"
    if milestone.start_date <= today <= milestone.due_date:
        return "yes", "Active milestone contains the configured local date, inclusively"
    return "no", "Configured local date is outside the milestone interval"


def matches(item: WorkItem, selection: MilestoneFilter, snapshot: Snapshot, today: date) -> bool:
    match selection.mode:
        case "all":
            return True
        case "unassigned":
            return item.milestone is None
        case "selected":
            return item.milestone == selection.selected
        case "active" | "date_current":
            milestone = next((m for m in snapshot.milestones if m.key == item.milestone), None)
            return milestone is not None and (
                milestone.state == "active"
                if selection.mode == "active"
                else date_current(milestone, today)[0] == "yes"
            )


def catalog(
    snapshot: Snapshot,
    host: str,
    projects: tuple[ProjectId, ...],
    selection: MilestoneFilter,
    visible: tuple[WorkItem, ...],
    timezone: str,
    now: datetime | None = None,
) -> MilestoneCatalog:
    today = (now or datetime.now(UTC)).astimezone(ZoneInfo(timezone)).date()
    items = tuple(item for item in snapshot.items if item.identity.project in projects)
    complete = snapshot.issue_coverage == "complete_configured_projects"
    entries: list[MilestoneCount] = []
    candidates: list[MilestoneKey] = []
    for milestone in snapshot.milestones:
        if milestone.key.kind == "project" and milestone.key.project not in projects:
            continue
        rows = tuple(item for item in items if item.milestone == milestone.key)
        current, reason = date_current(milestone, today)
        if current == "yes":
            candidates.append(milestone.key)
        entries.append(
            MilestoneCount(
                milestone=milestone,
                date_current=current,
                date_reason=reason,
                work_items=len(rows) if complete else None,
                opened_work_items=sum(item.state == "opened" for item in rows)
                if complete
                else None,
                visible_work_items=sum(item.milestone == milestone.key for item in visible),
            )
        )
    warnings = (
        ()
        if complete
        else ("Snapshot has no complete issue-pagination coverage; total counts are unknown",)
    )
    if len(candidates) > 1:
        warnings += (
            "Several milestones are date-current; no single milestone is automatically selected",
        )
    return MilestoneCatalog(
        source=snapshot.source,
        host=host,
        fetched_at=snapshot.fetched_at,
        timezone=timezone,
        date=today,
        projects=projects,
        issue_coverage=snapshot.issue_coverage,
        selection=selection,
        date_current_candidates=tuple(candidates),
        entries=tuple(entries),
        unassigned_work_items=sum(item.milestone is None for item in items) if complete else None,
        warnings=warnings,
    )
