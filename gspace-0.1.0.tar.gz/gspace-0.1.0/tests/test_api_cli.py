import json
import os
import subprocess
import sys

import pytest
from fastapi.testclient import TestClient

from gspace.api import create_app


def test_dashboard_details_and_previews_are_end_to_end(service):
    client = TestClient(create_app(service=service))
    dashboard = client.get("/api/dashboard")
    assert dashboard.status_code == 200
    assert len(dashboard.json()["views"]) == 4
    assert (
        client.get("/api/items/42/791").json()["item"]["merge_requests"][0]["iid"]["value"] == 154
    )
    preview = client.post("/api/items/42/791/preview", json={"action": "tag"})
    assert preview.json()["suggestion"] == "flight-2.4.09"
    assert preview.json()["executed"] is False
    assert client.get("/api/capabilities").json()["remote_mutations"] is False
    assert client.post("/api/items/42/791/merge", json={}).status_code == 404


def test_api_shared_preferences_and_conflict(service, key):
    client = TestClient(create_app(service=service))
    body = {
        "operation": "select",
        "revision": 0,
        "key": key.model_dump(mode="json"),
        "enabled": True,
    }
    assert client.post("/api/preferences", json=body).json()["revision"] == 1
    assert len(client.get("/api/dashboard?selected=true").json()["views"]) == 1
    assert client.post("/api/preferences", json=body).status_code == 409
    invalid = {
        "operation": "checklist",
        "revision": 1,
        "key": key.model_dump(mode="json"),
        "enabled": True,
    }
    assert client.post("/api/preferences", json=invalid).status_code == 422
    assert (
        client.post("/api/preferences", json={**body, "revision": 1, "enabled": "true"}).status_code
        == 422
    )


def test_api_does_not_accept_arbitrary_urls_or_remote_action(service):
    client = TestClient(create_app(service=service))
    assert (
        client.post(
            "/api/items/42/791/preview", json={"action": "deploy-dev", "url": "http://127.0.0.1"}
        ).status_code
        == 422
    )
    response = client.post("/api/items/42/791/observe/dev", json={"url": "https://evil.invalid"})
    assert response.status_code == 422
    configured_only = client.post("/api/items/42/791/observe/dev", json={})
    assert configured_only.status_code == 400
    assert "No endpoint configured" in configured_only.json()["detail"]


def test_local_origin_host_and_content_type_guards(service):
    client = TestClient(create_app(service=service))
    assert client.get("/api/dashboard", headers={"host": "evil.invalid"}).status_code == 400
    assert (
        client.post("/api/refresh", json={}, headers={"origin": "https://evil.invalid"}).status_code
        == 403
    )
    assert client.post("/api/refresh", content="{}").status_code == 415
    response = client.get("/")
    assert response.status_code == 200
    assert "frame-ancestors 'none'" in response.headers["content-security-policy"]
    assert 'lang="en"' in response.text
    assert client.get("/assets/app.js").status_code == 200


def cli(tmp_path, *args):
    config = tmp_path / "config.toml"
    config.write_text(
        'mode = "fixture"\npreferences_path = "preferences.toml"\ncache_path = "cache.json"\n'
    )
    return subprocess.run(
        [sys.executable, "-m", "gspace", args[0], "--config", str(config), *args[1:]],
        text=True,
        capture_output=True,
        timeout=15,
        env={**os.environ, "NO_COLOR": "1"},
    )


def test_cli_json_stdout_clean_and_error_stderr(tmp_path):
    good = cli(tmp_path, "dashboard", "--json")
    assert good.returncode == 0
    assert good.stderr == ""
    assert len(json.loads(good.stdout)["views"]) == 4
    assert "\x1b" not in good.stdout
    bad = cli(tmp_path, "show", "42:999", "--json")
    assert bad.returncode == 2 and bad.stdout == ""
    assert "error" in json.loads(bad.stderr)


@pytest.mark.parametrize("width", [40, 80, 160])
def test_cli_matrix_respects_terminal_width_and_no_color(tmp_path, width):
    result = cli(tmp_path, "list", "--no-color", "--width", str(width))
    assert result.returncode == 0
    assert "\x1b" not in result.stdout
    assert max(map(len, result.stdout.splitlines())) <= width


def test_cli_preferences_are_visible_to_api_and_compare(tmp_path):
    assert cli(tmp_path, "select", "42:791", "--json").returncode == 0
    selected = cli(tmp_path, "compare", "--json")
    assert len(json.loads(selected.stdout)["views"]) == 1
    assert cli(tmp_path, "group", "42:791", "Release", "--json").returncode == 0
    assert cli(tmp_path, "filters", "--group", "Release", "--json").returncode == 0
    assert len(json.loads(cli(tmp_path, "dashboard", "--json").stdout)["views"]) == 1
    from gspace.config import load_config

    response = TestClient(create_app(load_config(tmp_path / "config.toml"))).get("/api/dashboard")
    assert response.json()["views"][0]["selected"] is True
    assert response.json()["views"][0]["groups"] == ["Release"]


def test_cli_all_dedicated_commands_and_preview_are_read_only(tmp_path):
    for command in ("show", "pipelines", "environments"):
        assert cli(tmp_path, command, "42:791", "--json").returncode == 0
    preview = json.loads(cli(tmp_path, "preview", "42:791", "tag", "--json").stdout)
    assert preview["executed"] is False
    assert preview["suggestion"] == "flight-2.4.09"
    assert not (tmp_path / "cache.json").exists()
