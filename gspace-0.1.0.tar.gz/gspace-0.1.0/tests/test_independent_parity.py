import json
import subprocess
import sys
from datetime import UTC, datetime, timedelta
from urllib.parse import parse_qs, urlsplit

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from gspace.access import AccessError, ProfileTransport
from gspace.access_models import PatProfile
from gspace.actions import ActionService, ProbeComparisonRequest
from gspace.api import create_app
from gspace.config import AppConfig
from gspace.glab import AdapterError, GlabAdapter, RunResult
from gspace.models import ApplicationTestRecord, ProjectId, Version
from gspace.navigation import SavedView
from gspace.pipeline_config import EnvironmentDefinition, PipelineRules
from gspace.resource_catalog import BranchCatalog, resources
from gspace.service import ApplicationTestChange, SavedViewSet, Service
from tests.test_access_actions import SECRET, SHA, Remote, profile, tag
from tests.test_glab import live


def renamed(name, **changes):
    return PatProfile.model_validate({**profile().model_dump(), "name": name, **changes})


def test_profile_comparison_is_fresh_isolated_get_only_and_redacted(service):
    profiles = (profile(), renamed("reader", write_enabled=False), renamed("missing"))
    remotes = {p.name: Remote() for p in profiles}
    remotes["reader"].identity = 8
    remotes["missing"].identity = 9
    factories = []

    def factory(p):
        factories.append(p.name)
        return ProfileTransport(
            p,
            resolver=lambda _: None if p.name == "missing" else SECRET,
            http_transport=remotes[p.name].http,
        )

    actions = ActionService(profiles, factory)
    request = ProbeComparisonRequest(action=tag(), profiles=tuple(p.name for p in profiles))
    client = TestClient(create_app(service=service, actions=actions))
    response = client.post("/api/access/compare", json=request.model_dump(mode="json"))
    assert response.status_code == 200
    data = response.json()
    assert [r["kind"] for r in data["rows"]] == ["allowed", "denied", "unknown"]
    assert [r["identity"] for r in data["rows"]] == [{"value": 7}, {"value": 8}, None]
    assert data["rows"][2]["error_code"] == "missing_secret"
    assert data["executed"] is False and data["deferred_actions"] == ["ready", "merge", "rebase"]
    assert SECRET not in response.text and "secret_env" not in response.text
    assert "confirmation" not in response.text and actions._plans == {}
    assert factories == [p.name for p in profiles]
    for remote in remotes.values():
        assert all(method == "GET" for method, _, _ in remote.calls)
    again = actions.compare(request)
    assert again.checked_at > datetime.fromisoformat(data["checked_at"])
    assert len(factories) == 6  # No reused permission/identity evidence.


@pytest.mark.parametrize(
    "changes", [{"host": "https://other.invalid"}, {"projects": [{"value": 99}]}]
)
def test_profile_comparison_rejects_whole_scope_before_transport(changes):
    other = renamed("other", **changes)
    actions = ActionService(
        (profile(), other), lambda _: pytest.fail("scope must precede transport")
    )
    with pytest.raises(AccessError, match="same configured host and project"):
        actions.compare(ProbeComparisonRequest(action=tag(), profiles=("lab-owner", "other")))


@pytest.mark.parametrize(
    "names", [("lab-owner", "lab-owner"), ("reader", "missing"), ("lab-owner",)]
)
def test_profile_comparison_request_rejects_ambiguous_selection(names):
    with pytest.raises(ValidationError):
        ProbeComparisonRequest(action=tag(), profiles=names)


def test_failed_profile_does_not_mask_peer_or_expose_response(service):
    broken, owner = Remote(), Remote()
    broken.denied = True
    profiles = (renamed("blocked"), profile())
    actions = ActionService(
        profiles, lambda p: (broken if p.name == "blocked" else owner).factory(p)
    )
    comparison = actions.compare(
        ProbeComparisonRequest(action=tag(), profiles=("blocked", "lab-owner"))
    )
    assert [r.kind for r in comparison.rows] == ["denied", "allowed"]
    assert comparison.rows[0].identity is None
    assert SECRET not in comparison.model_dump_json()
    assert len(broken.calls) == 1
    assert all(m == "GET" for m, _, _ in owner.calls)


@pytest.mark.parametrize("kind", ["branches", "pipelines"])
def test_general_fixture_catalogs_include_unlinked_and_scope(service, kind):
    catalog = service.resource_catalog(kind, ProjectId(value=42))
    assert catalog.total == len(catalog.rows) == catalog.scope_total
    assert catalog.coverage_basis == "synthetic_fixture" and catalog.coverage == "complete"
    assert all(p.id.value == 42 for p in catalog.projects)
    if isinstance(catalog, BranchCatalog):
        assert any(r.branch.name == "main" for r in catalog.rows)
    else:
        assert any(r.pipeline.ref == "main" for r in catalog.rows)
        assert all(r.jobs_coverage == "not_loaded" and not r.pipeline.jobs for r in catalog.rows)
    with pytest.raises(KeyError):
        service.resource_catalog(kind, ProjectId(value=777))
    response = TestClient(create_app(service=service)).get(f"/api/{kind}?project=42")
    assert response.status_code == 200 and response.json()["total"] == catalog.total
    assert (
        TestClient(create_app(service=service)).get(f"/api/{kind}?project=777").status_code == 404
    )


def catalog_runner(kind, *, full=False, wrong_project=False, duplicate=False, malformed=False):
    calls = []

    def runner(argv, timeout):
        assert argv[:6] == [
            "glab",
            "api",
            "--hostname",
            "gitlab.example.invalid",
            "--method",
            "GET",
        ]
        calls.append(argv[-1])
        url = urlsplit(argv[-1])
        if url.path == "version":
            return RunResult(code=0, stdout=b'{"version":"18.11.12"}')
        assert (
            url.path
            == f"projects/42/{'repository/branches' if kind == 'branches' else 'pipelines'}"
        )
        query = parse_qs(url.query)
        assert query["pagination"] == ["offset"] and query["per_page"] == ["100"]
        page = int(query["page"][0])
        if kind == "pipelines" and query.get("source") == ["parent_pipeline"]:
            return RunResult(
                code=0,
                stdout=json.dumps(
                    [
                        {
                            "id": 9001,
                            "project_id": 42,
                            "ref": "child-ref",
                            "sha": SHA,
                            "source": "parent_pipeline",
                            "status": "running",
                        }
                    ]
                ).encode(),
            )
        count = 100 if page == 1 or full else 1
        if kind == "branches":
            rows = [{"name": f"topic/{page}-{n}", "commit": {"id": SHA}} for n in range(count)]
        else:
            rows = [
                {
                    "id": page * 1000 + n,
                    "project_id": 99 if wrong_project else 42,
                    "ref": "topic;$(unsafe)",
                    "sha": SHA,
                    "source": "push",
                    "status": "success",
                }
                for n in range(count)
            ]
        if duplicate:
            rows[-1] = rows[0]
        return RunResult(
            code=0, stdout=b"SECRET invalid JSON" if malformed else json.dumps(rows).encode()
        )

    return runner, calls


@pytest.mark.parametrize("kind", ["branches", "pipelines"])
def test_general_catalog_bounded_complete_gets_and_encoded_links(kind):
    runner, calls = catalog_runner(kind)
    cfg = live()
    catalog = resources(kind, cfg.projects, GlabAdapter(cfg, runner))
    assert catalog.total == (101 if kind == "branches" else 102)
    assert len(calls) == (3 if kind == "branches" else 4)
    assert (
        any("page=2" in call for call in calls)
        and catalog.coverage_basis == "bounded_GET_pagination"
    )
    if isinstance(catalog, BranchCatalog):
        assert "%2F" in catalog.rows[0].branch.link.url
        assert all(r.branch.rebase.kind == "unknown" for r in catalog.rows)
    else:
        assert all(r.pipeline.project.value == 42 and not r.pipeline.jobs for r in catalog.rows)


@pytest.mark.parametrize("kind", ["branches", "pipelines"])
@pytest.mark.parametrize("failure", ["limit", "duplicate", "malformed"])
def test_general_catalog_never_labels_partial_or_invalid_complete(kind, failure):
    runner, calls = catalog_runner(
        kind,
        full=failure == "limit",
        duplicate=failure == "duplicate",
        malformed=failure == "malformed",
    )
    with pytest.raises(AdapterError) as error:
        resources(kind, live().projects, GlabAdapter(live(), runner))
    assert error.value.code == ("limit" if failure == "limit" else "validation")
    assert len(calls) <= 4 and "SECRET" not in str(error.value)


def test_pipeline_general_catalog_rejects_foreign_project_without_followups():
    runner, calls = catalog_runner("pipelines", wrong_project=True)
    with pytest.raises(AdapterError, match="project identity mismatch"):
        resources("pipelines", live().projects, GlabAdapter(live(), runner))
    assert len(calls) == 3


def test_manual_history_current_superseded_stale_unknown_api(service, key):
    target = service.view(service.item(key), service.preferences.read()).application_tests[0].target
    assert target is not None and target.sha
    now = datetime.now(UTC)
    for age, outcome, version in [
        (3, "passed", Version(sha="f" * 40)),
        (2, "failed", target),
        (1, "not_tested", target),
    ]:
        service.change(
            ApplicationTestChange(
                revision=service.preferences.read().revision,
                record=ApplicationTestRecord(
                    key=key,
                    environment="dev",
                    version=version,
                    outcome=outcome,
                    checked_at=now - timedelta(minutes=age),
                    notes="[red]literal[/red]",
                ),
            )
        )
    history = service.application_test_history(key, "dev")
    assert [e.state for e in history.entries] == ["current", "superseded", "stale"]
    assert history.entries[0].record.outcome == "not_tested"
    assert history.entries[2].record.outcome == "passed"  # Outcome never reinterpreted.
    client = TestClient(create_app(service=service))
    response = client.get("/api/items/42/791/application-tests?environment=dev")
    assert response.status_code == 200 and len(response.json()["entries"]) == 3
    assert (
        client.get("/api/items/42/791/application-tests?environment=nonexistent").status_code == 400
    )
    assert client.get("/api/items/42/777/application-tests").status_code == 404
    assert not service.config.cache_path.exists()


def test_custom_environment_columns_are_shared_configured_and_scoped(tmp_path, key):
    defaults = PipelineRules()
    cfg = AppConfig(
        preferences_path=tmp_path / "prefs.toml",
        pipeline=PipelineRules(
            environments=defaults.environments
            + (EnvironmentDefinition(name="qa", label="Quality assurance", ref_source="branch"),)
        ),
    )
    service = Service(cfg)
    assert "environment:qa" in service.dashboard().columns
    saved = SavedView(
        name="QA",
        host="fixture",
        scope="work_items",
        projects=(key.project,),
        columns=("identity", "environment:qa"),
        orientation="columns",
    )
    service.change(SavedViewSet(revision=0, view=saved))
    restored = Service(cfg)
    result = restored.dashboard(saved_view="QA")
    assert result.columns == saved.columns
    descriptor = next(
        e for e in result.environment_columns if e.project == key.project and e.name == "qa"
    )
    assert descriptor.column == "environment:qa" and descriptor.label == "Quality assurance"
    client = TestClient(create_app(service=restored))
    assert "environment:qa" in client.get("/api/dashboard?view=QA").json()["columns"]
    bad = SavedView.model_validate({**saved.model_dump(), "columns": ["environment:missing"]})
    with pytest.raises(ValueError, match="not configured"):
        restored.change(SavedViewSet(revision=1, view=bad))
    with pytest.raises(ValidationError):
        SavedView.model_validate(
            {**saved.model_dump(), "columns": ["environment:https://evil.invalid"]}
        )


@pytest.mark.parametrize("command", ["branches", "pipeline-catalog", "app-history"])
def test_new_cli_clean_json_no_color_width_and_errors(tmp_path, command):
    cfg = tmp_path / "fixture.toml"
    cfg.write_text('mode="fixture"\npreferences_path="preferences.toml"\n')
    base = [sys.executable, "-m", "gspace", command]
    if command == "app-history":
        base += ["42:791"]
    else:
        base += ["--project", "42"]
    base += ["--config", str(cfg)]
    clean = subprocess.run([*base, "--json"], capture_output=True, text=True)
    assert clean.returncode == 0 and not clean.stderr
    data = json.loads(clean.stdout)
    assert "\x1b" not in clean.stdout
    rich = subprocess.run([*base, "--no-color", "--width", "60"], capture_output=True, text=True)
    assert rich.returncode == 0 and not rich.stderr and "\x1b" not in rich.stdout
    assert all(len(line) <= 60 for line in rich.stdout.splitlines())
    if command != "app-history":
        assert data["coverage"] == "complete" and data["coverage_basis"] == "synthetic_fixture"
        searched = subprocess.run(
            [*base, "--search", "main", "--json"], capture_output=True, text=True
        )
        selected = json.loads(searched.stdout)
        assert selected["display_filter"] == "main" and selected["scope_total"] > selected["total"]
        failure = subprocess.run(
            [*base, "--project", "777", "--json"], capture_output=True, text=True
        )
        assert (
            failure.returncode == 2
            and failure.stdout == ""
            and "error" in json.loads(failure.stderr)
        )


def test_rich_populated_history_and_comparison_have_json_equivalent(
    service, key, tmp_path, monkeypatch, capsys
):
    from gspace import cli

    target = service.view(service.item(key), service.preferences.read()).application_tests[0].target
    service.change(
        ApplicationTestChange(
            revision=0,
            record=ApplicationTestRecord(
                key=key,
                environment="dev",
                version=Version(sha="f" * 40),
                outcome="passed",
                checked_at=datetime.now(UTC),
                notes="literal [red]notes[/red]",
            ),
        )
    )
    assert target is not None
    monkeypatch.setattr(cli, "Service", lambda *args, **kwargs: service)
    monkeypatch.setattr(
        sys, "argv", ["gspace", "app-history", key.key, "--no-color", "--width", "100"]
    )
    assert cli.main() == 0
    rendered = capsys.readouterr()
    assert not rendered.err and "stale" in rendered.out and "passed" in rendered.out
    assert "dev" in rendered.out and "\x1b" not in rendered.out
    assert all(len(line) <= 100 for line in rendered.out.splitlines())
    monkeypatch.setattr(sys, "argv", ["gspace", "app-history", key.key, "--json"])
    assert cli.main() == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["entries"][0]["record"]["version"]["sha"] == "f" * 40
    assert payload["entries"][0]["state"] == "stale"
    remote = Remote()
    actions = ActionService((profile(), renamed("reader", write_enabled=False)), remote.factory)
    monkeypatch.setattr(cli, "ActionService", lambda _: actions)
    comparison = tmp_path / "compare.json"
    comparison.write_text(
        ProbeComparisonRequest(action=tag(), profiles=("lab-owner", "reader")).model_dump_json()
    )
    monkeypatch.setattr(
        sys, "argv", ["gspace", "probe-compare", str(comparison), "--no-color", "--width", "100"]
    )
    assert cli.main() == 0
    output = capsys.readouterr()
    assert not output.err and "allowed" in output.out and "denied" in output.out
    assert "deferred" in output.out and SECRET not in output.out and "\x1b" not in output.out
    monkeypatch.setattr(sys, "argv", ["gspace", "probe-compare", str(comparison), "--json"])
    assert cli.main() == 0
    assert [r["kind"] for r in json.loads(capsys.readouterr().out)["rows"]] == ["allowed", "denied"]
    assert all(method == "GET" for method, _, _ in remote.calls)


def test_history_with_no_exact_target_remains_unknown(tmp_path, key):
    defaults = PipelineRules()
    service = Service(
        AppConfig(
            preferences_path=tmp_path / "prefs.toml",
            pipeline=PipelineRules(
                environments=defaults.environments
                + (EnvironmentDefinition(name="qa", label="QA", ref_source="branch"),)
            ),
        )
    )
    service.change(
        ApplicationTestChange(
            revision=0,
            record=ApplicationTestRecord(
                key=key,
                environment="qa",
                version=Version(version="manual-7"),
                outcome="passed",
                checked_at=datetime.now(UTC),
            ),
        )
    )
    history = service.application_test_history(key, "qa")
    assert history.entries[0].state == "unknown" and history.entries[0].target is None


def test_comparison_rejects_deferred_actions_and_unknown_profiles_before_get(service):
    actions = ActionService((profile(), renamed("reader")), lambda _: pytest.fail("unexpected GET"))
    client = TestClient(create_app(service=service, actions=actions))
    request = {
        "action": {**tag().model_dump(mode="json"), "kind": "ready"},
        "profiles": ["lab-owner", "reader"],
    }
    assert client.post("/api/access/compare", json=request).status_code == 422
    request["action"]["kind"] = "create_tag"
    request["profiles"][1] = "unconfigured"
    assert client.post("/api/access/compare", json=request).status_code == 403
