"""Deterministic fixture-only OpenAPI export; never loads operator configuration."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from gspace.api import create_app
from gspace.config import AppConfig

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "docs/contracts/openapi.json"


def schema_text() -> str:
    schema = create_app(AppConfig(mode="fixture")).openapi()
    return json.dumps(schema, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", type=Path, default=DEFAULT)
    parser.add_argument("--check", action="store_true", help="Fail on missing file or schema drift")
    args = parser.parse_args()
    payload = schema_text()
    if args.check:
        if not args.output.is_file() or args.output.read_text() != payload:
            print(
                "OpenAPI contract drift; run poe contract-export and review the change",
                file=sys.stderr,
            )
            return 1
        print("OpenAPI contract is current")
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload)
        print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
