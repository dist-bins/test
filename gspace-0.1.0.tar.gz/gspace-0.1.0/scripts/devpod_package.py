"""Create an allowlisted source transfer archive without installed dependencies or local state."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = (
    "pyproject.toml",
    "src/gspace/licenses/manifest.json",
    "src/gspace/licenses/ajv.LICENSE",
    "src/gspace/licenses/ajv-formats.LICENSE",
    "uv.lock",
    "README.md",
    "gspace.example.toml",
    "gspace.cli-demo.toml",
    "gspace.devpod.example.toml",
    "docs/devpod.md",
    "docs/development.md",
    "docs/runbook.md",
    "docs/contracts/openapi.json",
    "integration/runner.Dockerfile",
    "integration/runtime-network-loopback.sb",
    "integration/fixture-runtime.Dockerfile",
    "integration/fixture-runtime-images.json",
    "integration/glab-guard.json",
    "integration/runtime_container_probe.py",
    "integration/gitlab-ci.yml",
    "integration/compose.yaml",
    "integration/runner-config.example.toml",
    "frontend-new/package.json",
    "frontend-new/package-lock.json",
    "frontend-new/tsconfig.json",
    "frontend-new/biome.json",
    "frontend-new/index.html",
    "frontend-new/app.js",
    "frontend-new/theme.js",
    "frontend-new/styles.css",
    "frontend-new/icon.svg",
    "frontend-new/gspace-wolf.svg",
    "frontend-new/gspace-wolf-gray.svg",
)
TREES = {
    "src/gspace": {".py", ".html", ".css", ".js", ".svg"},
    "scripts": {".py", ".mjs"},
    "tests": {".py"},
    "frontend-new/src": {".ts"},
    "frontend-new/contracts": {".ts", ".js", ".json"},
}
EXCLUDED = {"__pycache__", "node_modules", ".venv", ".git", ".state", ".repos"}
CURRENT_STATIC = {
    "src/gspace/static/" + Path(name).name: name
    for name in FILES
    if name.startswith("frontend-new/") and Path(name).suffix in {".html", ".js", ".css", ".svg"}
}


def source_files(root: Path) -> list[Path]:
    def check_parents(path: Path) -> None:
        while path != root:
            if path.is_symlink():
                raise ValueError(f"Linked source is not transferable: {path.relative_to(root)}")
            path = path.parent

    files = [root / name for name in FILES]
    for name, suffixes in TREES.items():
        tree = root / name
        check_parents(tree)
        for path in tree.rglob("*"):
            if EXCLUDED.intersection(path.relative_to(root).parts) or path.suffix == ".pyc":
                continue
            check_parents(path)
            if (
                path.is_file()
                and path.suffix in suffixes
                and not any(part.startswith(".") for part in path.relative_to(tree).parts)
            ):
                files.append(path)
    for path in files:
        check_parents(path)
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Missing regular source file: {path.relative_to(root)}")
    return sorted(set(files))


def create_archive(root: Path, target: Path) -> dict[str, str]:
    files = source_files(root)
    hashes = {}
    target.parent.mkdir(parents=True, exist_ok=True)
    with (
        target.open("wb") as raw,
        gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz,
        tarfile.open(fileobj=gz, mode="w") as archive,
    ):
        for path in files:
            relative = str(path.relative_to(root))
            payload = (root / CURRENT_STATIC.get(relative, relative)).read_bytes()
            hashes[relative] = hashlib.sha256(payload).hexdigest()
            member = tarfile.TarInfo("gspace/" + relative)
            member.size = len(payload)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(payload))
    return hashes


def main() -> None:
    target = ROOT / "dist/gspace-devpod.tar.gz"
    hashes = create_archive(ROOT, target)
    report = {
        "purpose": "Source-only DevPod transfer, no dependencies or operator state",
        "archive": str(target),
        "files": hashes,
        "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "installed_dependencies_included": False,
        "uploaded": False,
    }
    (target.with_name("gspace-devpod.manifest.json")).write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps({"archive": str(target), "files": len(hashes), "sha256": report["sha256"]}))


if __name__ == "__main__":
    main()
