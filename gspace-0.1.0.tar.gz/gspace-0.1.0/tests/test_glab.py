import json
from urllib.parse import parse_qs, urlsplit

import pytest

from gspace.config import AppConfig, LiveConfig, ProjectConfig
from gspace.glab import AdapterError, GlabAdapter, IssueDTO, RunResult, status
from gspace.models import Origin, ProjectId, RebaseVerified, Status
from gspace.preferences import Preferences


def live():
    return LiveConfig(
        hostname="gitlab.example.invalid",
        web_origin="https://gitlab.example.invalid",
        projects=(ProjectConfig(id=ProjectId(value=42), path="demo/flight"),),
        max_pages=2,
    )


def result(value, code=0):
    return RunResult(code=code, stdout=json.dumps(value).encode())


def test_safe_argv_explicit_get_and_encoding():
    calls = []

    def runner(argv, timeout):
        calls.append((argv, timeout))
        return result([])

    adapter = GlabAdapter(live(), runner)
    adapter.get("projects/42/pipelines", {"ref": "issue-791; $(touch /tmp/nope)"})
    argv, timeout = calls[0]
    assert argv[:7] == [
        "glab",
        "api",
        "--hostname",
        "gitlab.example.invalid",
        "--method",
        "GET",
        argv[-1],
    ]
    assert "%24%28" in argv[-1]
    assert timeout == 10
    for path in (
        "https://evil.invalid/",
        "projects/42/jobs/1/retry",
        "projects/42/merge_requests/1/merge",
        "../user",
    ):
        with pytest.raises(AdapterError):
            adapter.get(path)
    assert len(calls) == 1


def test_nonzero_exit_never_retries_or_exposes_output():
    calls = []

    def runner(argv, timeout):
        calls.append(argv)
        return RunResult(code=1, stdout=b"fake secret value")

    with pytest.raises(AdapterError, match="GET failed") as error:
        GlabAdapter(live(), runner).get("user")
    assert "secret" not in str(error.value)
    assert len(calls) == 1


def test_pagination_is_bounded_and_invalid_json_is_explicit():
    row = {"iid": 1, "project_id": 42, "title": "Synthetic", "state": "opened"}
    calls = []

    def runner(argv, timeout):
        calls.append(argv[-1])
        return result([dict(row, iid=n + 1) for n in range(100)])

    with pytest.raises(AdapterError, match="pagination limit"):
        GlabAdapter(live(), runner).pages("projects/42/issues", IssueDTO)
    assert len(calls) == 2
    assert "page=2" in calls[1]
    with pytest.raises(AdapterError, match="invalid"):
        GlabAdapter(live(), lambda *_: RunResult(code=0, stdout=b"not-json")).pages(
            "projects/42/issues", IssueDTO
        )


def test_unknown_remote_status_is_explicit():
    assert status("future-new-state") == Status.UNKNOWN


def test_full_hydration_distinct_ids_retried_jobs_and_rebase_evidence(tmp_path):
    sha = "a" * 40
    calls = []
    mr = {
        "iid": 154,
        "project_id": 42,
        "source_project_id": 42,
        "title": "Synthetic MR",
        "state": "opened",
        "draft": True,
        "source_branch": "issue-791",
        "target_branch": "main",
        "diverged_commits_count": 3,
        "rebase_in_progress": False,
        "sha": sha,
    }
    pipeline = {
        "id": 9201,
        "ref": "issue-791",
        "sha": sha,
        "status": "failed",
        "source": "merge_request_event",
    }

    def runner(argv, timeout):
        assert argv[5] == "GET"
        calls.append(argv[-1])
        url = urlsplit(argv[-1])
        path = url.path
        query = parse_qs(url.query)
        values = {
            "version": {"version": "18.11.12"},
            "user": {"id": 7},
            "projects/42/issues": [
                {
                    "iid": 791,
                    "project_id": 42,
                    "title": "Synthetic issue",
                    "state": "opened",
                    "assignees": [{"id": 7}],
                }
            ],
            "projects/42/milestones": [],
            "projects/42/issues/791/related_merge_requests": [],
            "projects/42/repository/branches": [{"name": "issue-791", "commit": {"id": sha}}],
            "projects/42/repository/tags": [{"name": "release-2.4.09", "commit": {"id": sha}}],
            "projects/42/merge_requests": [mr],
            "projects/42/merge_requests/154": mr,
            "projects/42/merge_requests/154/pipelines": [pipeline],
            "projects/42/pipelines": [pipeline] if query.get("ref") == ["issue-791"] else [],
            "projects/42/pipelines/9201/jobs": [
                {
                    "id": 901,
                    "name": "unit-test",
                    "stage": "test",
                    "status": "failed",
                    "retried": True,
                    "failure_reason": "script_failure",
                },
                {
                    "id": 903,
                    "name": "unit-test",
                    "stage": "test",
                    "status": "success",
                    "retried": False,
                },
                {"id": 905, "name": "publish-nexus", "stage": "publish", "status": "success"},
            ],
            "projects/42/deployments": [
                {
                    "id": 3,
                    "status": "success",
                    "ref": "issue-791",
                    "sha": sha,
                    "environment": {"id": 4, "name": "dev"},
                }
            ],
        }
        return result(values[path])

    cfg = AppConfig(
        mode="live",
        live=live(),
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
    )
    snapshot = GlabAdapter(live(), runner).snapshot(cfg, Preferences())
    item = snapshot.items[0]
    assert item.identity.issue.value == 791 and item.merge_requests[0].iid.value == 154
    assert item.merge_requests[0].source_sha == mr["sha"]
    assert isinstance(item.branches[0].rebase, RebaseVerified) and item.branches[0].rebase.required
    assert item.pipelines[0].jobs[1].attempt == 2
    assert item.pipelines[0].jobs[0].retried
    assert item.tags[0].association.origin == Origin.API
    assert "historical origin unproven" in item.tags[0].association.reason
    assert item.environments[0].deployments[0].status == Status.SUCCESS
    assert item.publishes[0].artifact == "Artifact identity unknown"
    assert any("include_retried=true" in call for call in calls)
    assert any("include_diverged_commits_count=true" in call for call in calls)


def test_version_mismatch_stops_before_project_calls(tmp_path):
    calls = []

    def runner(argv, timeout):
        calls.append(argv[-1])
        return result({"version": "19.0.0"})

    config = AppConfig(mode="live", live=live())
    with pytest.raises(AdapterError, match="version differs"):
        GlabAdapter(live(), runner).snapshot(config, Preferences())
    assert calls == ["version"]


@pytest.mark.parametrize(
    "variation", ["changed_sha", "missing_count", "in_progress", "different_targets", "fork"]
)
def test_rebase_never_uses_stale_or_conflicting_evidence(variation):
    sha = "a" * 40
    mr = {
        "iid": 154,
        "project_id": 42,
        "source_project_id": 42,
        "title": "Synthetic MR",
        "state": "opened",
        "draft": True,
        "source_branch": "issue-791",
        "target_branch": "main",
        "sha": sha,
        "diverged_commits_count": 0,
        "rebase_in_progress": False,
    }
    if variation == "changed_sha":
        mr["sha"] = "b" * 40
    if variation == "missing_count":
        mr["diverged_commits_count"] = None
    if variation == "in_progress":
        mr["rebase_in_progress"] = True
    if variation == "fork":
        mr["source_project_id"] = 99
    rows = [mr]
    if variation == "different_targets":
        rows.append({**mr, "iid": 155, "target_branch": "release"})

    def runner(argv, _timeout):
        path = urlsplit(argv[-1]).path
        data = {
            "version": {"version": "18.11.12"},
            "user": {"id": 7},
            "projects/42/issues": [
                {
                    "iid": 791,
                    "project_id": 42,
                    "title": "Synthetic",
                    "state": "opened",
                    "assignees": [{"id": 7}],
                }
            ],
            "projects/42/repository/branches": [{"name": "issue-791", "commit": {"id": sha}}],
            "projects/42/merge_requests": rows,
            **{f"projects/42/merge_requests/{row['iid']}": row for row in rows},
        }
        return result(data.get(path, []))

    snapshot = GlabAdapter(live(), runner).snapshot(
        AppConfig(mode="live", live=live()), Preferences()
    )
    assert snapshot.items[0].branches[0].rebase.kind == "unknown"
    if variation == "fork":
        assert not snapshot.items[0].merge_requests
        assert any("fork" in warning for warning in snapshot.warnings)


def test_subprocess_timeout_and_byte_limit_are_enforced():
    import sys

    from gspace.glab import run_argv

    with pytest.raises(AdapterError, match="timed out"):
        run_argv([sys.executable, "-c", "import time; time.sleep(0.4)"], 0.05)
    with pytest.raises(AdapterError, match="byte limit"):
        run_argv([sys.executable, "-c", "import sys; sys.stdout.buffer.write(b'x'*5_000_001)"], 3)


def test_subprocess_pins_transport_controls_without_auth_discovery(monkeypatch):
    import sys

    from gspace.glab import run_argv

    for key in ("GLAB_SKIP_TLS_VERIFY", "SKIP_TLS_VERIFY", "GLAB_CHECK_UPDATE", "CHECK_UPDATE"):
        monkeypatch.setenv(key, "true")
    monkeypatch.setenv("GITLAB_API_HOST", "wrong.example.invalid")
    keys = (
        "GLAB_SKIP_TLS_VERIFY",
        "SKIP_TLS_VERIFY",
        "GLAB_CHECK_UPDATE",
        "CHECK_UPDATE",
        "GLAB_NO_PROMPT",
        "GLAB_SEND_TELEMETRY",
        "GLAB_API_PROTOCOL",
        "GITLAB_API_HOST",
        "GITLAB_SUBFOLDER",
    )
    script = "import os,json;print(json.dumps({k:os.environ.get(k) for k in " + repr(keys) + "}))"
    result = run_argv([sys.executable, "-c", script, "--hostname", "configured.example.invalid"], 3)
    assert result.code == 0
    values = json.loads(result.stdout)
    assert all(values[key] == "false" for key in keys[:4])
    assert values["GLAB_NO_PROMPT"] == "true" and values["GLAB_SEND_TELEMETRY"] == "false"
    assert values["GLAB_API_PROTOCOL"] == "https"
    assert (
        values["GITLAB_API_HOST"] == "configured.example.invalid"
        and values["GITLAB_SUBFOLDER"] == "/"
    )
