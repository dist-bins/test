"""Finite local Git copies of the finite explicitly authorized CLI presentation/help files.

No source checkout changes, remotes, global configuration, hooks or auth reads.
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/gspace"
SNAPSHOT = ROOT / ".state/cli-source-checkpoints"
FILES = ("cli.py", "cli_render.py", "cli_models.py", "cli_commands.py")


def git(*arguments: str) -> str:
    result = subprocess.run(
        [
            "/usr/bin/git",
            "-C",
            str(SNAPSHOT),
            "-c",
            "core.hooksPath=/dev/null",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "credential.helper=",
            "-c",
            "user.name=GSpace local CLI snapshots",
            "-c",
            "user.email=gspace@localhost",
            *arguments,
        ],
        env={
            "PATH": "/usr/bin:/bin",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_CONFIG_SYSTEM": "/dev/null",
            "GIT_TERMINAL_PROMPT": "0",
        },
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--message", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 .,:_-]{0,119}", args.message):
        parser.error("Message must be 1-120 plain English characters")
    for path in (ROOT / ".state", SNAPSHOT, SNAPSHOT / ".git", SOURCE):
        if path.is_symlink() or (path.exists() and not path.is_dir()):
            raise ValueError("CLI checkpoint directories must be fixed real directories")
    (ROOT / ".state").mkdir(exist_ok=True)
    lock_path = ROOT / ".state/cli-checkpoint.lock"
    if lock_path.is_symlink():
        raise ValueError("CLI checkpoint lock cannot be a symlink")
    with lock_path.open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        SNAPSHOT.mkdir(exist_ok=True)
        if any(
            p.is_symlink() or p.name not in (*FILES, ".git", "source-manifest.json")
            for p in SNAPSHOT.iterdir()
        ):
            raise ValueError("Unexpected file in finite CLI snapshot directory")
        hashes: dict[str, str] = {}
        for name in FILES:
            source, target = SOURCE / name, SNAPSHOT / name
            if source.is_symlink() or target.is_symlink():
                raise ValueError("CLI checkpoint source/copy cannot be a symlink")
            if source.is_file():
                shutil.copyfile(source, target)
                hashes[name] = hashlib.sha256(source.read_bytes()).hexdigest()
            elif target.exists():
                target.unlink()
        if not hashes.get("cli.py"):
            raise ValueError("Required CLI source is absent")
        (SNAPSHOT / "source-manifest.json").write_text(
            json.dumps(
                {
                    "purpose": "Finite copies of authorized CLI presentation source; "
                    "not a source checkout",
                    "sha256": hashes,
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )
        if not (SNAPSHOT / ".git").exists():
            git("init", "--template=", "--initial-branch=cli-checkpoints")
        git("add", "--all", "--", ".")
        if git("diff", "--cached", "--name-only"):
            print(git("commit", "--no-verify", "-m", args.message))
        else:
            print("No CLI source changes to checkpoint")
        print("CLI checkpoint " + git("rev-parse", "HEAD"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
