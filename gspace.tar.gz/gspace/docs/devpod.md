# Install and configure GSpace on DevPod

## Source transfer

`dist/gspace-devpod.tar.gz` contains application and frontend sources, API contracts,
lockfiles, build/install scripts and example configuration. It contains no installed
Python/npm dependencies, upstream clones, authentication, operator state or review logs.
The archive is generated locally by `poe devpod-package`; transfer it yourself to DevPod.

Prerequisites on DevPod: Python 3.12, uv, Node.js with npm and Bun. Live reads
use the operator's existing glab installation/authentication. The verified local
Bun version is 1.3.14. Ordinary installation does not require Go or build a private
glab. The recipe installs project dependencies, not these system tools.

```sh
tar -xzf gspace-devpod.tar.gz
cd gspace
poe install
```

If `poe` is not installed yet, use `python3.12 scripts/install.py` for the same
installation pipeline; this also installs Poe into `.venv`. Thereafter use
`.venv/bin/poe install`, or `poe install` with the environment activated.
The task synchronizes `uv.lock`, installs frontend dependencies from
`frontend-new/package-lock.json` in a disposable directory with lifecycle scripts
disabled and native operator npm configuration, exports OpenAPI,
generates TypeScript and CSP-safe validators, checks strict TypeScript/Biome,
builds twice to check reproducibility. Python dependency declarations and all
Ruff, BasedPyright strict, pytest and development-tool settings remain in
`pyproject.toml`, including all task recipes under `[tool.poe.tasks]`.
`uv.lock` selects exact dependency versions. No requirements file is used.
The task builds a wheel with the current UI, resolves a temporary runtime-only
environment directly with `uv sync --locked`, and installs `gspace` via `uv tool
install` with those exact selected versions. It verifies the resulting global
runtime while keeping development tools in the project's `.venv`. Installation stops on
the first failed step. Original recovery assets and operator files are preserved.

Wheel builds use the exact locked build group in a temporary environment. The wheel
includes the original AJV and AJV-formats license texts used by the bundled validator.
`output/verification/build-provenance.json` records the actual build components,
input hashes and wheel/source member hashes. `poe build` reproduces this current
wheel/source pair offline after installation. `poe package-qa` additionally checks
the installed CLI, API, assets and notices from an unrelated working directory.

The executable directory is printed by installation and by `uv tool dir --bin`.
Ensure that directory is on PATH. No sudo or system Python install is needed.
Re-running `poe install` replaces the user-global GSpace tool with the current build.

## Corporate certificate trust during installation

The installer uses the system certificate store by default for uv. It preserves
explicit `SSL_CERT_FILE`, `SSL_CERT_DIR`, `NODE_EXTRA_CA_CERTS` and npm CA-file
settings across subprocesses. Python/uv subprocesses exclude credentials and
private index environment variables. Native npm retains its operator environment
and user/global configuration, including existing proxy/registry/CA selection.
The installer does not parse or copy authentication/configuration files. npm cache
and logs remain project-local; npm strict TLS verification is forced on. An explicit
`UV_SYSTEM_CERTS` choice is honored; `UV_NATIVE_TLS` is supported for older uv.
TLS verification remains enabled. An explicit CA file replaces uv's default
certificate source, so use the certificate bundle approved for your environment.

If `UnknownIssuer` appears, the CA may not be installed in the DevPod trust store.
Use an existing local PEM bundle supplied by your environment, without sharing it
or credentials with the developer:

```sh
SSL_CERT_FILE=/path/to/approved-ca-bundle.pem .venv/bin/python scripts/install.py
```

First retry without this override when the corporate CA is already installed in
the system store. Do not use an insecure-host option or disable TLS verification.
The installer does not add certificates globally or rewrite registry URLs/uv.lock.

If you already extracted a package and selected a mirror with `uv sync`, replace
only `scripts/install.py` for this correction. Keep the operator-modified lock and
configuration. Run `.venv/bin/python scripts/install.py` directly to avoid an outer
`uv run` synchronization changing the lock before installation starts. Missing
issuer trust and unavailable package versions are different errors; certificate
validation must succeed before the repository can return an HTTP response.

Official reference: [uv TLS certificates](https://docs.astral.sh/uv/concepts/authentication/certificates/).

## npm recovery and read capability probe

If npm reports `Exit handler never called!`, inspect the underlying code with:

```sh
tail -40 .state/install/npm-cache/_logs/*.log
```

The symptom was reproduced on Linux amd64 with Node22.17.1/npm10.9.2 when
networking was denied (`EAI_AGAIN`); public-network controls succeeded. This does
not identify the actual DevPod cause without its log. The corrected installer
retains npm's native HOME, environment and user/global config. It stages only
package.json/package-lock.json, never copies a project `.npmrc`, verifies TLS and
keeps package lifecycle scripts disabled. Required development and platform-optional
build tools are included even when native npm is configured to omit them. No
registry or lock is silently rewritten.
Current npm failure codes are summarized without echoing log URLs or secrets.

For an existing extracted project, the small `gspace-devpod-recovery.tar.gz`
contains only the corrected installer and standalone probe. Extract it from your
existing GSpace directory, then run the installer directly to retain your selected
Python mirror/lock:

```sh
tar -xzf gspace-devpod-recovery.tar.gz
.venv/bin/python scripts/install.py
```

The read probe runs independently of frontend/npm completion, using the already
synchronized Python environment and the operator's native glab:

```sh
.venv/bin/python scripts/devpod_probe.py
```

It prompts for the GitLab HTTPS origin and project ID or group/project path.
No config/action file is required. It checks version/identity/project, sampled
catalogs and available pipeline jobs, related MRs and native graph queries.
Missing sample IDs are reported as skipped. It makes at most15 requests in120
seconds, with10 seconds per request and no retry. Its GraphQL POST is a read query.
Reports contain statuses and sanitized identity/version information, never raw
provider errors or tokens. Read success does not establish write permission or
exhaustive pagination coverage. Use `-j` for JSON and `-o report.json` for an
explicit new output file. Existing files are never overwritten.

The application command `gspace probe` remains the action-specific probe requiring
an existing operator config and action file. It is distinct from this standalone
read diagnostic. Neither command creates credentials or modifies GitLab resources.

## GitLab API redirects

Ordinary GSpace uses stock glab and its native redirect behavior. The default is:

```toml
[live]
reject_redirects = false
```

Omitting the field has the same effect. This setting applies to the traditional
live adapter. If using an explicit `[[access_profiles]]` glab profile, set
`reject_redirects` on that profile instead. Its default is also false. Existing
wrapper arguments and glab authentication remain operator-owned. Native mode
does not validate every redirect destination itself.

Optional strict mode is available for operators who explicitly want every API
redirect refused. Install it with `poe install --guarded-glab` (requires Go1.27+
and curl), then set `reject_redirects = true` in the transport configuration in
use. Strict mode selects the private guarded companion and rejects an ordinary
launcher before API execution. A custom wrapper must launch that guarded build.
`poe glab-guard-qa` verifies this optional mode using local synthetic TLS servers.
Changes to connection policy require restart and cannot be made in UI Settings.

These are backend GitLab API redirects. Browser DevPod proxy paths are configured
independently with `[web] public_url` below; host/origin/prefix validation remains
active. TLS verification and ordinary read-only behavior are retained.

## Repository configuration

Hosts and repositories are configured in the TOML explicitly passed with `--config`.
There is no automatic repository discovery or UI editor for the host/project list.

```sh
cp gspace.devpod.example.toml config.toml
# Edit config.toml: replace live.hostname, live.web_origin and every live.projects entry.
gspace serve --config config.toml --port 8876
```

Each `[[live.projects]]` entry requires the numeric GitLab project ID (`id = {
value = 42 }`) and exact `group/project` path. Add one entry per repository.
`live.web_origin` must be HTTPS and match `live.hostname`. Only GitLab 18.11.12
passes the current compatibility gate. Preferences/cache paths are relative to
the configuration file. The first uncached live start requests a read-only
snapshot using existing glab access. Changing live scope requires a server restart
and explicit refresh if the existing cache has a different scope.

The UI selects among configured repositories. Settings edits public operator rules
(timezone, branch/tag conventions, pipeline/environment rules); saved views,
filters and selections are shared local preferences. Settings cannot change
GitLab hosts, repository allowlists, credentials or network policies.

## DevPod browser proxy

If DevPod opens the application at an external URL such as
`https://devpod.example.invalid/workspace/your-id/proxy/8876/`, put that complete
base URL in your operator TOML, independently of `[live]`:

```toml
[web]
public_url = "https://devpod.example.invalid/workspace/your-id/proxy/8876/"
```

Replace the example with the URL shown by your own DevPod. No developer needs
that URL. Start or restart with `gspace web --config config.toml --port 8876`;
`web` is an alias of `serve`. The setting supplies the exact allowed hostname,
browser origin and application path prefix. Assets, API calls, logos, avatars,
local Settings saves and application redirects retain that prefix. Both proxies
that remove the prefix and those that preserve it are supported. No trailing
slash is required in the browser URL. Do not append a `#/...` route to public_url.

Omit `[web]` for existing localhost behavior. Public URLs cannot contain
credentials, query strings, fragments, wildcards, ambiguous/encoded path segments
or a prefix starting with the reserved application `api`/`assets` namespaces.
The server remains loopback-only; proxy headers cannot authorize extra hosts or
origins. Web policy changes require restart and cannot be applied from UI Settings.
The source transfer archive includes the current built UI in both frontend-new
and packaged static assets, so an activated project venv also serves the current UI.

For the synthetic demo, use `gspace serve --config gspace.example.toml --port 8876`.
The server binds to `127.0.0.1`; forward port 8876 from DevPod and open
`http://127.0.0.1:8876/#/work` locally. Installation never starts a server or GitLab.

## Current acceptance limits

Local build/install and synthetic checks do not establish real DevPod acceptance.
Optional strict glab mode is verified locally; native mode follows glab rules.
Production DNS/IP/proxy
isolation, complete release/license attribution,
authenticated CE scenarios and real EE graph verification remain open independent
gates. No real corporate call is made when preparing or installing this package.
