# Development and task reference

## Prerequisites

Use CPython 3.12, uv, and a POSIX macOS/Linux filesystem with working `flock`, atomic
rename and `fsync`. The project rejects Python 3.13 through its package metadata.
Pydantic validates boundaries, BasedPyright checks the core strictly, and Ruff handles
lint/format. Poe the Poet is a locked development dependency, not a global install.

On DevPod, install dependencies inside this workspace. Do not run upstream GitLab or
CLI source entrypoints. The `.repos` clones are reference material and are excluded
from wheel/source archives. No Docker daemon, glab account or real URL is needed for
fixture operation. Live reads require the operator's existing glab access or an
explicit access descriptor; corporate access was not used in development.

```sh
uv sync --locked --all-groups --python 3.12
uv run --no-sync poe --version
uv run --no-sync poe --help
uv run --no-sync poe list
uv run --no-sync poe setup
uv run --no-sync poe check
```

`setup` synchronizes the lockfile only. It never installs a system package, creates a
token, changes a glab grant or starts GitLab. All recipes live inline under
`[tool.poe.tasks]` in `pyproject.toml`, together with dependency groups, Ruff,
BasedPyright strict and pytest rules. Tests inspect these definitions in the actual
source archive. Exact Python versions come from `uv.lock`; installation does not
generate another dependency file.

Tasks use argv command execution and an explicit `.venv` executor. They do not evaluate
shell strings or auto-synchronize dependencies before every check. The default uv cache
is `.state/install/uv-cache` when no `UV_CACHE_DIR` was supplied. Set an operator-owned
cache directory deliberately on persistent DevPod storage if needed.

## Safe routine recipes

| Task | Result |
|---|---|
| `default`, `help`, `list` | Print recipe help; no service starts |
| `setup` | Locked Python 3.12 dependency synchronization |
| `serve` | Loopback web server; default port 8876 |
| `dashboard`, `compare` | Independent Rich matrices; forward normal CLI options |
| `demo` | Synthetic work-item-as-columns matrix; no server or credentials |
| `test` | Synthetic model/adapter/API/CLI tests; no Docker bootstrap |
| `lint`, `format-check`, `typecheck` | Read-only quality checks |
| `format` | Format project Python files |
| `check` | Lint, format check, strict typing, tests, schema drift check |
| `build` | Current UI wheel/source with locked build provenance and bundled publisher notices |
| `package-qa` | Isolated noneditable wheel install and loopback runtime acceptance |
| `browser-qa` | Verified packaged UI acceptance in installed Chrome |
| `frontend-review` | New Claude UI review without editing frontend source |
| `frontend-contract`, `frontend-contract-check` | Canonical OpenAPI types/validators generation or exact drift check |
| `frontend-boundary`, `frontend-boundary-browser` | Synthetic runtime contract negatives and actual browser/CSP check |
| `frontend-build`, `frontend-build-check` | Strict tsc/Biome, reproducibility and compiled draft asset drift |
| `contract-export`, `contract-check` | Fixture-only OpenAPI export or drift check |
| `claude-monitor` | Filtered public events from this task's own logs |
| `profiles`, `doctor` | Redacted scopes or explicitly requested read-only diagnostics |
| `lab-preflight`, `lab-status` | Resource gates or dedicated Compose status |
| `lab-loopback` | Fixed localhost relay when internal-network host mappings are unavailable; requires exact running owned lab |
| `lab-readonly` | Actual credential-free CE version/health/isolation/login browser checks; no CI or effect claims |
| `runtime-container-qa` | Actual bounded nonroot Linux fixture with read-only root and outbound network denied |
| `glab-build`, `glab-guard-qa` | Private source-pinned native glab build and actual synthetic TLS redirect-denial matrix |
| `dependency-inventory` | Current build/bundle proof, offline recursive inventory and exact installed/artifact integrity; gaps exit 2 |

```sh
uv run --no-sync poe serve --config gspace.example.toml --port 8876
uv run --no-sync poe dashboard --config gspace.example.toml --no-color --width 140
uv run --no-sync poe compare --config gspace.example.toml --orientation columns
uv run --no-sync poe -q dashboard --config gspace.example.toml --json
uv run --no-sync poe demo
uv run --no-sync poe test -q
uv run --no-sync poe build
uv run --no-sync poe package-qa
uv run --no-sync poe browser-qa --browser /path/to/chromium
```

Use Poe's `-q` for machine-readable stdout; the underlying GSpace CLI always emits
clean JSON with `--json`, and errors only on stderr. Recipes forward extra arguments
without a shell. The browser script's macOS Chrome default can be overridden on Linux.
Playwright and an installed browser must be available; the recipe does not download
or install a browser silently. Network binding/browser launching may require approval
in restricted executors. Linux runtime portability is implemented but has not been
claimed as real DevPod acceptance. The separate `runtime-container-qa` task tests a
pinned Linux Python 3.12 fixture image with no network, host mounts or published
ports. It has a finite 8 GiB host-space guard and explicit resource limits; it
does not start GitLab or change the independent 60 GiB GitLab guard.

Go1.27+ and curl are needed only for the explicitly requested
`poe install --guarded-glab` variant. Ordinary installation uses the existing
native glab and does not require/build its private companion. Redirect refusal
is separately opt-in in the operator TOML. See [DevPod setup](devpod.md).

## Sensitive laboratory recipes

These are separate from `default`, `setup` and `check`. Each delegates to the existing
lab driver; no task duplicates seed or action logic. Flags are deliberately absent
from recipe definitions, so invoking an unapproved action fails before mutation.

```sh
uv run --no-sync poe lab-preflight
uv run --no-sync poe lab-status
uv run --no-sync poe lab-up --approved-resource-budget --approved-local-credentials
uv run --no-sync poe lab-seed --approved-local-mutations
uv run --no-sync poe lab-runner --approved-resource-budget --approved-local-credentials --approved-local-mutations
uv run --no-sync poe lab-exercise --approved-local-mutations --scenario dev-post-failure
uv run --no-sync poe lab-exercise --approved-local-mutations --scenario tag-preprod
uv run --no-sync poe lab-exercise --approved-local-mutations --scenario retry
uv run --no-sync poe lab-exercise --approved-local-mutations --scenario merged --confirm-local-dev-preprod-work
uv run --no-sync poe lab-verify
uv run --no-sync poe lab-stop
```

`lab-up` starts only the dedicated server after disk/RAM/CPU/port guards. It necessarily
creates GitLab bootstrap secrets in dedicated volumes, which is why a separate
credential flag is required. `lab-seed`/`lab-runner`/`lab-exercise` request the approved
synthetic PAT by hidden prompt; no PAT goes in arguments. `lab-stop` preserves volumes.
There is no destructive volume deletion task, automatic cleanup, global Docker prune,
permission escalation or token regeneration in tests. Additional token creation is
not covered by the original bootstrap approval; see the lab runbook.

The `action` task is preview-only by default. `--execute` additionally requires the exact
`PROFILE:PROJECT:KIND:EXPECTED_SHA` confirmation, current supported permission evidence,
and an explicitly write-enabled lab PAT descriptor. No corporate write transport is
available. See [access and actions](architecture/access-and-actions.md).

## Troubleshooting

- **Wrong Python:** run `python3.12 --version`, then synchronize with `--python 3.12`.
  Do not remove another project's environment or force another interpreter version.
- **Missing Poe/tasks:** synchronize the development group and confirm
  `pyproject.toml` contains the inline `[tool.poe.tasks]` configuration. `poe --help` must list `check`, `serve` and `lab-preflight`.
- **UnknownIssuer during install:** uv uses system certificate trust by default in
  the installer. Existing SSL/Node/npm CA-file settings are preserved. If the CA
  is absent from the system, set `SSL_CERT_FILE` to an approved local PEM bundle;
  keep TLS verification enabled and retain the operator's mirror/lock selection.
- **npm Exit handler never called:** use the short log command in
  [DevPod recovery](devpod.md#npm-recovery-and-read-capability-probe). Native npm
  retains the operator's own proxy/registry/user/global configuration; the installer
  does not parse/copy those files. Strict TLS and disabled lifecycle scripts remain.
- **Read capability probe without config files:** run
  `.venv/bin/python scripts/devpod_probe.py`. It prompts for scope and works before
  frontend installation. It reports sampled reads, never write authorization.
- **Offline build failure:** run `poe install` first, or synchronize all groups into
  the project cache. The offline build needs the locked build group and current
  frontend dependencies. Tests do not silently install anything.
- **Port occupied:** choose a different unprivileged loopback port; do not kill an
  unknown process. Stop only a PID recorded for this task after identifying it.
- **Stale preferences:** HTTP 409 means reload and review; no automatic replay occurs.
  A preference file bound to another instance must not be reused.
- **Schema drift:** run `poe contract-export`, review the JSON change, then
  `poe contract-check`. Export always constructs fixture mode and never reads live config.
- **Lab disk guard:** the current 60 GiB threshold must pass before pulls/start.
  Disk cleanup is an external operator decision. A unit test is not server evidence.
- **Missing secret/unknown capability:** configuration stores only an environment
  variable name. Supply the secret deliberately in the server's environment; never
  paste it into TOML, an URL, logs, shell arguments or the web UI. Unknown disables action.
- **Claude limit:** preserve new output and wait for the declared reset. The monitor
  shows tool/file/state only, not reasoning, prompts, result bodies or token telemetry.
# Frontend checkpoints

`poe frontend-checkpoint --message 'Describe the completed stage'` invokes the
fixed local-only wrapper for `frontend-new`. It is distinct from upstream clones.
Claude's continuation should permit only that known wrapper command, keeping
direct `.git` reads/writes, broad shell, remotes and upstream checkout changes
denied. The wrapper takes a bounded plain-text message and stages only its finite
asset/contract/documentation paths. Current checkpoints preserve the first clean
Claude preview and the subsequent corrective brief without root asset editing.

## TypeScript development checkpoint

The authorized migration preserves the current UI while moving maintained source
into `frontend-new/src`. Its one HTTP type surface and precompiled validators come
from the local Pydantic/FastAPI OpenAPI document. See
[the boundary architecture](architecture/frontend-types.md). Generation and boundary
checks have passed; application compilation and final compiled browser/package
acceptance remain pending while the sole Claude writer finishes the source.

The reviewed toolchain is currently isolated in `/tmp/gspace-ts-toolchain`, with
exact package pins and lock preserved in `output/verification/typescript-toolchain.*`.
Those isolated development installations use empty task-local user/global npm
configs and disabled lifecycle scripts; no existing npm credentials or corporate
registry are needed. Ordinary DevPod installation instead preserves native operator
npm configuration as described in the DevPod runbook. Generator
and build tasks accept `--toolchain /absolute/path` for that installed toolchain.
The current verification entrypoints use the selected macOS Node/Bun/Chrome paths.
The installed Python application runtime needs no JavaScript development tools.

```sh
uv run --no-sync poe frontend-contract-check
uv run --no-sync poe frontend-boundary
uv run --no-sync poe frontend-boundary-browser
uv run --no-sync poe frontend-build
uv run --no-sync poe frontend-build-check
```

`frontend-build` runs compiler and formatter/linter checks before bundling; it does
not weaken strict settings, run package scripts or publish assets. It builds twice,
checks identical bytes and requires unchanged sources during the check. Successful
draft compilation alone is not integration: final browser/image/package gates
must pass before replacing the stable packaged/served assets.
