"""Calendar boundaries preserve the existing GSpace date-current definition."""

from copy import deepcopy
from datetime import UTC, date, datetime

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from gspace.api import create_app
from gspace.config import AppConfig
from gspace.glab import GlabAdapter, MilestoneDTO
from gspace.milestones import catalog, date_current, matches
from gspace.models import Milestone, MilestoneFilter, ProjectId, Snapshot
from tests.milestone_edge_fixture import TODAY, edge_catalog, edge_snapshot
from tests.test_glab import live


def test_actual_api_catalog_and_shared_filter_preserve_date_edges(config, monkeypatch):
    snapshot = edge_snapshot()
    monkeypatch.setattr("gspace.service.synthetic_snapshot", lambda: snapshot)

    class FixedClock(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime(2026, 10, 7, 10, tzinfo=UTC)

    monkeypatch.setattr("gspace.milestones.datetime", FixedClock)
    monkeypatch.setattr("gspace.service.datetime", FixedClock)
    configuration = AppConfig.model_validate({**config.model_dump(), "timezone": "Europe/Zurich"})
    with TestClient(create_app(configuration)) as client:
        response = client.get("/api/milestones")
        assert response.status_code == 200
        result = response.json()
        assert result["date"] == "2026-10-07" and result["timezone"] == "Europe/Zurich"
        rows = {row["milestone"]["title"]: row for row in result["entries"]}
        assert rows["Start only"]["milestone"]["due_date"] is None
        assert rows["Due only"]["milestone"]["start_date"] is None
        assert rows["Missing dates"]["date_current"] == "unknown"
        response = client.post(
            "/api/preferences",
            json={
                "operation": "filters",
                "revision": 0,
                "filters": {
                    "state": "all",
                    "assigned": False,
                    "milestone": {"mode": "date_current"},
                },
            },
        )
        assert response.status_code == 200
        selected = client.get("/api/dashboard").json()["views"]
        expected = {snapshot.milestones[index].key for index in (3, 4, 5)}
        assert {v["item"]["identity"]["issue"]["value"] for v in selected} == {794, 795, 796}
        assert all(
            v["item"]["milestone"] in [key.model_dump(mode="json") for key in expected]
            for v in selected
        )


@pytest.mark.parametrize(
    ("start", "due", "today", "expected"),
    [
        *[("2026-10-07", None, f"2026-10-{day:02}", "unknown") for day in (6, 7, 8)],
        *[(None, "2026-10-07", f"2026-10-{day:02}", "unknown") for day in (6, 7, 8)],
        *[(None, None, f"2026-10-{day:02}", "unknown") for day in (6, 7, 8)],
        ("2026-10-07", "2026-10-09", "2026-10-06", "no"),
        ("2026-10-07", "2026-10-09", "2026-10-07", "yes"),
        ("2026-10-07", "2026-10-09", "2026-10-08", "yes"),
        ("2026-10-07", "2026-10-09", "2026-10-09", "yes"),
        ("2026-10-07", "2026-10-09", "2026-10-10", "no"),
        ("2026-10-07", "2026-10-07", "2026-10-06", "no"),
        ("2026-10-07", "2026-10-07", "2026-10-07", "yes"),
        ("2026-10-07", "2026-10-07", "2026-10-08", "no"),
        ("2028-02-28", "2028-03-01", "2028-02-29", "yes"),
    ],
)
def test_date_current_and_filter_keep_partial_unknown_and_inclusive_bounds(
    start, due, today, expected
):
    data = edge_snapshot().model_dump(mode="json")
    data["milestones"][0].update(start_date=start, due_date=due)
    snapshot = Snapshot.model_validate(data)
    milestone = snapshot.milestones[0]
    item = snapshot.items[0]
    local_date = date.fromisoformat(today)
    current, reason = date_current(milestone, local_date)
    assert current == expected
    assert matches(item, MilestoneFilter(mode="date_current"), snapshot, local_date) == (
        expected == "yes"
    )
    assert matches(item, MilestoneFilter(mode="active"), snapshot, local_date)
    assert matches(
        item, MilestoneFilter(mode="selected", selected=milestone.key), snapshot, local_date
    )
    if expected == "unknown":
        assert "Both start and due dates are needed" in reason
    assert milestone.start_date == (date.fromisoformat(start) if start else None)
    assert milestone.due_date == (date.fromisoformat(due) if due else None)


@pytest.mark.parametrize(
    ("start", "due"),
    [(None, None), ("2026-10-07", None), (None, "2026-10-07"), ("2026-10-07", "2026-10-09")],
)
def test_closed_state_never_becomes_date_current_even_with_missing_dates(start, due):
    data = edge_snapshot().model_dump(mode="json")
    data["milestones"][0].update(start_date=start, due_date=due, state="closed")
    snapshot = Snapshot.model_validate(data)
    current, reason = date_current(snapshot.milestones[0], TODAY)
    assert current == "no" and "closed" in reason
    for mode in ("active", "date_current"):
        assert not matches(snapshot.items[0], MilestoneFilter(mode=mode), snapshot, TODAY)
    assert matches(snapshot.items[0], MilestoneFilter(mode="all"), snapshot, TODAY)


def test_catalog_candidates_exclude_partial_missing_closed_and_outside_ranges():
    result = edge_catalog()
    assert result.date == TODAY and result.timezone == "Europe/Zurich"
    by_title = {entry.milestone.title: entry for entry in result.entries}
    assert {title for title, entry in by_title.items() if entry.date_current == "yes"} == {
        "Exact start",
        "Exact due",
        "Same day",
    }
    assert {title for title, entry in by_title.items() if entry.date_current == "unknown"} == {
        "Start only",
        "Due only",
        "Missing dates",
    }
    assert set(result.date_current_candidates) == {
        by_title[title].milestone.key for title in ("Exact start", "Exact due", "Same day")
    }
    assert result.selection.mode == "all" and len(result.warnings) == 1


@pytest.mark.parametrize(
    ("now", "expected"),
    [
        (datetime(2026, 10, 6, 21, 59, tzinfo=UTC), "no"),
        (datetime(2026, 10, 6, 22, 0, tzinfo=UTC), "yes"),
        (datetime(2026, 10, 9, 21, 59, tzinfo=UTC), "yes"),
        (datetime(2026, 10, 9, 22, 0, tzinfo=UTC), "no"),
    ],
)
def test_local_midnight_boundaries_use_configured_timezone(now, expected):
    snapshot = edge_snapshot()
    result = catalog(
        snapshot,
        "fixture",
        (ProjectId(value=42), ProjectId(value=99)),
        MilestoneFilter(),
        (),
        "Europe/Zurich",
        now=now,
    )
    entry = next(e for e in result.entries if e.milestone.title == "Exact start")
    assert entry.date_current == expected


@pytest.mark.parametrize(
    ("start", "due"),
    [("2026-10-07", None), (None, "2026-10-07"), (None, None), ("2026-10-07", "2026-10-07")],
)
def test_dto_adapter_preserves_supplied_dates_without_filling_missing_ends(start, due):
    raw = {
        "id": 9001,
        "iid": 91,
        "project_id": 42,
        "title": "Synthetic date edge",
        "state": "active",
        "start_date": start,
        "due_date": due,
        "web_url": "https://gitlab.example.invalid/demo/flight/-/milestones/91",
    }
    before = deepcopy(raw)
    adapter = GlabAdapter(live(), lambda *_: pytest.fail("No network/subprocess read authorized"))
    dto = MilestoneDTO.model_validate(raw)
    milestone = adapter.milestone(dto, live().projects[0])
    assert milestone.model_dump(mode="json")["start_date"] == start
    assert milestone.model_dump(mode="json")["due_date"] == due
    assert raw == before and dto.model_dump(mode="json")["start_date"] == start


def test_reversed_range_is_rejected_without_reordering_or_mutating_upstream_evidence():
    raw = {
        "id": 9001,
        "iid": 91,
        "project_id": 42,
        "title": "Reversed synthetic range",
        "state": "active",
        "start_date": "2026-10-09",
        "due_date": "2026-10-05",
        "web_url": "https://gitlab.example.invalid/demo/flight/-/milestones/91",
    }
    before = deepcopy(raw)
    dto = MilestoneDTO.model_validate(raw)
    adapter = GlabAdapter(live(), lambda *_: pytest.fail("No remote call authorized"))
    with pytest.raises(ValidationError, match="start date exceeds due date"):
        adapter.milestone(dto, live().projects[0])
    assert raw == before
    assert dto.model_dump(mode="json")["start_date"] == "2026-10-09"
    assert dto.model_dump(mode="json")["due_date"] == "2026-10-05"
    data = edge_snapshot().milestones[0].model_dump(mode="json")
    data.update(start_date="2026-10-09", due_date="2026-10-05")
    with pytest.raises(ValidationError, match="start date exceeds due date"):
        Milestone.model_validate(data)
