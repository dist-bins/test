"""Actual isolated browser acceptance for whole-application recovery.

Uses temporary operator/preferences state and backend GET-only profile mocks.
Browser traffic is restricted to its owned loopback origin. No lab effects,
real credentials or original operator files are involved.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import traceback
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from recovery_fixture import INERT_MARKER, ROOT, recovery_fixture

from gspace.models import Snapshot
from gspace.operator_settings import OperatorSettings, SettingsChange

ROUTES = (
    ("work", "work"),
    ("compare", "compare"),
    ("milestones", "milestones"),
    ("mrs", "mrs"),
    ("branches", "branches"),
    ("pipelines", "pipelines"),
    ("item-failed-ci", "item/42/791"),
    ("item-runtime-mismatch", "item/42/792"),
    ("item-tested-preprod", "item/42/793"),
    ("mr-detail", "mrs/42/154"),
    ("branch-detail", "branches/42/issue-791"),
    ("pipeline-detail", "pipelines/42/9201"),
    ("job-detail", "pipelines/42/9201/job/92010"),
    ("bookmarks", "bookmarks"),
    ("saved-views", "views"),
    ("settings", "settings"),
    ("access", "access"),
    ("sources", "sources"),
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    parser.add_argument("--capture-only", action="store_true")
    parser.add_argument("--journeys-only", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to(ROOT / "output/verification"):
        parser.error("Evidence must remain under owned output/verification")
    output.mkdir(parents=True, exist_ok=True)
    checks: list[dict[str, object]] = []
    captures: list[dict[str, object]] = []
    browser_errors: list[str] = []
    outside: list[str] = []
    requests: list[dict[str, str]] = []
    hashes = {
        name: hashlib.sha256((args.assets / name).read_bytes()).hexdigest()
        for name in ("app.js", "theme.js", "styles.css", "index.html")
    }
    with recovery_fixture(args.assets) as fixture, sync_playwright() as engine:
        base = fixture.base
        port = urlsplit(base).port
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(
            viewport={"width": 1600, "height": 1100}, service_workers="block"
        )

        def guard(route):
            request = route.request
            parsed = urlsplit(request.url)
            if parsed.scheme == "http" and parsed.hostname == "127.0.0.1" and parsed.port == port:
                requests.append({"method": request.method, "path": parsed.path})
                route.continue_()
            else:
                outside.append(request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.set_default_timeout(5000)
        page.on("pageerror", lambda error: browser_errors.append(str(error)))

        def check(name, operation):
            try:
                operation()
                checks.append({"check": name, "result": "passed"})
            except Exception as error:
                checks.append(
                    {
                        "check": name,
                        "result": "failed",
                        "error": str(error)[:1500],
                        "trace": traceback.format_exc()[-2500:],
                    }
                )

        def route(path):
            page.goto(base + "/#/" + path)
            page.wait_for_selector("main")
            page.wait_for_timeout(350)

        def capture(name, theme, width):
            filename = f"{name}-{theme}-{width}.png"
            page.screenshot(
                path=str(output / filename), full_page=width > 500, animations="disabled"
            )
            captures.append(
                {
                    "page": name,
                    "theme": theme,
                    "width": width,
                    "file": filename,
                    "document_width": page.evaluate("document.documentElement.scrollWidth"),
                    "viewport": width,
                    "viewport_only": width <= 500,
                }
            )

        # Actual screenshots for every page family, both themes and mobile.
        variants = (
            ()
            if args.journeys_only
            else (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390))
        )
        for theme, width in variants:
            page.set_viewport_size({"width": width, "height": 1100 if width > 500 else 844})
            route("work")
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            page.reload()
            for name, path in ROUTES:
                route(path)
                capture(name, theme, width)
                check(
                    f"{name} theme/viewport {theme}/{width}",
                    lambda theme=theme, width=width: (
                        expect(page.locator("html")).to_have_attribute("data-theme", theme),
                        expect(page.locator("main")).to_be_visible(),
                        expect(page.locator("body")).not_to_contain_text(INERT_MARKER),
                        expect(page.locator("body")).not_to_contain_text("GSPACE_SYNTHETIC_UNUSED"),
                        (
                            None
                            if page.evaluate("document.documentElement.scrollWidth") <= width + 1
                            else (_ for _ in ()).throw(
                                AssertionError("Document horizontal overflow")
                            )
                        ),
                    ),
                )

        if not args.capture_only:
            route("work")
            page.set_viewport_size({"width": 1600, "height": 1100})
            page.evaluate("localStorage.setItem('gspace.theme','light')")
            page.reload()

            def overview_and_evidence():
                route("work")
                expect(page.get_by_role("button", name="Overview", exact=True)).to_have_attribute(
                    "aria-pressed", "true"
                )
                expect(page.locator(".flowt")).to_be_visible()
                headers = page.locator(".flowt thead th.colh")
                assert headers.count() >= 4
                positions = [headers.nth(i).bounding_box() for i in range(4)]
                assert all(p is not None for p in positions)
                assert len({round(p["y"]) for p in positions if p}) == 1
                expand = page.locator('[data-fk="rx-work_items-pipeline"]')
                for _ in range(4):
                    expand.click()
                    expect(expand).to_have_attribute("aria-expanded", "true")
                    expect(page.locator(".flowt")).to_contain_text("unit-tests")
                    expand.click()
                    expect(expand).to_have_attribute("aria-expanded", "false")
                page.get_by_role("button", name="Detailed", exact=True).click()
                expect(page.locator(".mx").first).to_be_visible()
                page.reload()
                expect(page.get_by_role("button", name="Detailed", exact=True)).to_have_attribute(
                    "aria-pressed", "true"
                )
                page.get_by_role("button", name="Overview", exact=True).click()

            check(
                "Adjacent work columns; aligned progressive evidence; retained Detailed",
                overview_and_evidence,
            )

            def same_outcome_versions():
                route("compare")
                for iid in (792, 794):
                    with page.expect_response(base + "/api/preferences") as saved:
                        page.get_by_role(
                            "checkbox", name=f"Select #{iid} for comparison", exact=True
                        ).click()
                    assert saved.value.status == 200
                    page.wait_for_timeout(200)
                toggle = page.locator('[data-fk="rx-compare-env:dev"]')
                row = toggle.locator("xpath=ancestor::tr").first
                expect(row).to_contain_text("Same outcome; versions may differ")
                capture("compare-equal-outcomes-distinct-versions", "light", 1600)
                expect(row).to_contain_text("issue-791")
                expect(row).to_contain_text("issue-793")
                toggle.click()
                expect(toggle).to_have_attribute("aria-expanded", "true")
                expect(row).to_contain_text("054396c6")
                expect(row).to_contain_text("d8a00099")

            check(
                "Equal outcomes retain each item's runtime/test version and full aligned evidence",
                same_outcome_versions,
            )

            def manual_test():
                for mode in ("Overview", "Detailed"):
                    route("item/42/791")
                    page.get_by_role("button", name=mode, exact=True).click()
                    # Overview's environment expansion exposes the same exact-version editor.
                    toggle = page.locator('[data-fk="rx-item-env:dev"]')
                    if toggle.count() and toggle.get_attribute("aria-expanded") != "true":
                        toggle.click()
                    group = page.get_by_role(
                        "group", name="Record the Dev application test outcome", include_hidden=True
                    )
                    if not group.is_visible():
                        group.locator("xpath=ancestor::details[1]/summary").click()
                    expect(group).to_be_visible()
                    target = page.request.get(base + "/api/items/42/791").json()[
                        "application_tests"
                    ][0]["target"]
                    expect(page.locator("main")).to_contain_text(target["sha"])
                    page.locator('[data-fk="at-notes-42/791:dev"]').fill(
                        f"Recovery {mode} exact-version test"
                    )
                    with page.expect_response(base + "/api/preferences") as saved:
                        group.get_by_role("button", name="Passed", exact=True).click()
                    assert saved.value.status == 200
                    page.wait_for_timeout(350)
                    data = page.request.get(base + "/api/items/42/791").json()
                    evidence = data["application_tests"][0]
                    assert evidence["current"]["version"] == target
                    assert evidence["outcome"] == "passed"
                    assert not data["checklist"]["local_test"]
                    assert data["item"]["merge_requests"][0]["draft"]
                    history = page.request.get(base + "/api/items/42/791/application-tests").json()
                    assert any(
                        e["record"]["notes"].startswith("Recovery") for e in history["entries"]
                    )
                    page.reload()
                    page.wait_for_timeout(350)
                    expect(page.locator("main")).to_contain_text("passed")
                page.get_by_role("button", name="Overview", exact=True).click()
                previous = fixture.service.snapshot()
                updated = previous.model_dump(mode="json")
                item = updated["items"][0]
                env = next(e for e in item["environments"] if e["name"] == "dev")
                env["expected"]["sha"] = "e" * 40
                fixture.service._snapshot = Snapshot.model_validate(updated)
                try:
                    page.reload()
                    page.wait_for_timeout(400)
                    data = page.request.get(base + "/api/items/42/791").json()
                    evidence = data["application_tests"][0]
                    assert evidence["outcome"] == "not_tested"
                    assert evidence["target"]["sha"] == "e" * 40
                    assert evidence["history"]
                    toggle = page.locator('[data-fk="rx-item-env:dev"]')
                    if toggle.count() and toggle.get_attribute("aria-expanded") != "true":
                        toggle.click()
                    group = page.get_by_role(
                        "group", name="Record the Dev application test outcome", include_hidden=True
                    )
                    if not group.is_visible():
                        group.locator("xpath=ancestor::details[1]/summary").click()
                    expect(group).to_be_visible()
                    expect(page.locator("main")).to_contain_text("e" * 40)
                    capture("manual-test-new-version", "light", 1600)
                finally:
                    fixture.service._snapshot = previous

            check(
                "Overview/Detailed manual test; persistence/history; new SHA does not inherit pass",
                manual_test,
            )

            def settings():
                route("settings")
                expect(page.locator("main")).to_contain_text("In use locally")
                page.locator('[data-fk="g-important_job_patterns-ip-0"]').fill("unit-tests*")
                page.locator('[data-fk="g-environments-e-add"]').click()
                page.locator('[data-fk="g-environments-en-2"]').fill("qa")
                page.locator('[data-fk="g-environments-el-2"]').fill("QA")
                with page.expect_response(
                    lambda r: r.url == base + "/api/settings" and r.request.method == "POST"
                ) as saved:
                    page.locator('[data-fk="set-save"]').click()
                assert saved.value.status == 200
                current = page.request.get(base + "/api/settings").json()
                assert current["settings"]["pipeline"]["environments"][2]["name"] == "qa"
                assert fixture.service.config.pipeline.environments[2].name == "qa"
                assert "qa" in fixture.config_path.read_text()
                page.reload()
                expect(page.locator('[data-fk="g-environments-en-2"]')).to_have_value("qa")
                route("item/42/791")
                toggle = page.locator('[data-fk="rx-item-env:qa"]')
                if toggle.count() and toggle.get_attribute("aria-expanded") != "true":
                    toggle.click()
                group = page.get_by_role(
                    "group", name="Record the QA application test outcome", include_hidden=True
                )
                if not group.is_visible():
                    group.locator("xpath=ancestor::details[1]/summary").click()
                expect(group).to_be_visible()
                route("settings")
                page.locator('[data-fk="set-branch"]').fill("task-{iid}")
                latest = page.request.get(base + "/api/settings").json()
                latest["settings"]["timezone"] = "UTC"
                changed = page.request.post(
                    base + "/api/settings",
                    data={"revision": latest["revision"], "settings": latest["settings"]},
                )
                assert changed.status == 200
                start = len(requests)
                with page.expect_response(
                    lambda r: r.url == base + "/api/settings" and r.request.method == "POST"
                ) as conflict:
                    page.locator('[data-fk="set-save"]').click()
                assert conflict.value.status == 409
                expect(page.locator('[data-fk="set-branch"]')).to_have_value("task-{iid}")
                expect(page.locator('[data-fk="set-save"]')).to_be_disabled()
                assert (
                    sum(r == {"method": "POST", "path": "/api/settings"} for r in requests[start:])
                    == 1
                )
                page.get_by_role("button", name="Load latest and keep my edits", exact=True).click()
                expect(page.locator('[data-fk="set-save"]')).to_be_enabled()
                with page.expect_response(
                    lambda r: r.url == base + "/api/settings" and r.request.method == "POST"
                ) as reapplied:
                    page.locator('[data-fk="set-save"]').click()
                assert reapplied.value.status == 200
                assert fixture.service.config.branch_template == "task-{iid}"
                capture("settings-after-save", "light", 1600)

            check(
                "Settings changes TOML and running rules; conflict keeps draft without retry",
                settings,
            )

            def external_settings():
                route("settings")
                current = fixture.service.settings()
                changed = current.settings.model_dump()
                changed["branch_template"] = "external-{iid}"
                fixture.service.operator_store.update(
                    SettingsChange(
                        revision=current.revision,
                        settings=OperatorSettings.model_validate(changed),
                    )
                )
                assert fixture.service.config.branch_template != "external-{iid}"
                start = len(requests)
                page.locator('[data-fk="set-reload"]').click()
                expect(page.locator('[data-fk="set-branch"]')).to_have_value("external-{iid}")
                assert fixture.service.config.branch_template == "external-{iid}"
                page.wait_for_timeout(350)
                after = requests[start:]
                assert {"method": "GET", "path": "/api/dashboard"} in after
                assert {"method": "POST", "path": "/api/refresh"} not in after
                valid_file = fixture.config_path.read_text()
                fixture.config_path.write_text('timezone="invalid-sensitive-fixture-value"\n')
                page.locator('[data-fk="set-reload"]').click()
                expect(page.locator("main")).to_contain_text("last valid rules")
                expect(page.locator("body")).not_to_contain_text("invalid-sensitive-fixture-value")
                assert fixture.service.config.branch_template == "external-{iid}"
                fixture.config_path.write_text(valid_file)
                page.locator('[data-fk="set-reload"]').click()
                expect(page.locator("main")).to_contain_text("In use locally")

            check(
                "External Reload applies local views; invalid retains last good; no remote refresh",
                external_settings,
            )

            def compare_profiles():
                route("access")
                for name in ("owner", "readonly", "limited", "unavailable"):
                    page.locator(f'[data-fk="cmp-p-{name}"]').check()
                page.locator('[data-fk="cmp-kind"]').select_option("run_pipeline")
                page.locator('[data-fk="cmp-project"]').select_option("42")
                page.locator('[data-fk="cmp-branch"]').fill("issue-791")
                sha = fixture.service.snapshot().items[0].branches[0].sha
                page.locator('[data-fk="cmp-expected_sha"]').fill(sha)
                for _ in range(2):
                    start = len(fixture.calls)
                    with page.expect_response(base + "/api/access/compare") as compared:
                        page.locator('[data-fk="cmp-run"]').click()
                    assert compared.value.status == 200
                    result = compared.value.json()
                    assert [x["kind"] for x in result["rows"]] == [
                        "allowed",
                        "denied",
                        "unknown",
                        "unknown",
                    ]
                    assert result["rows"][-1]["error_code"] == "missing_secret"
                    assert result["executed"] is False
                    assert len(fixture.calls) > start
                    assert all(c["method"] == "GET" for c in fixture.calls[start:])
                    table = page.get_by_role("region", name="Permission comparison", exact=True)
                    expect(table).to_contain_text("Allowed")
                    expect(table).to_contain_text("Denied")
                    expect(table).to_contain_text("Unknown")
                    expect(table).to_contain_text("missing_secret")
                    expect(page.locator("main")).to_contain_text("Not executed")
                    expect(page.locator("main")).to_contain_text("No confirmation issued")
                expect(page.locator("body")).not_to_contain_text(INERT_MARKER)
                expect(page.locator("body")).not_to_contain_text("GSPACE_SYNTHETIC_UNUSED")
                assert not any(r["path"] == "/api/actions/execute" for r in requests)
                capture("profile-comparison", "light", 1600)
                for theme, width in (("dark", 1600), ("light", 390), ("dark", 390)):
                    page.set_viewport_size(
                        {"width": width, "height": 844 if width == 390 else 1100}
                    )
                    # Theme DOM is the actual UI mechanism; stored value survives later reloads.
                    page.evaluate(
                        "t=>{localStorage.setItem('gspace.theme',t);document.documentElement.dataset.theme=t}",
                        theme,
                    )
                    capture("profile-comparison", theme, width)
                    assert page.evaluate("document.documentElement.scrollWidth") <= width + 1
                page.set_viewport_size({"width": 1600, "height": 1100})

            check(
                "Web comparison: four GET profiles, isolated error, redacted, no grants/effects",
                compare_profiles,
            )

            def interrupted_compare():
                # Hold the owned local response while the operator edits the target.
                # The evidence still comes from the real ActionService GET mock.
                def interrupted(request_route):
                    response = request_route.fetch()
                    page.locator('[data-fk="cmp-branch"]').fill("issue-792")
                    request_route.fulfill(response=response)

                page.route("**/api/access/compare", interrupted)
                try:
                    page.locator('[data-fk="cmp-run"]').click()
                    page.wait_for_timeout(450)
                    expect(page.locator('[data-fk="cmp-branch"]')).to_have_value("issue-792")
                    expect(
                        page.get_by_role("region", name="Permission comparison", exact=True)
                    ).to_have_count(0)
                finally:
                    page.unroute("**/api/access/compare", interrupted)

            check(
                "Changing comparison target during response cannot show stale permission results",
                interrupted_compare,
            )

            def separate_runtime_error():
                previous = fixture.service.snapshot()
                updated = previous.model_dump(mode="json")
                item = next(i for i in updated["items"] if i["identity"]["issue"]["value"] == 792)
                environment = next(e for e in item["environments"] if e["name"] == "dev")
                environment["observation"] = {
                    "kind": "error",
                    "code": "transport",
                    "message": "Synthetic unavailable read",
                    "source": "fixture",
                    "checked_at": previous.fetched_at.isoformat(),
                }
                fixture.service._snapshot = Snapshot.model_validate(updated)
                try:
                    route("item/42/792")
                    page.get_by_role("button", name="Overview", exact=True).click()
                    attention = page.get_by_label("Attention for #792", exact=True)
                    expect(attention).to_contain_text("runtime read error")
                    expect(attention).not_to_contain_text("runs a different version")
                    capture("runtime-error-not-mismatch", "light", 1600)
                finally:
                    fixture.service._snapshot = previous

            check(
                "Runtime read error is distinct from observed version mismatch",
                separate_runtime_error,
            )

            def navigation_scope():
                route("work")
                repo = page.get_by_role("combobox", name="Repository", exact=True)
                repo.select_option("99")
                page.wait_for_timeout(300)
                assert "project=99" in page.url
                page.locator('[data-fk="w-assigned"]').uncheck()
                page.wait_for_timeout(350)
                expect(page.locator("main")).to_contain_text("Revise ground handling dispatch")
                page.get_by_role("link", name="Saved views", exact=False).first.click()
                page.locator("main").get_by_role("button", name="Open", exact=True).first.click()
                page.wait_for_timeout(350)
                assert "project=42" in page.url
                expect(page.locator("main")).to_contain_text("Flight active work")
                expect(page.locator("body")).to_contain_text("repository scope changed")
                page.get_by_role("link", name="Bookmarks", exact=False).first.click()
                page.locator("main").get_by_role(
                    "link", name="Ground service · issue-791", exact=True
                ).click()
                page.wait_for_timeout(300)
                assert "branches/99/issue-791" in page.url and "project=99" in page.url
                expect(page.locator(".inspector")).to_contain_text("ground-service")
                # Rapid scope interruption finishes in the explicitly chosen repository.
                repo.select_option("42")
                repo.select_option("99")
                page.wait_for_timeout(500)
                expect(repo).to_have_value("99")
                assert "project=99" in page.url
                capture("bookmark-other-project", "light", 1600)

            check(
                "Repository, saved view and same-name branch bookmark retain project identities",
                navigation_scope,
            )

            def mobile_settings():
                page.set_viewport_size({"width": 390, "height": 844})
                route("work")
                menu = page.locator('[data-fk="appmenu"]')
                expect(menu).to_be_visible()
                box = menu.bounding_box()
                assert box and box["x"] >= 0 and box["x"] + box["width"] <= 391
                menu.click()
                page.locator('[data-fk="menu-settings"]').click()
                expect(page.locator("main h1")).to_have_text("Settings")
                expect(page.locator(".app-menu[open]")).to_have_count(0)
                capture("mobile-settings-found", "light", 390)
                page.set_viewport_size({"width": 1600, "height": 1100})

            check(
                "Mobile Menu makes Settings immediately reachable and closes after navigation",
                mobile_settings,
            )

        remote_calls = list(fixture.calls)
        browser.close()
    report = {
        "checks": checks,
        "captures": captures,
        "browser_errors": browser_errors,
        "outside": outside,
        "requests": requests,
        "remote_mock_calls": remote_calls,
        "assets": hashes,
        "source": "actual compiled browser; temporary synthetic state; GET-only MockTransport",
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    failed = sum(c["result"] != "passed" for c in checks) + len(browser_errors) + len(outside)
    print(
        json.dumps(
            {
                "checks": len(checks),
                "failed": failed,
                "captures": len(captures),
                "report": str(output / "report.json"),
            }
        )
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
