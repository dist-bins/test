"""Bounded GET observation with DNS pinning, verified TLS and explicit network policy."""

from __future__ import annotations

import http.client
import ipaddress
import json
import re
import socket
import ssl
import threading
import time
from collections.abc import Callable
from contextlib import suppress
from datetime import UTC, datetime
from queue import Empty, Queue
from typing import Protocol, assert_never
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup
from pydantic import JsonValue, TypeAdapter, ValidationError

from gspace.config import Endpoint, HtmlExtraction, JsonExtraction
from gspace.models import Observation, ObservationError, Observed, Version

JSON = TypeAdapter[JsonValue](JsonValue)


class HttpReadPolicy(Protocol):
    @property
    def url(self) -> str: ...
    @property
    def allowed_origins(self) -> tuple[str, ...]: ...
    @property
    def allowed_networks(self) -> tuple[str, ...]: ...
    @property
    def allow_http(self) -> bool: ...
    @property
    def timeout_seconds(self) -> float: ...
    @property
    def max_bytes(self) -> int: ...
    @property
    def max_redirects(self) -> int: ...


class ObservationFailure(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def validate_url(url: str, endpoint: HttpReadPolicy) -> tuple[str, int, str]:
    parts = urlsplit(url)
    if (
        parts.scheme not in ("https", "http")
        or not parts.hostname
        or parts.username
        or parts.password
        or parts.query
        or parts.fragment
        or any(ord(c) < 33 for c in url)
    ):
        raise ObservationFailure("configuration", "Unsafe environment URL")
    try:
        port = parts.port or (443 if parts.scheme == "https" else 80)
    except ValueError as error:
        raise ObservationFailure("configuration", "Invalid environment URL port") from error
    normalized = (parts.scheme, parts.hostname.lower(), port)
    allowed: set[tuple[str, str | None, int]] = set()
    for origin in endpoint.allowed_origins:
        permitted = urlsplit(origin)
        allowed.add(
            (
                permitted.scheme,
                permitted.hostname,
                permitted.port or (443 if permitted.scheme == "https" else 80),
            )
        )
    if normalized not in allowed:
        raise ObservationFailure("configuration", "Environment origin is not allowlisted")
    if parts.scheme == "http" and not endpoint.allow_http:
        raise ObservationFailure("configuration", "Environment requires verified TLS")
    return parts.hostname, port, parts.path or "/"


def resolve_address(
    host: str, port: int, endpoint: HttpReadPolicy, timeout: float | None = None
) -> str:
    results: Queue[tuple[str, ...] | OSError] = Queue(maxsize=1)

    def resolve() -> None:
        try:
            addresses = tuple(
                sorted(
                    {
                        str(row[4][0])
                        for row in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
                    }
                )
            )
            results.put(addresses)
        except OSError as error:
            results.put(error)

    # The OS DNS call may finish later; its daemon never opens a connection after a timeout.
    threading.Thread(target=resolve, daemon=True).start()
    try:
        result = results.get(timeout=timeout if timeout is not None else endpoint.timeout_seconds)
    except Empty as error:
        raise ObservationFailure("transport", "Environment DNS timeout") from error
    if isinstance(result, OSError):
        raise result
    addresses = result
    networks = tuple(ipaddress.ip_network(n) for n in endpoint.allowed_networks)
    if not addresses:
        raise ObservationFailure("transport", "Environment DNS returned no addresses")
    for address in addresses:
        ip = ipaddress.ip_address(address)
        explicit = any(ip in network for network in networks)
        if (not ip.is_global and not explicit) or (endpoint.allow_http and not explicit):
            raise ObservationFailure(
                "configuration", "Environment address is not allowed by policy"
            )
    return addresses[0]


class PinnedTLS(http.client.HTTPSConnection):
    def __init__(self, host: str, port: int, address: str, timeout: float) -> None:
        super().__init__(host, port, timeout=timeout, context=ssl.create_default_context())
        self.address = address
        self.deadline = time.monotonic() + timeout

    def connect(self) -> None:
        raw = socket.create_connection((self.address, self.port), self.timeout)
        try:
            remaining = self.deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("TLS connection timeout")
            raw.settimeout(remaining)
            self.sock = ssl.create_default_context().wrap_socket(raw, server_hostname=self.host)
        except BaseException:
            raw.close()
            raise


def fetch(endpoint: HttpReadPolicy) -> bytes:
    url = endpoint.url
    deadline = time.monotonic() + endpoint.timeout_seconds
    for step in range(endpoint.max_redirects + 1):
        host, port, path = validate_url(url, endpoint)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ObservationFailure("transport", "Environment timeout")
        address = resolve_address(host, port, endpoint, remaining)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ObservationFailure("transport", "Environment timeout")
        connection: http.client.HTTPConnection
        if urlsplit(url).scheme == "https":
            connection = PinnedTLS(host, port, address, remaining)
        else:
            connection = http.client.HTTPConnection(address, port, timeout=remaining)

        def abort_connection(target: http.client.HTTPConnection = connection) -> None:
            connected = target.sock
            if connected is not None:
                with suppress(OSError):
                    connected.shutdown(socket.SHUT_RDWR)
            target.close()

        timer = threading.Timer(remaining, abort_connection)
        timer.daemon = True
        timer.start()
        try:
            connection.request("GET", path, headers={"Host": urlsplit(url).netloc, "Accept": "*/*"})
            response = connection.getresponse()
            if response.status in (301, 302, 303, 307, 308):
                location = response.getheader("Location")
                if not location or step == endpoint.max_redirects:
                    raise ObservationFailure("limit", "Environment redirect limit reached")
                url = urljoin(url, location)
                validate_url(url, endpoint)
                continue
            if response.status != 200:
                raise ObservationFailure("http", f"Environment HTTP status {response.status}")
            if response.getheader("Content-Encoding", "identity") != "identity":
                raise ObservationFailure("limit", "Compressed environment response is unsupported")
            body = bytearray()
            while len(body) <= endpoint.max_bytes:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise ObservationFailure("transport", "Environment timeout")
                if connection.sock is not None:
                    connection.sock.settimeout(remaining)
                chunk = response.read1(min(8192, endpoint.max_bytes + 1 - len(body)))
                if not chunk:
                    break
                body.extend(chunk)
            if len(body) > endpoint.max_bytes:
                raise ObservationFailure("limit", "Environment response exceeds byte limit")
            return bytes(body)
        finally:
            timer.cancel()
            connection.close()
    raise ObservationFailure("limit", "Environment redirect limit reached")


def extract(body: bytes, endpoint: Endpoint) -> Version:
    if len(body) > endpoint.max_bytes:
        raise ObservationFailure("limit", "Environment response exceeds byte limit")
    values: dict[str, str] = {}
    match endpoint.extraction:
        case JsonExtraction(fields=fields):
            document = JSON.validate_json(body)
            for entry in fields:
                value: JsonValue = document
                for part in entry.path.split("."):
                    if not isinstance(value, dict) or part not in value:
                        raise ObservationFailure("extraction", "Configured JSON path is absent")
                    value = value[part]
                if not isinstance(value, str) or not value or len(value) > 200:
                    raise ObservationFailure("extraction", "Version field must be a bounded string")
                values[entry.field] = value
        case HtmlExtraction(fields=fields):
            soup = BeautifulSoup(body.decode("utf-8"), "html.parser")
            for entry in fields:
                selected = (
                    soup.find_all(id=entry.selector[1:])
                    if entry.selector.startswith("#")
                    else soup.find_all(class_=entry.selector[1:])
                    if entry.selector.startswith(".")
                    else soup.find_all(entry.selector)
                )
                if len(selected) != 1:
                    raise ObservationFailure("extraction", "HTML selector must select one element")
                text = selected[0].get_text(" ", strip=True)
                if len(text) > 2000:
                    raise ObservationFailure("limit", "HTML version element exceeds text limit")
                before, after = entry.pattern.split("{value}")
                pattern = re.escape(before) + r"([A-Za-z0-9._/+:-]{1,200})" + re.escape(after)
                found = re.fullmatch(pattern, text)
                if found is None:
                    raise ObservationFailure("extraction", "HTML version pattern did not match")
                values[entry.field] = found.group(1)
        case _ as unreachable:  # pyright: ignore[reportUnnecessaryComparison]
            assert_never(unreachable)
    return Version.model_validate(values)


def observe(endpoint: Endpoint, fetcher: Callable[[Endpoint], bytes] = fetch) -> Observation:
    now = datetime.now(UTC)
    source = f"configured {endpoint.name} endpoint"
    try:
        validate_url(endpoint.url, endpoint)
        return Observed(value=extract(fetcher(endpoint), endpoint), source=source, checked_at=now)
    except ObservationFailure as error:
        code = error.code
        if code not in ("configuration", "transport", "http", "extraction", "limit"):
            code = "transport"
        return ObservationError.model_validate(
            {"code": code, "message": str(error), "source": source, "checked_at": now}
        )
    except (OSError, ssl.SSLError, http.client.HTTPException):
        return ObservationError(
            code="transport", message="Environment transport failed", source=source, checked_at=now
        )
    except (ValueError, ValidationError, json.JSONDecodeError):
        return ObservationError(
            code="extraction",
            message="Environment version could not be parsed",
            source=source,
            checked_at=now,
        )
