"""Fixed loopback TCP relay into the dedicated internal lab network.

Used when the local Docker implementation does not publish internal-network
ports. No arbitrary destination, shell, authentication-file read or payload log.
The reviewed Ruby socket snippet runs only in our exact pinned lab container.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.gitlab_lab import docker_environment, docker_run  # noqa: E402

CONTAINER = "gspace-integration-181112-v1-gitlab-1"
IMAGE = (
    "gitlab/gitlab-ce:18.11.12-ce.0@sha256:"
    "9dc94c49789d1ffec78e1998b088c83d7d1d9d5f2dc8b388cbb2bd2de328dd21"
)
DESTINATIONS = {8929: ("127.0.0.1", 8929), 8890: ("runtime", 8890)}
RUBY = (
    "require 'socket'; STDOUT.sync=true; s=TCPSocket.new(ARGV[0],Integer(ARGV[1])); "
    "a=Thread.new{begin; IO.copy_stream(STDIN,s); s.close_write; "
    "rescue IOError,SystemCallError; end}; "
    "begin; IO.copy_stream(s,STDOUT); rescue IOError,SystemCallError; end; s.close; a.kill"
)
MAX_BYTES = 64 * 1024 * 1024


def validate_container() -> None:
    result = docker_run(
        [
            "docker",
            "inspect",
            CONTAINER,
            "--format",
            '{{.Config.Image}}|{{index .Config.Labels "com.docker.compose.project"}}|'
            "{{.State.Running}}",
        ],
        timeout=15,
    )
    expected = f"{IMAGE}|gspace-integration-181112-v1|true"
    if result.returncode or result.stdout.strip() != expected:
        raise RuntimeError("Exact owned running lab container required")


async def run(environment: dict[str, str]) -> None:
    active = 0

    async def handle(reader, writer, port):
        nonlocal active
        if active >= 12:
            writer.close()
            await writer.wait_closed()
            return
        active += 1
        process = None
        host, destination = DESTINATIONS[port]
        try:
            async with asyncio.timeout(90):
                process = await asyncio.create_subprocess_exec(
                    "docker",
                    "exec",
                    "-i",
                    CONTAINER,
                    "/opt/gitlab/embedded/bin/ruby",
                    "-e",
                    RUBY,
                    host,
                    str(destination),
                    env=environment,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.DEVNULL,
                )

                async def upload():
                    total = 0
                    while data := await reader.read(16384):
                        total += len(data)
                        if total > MAX_BYTES:
                            raise RuntimeError("Lab relay request size limit")
                        process.stdin.write(data)
                        await process.stdin.drain()
                    process.stdin.close()

                async def download():
                    total = 0
                    while data := await process.stdout.read(16384):
                        total += len(data)
                        if total > MAX_BYTES:
                            raise RuntimeError("Lab relay response size limit")
                        writer.write(data)
                        await writer.drain()

                sender = asyncio.create_task(upload())
                try:
                    await download()
                finally:
                    sender.cancel()
                    await asyncio.gather(sender, return_exceptions=True)
        except (OSError, RuntimeError, TimeoutError):
            pass  # No payload, header, credential, error-body or URL logging.
        finally:
            if process is not None and process.returncode is None:
                process.terminate()
                await process.wait()
            active -= 1
            writer.close()
            await writer.wait_closed()

    servers = []
    try:
        for port in DESTINATIONS:
            server = await asyncio.start_server(
                lambda reader, writer, port=port: handle(reader, writer, port),
                host="127.0.0.1",
                port=port,
                limit=32768,
            )
            servers.append(server)
        print(
            json.dumps({"status": "running", "bind": "127.0.0.1", "ports": list(DESTINATIONS)}),
            flush=True,
        )
        state = Path(__file__).resolve().parents[1] / ".state/lab"
        state.mkdir(parents=True, exist_ok=True)
        (state / "loopback.pid").write_text(str(os.getpid()) + "\n")
        await asyncio.gather(*(server.serve_forever() for server in servers))
    finally:
        for server in servers:
            server.close()
            await server.wait_closed()


if __name__ == "__main__":
    validate_container()
    with docker_environment() as environment:
        asyncio.run(run(environment))
