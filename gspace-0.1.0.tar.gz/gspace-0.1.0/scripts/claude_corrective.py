"""Run the authorized sole frontend writer with fixed model, effort and tool scope.

Reads no authentication files and performs no login/account/provider changes.
Only this task's public process/model/status events are summarized. Full CLI output
is retained separately and must be read through the public-event monitor.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend-new"
REFERENCE = Path(
    "/Users/else/Mega/8-Progetti/omnichat/.repos/gramsrv-admin-ui/cmd/telesrv-admin/web/src/styles"
)
MODEL = "claude-opus-5-5"
EFFORT = "high"
CHECKPOINT = f"{ROOT / '.venv/bin/python'} {ROOT / 'scripts/frontend_checkpoint.py'} --message *"
CLI_CHECKPOINT = f"{ROOT / '.venv/bin/python'} {ROOT / 'scripts/cli_checkpoint.py'} --message *"
OUTPUT = ROOT / "output/claude"
STAMP = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
PREFIX = OUTPUT / f"opus55-high-{STAMP}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--review", action="store_true", help="Apply fixed task-owned browser feedback"
    )
    parser.add_argument(
        "--visual",
        choices=["before", "after"],
        help="Review actual images with verified Read access",
    )
    parser.add_argument("--parity", action="store_true", help="Implement verified parity contracts")
    parser.add_argument(
        "--typescript", action="store_true", help="Perform authorized strict TS migration"
    )
    parser.add_argument(
        "--visual-overview",
        action="store_true",
        help="Implement the prepared additional visual modes and shared contracts",
    )
    parser.add_argument(
        "--visual-overview-review",
        action="store_true",
        help="Inspect every new compiled visual-mode capture",
    )
    parser.add_argument("--resume", help="Continue only a verified task-owned session UUID")
    parser.add_argument(
        "--cli-review",
        action="store_true",
        help="Withdrawn: CLI presentation is now Codex-owned",
    )
    args = parser.parse_args()
    if args.cli_review:
        raise ValueError("Claude CLI presentation scope is withdrawn; Codex owns CLI under D04/6")
    if datetime.now(UTC) < datetime(2026, 10, 7, 3, 30, tzinfo=UTC):
        raise ValueError("The observed task-owned quota reset is03:30UTC7October; no Claude retry")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    permissions = {
        "allow": [
            "Read",
            "Glob",
            "Grep",
            "Edit(./**)",
            "Write(./**)",
            f"Bash({CHECKPOINT})",
        ],
        "deny": [
            f"{tool}({path})"
            for tool in ("Read", "Edit", "Write")
            for path in ("./.git/**", "./.claude/**", "./.env", "./.env.*")
        ]
        + [f"{tool}(/{REFERENCE}/**)" for tool in ("Edit", "Write")]
        + ["Bash(git *)"],
    }
    prompt = """Continue the authorized second corrective GSpace frontend pass.
You are the sole frontend asset writer. Start from the clean Git checkpoint fd48a2d.
Read docs/next-pass.md, API.md and contracts/openapi.json before substantial edits.
Implement the entire corrective brief, starting with adjacent work-item columns
whose coherent vertical process presentation makes branch/MR/pipeline/jobs/publish/
dev/tag/tag-pipeline/preprod and their provenance understandable. Keep normal views.
Design thoughtfully rather than merely rearranging the same flat evidence table.
Correct repository scope, stale responses, host/project view and bookmark payloads,
repeat-refresh feedback, accessible mobile controls and truthful access/action UI.
Use only actual typed API fields; do not invent relationships, permission or success.
Work only in frontend-new. The added reference styles directory is read-only.
Never access old UI, sessions/logs/auth, other project data, shell history or secrets.
No network services, login, account/billing/provider changes or real remote actions.
No bypass permissions, arbitrary shell or direct Git. The only permitted command is
the fixed frontend_checkpoint.py wrapper shown in next-pass.md; use it for reviewable
stages. If unavailable, request a checkpoint in your final summary and keep working.
Use English UI/docs, both approved wolf assets, light/dark/system themes and responsive
keyboard-accessible behavior. Document implemented/deferred features in docs/design.md.
Do not claim tests that were not run. Root runs browser/API/package tests separately.
Never silently change model: this run is explicitly Claude Opus 5.5, high effort.
Finish a usable corrective frontend and summarize concrete changes and limitations.
"""
    if args.review:
        feedback = ROOT / "output/verification/frontend-feedback.md"
        text = feedback.read_text()
        if len(text) > 12000:
            raise ValueError("Review feedback must be a compact task-owned report")
        prompt = f"""Apply the following verified GSpace browser review feedback.
You are the sole frontend writer, continuing the existing checkpointed implementation.
Use Claude Opus 5.5/high only; no fallback or subagents of another model.
Make focused corrections, preserving working workflows and their evidence semantics.
Read only the relevant source sections and docs/design.md; the contracts remain unchanged.
Own only frontend-new; the added reference CSS is read-only. No old renderer, unrelated
sessions/logs/auth, credentials, login, billing/provider changes or remote actions.
No arbitrary shell/direct Git/bypass. The only command is the already permitted fixed
frontend_checkpoint.py wrapper; create a reviewable local checkpoint after corrections.
Update docs/design.md honestly; root runs the tests, so do not claim new test results.

{text}
"""
    if args.parity:
        prompt = """Implement the authorized complete GSpace requirements-parity frontend.
You are the SOLE frontend asset writer, exact Claude Opus 5.5/high, no fallback/subagents.
Continue preserved partial Git checkpoint 1c071d3 after the observed session-limit reset.
Some app.js changes exist but CSS/popover engine/settings integration are unfinished.
Inspect and finish them; do not discard the checkpoint or start a competing writer.
Read API.md iteration04 and targeted relevant schemas in contracts/openapi.json,
contracts/sample-milestones.json, contracts/sample-settings.json, sample-dashboard.json,
docs/visual-review-before.md and docs/parity-brief.md. Backend/API are root-tested;
do not invent schema/relations/success. Own frontend-new assets and docs only.
First implement the stable evidence popover (no layout shift/moving i), then ALL milestone,
shared filters/manual version-bound app tests/custom environments/settings/effective
overrides/important jobs requirements. Apply actual visual findings across ALL screens.
Preserve adjacent process columns and normal views, keyboard/touch/light/dark/mobile,
both wolf assets and truthful synthetic labels. No upstream scripts, network actions,
URLs/auth edits, old UI, unrelated projects/sessions/logs, .git/.claude/.env/auth reads,
account/billing/provider changes or permission bypass. Only shell command authorized:
the fixed frontend_checkpoint.py wrapper. Use checkpoints or request them if unavailable.
Use English UI/docs. Report implemented/deferred behavior honestly; root runs browser/API
verification. Finish usable complete integration, not a proposal. Read the entire brief.
Accepted additional defects: center every process node exactly on its rail, including
multi-node cells and item/MR details; project icon must never overlap repository text.
Root independently passed151tests,12offlinepackage,31stable-browser checks. Both running
ports intentionally serve stableba7ee8c. Root will launch isolated draft browser tests.
The baseline visual review is already complete; use its findings, not invented reviews.
"""
    if args.typescript:
        prompt = """Perform the explicitly authorized GSpace TypeScript migration.
You remain the SOLE frontend source writer, exact Claude Opus5.5/high, no fallback/subagents.
Continue the latest finite checkpoint in this same task-owned session. Preserve and finish
existing TypeScript modules after any interrupted pass; do not discard them.
Read docs/typescript-brief.md, API.md and the root-generated contracts/api.d.ts before editing.
Preserve all views, workflow/evidence semantics, Settings first-click fix, stable popovers,
light/dark/mobile design and keyboard behavior. No React rewrite is needed.
Convert maintained app/theme logic to strict TypeScript source, using the ONE generated
OpenAPI HTTP surface. No unchecked legacy-JS bridge, any, blanket ts-ignore/ts-nocheck,
disabled strictness or unsafe unknown-as chains. Keep unknown HTTP values behind genuine
runtime validation; root provides generation/build/drift/compiler integration and feedback.
Use typed UI state and explicit discriminated alternatives; editable drafts are separate
from validated remote DTOs. Do not duplicate HTTP types through pydantic2ts.
Root owns generated contracts and compiled assets; do not hand-edit them. Own maintained
source/config/docs only as assigned in the brief. Root runs tsc/Biome/build/browser checks.
No arbitrary shell/direct Git/bypass/network/auth/account/provider changes. The fixed
frontend_checkpoint.py wrapper is the only allowed command and now includes TS sources,
package/lock/compiler/Biome metadata. Use it for recoverable stages. Exclude dependencies,
review screenshots and private data. Finish useful source and report exact pending checks.
"""
    if args.visual_overview:
        if args.review or args.parity or args.typescript or args.visual:
            raise ValueError("The visual overview is one independent sole-writer pass")
        if datetime.now(UTC) < datetime(2026, 10, 6, 22, 30, tzinfo=UTC):
            raise ValueError("The authorized visual pass cannot start before22:30UTC")
        prompt = """Resume the explicitly authorized additional GSpace visual frontend pass.
You are the SOLE web designer, exact Claude Opus5.5/high. No fallback or subagents.
Start from current finite Git2afefa9 and preserved strict maintained TypeScript.
FIRST read docs/visual-overview-brief.md in full (including verbatim user requests), API.md,
docs/design.md and targeted current generated contracts/api.d.ts/openapi schemas.
Let your design judgment organize a coherent, compact beginner visual mode in addition
 to every existing detailed view. PRIORITIZE adjacent work-item columns with intelligible
vertical branch -> MR -> branch pipeline/jobs -> Nexus -> manual Dev -> tag -> tag pipeline
-> Preprod. Render actual relationships/1:N/provenance/override/unknown honestly; native
cross-project graph has scoped nodes/edges/sourceJob and independent application/config SHA.
Implement milestone date timeline, configurable custom environments, shared navigation
curated icons/colors/pins/order and project selector local avatar/fallback using the CURRENT
ready156-schema contracts. No localStorage replacement for shared TOML or external images.
Preserve normal tables, full drilldown, all filters/selection, attempts/hidden jobs, separate
job/deploy/runtime/manual application test facts. Never auto-ready, retry, rebase or invent
criticality/success/relationships. No new arbitrary query/URL/proxy or real GitLab access.
Keep accessible light/dark/system/mobile/keyboard and all assets packaged locally.
Use the authorized reference styles directory READ ONLY; no other project's sessions,
logs/auth or data. Root actually reviewed96original captures and9mobile supplements;
use review-input/after and review-input/supplements for available pixels when useful.
Do not claim your own image inspection from root notes, filenames or inferred code.
Fix confirmed duplicate manual-history prose/mobile MR title and debloat repeated chrome.
Own ONLY maintained frontend-new source/styles/docs. Root owns generated contracts,
compiled assets, backend and CLI; do not hand-edit generated contracts or preview assets.
No arbitrary shell/direct Git/bypass/network/auth/login/account/billing/model changes.
The ONLY permitted command is the fixed frontend_checkpoint.py wrapper in next-pass.md.
Checkpoint before/after useful stages. Neither running preview may be stopped/restarted.
Root will run strictTS/Biome/schema/reproducible build and compiled-browser/theme/viewport/
persistence/repeated-refresh/popover gates, capture new pages and send bounded feedback.
Update docs/design.md with exact implemented versus missing features; don't claim unrun
checks. Finish a usable complete frontend, not a design proposal or all-table reshuffle.
The live glab redirect gate and license evidence limitations remain independent and open.
"""
    if args.visual:
        permissions["allow"] = ["Read", "Glob", "Grep", "Write(./docs/**)"]
        permissions["deny"] += ["Edit", "Bash"]
        prompt = f"""Perform the authorized EVERY-PAGE GSpace visual review: {args.visual}.
You are Claude Opus 5.5/high, no fallback/subagents/model changes. Root owns backend;
you are the sole frontend author, but THIS PASS writes only docs/visual-review-{args.visual}.md.
Read review-input/{args.visual}/manifest.json. Then actually READ every PNG image named in
that manifest using your Read image tool; do not claim inspection from filenames or code.
If image pixels are unavailable, explicitly stop the review and report that limitation.
For each page/state/theme/viewport record the image filename, findings and proposed corrections.
Review all pages: work columns/normal alternatives, compare, items, MRs, branches, pipelines/jobs,
views/bookmarks, access, sources, and new milestones/settings if present. Assess density,
coherent process linkage, unknown/error evidence, responsive and keyboard affordances.
Pay particular attention to evidence information 'i': inspect the actual open popover states
and check stable anchored click/tap placement, viewport bounds, no table layout shift,
Esc/outside-click close and focus return. Separate pixel observations from behavior that
requires root's browser checks. Inspect node/rail centering and repository icon/text clearance.
Detailed evidence must remain keyboard/touch available. Do not edit assets in this review phase.
Only this clean frontend context and its synthetic screenshots are authorized. Never read .git,
.claude, auth/env files, unrelated sessions/logs/project data; no network/shell/provider changes.
Write a concrete English visual coverage matrix and prioritized findings, separating actual
pixel observations from inferred code concerns. No claims of root tests. Finish the document.
"""
    if args.visual_overview_review:
        if args.review or args.parity or args.typescript or args.visual or args.visual_overview:
            raise ValueError("The new visual pixel review is one independent read-only pass")
        permissions["allow"] = ["Read", "Glob", "Grep", "Write(./docs/**)"]
        permissions["deny"] += ["Edit", "Bash"]
        prompt = """Review the actual compiled GSpace Visual and retained Detailed modes.
Exact same Claude Opus5.5/high session; no fallback/subagents/model changes.
Root preserves each source/compiled/review checkpoint and runs independent fixture checks.
Read the current manifest's checkpoint, capture provenance and review context. Do not reuse
old screenshot conclusions to claim review of the current compiled bytes. Source fixes and
test outcomes do not establish image usability; pixels do not prove unexercised behavior.
Read review-input/visual-mode/manifest.json and ACTUALLY READ every PNG listed using Read.
Write ONLY docs/visual-review-visual-mode.md with per-image inspected coverage and findings.
Do not edit source/assets or generated contracts in this review. Do not claim image review
from filenames, root results or code. If image access is unavailable, say so precisely.
Assess all actual new work/compare-four/resource cards/timeline/navigation/item/graph states
in both themes and1600/390viewports: hierarchy, coherence, node/rail alignment, semantic
status separation, readability, mobile containment and access to retained detailed modes.
The manifest also includes16 Detailed-view images from the completed
regression/parity runs. Review their actual usability, not only whether the mode switch exists:
normal rows and comparison columns, pipeline/job attempts, evidence popovers, settings/custom
environments/conflicts and refresh errors, including narrow screens. Per-image provenance
identifies retained captures versus fresh runs. Distinguish pixels from tested behavior.
The delivered graph is on work-item detail only. A standalone general pipeline graph and
local inspectors for uncatalogued downstream nodes are ABSENT, not already delivered.
Report those as scoped feature gaps separately from usability defects in the delivered views.
Separate confirmed pixel defects from behavior already tested or inferred from source.
The backend fixture shows current data only; don't demand missing real GitLab or licensing
proof as visual defects. No real services/auth/sessions/logs/reference-other-data reads.
Report prioritized concrete corrections and whether the displayed modes are usable.
Report any remaining concrete usability issue with severity; don't expand the approved scope.
"""
        context = ROOT / "output/verification/visual-final-review-context-20261007.md"
        if context.is_file():
            latest = context.read_text()
            if len(latest) > 8000:
                raise ValueError("Final review context must remain compact and task-owned")
            prompt += "\nCurrent root-verified context:\n" + latest
    permissions["deny"] += [
        f"{tool}({ROOT / 'src/gspace' / name})"
        for tool in ("Edit", "Write")
        for name in ("cli.py", "cli_render.py", "cli_models.py", "cli_commands.py")
    ]
    prompt += "\nCLI presentation is now Codex-owned. Do not edit or review/redesign CLI source.\n"
    arguments = [
        "/opt/homebrew/bin/claude",
        "--print",
        "--model",
        MODEL,
        "--effort",
        EFFORT,
        "--safe-mode",
        "--restricted",
        "--strict-mcp-config",
        "--mcp-config",
        '{"mcpServers":{}}',
        "--disable-slash-commands",
        "--permission-mode",
        "dontAsk",
        "--permission-prompts",
        "none",
        "--tools",
        "Read,Glob,Grep,Edit,Write,Bash",
        "--allowedTools",
        *permissions["allow"],
        "--settings",
        json.dumps({"permissions": permissions, "switchModelsOnFlag": False}),
        "--output-format",
        "stream-json",
        "--verbose",
        "--add-dir",
        str(REFERENCE),
    ]
    if args.resume:
        session = str(UUID(args.resume))
        owned = any(
            state.get("session_id") == session
            and state.get("model_verified") is True
            and state.get("actual_model") == MODEL
            for path in OUTPUT.glob("*.status.json")
            if (state := json.loads(path.read_text()))
        )
        if not owned:
            raise ValueError("Only this task's verified session may be resumed")
        arguments.extend(["--resume", session])
    for path in OUTPUT.glob("*.status.json"):
        prior = json.loads(path.read_text())
        if prior.get("status") not in ("starting", "running") or not prior.get("pid"):
            continue
        try:
            os.kill(prior["pid"], 0)
        except ProcessLookupError:
            continue
        raise RuntimeError("A task-owned Claude process is still active; no concurrent writer")
    state = {
        "status": "starting",
        "started_at": datetime.now(UTC).isoformat(),
        "model": MODEL,
        "effort": EFFORT,
        "cwd": str(FRONTEND),
        "stream": str(PREFIX.with_suffix(".jsonl")),
        "model_verified": False,
    }
    status = PREFIX.with_suffix(".status.json")
    with PREFIX.with_suffix(".stderr.txt").open("w") as stderr:
        process = subprocess.Popen(
            arguments,
            cwd=FRONTEND,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=stderr,
            text=True,
            env={**os.environ, "CLAUDE_CODE_EFFORT_LEVEL": EFFORT},
        )
        state.update({"pid": process.pid, "status": "running"})
        status.write_text(json.dumps(state, indent=2) + "\n")
        (OUTPUT / "opus55-high-current.status-path").write_text(str(status) + "\n")
        print(json.dumps(state), flush=True)
        assert process.stdin is not None and process.stdout is not None
        process.stdin.write(prompt)
        process.stdin.close()
        with PREFIX.with_suffix(".jsonl").open("w") as stream:
            for line in process.stdout:
                stream.write(line)
                stream.flush()
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if row.get("type") == "system" and row.get("subtype") == "init":
                    actual = row.get("model")
                    state["session_id"] = row.get("session_id")
                    state["model_verified"] = actual == MODEL
                    state["actual_model"] = actual
                    if actual != MODEL:
                        state["status"] = "error"
                        state["public_result"] = "Unexpected model; writer stopped before edits"
                        process.terminate()
                    status.write_text(json.dumps(state, indent=2) + "\n")
                    print(json.dumps({"event": "init", "model": actual}), flush=True)
                if row.get("type") == "result":
                    state["status"] = "error" if row.get("is_error") else "done"
                    state["public_result"] = str(row.get("result", ""))[:2400]
                    state["session_id"] = row.get("session_id")
                    state["actual_models_used"] = list(row.get("modelUsage", {}))
                    if state["actual_models_used"] != [MODEL]:
                        state["status"] = "error"
                        state["model_verification_error"] = "Final modelUsage differs from pin"
        state["exit_code"] = process.wait()
        if state["status"] == "running":
            state["status"] = "error" if state["exit_code"] else "done"
        state["finished_at"] = datetime.now(UTC).isoformat()
        status.write_text(json.dumps(state, indent=2) + "\n")
        print(json.dumps({"status": state["status"], "exit_code": state["exit_code"]}))
        return state["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
