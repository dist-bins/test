"""Typed CLI-only sources and subcommands; application config is ordinary Pydantic."""

from __future__ import annotations

import argparse
import os
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal, NoReturn

from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    CliApp,
    CliPositionalArg,
    CliSettingsSource,
    CliSubCommand,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    get_subcommand,
)
from pydantic_settings.exceptions import SettingsError
from rich_argparse import RichHelpFormatter

from gspace.cli_render import make_console
from gspace.models import EnvironmentLabel, Model


class OptionAlias(Model, frozen=True):
    """CLI-only alias metadata; one meaning per letter across all commands."""

    name: str
    short: str = Field(min_length=1, max_length=1, pattern="^[A-Za-z]$")
    negative: str | None = Field(default=None, min_length=1, max_length=1, pattern="^[A-Za-z]$")


OPTION_ALIASES = (
    OptionAlias(name="config", short="c"),
    OptionAlias(name="json", short="j", negative="J"),
    OptionAlias(name="color", short="C", negative="N"),
    OptionAlias(name="width", short="w"),
    OptionAlias(name="all", short="a", negative="A"),
    OptionAlias(name="search", short="s"),
    OptionAlias(name="group", short="g"),
    OptionAlias(name="project", short="p"),
    OptionAlias(name="view", short="v"),
    OptionAlias(name="orientation", short="o"),
    OptionAlias(name="milestone", short="m"),
    OptionAlias(name="milestone-key", short="M"),
    OptionAlias(name="off", short="f", negative="F"),
    OptionAlias(name="state", short="t"),
    OptionAlias(name="unassigned", short="u", negative="U"),
    OptionAlias(name="show-hidden", short="H", negative="I"),
    OptionAlias(name="reason", short="r"),
    OptionAlias(name="previous-tag", short="T"),
    OptionAlias(name="execute", short="x", negative="X"),
    OptionAlias(name="confirm", short="k"),
    OptionAlias(name="refresh", short="R", negative="D"),
    OptionAlias(name="environment", short="e"),
    OptionAlias(name="port", short="P"),
)


def early_toggle(argv: list[str], name: str, default: bool) -> bool:
    """Only diagnostic presentation before typed parsing; never changes parsed arguments."""
    alias = next(option for option in OPTION_ALIASES if option.name == name)
    enabled = default
    for argument in argv:
        if argument in (f"--{name}", f"-{alias.short}"):
            enabled = True
        elif argument in (f"--no-{name}", f"-{alias.negative}"):
            enabled = False
    return enabled


class Common(Model, frozen=True):
    config: Path | None = Field(default=None, description="Operator TOML; default fixture mode")
    json_output: bool = Field(
        default=False, alias="json", description="Raw JSON stdout; diagnostics on stderr"
    )
    color: bool = Field(
        default=True, description="Automatic terminal colors; --no-color disables colors"
    )
    width: int | None = Field(
        default=None, ge=40, description="Terminal width override, at least 40 columns"
    )

    def cli_cmd(self) -> None:
        """Dispatch occurs once in the shared application entrypoint."""


class MatrixCommand(Common, frozen=True):
    all: bool = Field(default=False, description="Include closed, unassigned and hidden work items")
    search: str | None = Field(
        default=None, description="Local title / identity / ref display filter"
    )
    group: str | None = Field(default=None, description="Shared local group filter")
    project: int | None = Field(default=None, gt=0, description="Configured project ID")
    view: str | None = Field(default=None, description="Shared saved-view name")
    orientation: Literal["rows", "columns"] | None = Field(
        default=None, description="Work items as rows or side-by-side process columns"
    )
    milestone: Literal["all", "active", "date_current", "unassigned"] | None = Field(
        default=None, description="Milestone selection mode; dates use configured timezone"
    )
    milestone_key: str | None = Field(
        default=None, description="Explicit project:ID:ID or group:ID:ID milestone key"
    )


class KeyCommand(Common, frozen=True):
    key: CliPositionalArg[str] = Field(description="Project-scoped work item, e.g. 42:791")


class FlagCommand(KeyCommand, frozen=True):
    off: bool = False


class GroupCommand(FlagCommand, frozen=True):
    name: CliPositionalArg[str]


class ChecklistCommand(FlagCommand, frozen=True):
    field: CliPositionalArg[Literal["local_test", "dev_test", "preprod_test", "work_confirmed"]]


class FilterCommand(Common, frozen=True):
    state: Literal["opened", "closed", "all"] = "opened"
    unassigned: bool = False
    show_hidden: bool = False
    search: str = ""
    group: str = ""
    milestone: Literal["all", "active", "date_current", "unassigned"] = "all"
    milestone_key: str | None = Field(
        default=None, description="Explicit project:ID:ID or group:ID:ID milestone key"
    )


class OverrideCommand(FlagCommand, frozen=True):
    kind: CliPositionalArg[Literal["branch", "mr", "tag"]]
    value: CliPositionalArg[str]
    reason: str


class PreviewCommand(KeyCommand, frozen=True):
    action: CliPositionalArg[
        Literal["tag", "deploy-dev", "deploy-preprod", "rebase", "retry", "ready", "merge"]
    ]
    previous_tag: str | None = None


class ObserveCommand(KeyCommand, frozen=True):
    environment: CliPositionalArg[EnvironmentLabel]


class FileCommand(Common, frozen=True):
    file: CliPositionalArg[Path]


class NameCommand(Common, frozen=True):
    name: CliPositionalArg[str]


class DoctorCommand(Common, frozen=True):
    profile: CliPositionalArg[str]


class ActionCommand(FileCommand, frozen=True):
    execute: bool = False
    confirm: str | None = None


class MRCommand(Common, frozen=True):
    project: int | None = Field(default=None, gt=0, description="Configured project ID")
    refresh: bool = False
    state: Literal["all", "open", "closed", "merged"] = "all"


class MilestoneCommand(Common, frozen=True):
    project: int | None = Field(default=None, gt=0, description="Configured project ID")


class CatalogCommand(MilestoneCommand, frozen=True):
    search: str = Field(default="", max_length=200)


class HistoryCommand(KeyCommand, frozen=True):
    environment: EnvironmentLabel | None = None


class ServeCommand(Common, frozen=True):
    port: int = Field(default=8876, ge=1024, le=65535)


class CliRoot(BaseSettings):
    """GSpace: read-only GitLab cockpit and explicitly local operator preferences."""

    model_config = SettingsConfigDict(
        cli_implicit_flags=True,
        cli_kebab_case=True,
        cli_enforce_required=True,
        cli_avoid_json=True,
        cli_hide_none_type=True,
        case_sensitive=True,
        extra="forbid",
        cli_shortcuts={option.name: option.short for option in OPTION_ALIASES},
    )
    dashboard: CliSubCommand[MatrixCommand] = Field(
        description="Shared work-item cockpit; active assigned items by default"
    )
    list: CliSubCommand[MatrixCommand] = Field(
        description="Compact listing with observed attention; shared filters"
    )
    compare: CliSubCommand[MatrixCommand] = Field(
        description="Compare selected work items in shared preferences"
    )
    show: CliSubCommand[KeyCommand] = Field(
        description="Full evidence, associations, checklist and links"
    )
    pipelines: CliSubCommand[KeyCommand] = Field(
        description="Pipeline identities, job attempts and Nexus publications"
    )
    pipeline_graph: CliSubCommand[KeyCommand] = Field(
        alias="pipeline-graph", description="Bounded native upstream/downstream project evidence"
    )
    environments: CliSubCommand[KeyCommand] = Field(
        description="Expected/observed versions, deploy records and app tests"
    )
    projects: CliSubCommand[Common] = Field(description="Configured project scope")
    mrs: CliSubCommand[MRCommand] = Field(
        description="Authored merge requests across configured projects"
    )
    milestones: CliSubCommand[MilestoneCommand] = Field(
        description="Scoped milestone dates and covered work-item counts"
    )
    branches: CliSubCommand[CatalogCommand] = Field(
        description="General branch catalog with honest rebase evidence"
    )
    pipeline_catalog: CliSubCommand[CatalogCommand] = Field(
        alias="pipeline-catalog", description="General pipeline catalog; jobs are not loaded"
    )
    app_history: CliSubCommand[HistoryCommand] = Field(
        alias="app-history", description="Exact-version manual application-test history"
    )
    settings: CliSubCommand[Common] = Field(
        description="Local operator settings and effective project rules"
    )
    settings_set: CliSubCommand[FileCommand] = Field(
        alias="settings-set",
        description="Update local operator settings from a revisioned JSON file",
    )
    app_test: CliSubCommand[FileCommand] = Field(
        alias="app-test", description="Record an exact-version local manual application result"
    )
    views: CliSubCommand[Common] = Field(description="Shared saved views")
    bookmarks: CliSubCommand[Common] = Field(description="Shared scoped bookmarks")
    navigation: CliSubCommand[Common] = Field(description="Scoped navigation, pins and decorations")
    navigation_set: CliSubCommand[FileCommand] = Field(
        alias="navigation-set", description="Set a shared local navigation decoration"
    )
    navigation_delete: CliSubCommand[FileCommand] = Field(
        alias="navigation-delete", description="Remove a shared local navigation decoration"
    )
    view_save: CliSubCommand[FileCommand] = Field(alias="view-save")
    view_delete: CliSubCommand[NameCommand] = Field(alias="view-delete")
    bookmark_set: CliSubCommand[FileCommand] = Field(alias="bookmark-set")
    bookmark_delete: CliSubCommand[FileCommand] = Field(alias="bookmark-delete")
    profiles: CliSubCommand[Common] = Field(description="Redacted configured access profiles")
    doctor: CliSubCommand[DoctorCommand] = Field(
        description="Read-only diagnostics for an explicit configured profile"
    )
    probe: CliSubCommand[FileCommand] = Field(
        description="GET-only action precondition probe from a JSON file"
    )
    probe_compare: CliSubCommand[FileCommand] = Field(
        alias="probe-compare", description="Compare GET-only probes across explicit profiles"
    )
    action: CliSubCommand[ActionCommand] = Field(
        description="Action preview; finite lab execution requires explicit confirmation"
    )
    preferences: CliSubCommand[Common] = Field(description="Shared local preference state")
    pin: CliSubCommand[FlagCommand] = Field(description="Set or clear a local pin")
    hide: CliSubCommand[FlagCommand] = Field(description="Set or clear local visibility")
    select: CliSubCommand[FlagCommand] = Field(
        description="Set or clear local comparison selection"
    )
    group: CliSubCommand[GroupCommand] = Field(
        description="Manage local work-item group membership"
    )
    checklist: CliSubCommand[ChecklistCommand] = Field(
        description="Manual confirmation only; never changes MR draft"
    )
    filters: CliSubCommand[FilterCommand] = Field(
        description="Update shared local work-item filters"
    )
    override: CliSubCommand[OverrideCommand] = Field(
        description="Record an explicit local association override"
    )
    preview: CliSubCommand[PreviewCommand] = Field(
        description="Preview suggestions without remote execution"
    )
    observe: CliSubCommand[ObserveCommand] = Field(
        description="Read a configured environment version endpoint"
    )
    refresh: CliSubCommand[Common] = Field(description="Refresh remote read-only evidence")
    serve: CliSubCommand[ServeCommand] = Field(description="Serve the web UI on loopback")

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        # Deliberately exclude environment, dotenv and file-secret sources.
        return (init_settings,)

    def cli_cmd(self) -> None:
        CliApp.run_subcommand(self)


def parse(argv: list[str], *, display_command: str | None = None) -> argparse.Namespace:
    width: int | None = None
    width_flag = next((flag for flag in ("--width", "-w") if flag in argv), None)
    if width_flag:
        try:
            candidate = int(argv[argv.index(width_flag) + 1])
            width = candidate if candidate >= 40 else None
        except (ValueError, IndexError):
            pass  # The existing typed parser owns argument validation.
    console = make_console(
        no_color=not early_toggle(argv, "color", True) or "NO_COLOR" in os.environ, width=width
    )

    class HelpFormatter(RichHelpFormatter):
        help_markup = False
        text_markup = False

        def __init__(self, prog: str) -> None:
            if display_command and prog == f"gspace {argv[0]}":
                prog = display_command
            super().__init__(prog, console=console, width=console.width)

    negative_aliases = {
        f"-{option.negative}" for option in OPTION_ALIASES if option.negative is not None
    }

    class BooleanAction(argparse.BooleanOptionalAction):
        def __call__(
            self,
            parser: argparse.ArgumentParser,
            namespace: argparse.Namespace,
            values: str | Sequence[Any] | None,
            option_string: str | None = None,
        ) -> None:
            if option_string in negative_aliases:
                setattr(namespace, self.dest, False)
            else:
                super().__call__(parser, namespace, values, option_string)

    class Parser(argparse.ArgumentParser):
        def add_argument(self, *args: str, **kwargs: Any) -> argparse.Action:
            if kwargs.get("action") is argparse.BooleanOptionalAction:
                option = next(
                    (alias for alias in OPTION_ALIASES if f"--{alias.name}" in args), None
                )
                if option is not None and option.negative is not None:
                    args = (*args, f"-{option.negative}")
                    kwargs["action"] = BooleanAction
            # Pydantic also calls this hook with argparse argument groups.
            return argparse.ArgumentParser.add_argument(self, *args, **kwargs)

        def error(self, message: str) -> NoReturn:
            raise SettingsError(f"error parsing CLI: {message}")

    source: CliSettingsSource[Any] = CliSettingsSource(
        CliRoot,
        cli_prog_name="gspace",
        formatter_class=HelpFormatter,
        add_argument_method=Parser.add_argument,
        cli_exit_on_error=False,
        root_parser=Parser(
            prog="gspace",
            description=CliRoot.__doc__,
            formatter_class=HelpFormatter,
            add_help=False,
            allow_abbrev=False,
        ),
    )
    root = CliApp.run(CliRoot, cli_args=argv, cli_settings_source=source)
    selected = get_subcommand(root, is_required=True)
    assert isinstance(selected, Common)
    field = next(name for name in CliRoot.model_fields if getattr(root, name) is selected)
    payload = selected.model_dump()
    payload["json"] = payload.pop("json_output")
    payload["no_color"] = not payload.pop("color")
    payload["command"] = field.replace("_", "-")
    return argparse.Namespace(**payload)
