"""Characterize default native GSpace/glab redirects on owned isolated loopback.

This uses the ordinary production runner with native redirect behavior.
Use glab_guard_check.py for the separately selected strict mode.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output/verification/offline-runtime"
MARKER = "gspace-inert-synthetic-fixture-only"


def main() -> None:
    executable = shutil.which("glab")
    assert executable is not None
    records: list[dict[str, object]] = []
    status = 302
    second_port = False
    target_port = 0

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            size = int(self.headers.get("Content-Length", "0"))
            assert 0 <= size <= 1024
            body = self.rfile.read(size)
            initial = self.path in ("/api/v4/version", "/api/graphql")
            records.append(
                {
                    "path": self.path,
                    "method": self.command,
                    "private_token_marker": self.headers.get("Private-Token") == MARKER,
                    "query_marker": b"GSpaceSyntheticRead" in body,
                    "body_bytes": len(body),
                }
            )
            if initial:
                self.send_response(status)
                endpoint = "/api/v4/projects/999/synthetic-endpoint"
                self.send_header(
                    "Location",
                    f"http://127.0.0.1:{target_port}{endpoint}" if second_port else endpoint,
                )
            else:
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
            self.end_headers()
            if not initial:
                self.wfile.write(b'{"data":{"__typename":"Query"}}')

        do_POST = do_GET

        def log_message(self, format: str, *args: object) -> None:
            pass

    servers = [ThreadingHTTPServer(("127.0.0.1", 0), Handler) for _ in range(2)]
    source_port, target_port = (s.server_port for s in servers)
    for server in servers:
        threading.Thread(target=server.serve_forever, daemon=True).start()
    cases: list[dict[str, object]] = []
    try:
        with tempfile.TemporaryDirectory(prefix="gspace-glab-methods-") as directory:
            temporary = Path(directory)
            for name in ("glab", "xdg"):
                (temporary / name).mkdir()
            environment = {
                "PATH": "/opt/homebrew/bin:/usr/bin:/bin",
                "PYTHONPATH": str(ROOT / "src"),
                "GLAB_CONFIG_DIR": str(temporary / "glab"),
                "XDG_CONFIG_HOME": str(temporary / "xdg"),
                "GIT_CONFIG_GLOBAL": "/dev/null",
                "GIT_CONFIG_SYSTEM": "/dev/null",
                "GIT_CONFIG_NOSYSTEM": "1",
                "GITLAB_TOKEN": MARKER,
                "GLAB_USE_KEYRING": "false",
                "USE_KEYRING": "false",
                "GLAB_CHECK_UPDATE": "false",
            }
            profile = temporary / "owned-ports.sb"
            profile.write_text(
                "(version 1)\n(allow default)\n(deny network*)\n"
                f'(allow network-outbound (remote ip "localhost:{source_port}"))\n'
                f'(allow network-outbound (remote ip "localhost:{target_port}"))\n'
                '(deny mach-lookup (global-name "com.apple.mDNSResponder"))\n'
                '(deny network-outbound (literal "/private/var/run/mDNSResponder"))\n'
            )
            child = (
                "import sys,json;from gspace.glab import run_argv;"
                "r=run_argv(json.loads(sys.argv[1]),3,api_protocol='http');"
                "print(json.dumps({'code':r.code}))"
            )
            for method in ("GET", "POST"):
                for status in (301, 302, 303, 307, 308):
                    for second_port in (False, True):
                        records.clear()
                        path = "graphql" if method == "POST" else "version"
                        argv = [
                            executable,
                            "api",
                            "--hostname",
                            f"127.0.0.1:{source_port}",
                            "--method",
                            method,
                            path,
                        ]
                        if method == "POST":
                            argv.extend(["-f", "query=query GSpaceSyntheticRead { __typename }"])
                        result = subprocess.run(
                            [
                                "/usr/bin/sandbox-exec",
                                "-f",
                                str(profile),
                                sys.executable,
                                "-c",
                                child,
                                json.dumps(argv),
                            ],
                            cwd=temporary,
                            env=environment,
                            capture_output=True,
                            text=True,
                            check=True,
                            timeout=6,
                        )
                        assert json.loads(result.stdout)["code"] == 0
                        assert len(records) == 2
                        expected = "POST" if method == "POST" and status in (307, 308) else "GET"
                        assert records[1]["method"] == expected
                        assert records[1]["private_token_marker"] is True
                        assert records[1]["query_marker"] is (expected == "POST")
                        cases.append(
                            {
                                "initial_method": method,
                                "status": status,
                                "second_owned_port": second_port,
                                "requests": list(records),
                            }
                        )
            help_result = subprocess.run(
                ["/usr/bin/sandbox-exec", "-f", str(profile), executable, "api", "--help"],
                cwd=temporary,
                env=environment,
                capture_output=True,
                text=True,
                check=True,
                timeout=3,
            )
            assert "redirect" not in help_result.stdout.lower()
            (OUTPUT / "glab-isolated-api-help.txt").write_text(help_result.stdout)
    finally:
        for server in servers:
            server.shutdown()
            server.server_close()
    report = {
        "purpose": "Actual redirect method and inert-header boundary; no real credentials/effects",
        "cases": cases,
        "installed_api_help_exposes_redirect_option": False,
        "scope": "Two owned loopback ports, empty auth configuration, DNS denied",
        "limits": [
            "No actual GitLab mutation or corporate request executed",
            "OAuth/foreign-domain/TLS-downgrade behavior is source inference, not this probe",
        ],
    }
    (OUTPUT / "glab-redirect-methods.json").write_text(json.dumps(report, indent=2) + "\n")
    print("20 installed-glab GET/POST redirect cases passed; CLI help has no redirect option")


if __name__ == "__main__":
    main()
