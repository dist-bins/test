"""Native relation traversal with independent project hydration and bounded uncertainty."""

import json
from urllib.parse import parse_qs, urlsplit

import pytest
from pydantic import ValidationError

from gspace.config import LiveConfig, PipelineGraphLimits, ProjectConfig
from gspace.fixture import synthetic_snapshot
from gspace.glab import AdapterError, GlabAdapter, RunResult
from gspace.models import PipelineGraph, ProjectId
from gspace.pipeline_graph import read_pipeline_graph

A = "a" * 40
B = "b" * 40


def node(project=42, ident=9201, sha=A, source="push", **changes):
    return {
        "id": f"gid://gitlab/Ci::Pipeline/{ident}",
        "iid": str(ident - 9000),
        "sha": sha,
        "ref": "issue-791" if project == 42 else "main",
        "source": source,
        "status": "SUCCESS",
        "project": {
            "id": f"gid://gitlab/Project/{project}",
            "fullPath": "demo/flight-service" if project == 42 else f"demo/deploy-{project}",
        },
        "sourceJob": None,
        **changes,
    }


def expanded(raw, children=(), parent=None, more=False, cursor=None, errors=()):
    return {
        "data": {
            "project": {
                **raw["project"],
                "pipeline": {
                    **raw,
                    "upstream": parent,
                    "downstream": {
                        "nodes": list(children),
                        "pageInfo": {"hasNextPage": more, "endCursor": cursor},
                    },
                },
            }
        },
        "errors": list(errors),
    }


def job(ident, project=42, pipeline=9201, retried=False):
    return {
        "id": ident,
        "name": "deploy-dev",
        "stage": "deploy",
        "status": "success",
        "retried": retried,
        "pipeline": {"id": pipeline, "project_id": project},
    }


def deploy(ident=3001, project=99, pipeline=9701, sha=B, **changes):
    return {
        "id": ident,
        "ref": "main",
        "sha": sha,
        "status": "success",
        "environment": {"id": 55, "name": "dev"},
        "deployable": {"id": 12001, "pipeline": {"id": pipeline, "project_id": project}},
        **changes,
    }


class Remote:
    def __init__(
        self,
        graph,
        jobs=None,
        deployments=None,
        limits=None,
        projects=(42, 99),
        version="18.11.12-ee",
    ):
        self.graph = graph
        self.jobs = jobs or {}
        self.deployments = deployments or {}
        self.calls = []
        self.version = version
        configured = tuple(
            ProjectConfig(
                id=ProjectId(value=p), path="demo/flight-service" if p == 42 else f"demo/deploy-{p}"
            )
            for p in projects
        )
        self.adapter = GlabAdapter(
            LiveConfig(
                hostname="gitlab.example.invalid",
                web_origin="https://gitlab.example.invalid",
                projects=configured,
                pipeline_graph=limits or PipelineGraphLimits(),
            ),
            self.rest,
            self.graph_read,
        )

    def graph_read(self, project, key, cursor):
        self.calls.append(("graph", project.id.value, key.pipeline.value, cursor))
        value = self.graph.get((project.id.value, key.pipeline.value, cursor))
        if isinstance(value, Exception):
            raise value
        return json.dumps(value if value is not None else {"data": {"project": None}}).encode()

    def rest(self, argv, timeout):
        endpoint = urlsplit(argv[-1])
        self.calls.append(("get", endpoint.path, parse_qs(endpoint.query)))
        if endpoint.path == "version":
            data = {"version": self.version}
        elif endpoint.path.endswith("/jobs"):
            _, project, _, pipeline, _ = endpoint.path.split("/")
            data = self.jobs.get((int(project), int(pipeline)), [])
        elif endpoint.path.endswith("/deployments"):
            data = self.deployments.get(int(endpoint.path.split("/")[1]), [])
        else:
            raise AssertionError(endpoint.path)
        if isinstance(data, Exception):
            raise data
        return RunResult(code=0, stdout=json.dumps(data).encode())


def item():
    original = synthetic_snapshot().items[0]
    pipeline = original.pipelines[0].model_copy(update={"sha": A})
    # Keep one root while preserving the WorkItem's domain integrity.
    return original.model_copy(update={"pipelines": (pipeline,), "publishes": ()})


def cross_project(**remote_changes):
    root = node()
    child = node(
        99,
        9701,
        B,
        source="pipeline",
        sourceJob={"id": "gid://gitlab/Ci::Bridge/11001", "kind": "BRIDGE", "retried": False},
    )
    graph = {
        (42, 9201, None): expanded(root, [child]),
        (99, 9701, None): expanded(child, parent=root),
    }
    return Remote(
        graph,
        jobs={(42, 9201): [job(11001)], (99, 9701): [job(12001, 99, 9701)]},
        deployments={99: [deploy()]},
        **remote_changes,
    )


def test_native_cross_project_edges_jobs_deployments_and_application_identity_are_separate():
    remote = cross_project()
    graph = read_pipeline_graph(remote.adapter, item())
    assert graph.coverage.kind == "complete" and len(graph.nodes) == 2 and len(graph.edges) == 1
    root, child = graph.nodes
    assert root.kind == child.kind == "available"
    assert graph.roots[0].application_sha == A and child.pipeline.sha == B
    assert child.pipeline.project.value == 99 and child.pipeline.jobs[0].project.value == 99
    assert (
        child.deployments[0].record.sha == B and child.deployments[0].pipeline.project.value == 99
    )
    edge = graph.edges[0]
    assert edge.source_job.kind == "source_job" and edge.source_job.project.value == 42
    assert child.reference.iid.value == 701 and child.reference.key.pipeline.value == 9701
    assert child.reference.link.url.endswith("/demo/deploy-99/-/pipelines/9701")
    assert graph.application_binding == "edge_does_not_prove_deployed_application_version"
    assert (
        len([c for c in remote.calls if c[0] == "graph"]) == 2
    )  # Cycle back to root does not recurse.
    assert PipelineGraph.model_validate_json(graph.model_dump_json()) == graph


def test_profile_scope_keeps_visible_outside_reference_but_never_reads_it():
    remote = cross_project(projects=(42,))
    graph = read_pipeline_graph(remote.adapter, item())
    assert graph.nodes[1].kind == "unavailable" and graph.coverage.kind == "unknown"
    assert len(graph.edges) == 1 and graph.nodes[1].reference.key.project.value == 99
    assert not any(c[0] == "graph" and c[1] == 99 for c in remote.calls)
    assert not any(c[0] == "get" and c[1].startswith("projects/99") for c in remote.calls)


def test_null_child_and_partial_error_preserve_visible_edge_without_error_message():
    remote = cross_project()
    raw = remote.graph[(42, 9201, None)]
    raw["errors"] = [
        {"message": "SECRET REMOTE ERROR", "path": ["project", "pipeline", "downstream"]}
    ]
    raw["data"]["project"]["pipeline"]["downstream"]["nodes"].append(None)
    graph = read_pipeline_graph(remote.adapter, item())
    assert len(graph.edges) == 1
    assert graph.coverage.kind == "unknown" and graph.unknown_relations
    assert "SECRET" not in graph.model_dump_json()


def test_missing_pipeline_root_is_explicit_unavailable_no_hydration_requests():
    remote = Remote({})
    graph = read_pipeline_graph(remote.adapter, item())
    assert graph.nodes[0].kind == "unavailable" and graph.coverage.kind == "unknown"
    assert len(remote.calls) == 2 and graph.roots[0].application_sha == A


@pytest.mark.parametrize(
    "change",
    [
        {"sha": B},
        {"id": "gid://gitlab/Ci::Pipeline/9999"},
        {"project": {"id": "gid://gitlab/Project/42", "fullPath": "other/project"}},
    ],
)
def test_root_identity_change_is_not_silently_accepted(change):
    root = node(**change)
    remote = Remote({(42, 9201, None): expanded(root)})
    graph = read_pipeline_graph(remote.adapter, item())
    assert graph.nodes[0].kind == "unavailable"
    assert graph.nodes[0].reference.sha == A and graph.coverage.kind == "unknown"


def test_native_downstream_pagination_reads_once_per_cursor_and_merges_edges():
    root = node()
    child = node(99, 9701, B)
    second = node(99, 9702, B)
    remote = Remote(
        {
            (42, 9201, None): expanded(root, [child], more=True, cursor="next"),
            (42, 9201, "next"): expanded(root, [second]),
            (99, 9701, None): expanded(child, parent=root),
            (99, 9702, None): expanded(second, parent=root),
        }
    )
    graph = read_pipeline_graph(remote.adapter, item())
    assert len(graph.edges) == 2 and graph.coverage.kind == "unknown"
    assert len([c for c in remote.calls if c[0] == "graph"]) == 4


@pytest.mark.parametrize("cursor", ["same", None, "bad\n"])
def test_repeated_missing_or_invalid_cursor_does_not_retry_forever(cursor):
    root = node()
    response = expanded(root, more=True, cursor=cursor)
    remote = Remote({(42, 9201, None): response, (42, 9201, "same"): response})
    graph = read_pipeline_graph(remote.adapter, item())
    assert graph.coverage.kind == "unknown"
    assert len([c for c in remote.calls if c[0] == "graph"]) <= 2


@pytest.mark.parametrize(
    "limits",
    [
        PipelineGraphLimits(max_depth=0),
        PipelineGraphLimits(max_nodes=1),
        PipelineGraphLimits(max_pages=1),
        PipelineGraphLimits(max_requests=1),
    ],
)
def test_each_budget_yields_typed_partial_graph(limits):
    remote = cross_project(limits=limits)
    if limits.max_pages == 1:
        remote.graph[(42, 9201, None)]["data"]["project"]["pipeline"]["downstream"]["pageInfo"] = {
            "hasNextPage": True,
            "endCursor": "next",
        }
    graph = read_pipeline_graph(remote.adapter, item())
    assert graph.coverage.kind == "unknown"
    assert len(remote.calls) <= limits.max_requests
    assert len(graph.nodes) <= limits.max_nodes


def test_time_budget_stops_new_requests(monkeypatch):
    ticks = iter((0.0, 0.0, 40.0, 40.0, 40.0))
    monkeypatch.setattr("gspace.pipeline_graph.time.monotonic", lambda: next(ticks, 40.0))
    remote = cross_project()
    graph = read_pipeline_graph(remote.adapter, item())
    assert len(remote.calls) == 1 and graph.nodes[0].kind == "unavailable"


def test_downstream_job_failure_and_hidden_trigger_do_not_become_deploy_failure():
    remote = cross_project()
    remote.graph[(42, 9201, None)]["data"]["project"]["pipeline"]["downstream"]["nodes"][0][
        "sourceJob"
    ] = None
    remote.graph[(99, 9701, None)]["data"]["project"]["pipeline"]["sourceJob"] = None
    remote.jobs[(99, 9701)] = [
        {**job(12001, 99, 9701), "status": "failed", "failure_reason": "script_failure"}
    ]
    graph = read_pipeline_graph(remote.adapter, item())
    child = graph.nodes[1]
    assert child.kind == "available" and child.pipeline.jobs[0].status.value == "failed"
    assert (
        child.deployments[0].record.status.value == "success"
        and graph.edges[0].source_job.kind == "unknown"
    )


def test_foreign_jobs_and_deployments_omitted_with_unknown_coverage():
    remote = cross_project()
    remote.jobs[(99, 9701)] = [job(12001, 42, 9701)]
    remote.deployments[99] = [deploy(project=42)]
    graph = read_pipeline_graph(remote.adapter, item())
    child = graph.nodes[1]
    assert child.kind == "available" and not child.pipeline.jobs and not child.deployments
    assert child.jobs_coverage.kind == child.deployments_coverage.kind == "unknown"


def test_same_sha_or_ref_without_deployable_identity_does_not_bind_deployment():
    remote = cross_project()
    remote.deployments[99] = [deploy(deployable=None), deploy(3002, pipeline=9999)]
    graph = read_pipeline_graph(remote.adapter, item())
    child = graph.nodes[1]
    assert (
        child.kind == "available"
        and not child.deployments
        and child.deployments_coverage.kind == "unknown"
    )


def test_hydration_error_is_redacted_and_does_not_erase_native_edges():
    remote = cross_project()
    remote.jobs[(99, 9701)] = AdapterError("transport", "SECRET")
    graph = read_pipeline_graph(remote.adapter, item())
    assert len(graph.edges) == 1
    assert (
        graph.nodes[1].jobs_coverage.kind == "unknown" and "SECRET" not in graph.model_dump_json()
    )


def test_root_version_pin_rejects_different_release():
    remote = cross_project(version="18.11.13-ee")
    with pytest.raises(AdapterError, match="pinned"):
        read_pipeline_graph(remote.adapter, item())
    assert len(remote.calls) == 1


def test_dangling_and_duplicate_graph_edges_and_wrong_root_sha_rejected():
    graph = read_pipeline_graph(cross_project().adapter, item())
    data = graph.model_dump()
    for change in (
        {"edges": [*data["edges"], *data["edges"]]},
        {"nodes": data["nodes"][:1]},
        {"roots": [{**data["roots"][0], "application_sha": B}]},
    ):
        with pytest.raises(ValidationError):
            PipelineGraph.model_validate({**data, **change})


def test_fixture_api_and_cli_share_graph_without_contaminating_work_item(
    service, key, capsys, monkeypatch
):
    from fastapi.testclient import TestClient

    from gspace.api import create_app
    from gspace.cli import main

    client = TestClient(create_app(service=service))
    before = client.get("/api/items/42/791").json()
    response = client.get("/api/items/42/791/pipeline-graph")
    assert response.status_code == 200
    graph = PipelineGraph.model_validate(response.json())
    assert graph.source == "fixture" and len(graph.edges) == 1 and len(graph.nodes) == 3
    assert graph.nodes[-1].reference.key.project.value == 99
    assert (
        client.get("/api/items/42/791").json() == before and "pipeline_graph" not in before["item"]
    )
    assert client.get("/api/items/404/791/pipeline-graph").status_code == 404
    assert client.get("/api/items/0/791/pipeline-graph").status_code == 422
    assert client.post("/api/items/42/791/pipeline-graph", json={}).status_code == 405
    config = service.config.preferences_path.parent / "demo.toml"
    config.write_text('mode="fixture"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n')
    monkeypatch.setattr(
        "sys.argv", ["gspace", "pipelines", "graph", "42:791", "-c", str(config), "-j", "-N"]
    )
    assert main() == 0
    captured = capsys.readouterr()
    assert not captured.err
    rendered = PipelineGraph.model_validate_json(captured.out)
    assert rendered.edges == graph.edges and rendered.roots == graph.roots
    monkeypatch.setattr(
        "sys.argv", ["gspace", "pipelines", "graph", "42:791", "-c", str(config), "-N", "-w", "80"]
    )
    assert main() == 0
    plain = capsys.readouterr()
    assert "Trigger edges do not prove" in plain.out and "\x1b" not in plain.out
    assert "42:9201" in plain.out and "99:97792" in plain.out
    assert "\\x0a" not in plain.out


def test_graph_page_validates_cursor_before_injected_runner():
    from gspace.models import PipelineKey

    remote = cross_project()
    with pytest.raises(ValueError, match="cursor"):
        remote.adapter.graph_page(
            remote.adapter.config.projects[0],
            PipelineKey(project=ProjectId(value=42), pipeline=item().pipelines[0].id),
            "bad\n",
        )
    assert not remote.calls


@pytest.mark.parametrize("field", ["id", "retried"])
def test_nullable_native_source_job_metadata_preserves_edges(field):
    remote = cross_project()
    for key in ((42, 9201, None), (99, 9701, None)):
        pipeline = remote.graph[key]["data"]["project"]["pipeline"]
        target = pipeline["downstream"]["nodes"][0] if key[0] == 42 else pipeline
        target["sourceJob"][field] = None
    graph = read_pipeline_graph(remote.adapter, item())
    assert len(graph.edges) == 1 and len(graph.nodes) == 2
    assert graph.edges[0].source_job.kind == "unknown" and graph.coverage.kind == "unknown"


def test_partial_graph_cannot_claim_complete_coverage():
    graph = read_pipeline_graph(cross_project(projects=(42,)).adapter, item())
    with pytest.raises(ValidationError, match="Complete graph coverage"):
        PipelineGraph.model_validate({**graph.model_dump(), "coverage": {"kind": "complete"}})
