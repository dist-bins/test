"""Fresh permission checks and single-use confirmations for synthetic lab writes.

Corporate profiles remain diagnostic/read-only. Supported means the documented
preconditions are supported by current GET evidence, not a guarantee of success.
"""

from __future__ import annotations

import fnmatch
import secrets
import threading
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Annotated, Literal, Self
from urllib.parse import quote

from pydantic import AwareDatetime, Field, TypeAdapter, field_validator, model_validator

from gspace.access import AccessError, ProfileTransport
from gspace.access_models import (
    AccessProfile,
    GlabProfile,
    PatProfile,
    Permission,
    PermissionDenied,
    PermissionScope,
    PermissionSupported,
    PermissionUnknown,
)
from gspace.glab import DTO, BranchDTO, JobDTO, MrDTO, PipelineDTO, TagDTO, UserDTO, VersionDTO
from gspace.models import JobId, Model, MrIid, PipelineId, ProjectId, Sha, Text, UserId


class ActionBase(Model, frozen=True):
    profile: Text
    project: ProjectId


class CreateDraftMR(ActionBase, frozen=True):
    kind: Literal["create_draft_mr"] = "create_draft_mr"
    source_branch: Text
    target_branch: Text
    expected_sha: Sha
    title: Annotated[str, Field(min_length=1, max_length=200)]
    description: Annotated[str, Field(max_length=10000)] = ""


class EditDraftMR(ActionBase, frozen=True):
    kind: Literal["edit_draft_mr"] = "edit_draft_mr"
    iid: MrIid
    expected_sha: Sha
    title: Annotated[str, Field(min_length=1, max_length=200)]
    description: Annotated[str, Field(max_length=10000)] = ""


class CreateTag(ActionBase, frozen=True):
    kind: Literal["create_tag"] = "create_tag"
    branch: Text
    expected_sha: Sha
    tag: Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")]


class RunPipeline(ActionBase, frozen=True):
    kind: Literal["run_pipeline"] = "run_pipeline"
    branch: Text
    expected_sha: Sha


class ChangePipeline(ActionBase, frozen=True):
    kind: Literal["change_pipeline"] = "change_pipeline"
    id: PipelineId
    expected_sha: Sha
    operation: Literal["retry", "cancel"]


class ChangeJob(ActionBase, frozen=True):
    kind: Literal["change_job"] = "change_job"
    id: JobId
    pipeline: PipelineId
    expected_sha: Sha
    operation: Literal["retry", "cancel", "play"]


type Action = Annotated[
    CreateDraftMR | EditDraftMR | CreateTag | RunPipeline | ChangePipeline | ChangeJob,
    Field(discriminator="kind"),
]


class MetadataDTO(DTO):
    version: Text
    enterprise: bool = Field(strict=True)


class ActionPipelineDTO(PipelineDTO):
    tag: bool = Field(strict=True)


class ProtectedTagRefDTO(TagDTO):
    protected: bool | None = Field(default=None, strict=True)


class AccessLevelDTO(DTO):
    access_level: int = Field(strict=True, ge=0)


class ProjectPermissionsDTO(DTO):
    project_access: AccessLevelDTO | None = None
    group_access: AccessLevelDTO | None = None


class ProjectPolicyDTO(DTO):
    id: int = Field(strict=True, gt=0)
    archived: bool | None = Field(default=None, strict=True)
    description: str | None = None
    permissions: ProjectPermissionsDTO | None = None
    merge_requests_enabled: bool | None = Field(default=None, strict=True)
    builds_access_level: Literal["enabled", "private", "disabled"] | None = None


class TokenDTO(DTO):
    user_id: int = Field(strict=True, gt=0)
    scopes: tuple[str, ...]
    active: bool = Field(strict=True)
    revoked: bool = Field(strict=True)
    expires_at: str | None = None


class ProtectedTagDTO(DTO):
    name: Text


class ProtectedBranchDTO(BranchDTO):
    protected: bool | None = Field(default=None, strict=True)


class ActionJobDTO(JobDTO):
    pipeline: PipelineDTO
    ref: Text


class PlanBase(Model, frozen=True):
    action: Action
    executed: Literal[False] = False
    summary: Text


class BlockedPlan(PlanBase, frozen=True):
    kind: Literal["blocked"] = "blocked"
    permission: Annotated[PermissionDenied | PermissionUnknown, Field(discriminator="kind")]
    confirmation: None = None
    expires_at: None = None


class ConfirmablePlan(PlanBase, frozen=True):
    kind: Literal["confirmable"] = "confirmable"
    permission: PermissionSupported
    confirmation: Annotated[str, Field(min_length=32, max_length=200)]
    expires_at: AwareDatetime


type ActionPlan = Annotated[BlockedPlan | ConfirmablePlan, Field(discriminator="kind")]


class ConfirmAction(Model, frozen=True):
    confirmation: Annotated[str, Field(min_length=32, max_length=200)]
    confirmed: Literal[True]

    @field_validator("confirmed", mode="before")
    @classmethod
    def explicit_true(cls, value: object) -> object:
        if value is not True:
            raise ValueError("Explicit boolean confirmation required")
        return value


class ActionResult(Model, frozen=True):
    executed: Literal[True] = True
    effect: Literal["accepted"] = "accepted"
    action: Text
    profile: Text
    host: Text
    project: ProjectId
    identity: UserId
    accepted_at: AwareDatetime
    message: Text = "GitLab accepted the request; inspect fresh resource/job/runtime evidence"


class ProfileSummary(Model, frozen=True):
    name: Text
    kind: Literal["glab", "pat"]
    host: Text
    projects: tuple[ProjectId, ...]
    write_enabled: bool


class ProbeComparisonRequest(Model, frozen=True):
    action: Action
    profiles: Annotated[tuple[Text, ...], Field(min_length=2, max_length=16)]

    @model_validator(mode="after")
    def unique_profiles(self) -> Self:
        if len(set(self.profiles)) != len(self.profiles):
            raise ValueError("Comparison profiles must be unique")
        if self.action.profile not in self.profiles:
            raise ValueError("Action profile must be included in comparison")
        return self


class ProbeComparisonRow(Model, frozen=True):
    profile: ProfileSummary
    project: ProjectId
    identity: UserId | None
    kind: Literal["allowed", "denied", "unknown"]
    reason: Text
    evidence: tuple[Text, ...]
    checked_at: AwareDatetime
    error_code: str | None = None

    @model_validator(mode="after")
    def established_identity(self) -> Self:
        if self.kind == "allowed" and (self.identity is None or self.error_code is not None):
            raise ValueError("Allowed preconditions require fresh identity and no error")
        return self


class ProbeComparison(Model, frozen=True):
    action: Action
    host: Text
    project: ProjectId
    rows: tuple[ProbeComparisonRow, ...]
    executed: Literal[False] = False
    checked_at: AwareDatetime
    deferred_actions: tuple[Literal["ready", "merge", "rebase"], ...] = ("ready", "merge", "rebase")

    @model_validator(mode="after")
    def same_scope(self) -> Self:
        if self.project != self.action.project or len({r.profile.name for r in self.rows}) != len(
            self.rows
        ):
            raise ValueError("Comparison action/project/profile identities differ")
        if any(
            r.profile.host.rstrip("/") != self.host.rstrip("/")
            or r.project != self.project
            or self.project not in r.profile.projects
            for r in self.rows
        ):
            raise ValueError("Comparison exceeds one host/project scope")
        return self


class DoctorBase(Model, frozen=True):
    profile: ProfileSummary
    api_version: str
    identity: UserId
    checked_at: AwareDatetime
    message: Text = "Read-only diagnostics; no permission was tested by writing"


class GlabDoctor(DoctorBase, frozen=True):
    kind: Literal["glab"] = "glab"
    executable: Text
    executable_version: Text
    write_transport: Literal["disabled", "unknown"]


class PatDoctor(DoctorBase, frozen=True):
    kind: Literal["pat"] = "pat"
    executable: None = None
    executable_version: None = None
    write_transport: Literal["isolated_lab_pat", "disabled"]


type DoctorReport = Annotated[GlabDoctor | PatDoctor, Field(discriminator="kind")]


class PlanRecord(Model, frozen=True):
    action: Action
    identity: UserId
    expires_at: AwareDatetime


class ActionService:
    def __init__(
        self,
        profiles: tuple[AccessProfile, ...],
        transport_factory: Callable[[AccessProfile], ProfileTransport] = ProfileTransport,
    ) -> None:
        self.profiles = profiles
        self._factory = transport_factory
        self._plans: dict[str, PlanRecord] = {}
        self._lock = threading.RLock()

    def profile(self, name: str) -> AccessProfile:
        profile = next((p for p in self.profiles if p.name == name), None)
        if profile is None:
            raise AccessError("scope", "Access profile is not configured")
        return profile

    def summaries(self) -> tuple[ProfileSummary, ...]:
        return tuple(
            ProfileSummary(
                name=p.name,
                kind=p.kind,
                host=p.host,
                projects=p.projects,
                write_enabled=p.write_enabled,
            )
            for p in self.profiles
        )

    def doctor(self, name: str) -> DoctorReport:
        profile = self.profile(name)
        transport = self._factory(profile)
        version = transport.version()
        api_version = transport.get("version", VersionDTO).version
        from gspace.gitlab_release import read_release

        try:
            read_release(api_version)
        except ValueError as error:
            raise AccessError(
                "compatibility", "Profile API version differs from pinned GitLab 18.11.12"
            ) from error
        user = transport.get("user", UserDTO)
        summary = ProfileSummary(
            name=profile.name,
            kind=profile.kind,
            host=profile.host,
            projects=profile.projects,
            write_enabled=profile.write_enabled,
        )
        if isinstance(profile, GlabProfile):
            if version is None:
                raise AccessError("launcher", "Glab launcher version is unavailable")
            return GlabDoctor(
                profile=summary,
                api_version=api_version,
                identity=UserId(value=user.id),
                checked_at=datetime.now(UTC),
                executable=transport.executable(),
                executable_version=version,
                write_transport="unknown" if profile.write_enabled else "disabled",
            )
        return PatDoctor(
            profile=summary,
            api_version=api_version,
            identity=UserId(value=user.id),
            checked_at=datetime.now(UTC),
            write_transport="isolated_lab_pat"
            if profile.write_enabled and profile.host.rstrip("/") == "http://127.0.0.1:8929"
            else "disabled",
        )

    def compare(self, request: ProbeComparisonRequest) -> ProbeComparison:
        # Validate every profile before any credential resolution or GET. Only
        # the profile selector changes; all resource/action fields stay exact.
        profiles = tuple(self.profile(name) for name in request.profiles)
        host = self.profile(request.action.profile).host.rstrip("/")
        if any(
            p.host.rstrip("/") != host or request.action.project not in p.projects for p in profiles
        ):
            raise AccessError("scope", "Comparison requires the same configured host and project")
        summaries = {p.name: p for p in self.summaries()}
        rows: list[ProbeComparisonRow] = []
        for profile in profiles:
            action = TypeAdapter[Action](Action).validate_python(
                {**request.action.model_dump(), "profile": profile.name}
            )
            try:
                permission = self.probe(action)
                rows.append(
                    ProbeComparisonRow(
                        profile=summaries[profile.name],
                        project=request.action.project,
                        identity=permission.scope.identity,
                        kind="allowed" if permission.kind == "supported" else permission.kind,
                        reason=permission.reason,
                        evidence=permission.evidence,
                        checked_at=permission.checked_at,
                    )
                )
            except AccessError as error:
                # Never expose transport bodies, secret resolver exceptions or
                # arbitrary exception text; one failed profile does not mask peers.
                code = (
                    error.code
                    if error.code
                    in (
                        "scope",
                        "compatibility",
                        "transport",
                        "validation",
                        "limit",
                        "unavailable",
                        "launcher",
                        "authentication",
                        "profile",
                        "permission",
                        "missing_secret",
                        "remote",
                        "denied",
                    )
                    else "transport"
                )
                rows.append(
                    ProbeComparisonRow(
                        profile=summaries[profile.name],
                        project=request.action.project,
                        identity=None,
                        kind="denied" if error.code == "denied" else "unknown",
                        reason="Fresh permission evidence is unavailable",
                        evidence=(
                            "GET-only comparison; no permission established for this profile",
                        ),
                        checked_at=datetime.now(UTC),
                        error_code=code,
                    )
                )
        return ProbeComparison(
            action=request.action,
            host=host,
            project=request.action.project,
            rows=tuple(rows),
            checked_at=datetime.now(UTC),
        )

    def probe(self, action: Action) -> Permission:
        profile = self.profile(action.profile)
        if action.project not in profile.projects:
            raise AccessError("scope", "Action project exceeds configured profile scope")
        transport = self._factory(profile)
        version = transport.get("version", VersionDTO).version
        from gspace.gitlab_release import read_release

        try:
            read_release(version)
        except ValueError as error:
            raise AccessError(
                "compatibility", "Action API version differs from pinned GitLab 18.11.12"
            ) from error
        user = transport.get("user", UserDTO)
        scope = PermissionScope(
            profile=profile.name,
            host=profile.host,
            project=action.project,
            identity=UserId(value=user.id),
        )
        now = datetime.now(UTC)
        evidence = ["Exact GitLab 18.11.12 version", "Fresh authenticated identity GET"]

        def answer(kind: Literal["supported", "denied", "unknown"], reason: str) -> Permission:
            data = dict(scope=scope, reason=reason, evidence=tuple(evidence), checked_at=now)
            if kind == "supported":
                return PermissionSupported.model_validate(data)
            if kind == "denied":
                return PermissionDenied.model_validate(data)
            return PermissionUnknown.model_validate(data)

        if not profile.write_enabled:
            return answer("denied", "This access profile is read-only by operator configuration")
        if not isinstance(profile, PatProfile):
            return answer(
                "unknown", "Glab launcher cannot establish token scopes or guarded write transport"
            )
        if profile.host.rstrip("/") != "http://127.0.0.1:8929":
            return answer(
                "denied", "This iteration permits writes only to the isolated synthetic lab"
            )
        try:
            token = transport.get("personal_access_tokens/self", TokenDTO)
            if (
                token.user_id != user.id
                or not token.active
                or token.revoked
                or "api" not in token.scopes
            ):
                return answer(
                    "denied", "Current token identity, active state or API scope is insufficient"
                )
            evidence.append("PAT self GET: active, non-revoked, api scope, matching user")
            metadata = transport.get("metadata", MetadataDTO)
            if metadata.version != "18.11.12" or metadata.enterprise:
                return answer(
                    "unknown",
                    "CE lab required; enterprise protection and approval policy is unverified",
                )
            evidence.append(
                "Exact CE metadata GET; enterprise environment protections are unavailable"
            )
            project = transport.get(f"projects/{action.project.value}", ProjectPolicyDTO)
            if project.id != action.project.value:
                return answer("denied", "Project response identity differs from requested scope")
            if project.archived is True:
                return answer("denied", "Project is archived")
            if project.archived is None or project.permissions is None:
                return answer("unknown", "Project archival or membership evidence is missing")
            levels = [
                p.access_level
                for p in (project.permissions.project_access, project.permissions.group_access)
                if p
            ]
            if not levels or max(levels) < 40:
                return answer(
                    "denied",
                    "The conservative lab policy requires current Maintainer or Owner membership",
                )
            if project.description != "GSpace isolated integration lab v1":
                return answer("denied", "Project does not carry the isolated lab ownership marker")
            evidence.append(
                "Current unarchived marker-owned project with Maintainer/Owner membership"
            )
            if isinstance(action, (CreateDraftMR, EditDraftMR)):
                if project.merge_requests_enabled is False:
                    return answer("denied", "Project disables merge requests")
                if project.merge_requests_enabled is None:
                    return answer("unknown", "Merge request project policy is missing")
            else:
                if project.builds_access_level == "disabled" and not isinstance(action, CreateTag):
                    return answer("denied", "Project disables CI pipelines")
                if project.builds_access_level is None and not isinstance(action, CreateTag):
                    return answer("unknown", "CI project policy is missing")
            tag_ref = False
            if isinstance(action, EditDraftMR):
                mr = transport.get(
                    f"projects/{action.project.value}/merge_requests/{action.iid.value}", MrDTO
                )
                if (
                    mr.iid != action.iid.value
                    or mr.project_id != action.project.value
                    or mr.source_project_id != action.project.value
                    or mr.sha != action.expected_sha
                ):
                    return answer("denied", "MR identity/source project/SHA changed")
                if not mr.draft or mr.state != "opened":
                    return answer("denied", "Only open draft MRs may be edited by this action")
                branch = mr.source_branch
            elif isinstance(action, (ChangeJob, ChangePipeline)):
                pipeline_id = action.pipeline if isinstance(action, ChangeJob) else action.id
                pipeline = transport.get(
                    f"projects/{action.project.value}/pipelines/{pipeline_id.value}",
                    ActionPipelineDTO,
                )
                if pipeline.id != pipeline_id.value or pipeline.sha != action.expected_sha:
                    return answer("denied", "Pipeline identity/SHA changed")
                branch = pipeline.ref
                tag_ref = pipeline.tag
                if isinstance(action, ChangeJob):
                    job = transport.get(
                        f"projects/{action.project.value}/jobs/{action.id.value}", ActionJobDTO
                    )
                    if (
                        job.id != action.id.value
                        or job.pipeline.id != pipeline_id.value
                        or job.pipeline.sha != action.expected_sha
                        or job.ref != pipeline.ref
                    ):
                        return answer(
                            "denied", "Job no longer belongs to the expected pipeline/ref/SHA"
                        )
                    allowed = {
                        "play": ("manual",),
                        "retry": ("failed", "canceled"),
                        "cancel": ("running", "pending", "created"),
                    }
                    if job.status not in allowed[action.operation] or job.retried:
                        return answer("denied", "Job state does not permit the chosen operation")
                elif action.operation == "retry" and pipeline.status not in ("failed", "canceled"):
                    return answer("denied", "Pipeline is not failed or canceled")
                elif action.operation == "cancel" and pipeline.status not in (
                    "running",
                    "pending",
                    "created",
                ):
                    return answer("denied", "Pipeline is not active")
            else:
                branch = (
                    action.source_branch if isinstance(action, CreateDraftMR) else action.branch
                )
            ref_path = f"projects/{action.project.value}/repository/"
            if tag_ref:
                checked_tag = transport.get(
                    ref_path + f"tags/{quote(branch, safe='')}", ProtectedTagRefDTO
                )
                if checked_tag.name != branch or checked_tag.commit.id != action.expected_sha:
                    return answer("denied", "Tag identity/SHA changed")
                protected = checked_tag.protected
            else:
                checked_branch = transport.get(
                    ref_path + f"branches/{quote(branch, safe='')}", ProtectedBranchDTO
                )
                if checked_branch.name != branch or checked_branch.commit.id != action.expected_sha:
                    return answer("denied", "Branch identity/SHA differs from preview")
                protected = checked_branch.protected
            if protected is True:
                return answer("denied", "Protected source refs are outside the write scope")
            if protected is None:
                return answer("unknown", "Source ref protection evidence is missing")
            evidence.append("Unprotected exact source ref and expected SHA")
            if isinstance(action, CreateDraftMR):
                target = transport.get(
                    (
                        f"projects/{action.project.value}/repository/branches/"
                        f"{quote(action.target_branch, safe='')}"
                    ),
                    BranchDTO,
                )
                if (
                    target.name != action.target_branch
                    or action.source_branch == action.target_branch
                ):
                    return answer("denied", "Invalid or same source/target branch")
            if isinstance(action, CreateTag):
                rules = transport.pages(
                    f"projects/{action.project.value}/protected_tags", ProtectedTagDTO
                )
                if any(fnmatch.fnmatchcase(action.tag, rule.name) for rule in rules):
                    return answer("denied", "Tag matches a protected tag policy")
                evidence.append("Complete protected-tag policy GET; no matching protection")
            return answer(
                "supported",
                "GET evidence supports this isolated lab operation; GitLab remains authoritative",
            )
        except AccessError as error:
            return answer(
                "denied" if error.code == "denied" else "unknown",
                "Permission read was denied/revoked"
                if error.code == "denied"
                else "Permission evidence is unavailable; no write probe or retry",
            )

    def preview(self, action: Action) -> ActionPlan:
        permission = self.probe(action)
        confirmation = None
        expires = None
        if isinstance(permission, PermissionSupported):
            confirmation = secrets.token_urlsafe(32)
            expires = datetime.now(UTC) + timedelta(seconds=90)
            with self._lock:
                self._plans = {
                    k: v for k, v in self._plans.items() if v.expires_at > datetime.now(UTC)
                }
                if len(self._plans) >= 100:
                    raise AccessError("limit", "Too many pending confirmations")
                self._plans[confirmation] = PlanRecord(
                    action=action, identity=permission.scope.identity, expires_at=expires
                )
            return ConfirmablePlan(
                action=action,
                permission=permission,
                confirmation=confirmation,
                expires_at=expires,
                summary=f"Preview {action.kind} in project {action.project.value}",
            )
        return BlockedPlan(
            action=action,
            permission=permission,
            summary=f"Blocked preview {action.kind} in project {action.project.value}",
        )

    def execute(self, body: ConfirmAction) -> ActionResult:
        with self._lock:
            record = self._plans.pop(body.confirmation, None)
        if record is None or record.expires_at <= datetime.now(UTC):
            raise AccessError(
                "confirmation", "Confirmation is missing, used or expired; prepare a new preview"
            )
        permission = self.probe(record.action)  # no permission cache can authorize a write
        if (
            not isinstance(permission, PermissionSupported)
            or permission.scope.identity != record.identity
        ):
            raise AccessError(
                "denied", "Current permission/identity/resource changed; confirmation consumed"
            )
        action = record.action
        base = f"projects/{action.project.value}"
        match action:
            case CreateDraftMR():
                method, path = "POST", base + "/merge_requests"
                payload: dict[str, object] = {
                    "source_branch": action.source_branch,
                    "target_branch": action.target_branch,
                    "title": "Draft: " + action.title.removeprefix("Draft: "),
                    "description": action.description,
                }
            case EditDraftMR():
                method, path = "PUT", base + f"/merge_requests/{action.iid.value}"
                payload = {
                    "title": "Draft: " + action.title.removeprefix("Draft: "),
                    "description": action.description,
                }
            case CreateTag():
                method, path = "POST", base + "/repository/tags"
                payload = {"tag_name": action.tag, "ref": action.expected_sha}
            case RunPipeline():
                method, path = "POST", base + "/pipelines"
                payload = {"ref": action.branch}
            case ChangePipeline():
                method, path = "POST", base + f"/pipelines/{action.id.value}/{action.operation}"
                payload = {}
            case ChangeJob():
                method, path = "POST", base + f"/jobs/{action.id.value}/{action.operation}"
                payload = {}
        self._factory(self.profile(action.profile)).request(method, path, body=payload)
        return ActionResult(
            action=action.kind,
            profile=action.profile,
            host=permission.scope.host,
            project=action.project,
            identity=permission.scope.identity,
            accepted_at=datetime.now(UTC),
        )
