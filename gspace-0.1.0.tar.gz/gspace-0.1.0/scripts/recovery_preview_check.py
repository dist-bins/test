"""Verify only an owned frozen fixture preview; no credentials or real effects."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    state_path = args.state.resolve()
    output = args.output.resolve()
    for path in (state_path, output):
        if not path.is_relative_to(ROOT / "output/verification"):
            parser.error("Use owned verification paths")
    state = json.loads(state_path.read_text())
    base = state["base"]
    origin = urlsplit(base)
    assert origin.scheme == "http" and origin.hostname == "127.0.0.1" and origin.port
    assert not origin.username and not origin.password and origin.path == ""
    assert state["mode"] == "fixture" and state["real_credentials_used"] is False
    assert state["original_operator_files_used"] is False
    with httpx.Client(base_url=base, timeout=5, trust_env=False, follow_redirects=False) as client:
        for name, digest in state["assets"].items():
            assert name in {
                "index.html",
                "app.js",
                "theme.js",
                "styles.css",
                "icon.svg",
                "gspace-wolf.svg",
                "gspace-wolf-gray.svg",
            }
            response = client.get("/assets/" + name)
            response.raise_for_status()
            assert len(response.content) < 2000000
            assert hashlib.sha256(response.content).hexdigest() == digest, name
        dashboard = client.get("/api/dashboard")
        dashboard.raise_for_status()
        assert len(dashboard.json()["views"]) == 4
        assert client.post("/api/actions/execute", json={}).status_code == 403
    errors = []
    outside = []
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        for theme, width in (("dark", 1600), ("light", 390)):
            context = browser.new_context(
                viewport={"width": width, "height": 1100 if width == 1600 else 844},
                service_workers="block",
            )
            page = context.new_page()
            page.on("pageerror", lambda error: errors.append(str(error)))

            def guard(route, _request):
                if route.request.url.startswith(base + "/"):
                    route.continue_()
                else:
                    outside.append(route.request.url)
                    route.abort()

            context.route("**/*", guard)
            page.goto(base + "/#/work")
            expect(page.get_by_role("button", name="Overview", exact=True)).to_have_attribute(
                "aria-pressed", "true"
            )
            page.locator('[data-fk="theme"]').click()
            page.locator(f'[data-fk="ap-th-{theme}"]').click()
            page.keyboard.press("Escape")
            expect(page.locator("main")).to_contain_text("Pipeline #9201 failed")
            assert page.evaluate("document.documentElement.scrollWidth") <= width + 1
            if width == 1600:
                expect(page.locator(".flowt")).to_be_visible()
                assert page.locator(".flowt thead th").count() >= 5
            page.screenshot(
                path=str(output.with_name(f"{output.stem}-{theme}-{width}.png")),
                animations="disabled",
            )
            context.close()
        browser.close()
    assert not errors and not outside
    record = {
        "purpose": "Actual corrected frozen preview hashes, API and desktop/mobile smoke",
        "pid": state["pid"],
        "url": state["url"],
        "mode": state["mode"],
        "served_asset_hashes_match": True,
        "dashboard_views": 4,
        "overview_fresh_default": True,
        "action_execution_status": 403,
        "browser_errors": errors,
        "outside": outside,
    }
    output.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
