"""Copy exact publisher license texts for dependencies embedded in browser assets."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGES = ("ajv", "ajv-formats")


def read_public(path: Path, root: Path) -> bytes:
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Publisher notice escapes the owned project")
    for parent in (path, *path.parents):
        if parent == root:
            break
        if parent.is_symlink():
            raise ValueError("Publisher notice inputs cannot be linked")
    if not path.is_file() or path.stat().st_size > 1_000_000:
        raise ValueError("Publisher notice input is missing or oversized")
    return path.read_bytes()


def generate(root: Path) -> dict[str, object]:
    frontend = root / "frontend-new"
    lock = json.loads(read_public(frontend / "package-lock.json", root))
    records = []
    payloads: dict[str, bytes] = {}
    for name in PACKAGES:
        package = frontend / "node_modules" / name
        metadata = json.loads(read_public(package / "package.json", root))
        locked = lock["packages"]["node_modules/" + name]
        if metadata.get("name") != name or metadata.get("version") != locked["version"]:
            raise ValueError("Bundled publisher identity differs from the frontend lock")
        if metadata.get("license") != "MIT" or locked.get("license") != "MIT":
            raise ValueError("Bundled publisher license declaration needs explicit review")
        body = read_public(package / "LICENSE", root)
        text = body.decode("utf-8")
        if "Copyright" not in text or "Permission is hereby granted" not in text:
            raise ValueError("Bundled publisher license text is missing its actual grant")
        filename = name + ".LICENSE"
        payloads[filename] = body
        records.append(
            {
                "name": name,
                "version": metadata["version"],
                "license": "MIT",
                "file": filename,
                "sha256": hashlib.sha256(body).hexdigest(),
                "publisher_source": f"frontend-new/node_modules/{name}/LICENSE",
                "scope": "browser_bundled",
            }
        )
    destination = root / "src/gspace/licenses"
    for parent in (destination, *destination.parents):
        if parent == root:
            break
        if parent.is_symlink():
            raise ValueError("Bundled notice destination cannot be linked")
    destination.mkdir(parents=True, exist_ok=True)
    for name, body in payloads.items():
        target = destination / name
        if target.is_symlink():
            raise ValueError("Bundled notice destination cannot be linked")
        target.write_bytes(body)
    report = {
        "purpose": (
            "Exact third-party texts for browser-bundled dependencies; no first-party license grant"
        ),
        "components": records,
    }
    manifest = destination / "manifest.json"
    if manifest.is_symlink():
        raise ValueError("Bundled notice destination cannot be linked")
    manifest.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return report


if __name__ == "__main__":
    result = generate(ROOT)
    print(json.dumps({"packaged_bundled_notices": len(result["components"])}))
