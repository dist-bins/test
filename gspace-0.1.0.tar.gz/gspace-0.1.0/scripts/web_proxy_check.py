"""Compiled UI journeys behind owned prefix-stripping and prefix-preserving loopback proxies."""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

import httpx
from playwright.sync_api import expect, sync_playwright
from recovery_fixture import ROOT, recovery_fixture

from gspace.web_config import WebConfig

PREFIX = "/workspace/synthetic/proxy/8876"


def main() -> None:
    output = ROOT / "output/verification/web-proxy-20261020"
    output.mkdir(parents=True, exist_ok=True)
    checks: list[dict[str, object]] = []
    errors: list[str] = []
    outside: list[str] = []
    failed: list[str] = []
    escaped: list[str] = []
    calls: list[dict[str, str]] = []
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        for stripped in (True, False):

            class Proxy(BaseHTTPRequestHandler):
                strip_prefix = stripped
                target = ""

                def handle_request(self) -> None:
                    if not (self.path == PREFIX or self.path.startswith(PREFIX + "/")):
                        escaped.append(self.path)
                        self.send_error(404)
                        return
                    path = self.path[len(PREFIX) :] or "/" if self.strip_prefix else self.path
                    headers = {
                        name: value
                        for name, value in self.headers.items()
                        if name.lower() in ("host", "origin", "accept", "content-type")
                    }
                    length = int(self.headers.get("Content-Length", "0"))
                    if not 0 <= length <= 1_000_000:
                        self.send_error(413)
                        return
                    body = self.rfile.read(length) if length else b""
                    calls.append({"method": self.command, "path": self.path})
                    with httpx.Client(
                        trust_env=False, timeout=10, follow_redirects=False
                    ) as client:
                        response = client.request(
                            self.command, self.target + path, headers=headers, content=body
                        )
                    self.send_response(response.status_code)
                    for name, value in response.headers.items():
                        if name.lower() not in (
                            "content-length",
                            "transfer-encoding",
                            "connection",
                        ):
                            self.send_header(name, value)
                    self.send_header("Content-Length", str(len(response.content)))
                    self.end_headers()
                    self.wfile.write(response.content)

                do_GET = handle_request
                do_POST = handle_request

                def log_message(self, _format: str, *args: object) -> None:
                    pass

            proxy = ThreadingHTTPServer(("127.0.0.1", 0), Proxy)
            origin = f"http://127.0.0.1:{proxy.server_port}"
            public = origin + PREFIX
            try:
                with recovery_fixture(web=WebConfig(public_url=public)) as fixture:
                    Proxy.target = fixture.base
                    worker = threading.Thread(target=proxy.serve_forever, daemon=True)
                    worker.start()
                    try:
                        for theme, width in (("light", 1600), ("dark", 390)):
                            context = browser.new_context(
                                viewport={"width": width, "height": 1000 if width == 1600 else 844},
                                service_workers="block",
                            )
                            context.add_init_script(
                                "localStorage.setItem('gspace.theme', " + json.dumps(theme) + ")"
                            )
                            page = context.new_page()
                            page.on("pageerror", lambda error: errors.append(str(error)))
                            page.on(
                                "response",
                                lambda response: (
                                    failed.append(f"{response.status} {response.url}")
                                    if response.status >= 400
                                    else None
                                ),
                            )

                            def guard(route, _request, *, origin=origin):
                                url = urlsplit(route.request.url)
                                if url.scheme == "http" and url.netloc == urlsplit(origin).netloc:
                                    route.continue_()
                                else:
                                    outside.append(route.request.url)
                                    route.abort()

                            context.route("**/*", guard)
                            # No final slash: server metadata must still give exact URLs.
                            page.goto(public + "#/work")
                            expect(page).to_have_title("GSpace")
                            expect(page.locator("main")).to_contain_text("Preserve passenger")
                            expect(page.locator("html")).to_have_attribute("data-theme", theme)
                            assert (
                                page.evaluate("document.documentElement.scrollWidth") <= width + 1
                            )
                            for image in page.locator("img[src]").all():
                                assert image.get_attribute("src").startswith(PREFIX + "/")
                            page.goto(public + "/#/settings")
                            expect(page.locator("main")).to_contain_text("In use locally")
                            branch = page.locator('[data-fk="set-branch"]')
                            value = "proxy-{iid}" if width == 1600 else "issue-{iid}"
                            branch.fill(value)
                            with page.expect_response(
                                lambda response, public=public: (
                                    response.url == public + "/api/settings"
                                    and response.request.method == "POST"
                                )
                            ) as saved:
                                page.locator('[data-fk="set-save"]').click()
                            assert saved.value.status == 200
                            page.reload()
                            expect(branch).to_have_value(value)
                            assert fixture.service.config.branch_template == value
                            # Same-origin avatar bytes use the public prefixed route as well.
                            avatar = page.request.get(public + "/api/projects/42/avatar")
                            assert avatar.status == 200
                            assert (
                                page.request.get(public + "/api/capabilities").json()[
                                    "remote_mutations"
                                ]
                                is False
                            )
                            page.goto(public + "/#/work")
                            page.get_by_role("button", name="Detailed", exact=True).click()
                            expect(page.locator(".mx").first).to_be_visible()
                            page.get_by_role("button", name="Overview", exact=True).click()
                            expect(page.locator("main")).to_contain_text("Preserve passenger")
                            name = f"{'stripped' if stripped else 'preserved'}-{theme}-{width}"
                            page.screenshot(path=str(output / f"{name}.png"))
                            checks.append({"case": name, "page": page.url, "settings_save": 200})
                            context.close()
                    finally:
                        proxy.shutdown()
                        worker.join(timeout=5)
            finally:
                proxy.server_close()
        browser.close()
    assert not errors and not outside and not failed and not escaped
    report = {
        "purpose": "Actual compiled browser/proxy/settings journeys; temporary synthetic state",
        "browser_plugin": "Browser plugin not available; existing Playwright/Chrome runner used",
        "checks": checks,
        "requests": calls,
        "browser_errors": errors,
        "outside_requests": outside,
        "http_errors": failed,
        "escaped_prefix": escaped,
        "real_devpod": "not exercised",
        "corporate_requests": False,
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": len(checks), "requests": len(calls), "output": str(output)}))


if __name__ == "__main__":
    main()
