"""Inspect finite text corrections on isolated compiled fixtures, never operator state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]
TEXT_BOUNDS = """e=>{
 const box=e.getBoundingClientRect(), style=getComputedStyle(e), rects=[];
 for(const n of e.childNodes) if(n.nodeType===Node.TEXT_NODE && n.textContent.trim()) {
  const r=document.createRange();r.selectNodeContents(n);
  for(const x of r.getClientRects())
   rects.push({left:x.left,right:x.right,top:x.top,bottom:x.bottom});
 }
 return {box:{left:box.left,right:box.right,top:box.top,bottom:box.bottom},
 rects,whiteSpace:style.whiteSpace,clamp:style.webkitLineClamp};
}"""


def contained(measurement):
    box = measurement["box"]
    assert measurement["rects"], measurement
    assert all(
        rect["left"] >= box["left"] - 0.75
        and rect["right"] <= box["right"] + 0.75
        and rect["top"] >= box["top"] - 0.75
        and rect["bottom"] <= box["bottom"] + 0.75
        for rect in measurement["rects"]
    ), measurement


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/finite-text-browser-20261007"
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    checks, measurements, outside, errors = [], [], [], []
    with fixture_server(args.assets.resolve()) as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(service_workers="block")

        def guard(route):
            url = urlsplit(route.request.url)
            if url.scheme == "http" and url.hostname == "127.0.0.1" and url.port == port:
                route.continue_()
            else:
                outside.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.set_default_timeout(5000)
        page.on("pageerror", lambda error: errors.append(str(error)))

        def go(route):
            page.goto(base + "/#/" + route)
            page.wait_for_timeout(200)
            page.wait_for_load_state("networkidle")

        def capture(name):
            page.screenshot(path=str(args.output / (name + ".png")))

        def check(name, operation):
            try:
                operation()
                checks.append({"name": name, "passed": True})
            except Exception as error:
                checks.append({"name": name, "passed": False, "error": str(error)[:2400]})

        go("work")
        for iid in (791, 792, 793, 794):
            revision = page.request.get(base + "/api/preferences").json()["revision"]
            response = page.request.post(
                base + "/api/preferences",
                data={
                    "operation": "select",
                    "key": {"project": {"value": 42}, "issue": {"value": iid}},
                    "enabled": True,
                    "revision": revision,
                },
            )
            assert response.status == 200
        page.evaluate("localStorage.setItem('gspace.mode','visual')")

        def run_case(theme, width):
            height = 1100 if width > 500 else 844
            page.set_viewport_size({"width": width, "height": height})
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            page.reload()
            page.wait_for_load_state("networkidle")
            suffix = f"{theme}-{width}"
            for route in ("work", "compare"):

                def flow(route=route):
                    go(route)
                    expect(page.locator('[data-fk="mode-visual"]')).to_have_attribute(
                        "aria-pressed", "true"
                    )
                    if width > 500:
                        cells = page.locator(".flowt tr.fr-env").last.locator("td")
                        expect(cells).to_have_count(4)
                        for index in range(4):
                            cell = cells.nth(index)
                            expect(cell.locator(".fl-fact")).to_have_count(4)
                            assert cell.locator(".fl-fact-l").all_text_contents() == [
                                "Deploy record",
                                "Deploy job",
                                "Runtime",
                                "App test",
                            ]
                            value = cell.locator(".fl-fact-v").nth(1)
                            expect(value).to_have_text(
                                "deploy-preprod success" if index == 2 else "deploy-preprod manual"
                            )
                            expect(value.locator(".fl-dot")).to_be_visible()
                            bounds = value.evaluate(TEXT_BOUNDS)
                            contained(bounds)
                            measurements.append(
                                {"view": route, "theme": theme, "width": width, "fact": bounds}
                            )
                    else:
                        strips = page.locator(".strips > .strip")
                        expect(strips).to_have_count(4)
                        for index in range(4):
                            expect(strips.nth(index).locator(".sp-f")).to_have_count(8)
                            expect(strips.nth(index).locator(".sp-dot")).to_have_count(8)
                    capture(f"{route}-{suffix}")

                check(f"{route} visible status/dot/four independent facts {suffix}", flow)

            def item_fact():
                go("item/42/793")
                step = page.locator(".flow-lane .lane-step").filter(
                    has=page.locator(".lane-label", has_text="Preprod")
                )
                expect(step.locator(".fl-fact")).to_have_count(4)
                value = step.locator(".fl-fact-v").nth(1)
                expect(value).to_have_text("deploy-preprod success")
                expect(value.locator(".fl-dot")).to_be_visible()
                contained(value.evaluate(TEXT_BOUNDS))

            check(f"shared item environment fact wraps without losing evidence {suffix}", item_fact)
            go("work")
            anchor = page.locator(".flowt" if width > 500 else ".strips")
            before = anchor.bounding_box()
            failures = []
            reason = {"detail": "502 Bad Gateway"}

            def fail_refresh(route):
                failures.append(route.request.url)
                route.fulfill(status=502, content_type="application/json", body=json.dumps(reason))

            page.route(base + "/api/refresh", fail_refresh)

            def refresh(button):
                with page.expect_response(base + "/api/refresh"):
                    button.click()
                expect(page.locator('[data-fk="refresh"]')).to_be_enabled()

            def repeated_failure():
                for _ in range(10):
                    refresh(page.locator('[data-fk="refresh"]'))
                expect(page.locator("#tray .prob")).to_have_count(1)
                expect(page.locator("#tray .prob-count")).to_have_text("×10")
                detail = page.locator("#tray .prob-detail")
                expect(detail).to_have_text(
                    "GitLab adapter error: 502 Bad Gateway. The previous snapshot is still shown."
                )
                bounds = detail.evaluate(TEXT_BOUNDS)
                assert bounds["clamp"] == ("3" if width > 500 else "2")
                if width > 500:
                    contained(bounds)
                tray = page.locator("#tray").bounding_box()
                after = anchor.bounding_box()
                assert before and after and abs(after["y"] - before["y"]) < 0.75, (before, after)
                assert tray and tray["x"] >= 0 and tray["x"] + tray["width"] <= width + 0.75
                if width < 500:
                    assert tray["height"] <= height / 4
                page.wait_for_timeout(250)
                assert len(failures) == 10  # no background retry
                expect(page.get_by_role("button", name="Retry: Refresh failed")).to_be_enabled()
                measurements.append(
                    {
                        "theme": theme,
                        "width": width,
                        "tray": tray,
                        "collapsed_text": bounds,
                        "failures": len(failures),
                    }
                )
                capture(f"refresh-errors-{suffix}")

            check(
                f"ten errors deduplicate/punctuate/retain snapshot/no-shift/no-auto-retry {suffix}",
                repeated_failure,
            )

            def punctuation():
                reason["detail"] = "Synthetic unavailable source."
                refresh(page.get_by_role("button", name="Retry: Refresh failed"))
                expect(page.locator("#tray .prob")).to_have_count(1)
                expect(page.locator("#tray .prob-count")).to_have_count(0)
                expect(page.locator("#tray .prob-detail")).to_have_text(
                    "GitLab adapter error: Synthetic unavailable source. "
                    "The previous snapshot is still shown."
                )
                assert len(failures) == 11

            check(f"explicit Retry preserves existing punctuation {suffix}", punctuation)
            page.unroute(base + "/api/refresh", fail_refresh)

            def recovery():
                refresh(page.get_by_role("button", name="Retry: Refresh failed"))
                for _ in range(9):
                    refresh(page.locator('[data-fk="refresh"]'))
                expect(page.locator("#tray .prob")).to_have_count(0)
                page.wait_for_timeout(200)
                page.wait_for_load_state("networkidle")
                expect(anchor).to_be_visible()
                after = anchor.bounding_box()
                assert before and after and abs(after["y"] - before["y"]) < 0.75, (before, after)
                capture(f"refresh-recovery-{suffix}")

            check(
                f"explicit recovery and ten successes clear errors without accumulation {suffix}",
                recovery,
            )

        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            run_case(theme, width)
        browser.close()
    failed = sum(not row["passed"] for row in checks) + len(errors) + len(outside)
    (args.output / "report.json").write_text(
        json.dumps(
            {
                "purpose": __doc__,
                "checks": checks,
                "measurements": measurements,
                "outside": outside,
                "js_errors": errors,
                "failed": failed,
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps({"checks": len(checks), "failed": failed}))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
