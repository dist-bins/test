"""Explicitly approved isolated GitLab lab operations; never a corporate client.

All endpoints are fixed loopback. Tokens are prompted, never read from auth files,
never printed, and never passed in argv. Mutation commands require explicit flags.
The module's import performs no I/O; unit tests use injected HTTP transports.
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import quote

import httpx
import tomli_w

from gspace.config import AppConfig
from gspace.glab import GlabAdapter
from gspace.models import IssueIid, ProjectId, WorkKey

ROOT = Path(__file__).resolve().parents[1]
COMPOSE = ROOT / "integration/compose.yaml"
STATE = ROOT / ".state/lab"
ORIGIN = "http://127.0.0.1:8929"
MARKER = "GSpace isolated integration lab v1"
GIB = 1024**3
MIN_FREE = 60 * GIB
MIN_RAM = 10 * GIB
COMPOSE_ARGV = ["docker", "compose", "-f", str(COMPOSE)]


class LabError(Exception):
    """Safe operational error without remote response bodies or secrets."""


def approved(value: bool, action: str) -> None:
    if not value:
        raise LabError(f"Explicit approval required before {action}")


@contextmanager
def docker_environment() -> Iterator[dict[str, str]]:
    # Public images need no credential helper. Keep the operator's context,
    # certificates and credential configuration outside this isolated client.
    with tempfile.TemporaryDirectory(prefix="gspace-docker-public-") as temporary:
        directory = Path(temporary)
        # A nonempty map with an empty anonymous Hub record prevents Docker's
        # platform-default credential-helper autodetection. No credential exists.
        configuration: dict[str, object] = {"auths": {"https://index.docker.io/v1/": {}}}
        plugin_directories = (
            Path("/opt/homebrew/lib/docker/cli-plugins"),
            Path("/Applications/OrbStack.app/Contents/MacOS/xbin"),
        )
        plugins = [str(path) for path in plugin_directories if (path / "docker-compose").is_file()]
        if plugins:
            configuration["cliPluginsExtraDirs"] = plugins
        config_file = directory / "config.json"
        config_file.write_text(json.dumps(configuration))
        config_file.chmod(0o600)
        environment = {
            key: value
            for key, value in os.environ.items()
            if key
            not in (
                "DOCKER_CONTEXT",
                "DOCKER_CERT_PATH",
                "DOCKER_TLS_VERIFY",
                "DOCKER_TLS",
                "DOCKER_AUTH_CONFIG",
            )
        }
        environment.update(DOCKER_CONFIG=str(directory), DOCKER_HOST="unix:///var/run/docker.sock")
        yield environment


def docker_run(
    argv: list[str], *, confidential_input: str | None = None, timeout: int = 900
) -> subprocess.CompletedProcess[str]:
    with docker_environment() as environment:
        return subprocess.run(
            argv,
            input=confidential_input,
            env=environment,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )


def compose(*args: str, confidential_input: str | None = None) -> str:
    result = docker_run(
        [*COMPOSE_ARGV, *args],
        confidential_input=confidential_input,
    )
    if result.returncode:
        raise LabError("Docker Compose operation failed; inspect the dedicated lab manually")
    return result.stdout


def budget(free_bytes: int, memory_bytes: int, cpus: int) -> None:
    if free_bytes < MIN_FREE:
        raise LabError("Lab requires at least 60 GiB free host storage; no cleanup is automatic")
    if memory_bytes < MIN_RAM or cpus < 5:
        raise LabError("Lab requires at least 10 GiB Docker memory and 5 Docker CPUs")


def preflight() -> dict[str, object]:
    result = docker_run(
        ["docker", "info", "--format", "{{.MemTotal}} {{.NCPU}} {{.Architecture}}"],
        timeout=15,
    )
    if result.returncode:
        raise LabError("Docker daemon unavailable")
    memory, cpus, architecture = result.stdout.strip().split()
    free = shutil.disk_usage(ROOT).free
    budget(free, int(memory), int(cpus))
    for port in (8929, 8890):
        with socket.socket() as probe:
            try:
                probe.bind(("127.0.0.1", port))
            except OSError as error:
                raise LabError(
                    f"Port {port} occupied; no foreign process will be stopped"
                ) from error
    return {
        "free_bytes": free,
        "docker_memory_bytes": int(memory),
        "docker_cpus": int(cpus),
        "architecture": architecture,
    }


class Client:
    def __init__(self, token: str, *, mutations: bool, transport=None) -> None:
        if not token or len(token) > 512 or any(ord(c) < 33 for c in token):
            raise LabError("Invalid lab token")
        self.mutations = mutations
        self.http = httpx.Client(
            base_url=ORIGIN + "/api/v4/",
            headers={"PRIVATE-TOKEN": token},
            timeout=15,
            follow_redirects=False,
            trust_env=False,
            transport=transport,
        )

    def call(self, method: str, path: str, body=None, *, missing=False, query=None):
        if (
            path.startswith("/")
            or any(c in path for c in (":", "?", "..", "\\", "#"))
            or any(ord(c) < 32 for c in path)
            or method not in ("GET", "POST", "PUT")
        ):
            raise LabError("Unsafe lab API path")
        if method != "GET" and not self.mutations:
            raise LabError("Lab client is read-only")
        try:
            with self.http.stream(method, path, json=body, params=query) as response:
                if missing and response.status_code == 404:
                    return None
                if not 200 <= response.status_code < 300:
                    raise LabError(
                        f"Local GitLab {method} failed with status {response.status_code}"
                    )
                content = bytearray()
                for block in response.iter_bytes():
                    content.extend(block)
                    if len(content) > 5_000_000:
                        raise LabError("Lab response exceeds size limit")
                return json.loads(content)
        except (httpx.HTTPError, ValueError) as error:
            raise LabError("Local GitLab transport or JSON error") from error

    def rows(self, path: str):
        rows = []
        for page in range(1, 21):
            batch = self.call("GET", path, query={"page": page, "per_page": 100})
            if not isinstance(batch, list):
                raise LabError("Expected list response")
            rows.extend(batch)
            if len(batch) < 100:
                return rows
        raise LabError("Local GitLab page limit reached")

    def check(self):
        version = self.call("GET", "version")
        if version.get("version") != "18.11.12":
            raise LabError("Version gate requires exact GitLab 18.11.12")
        return self.call("GET", "user")

    def close(self):
        self.http.close()


def save(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(dir=path.parent, prefix=".lab-")
    try:
        with os.fdopen(descriptor, "w") as file:
            json.dump(value, file, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def load_state() -> dict:
    data = json.loads((STATE / "manifest.json").read_text())
    if data["origin"] != ORIGIN or data["marker"] != MARKER:
        raise LabError("Manifest is not the isolated lab")
    return data


def guard_projects(client: Client, state: dict) -> None:
    client.check()
    for project in state["projects"]:
        row = client.call("GET", f"projects/{project['id']}")
        if row["description"] != MARKER or row["path_with_namespace"] != project["path"]:
            raise LabError("Project ownership marker changed; refusing operation")


def file_exists(client: Client, project: int, branch: str, path: str) -> bool:
    # Query parameters are controlled constants, encoded once.
    return (
        client.call(
            "GET",
            f"projects/{project}/repository/files/{quote(path, safe='')}",
            query={"ref": branch},
            missing=True,
        )
        is not None
    )


def commit(client: Client, project: int, branch: str, files: dict[str, str], message: str):
    actions = [
        {
            "action": "update" if file_exists(client, project, branch, path) else "create",
            "file_path": path,
            "content": content,
        }
        for path, content in files.items()
    ]
    return client.call(
        "POST",
        f"projects/{project}/repository/commits",
        {"branch": branch, "commit_message": message, "actions": actions},
    )


def seed(client: Client) -> dict:
    user = client.check()
    if user["username"] != "gspace-lab-owner":
        raise LabError("Seed token must belong to synthetic gspace-lab-owner")
    projects = []
    for name in ("gspace-lab-flight", "gspace-lab-ground"):
        path = f"{user['username']}/{name}"
        project = client.call("GET", "projects/" + quote(path, safe=""), missing=True)
        if project is None:
            project = client.call(
                "POST",
                "projects",
                {
                    "name": name,
                    "path": name,
                    "description": MARKER,
                    "visibility": "private",
                    "initialize_with_readme": True,
                    "default_branch": "main",
                },
            )
        if project["description"] != MARKER or project["namespace"]["path"] != user["username"]:
            raise LabError("Existing project is not the isolated lab; never overwrite it")
        projects.append({"id": project["id"], "path": project["path_with_namespace"]})
    main = projects[0]["id"]
    base = f"projects/{main}"
    if not file_exists(client, main, "main", ".gitlab-ci.yml"):
        commit(
            client,
            main,
            "main",
            {".gitlab-ci.yml": (ROOT / "integration/gitlab-ci.yml").read_text()},
            "Configure explicitly synthetic CI lab",
        )
    mrs = {}
    for iid in range(791, 797):
        issue = client.call("GET", f"{base}/issues/{iid}", missing=True)
        if issue is None:
            issue = client.call(
                "POST",
                base + "/issues",
                {
                    "iid": iid,
                    "title": f"Lab work item {iid}",
                    "description": MARKER,
                    "assignee_ids": [user["id"]] if iid != 796 else [],
                },
            )
        if issue["iid"] != iid or issue["description"] != MARKER:
            raise LabError("Issue IID or ownership marker differs")
        if iid == 795 and issue["state"] != "closed":
            client.call("PUT", f"{base}/issues/{iid}", {"state_event": "close"})
        if iid >= 795:
            continue
        branch = f"issue-{iid}"
        if client.call("GET", base + "/repository/branches/" + branch, missing=True) is None:
            client.call("POST", base + "/repository/branches", {"branch": branch, "ref": "main"})
            commit(
                client,
                main,
                branch,
                {
                    ".lab-source-branch": branch,
                    ".lab-test-mode": "fail-once" if iid == 794 else "pass",
                    f"change-{iid}.txt": f"Synthetic change for {iid}\n",
                },
                f"Prepare synthetic work item {iid}",
            )
        candidates = [
            row for row in client.rows(base + "/merge_requests") if row["source_branch"] == branch
        ]
        if not candidates:
            mr = client.call(
                "POST",
                base + "/merge_requests",
                {
                    "source_branch": branch,
                    "target_branch": "main",
                    "title": f"{'' if iid == 792 else 'Draft: '}Lab change {iid}",
                    "remove_source_branch": False,
                },
            )
        elif len(candidates) == 1:
            mr = candidates[0]
        else:
            raise LabError("Ambiguous seed MR; refusing to choose")
        mrs[str(iid)] = mr["iid"]
        if iid == 794 and mr["state"] == "opened":
            client.call("PUT", f"{base}/merge_requests/{mr['iid']}", {"state_event": "close"})
    other = projects[1]["id"]
    if client.call("GET", f"projects/{other}/issues/791", missing=True) is None:
        client.call(
            "POST",
            f"projects/{other}/issues",
            {"iid": 791, "title": "Same IID, distinct project", "description": MARKER},
        )
    state = {
        "origin": ORIGIN,
        "marker": MARKER,
        "gitlab_version": "18.11.12",
        "projects": projects,
        "mrs": mrs,
        "events": [],
        "seeded_at": datetime.now(UTC).isoformat(),
    }
    save(STATE / "manifest.json", state)
    configure(client, state)
    return state


def configure(client: Client, state: dict) -> None:
    main = state["projects"][0]["id"]
    endpoints = []
    for iid in range(791, 795):
        row = client.call("GET", f"projects/{main}/repository/branches/issue-{iid}")
        for name in ("dev", "preprod"):
            expected = {"branch": f"issue-{iid}", "sha": row["commit"]["id"]}
            fields = [
                {"field": "branch", "path": "info.x-build.branch"},
                {"field": "sha", "path": "info.x-build.sha"},
            ]
            if name == "preprod" and iid == 793:
                tag = client.call(
                    "GET", f"projects/{main}/repository/tags/flight-2.4.10", missing=True
                )
                if tag:
                    expected = {"tag": tag["name"], "sha": tag["commit"]["id"]}
                    fields = [
                        {"field": "tag", "path": "info.x-build.tag"},
                        {"field": "sha", "path": "info.x-build.sha"},
                    ]
            endpoints.append(
                {
                    "name": name,
                    "key": {"project": {"value": main}, "issue": {"value": iid}},
                    "url": f"http://127.0.0.1:8890/projects/{main}/items/{iid}/{name}/openapi.json",
                    "allowed_origins": ["http://127.0.0.1:8890"],
                    "allowed_networks": ["127.0.0.1/32"],
                    "allow_http": True,
                    "expected": expected,
                    "extraction": {"kind": "json", "fields": fields},
                }
            )
    cfg = {
        "mode": "live",
        "preferences_path": str(STATE / "preferences.toml"),
        "cache_path": str(STATE / "cache.json"),
        "live": {
            "hostname": "127.0.0.1:8929",
            "transport": "isolated_loopback_http",
            "web_origin": ORIGIN,
            "projects": [
                {"id": {"value": project["id"]}, "path": project["path"]}
                for project in state["projects"]
            ],
        },
        "endpoints": endpoints,
    }
    AppConfig.model_validate(cfg)
    (STATE / "gspace.toml").write_text(tomli_w.dumps(cfg))


def register(client: Client, state: dict) -> dict:
    guard_projects(client, state)
    main = state["projects"][0]["id"]
    if "runner_id" in state:
        raise LabError("Runner already recorded; inspect it instead of creating another")
    compose("build", "runner")
    runner = client.call(
        "POST",
        "user/runners",
        {
            "runner_type": "project_type",
            "project_id": main,
            "description": MARKER,
            "tag_list": ["gspace-isolated"],
            "run_untagged": False,
            "locked": True,
            "maximum_timeout": 300,
        },
    )
    state["runner_id"] = runner["id"]
    save(STATE / "manifest.json", state)
    config = (
        (ROOT / "integration/runner-config.example.toml")
        .read_text()
        .replace('"OPERATOR_APPROVED_RUNNER_AUTHENTICATION_TOKEN"', json.dumps(runner["token"]))
    )
    # Secret bytes travel via stdin into only the dedicated runner config volume.
    compose(
        "run",
        "--rm",
        "--no-deps",
        "-T",
        "--entrypoint",
        "bash",
        "runner",
        "-c",
        "umask 077; cat > /etc/gitlab-runner/config.toml",
        confidential_input=config,
    )
    compose("--profile", "jobs", "up", "-d", "runner", "runtime")
    return {"runner_id": runner["id"], "executor": "shell", "privileged": False}


def latest_pipeline(client: Client, project: int, ref: str, sha: str) -> dict:
    matches = [
        row
        for row in client.rows(f"projects/{project}/pipelines")
        if row["ref"] == ref and row["sha"] == sha
    ]
    if not matches:
        raise LabError("No actual pipeline exists yet; inspect again explicitly")
    return max(matches, key=lambda row: row["id"])


def wait_pipeline(client: Client, project: int, pipeline: int, desired=("success", "manual")):
    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        row = client.call("GET", f"projects/{project}/pipelines/{pipeline}")
        if row["status"] in desired:
            return row
        if row["status"] in ("failed", "canceled", "skipped"):
            raise LabError(f"Pipeline {pipeline} ended with {row['status']}; no retry performed")
        time.sleep(2)
    raise LabError(f"Pipeline {pipeline} wait expired; no retry performed")


def play(client: Client, project: int, pipeline: int, name: str) -> dict:
    wait_pipeline(client, project, pipeline)
    jobs = client.rows(f"projects/{project}/pipelines/{pipeline}/jobs")
    chosen = [job for job in jobs if job["name"] == name and job["status"] == "manual"]
    if len(chosen) != 1:
        raise LabError("Manual deployment job is unavailable or ambiguous")
    client.call("POST", f"projects/{project}/jobs/{chosen[0]['id']}/play")
    wait_pipeline(client, project, pipeline, desired=("success",))
    return {"pipeline_id": pipeline, "job_id": chosen[0]["id"], "job": name}


def exercise(client: Client, state: dict, scenario: str, confirmations: bool) -> dict:
    guard_projects(client, state)
    main = state["projects"][0]["id"]
    base = f"projects/{main}"
    if scenario == "dev-post-failure":
        branch = client.call("GET", base + "/repository/branches/issue-791")
        pipeline = latest_pipeline(client, main, "issue-791", branch["commit"]["id"])
        evidence = play(client, main, pipeline["id"], "deploy-dev")
        changed = commit(
            client,
            main,
            "issue-791",
            {".lab-test-mode": "fail"},
            "Intentional application failure after a successful dev deployment",
        )
        state["events"].append(
            {"scenario": scenario, **evidence, "post_failure_sha": changed["id"]}
        )
    elif scenario == "tag-preprod":
        tag = client.call("GET", base + "/repository/tags/flight-2.4.10", missing=True)
        if tag is None:
            tag = client.call(
                "POST", base + "/repository/tags", {"tag_name": "flight-2.4.10", "ref": "issue-793"}
            )
        pipeline = latest_pipeline(client, main, tag["name"], tag["commit"]["id"])
        evidence = play(client, main, pipeline["id"], "deploy-preprod")
        state["events"].append({"scenario": scenario, **evidence, "tag": tag["name"]})
    elif scenario == "retry":
        branch = client.call("GET", base + "/repository/branches/issue-794")
        pipeline = latest_pipeline(client, main, "issue-794", branch["commit"]["id"])
        wait_pipeline(client, main, pipeline["id"], desired=("failed",))
        jobs = client.rows(f"{base}/pipelines/{pipeline['id']}/jobs")
        failed = [job for job in jobs if job["name"] == "test-app" and job["status"] == "failed"]
        if len(failed) != 1:
            raise LabError("Expected one explicit application failure to retry")
        client.call("POST", f"{base}/jobs/{failed[0]['id']}/retry")
        wait_pipeline(client, main, pipeline["id"])
        state["events"].append(
            {"scenario": scenario, "pipeline_id": pipeline["id"], "retried_job_id": failed[0]["id"]}
        )
    elif scenario == "merged":
        approved(confirmations, "manual local/dev/preprod/work confirmation and synthetic merge")
        mr = state["mrs"]["793"]
        client.call("PUT", f"{base}/merge_requests/{mr}", {"title": "Lab change 793"})
        result = client.call(
            "PUT", f"{base}/merge_requests/{mr}/merge", {"should_remove_source_branch": False}
        )
        if result["state"] != "merged":
            raise LabError("MR was not merged; no automatic retry")
        state["events"].append({"scenario": scenario, "mr_iid": mr, "state": "merged"})
    else:
        raise LabError("Unsupported scenario")
    save(STATE / "manifest.json", state)
    configure(client, state)
    return state["events"][-1]


def verify(client: Client, state: dict, token: str) -> dict:
    from gspace.config import load_config
    from gspace.models import Comparison
    from gspace.service import Service

    guard_projects(client, state)
    cfg = load_config(STATE / "gspace.toml")
    with tempfile.TemporaryDirectory(prefix="gspace-lab-glab-") as temporary:
        environment = {
            "PATH": os.environ.get("PATH", ""),
            "GLAB_CONFIG_DIR": temporary,
            "GLAB_API_PROTOCOL": "http",
            "GITLAB_TOKEN": token,
            "GITLAB_HOST": "127.0.0.1:8929",
            "GITLAB_API_HOST": "127.0.0.1:8929",
            "GLAB_CHECK_UPDATE": "false",
            "GLAB_SEND_TELEMETRY": "false",
            "NO_COLOR": "1",
        }
        # Keep secrets out of argv; restore the entire environment afterward.
        previous = os.environ.copy()
        try:
            os.environ.clear()
            os.environ.update(environment)
            service = Service(cfg, adapter=GlabAdapter(cfg.live))
            snapshot = service.refresh()
            dashboard = service.dashboard()
            main = state["projects"][0]["id"]
            observations = []
            for endpoint in cfg.endpoints:
                item = service.observe_environment(endpoint.key, endpoint.name)
                comparison = next(
                    c
                    for c in service.view(item, service.preferences.read()).comparisons
                    if c.name == endpoint.name
                )
                observations.append(
                    {
                        "issue": endpoint.key.issue.value,
                        "environment": endpoint.name.value,
                        "result": comparison.result.value,
                        "reason": comparison.reason,
                    }
                )
            main_key = WorkKey(project=ProjectId(value=main), issue=IssueIid(value=791))
            item = service.item(main_key)
            report = {
                "gitlab_version": snapshot.gitlab_version,
                "source": snapshot.source,
                "verified_at": datetime.now(UTC).isoformat(),
                "visible_active_assigned": len(dashboard.views),
                "issue_791_projects": [
                    i.identity.project.value
                    for i in snapshot.items
                    if i.identity.issue.value == 791
                ],
                "remote_mutations_available": False,
                "jobs": [
                    {
                        "pipeline": p.id.value,
                        "status": p.status.value,
                        "attempts": [
                            {
                                "id": j.id.value,
                                "name": j.name,
                                "attempt": j.attempt,
                                "retried": j.retried,
                                "status": j.status.value,
                            }
                            for j in p.jobs
                        ],
                    }
                    for i in snapshot.items
                    for p in i.pipelines
                ],
                "deployments": [
                    {
                        "issue": i.identity.issue.value,
                        "environment": e.name.value,
                        "id": d.id,
                        "status": d.status.value,
                        "sha": d.sha,
                    }
                    for i in snapshot.items
                    for e in i.environments
                    for d in e.deployments
                ],
                "mr_states": [
                    {"iid": m.iid.value, "state": m.state.value, "draft": m.draft}
                    for i in snapshot.items
                    for m in i.merge_requests
                ],
                "observations": observations,
                "executed_scenarios": state["events"],
                "post_failure_runtime_mismatch": any(
                    c.result == Comparison.MISMATCH
                    for c in service.view(item, service.preferences.read()).comparisons
                ),
                "nexus_artifact_independently_verified": False,
            }
            assert snapshot.source == "glab" and snapshot.gitlab_version == "18.11.12"
            assert len(dashboard.views) == 4
            assert len(report["issue_791_projects"]) == 2
            assert service.preview(main_key, "merge").executed is False
            save(STATE / "integration-report.json", report)
            return report
        finally:
            os.environ.clear()
            os.environ.update(previous)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command",
        choices=["preflight", "start", "seed", "runner", "exercise", "verify", "stop", "status"],
    )
    parser.add_argument("--approved-resource-budget", action="store_true")
    parser.add_argument("--approved-local-credentials", action="store_true")
    parser.add_argument("--approved-local-mutations", action="store_true")
    parser.add_argument("--confirm-local-dev-preprod-work", action="store_true")
    parser.add_argument(
        "--scenario", choices=["dev-post-failure", "tag-preprod", "retry", "merged"]
    )
    args = parser.parse_args()
    client = None
    try:
        if args.command == "preflight":
            output = preflight()
        elif args.command == "start":
            approved(args.approved_resource_budget, "GitLab resource allocation")
            approved(
                args.approved_local_credentials, "GitLab bootstrap credentials in dedicated volumes"
            )
            output = preflight()
            compose("up", "-d", "gitlab")
        elif args.command == "status":
            output = {
                "project": "gspace-integration-181112-v1",
                "services": compose("--profile", "jobs", "ps", "--format", "json"),
            }
        elif args.command == "stop":
            # Stops only this explicit Compose project; dedicated volumes remain.
            compose("--profile", "jobs", "stop")
            output = {"stopped": "gspace-integration-181112-v1", "volumes_preserved": True}
        else:
            mutating = args.command in ("seed", "runner", "exercise")
            if mutating:
                approved(args.approved_local_mutations, "synthetic lab mutations")
            if args.command == "runner":
                approved(args.approved_local_credentials, "runner token/configuration creation")
                approved(
                    args.approved_resource_budget, "isolated runner build and resource allocation"
                )
            token = getpass.getpass("Approved isolated lab PAT (never printed): ")
            client = Client(token, mutations=mutating)
            if args.command == "seed":
                output = seed(client)
            elif args.command == "runner":
                output = register(client, load_state())
            elif args.command == "exercise":
                if args.scenario is None:
                    raise LabError("Choose one explicit scenario")
                output = exercise(
                    client, load_state(), args.scenario, args.confirm_local_dev_preprod_work
                )
            else:
                output = verify(client, load_state(), token)
        print(json.dumps(output, indent=2))
        return 0
    except (LabError, OSError, ValueError, subprocess.TimeoutExpired) as error:
        message = str(error) if isinstance(error, LabError) else "Local lab operation failed"
        print(json.dumps({"error": message}), file=sys.stderr)
        return 2
    finally:
        if client is not None:
            client.close()


if __name__ == "__main__":
    raise SystemExit(main())
