"""Running-service operator edits using isolated files and no remote transport."""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from gspace.api import create_app
from gspace.config import load_config
from gspace.fixture import synthetic_snapshot
from gspace.glab import GlabAdapter
from gspace.operator_settings import OperatorSettings, OperatorStore, SettingsChange
from gspace.service import Service


def running(tmp_path: Path) -> tuple[Path, Service, TestClient]:
    path = tmp_path / "config.toml"
    path.write_text(
        '# Keep operator note\nmode="fixture"\npreferences_path="prefs.toml"\n'
        'cache_path="cache.json"\ntimezone="Europe/Zurich"\n'
    )
    service = Service(load_config(path), config_path=path)
    client = TestClient(create_app(service=service))
    assert client.get("/api/dashboard").status_code == 200
    return path, service, client


def external_change(path: Path, service: Service) -> SettingsChange:
    current = service.settings()
    payload = current.settings.model_dump(mode="json")
    payload["timezone"] = "UTC"
    payload["branch_template"] = "task-{iid}"
    payload["pipeline"]["environments"].append(
        {"name": "qa", "label": "Quality assurance", "ref_source": "branch"}
    )
    payload["pipeline"]["important_job_patterns"] = ["publish-*"]
    change = SettingsChange(
        revision=current.revision, settings=OperatorSettings.model_validate(payload)
    )
    OperatorStore(path, load_config(path)).update(change)
    return change


@pytest.mark.parametrize("entry", ["settings", "dashboard", "refresh", "history"])
def test_external_valid_rules_apply_to_existing_service(tmp_path, entry):
    path, service, client = running(tmp_path)
    key = service.snapshot().items[0].identity
    old_snapshot = service.snapshot()
    external_change(path, service)
    match entry:
        case "settings":
            assert client.get("/api/settings").json()["settings"]["timezone"] == "UTC"
        case "dashboard":
            assert client.get("/api/dashboard").status_code == 200
        case "refresh":
            service.refresh()
        case "history":
            assert service.application_test_history(key).timezone == "UTC"
    assert service.config.timezone == "UTC"
    dashboard = service.dashboard()
    assert "environment:qa" in dashboard.columns
    assert [e.name for e in dashboard.views[0].item.environments] == ["dev", "preprod", "qa"]
    assert all(j.important == (j.role == "publish") for j in dashboard.views[0].job_configuration)
    assert service.application_test_history(key).timezone == "UTC"
    assert service.snapshot().items == old_snapshot.items
    assert service.config.preferences_path == tmp_path / "prefs.toml"
    assert "# Keep operator note" in path.read_text()


@pytest.mark.parametrize(
    "payload",
    [
        'mode="fixture"\ntimezone="No/Zone"\n',
        'mode="fixture"\nsecret="DO-NOT-ECHO"\n',
        'timezone="DO-NOT-ECHO',
        'mode="fixture"\npreferences_path="DO-NOT-ECHO.toml"\ncache_path="cache.json"\n',
    ],
)
def test_bad_or_protected_external_file_keeps_last_good_runtime_and_recovers(tmp_path, payload):
    path, service, client = running(tmp_path)
    good = path.read_bytes()
    old_config = service.config
    path.write_text(payload)
    response = client.get("/api/settings")
    assert response.status_code == 400
    assert "last valid rules remain active" in response.json()["detail"].lower()
    assert "DO-NOT-ECHO" not in response.text
    dashboard = client.get("/api/dashboard")
    assert dashboard.status_code == 200
    assert any("last valid rules" in w.lower() for w in dashboard.json()["warnings"])
    assert service.config == old_config
    assert not (tmp_path / "DO-NOT-ECHO.toml").exists()
    path.write_bytes(good)
    assert client.get("/api/settings").status_code == 200
    assert not any("last valid rules" in w for w in service.dashboard().warnings)


def test_ambiguous_rules_are_not_adopted_from_external_file(tmp_path):
    path, service, client = running(tmp_path)
    current = service.settings()
    data = current.settings.model_dump(mode="json")
    data["pipeline"]["jobs"].append({"pattern": "publish-*", "role": "publish"})
    OperatorStore(path, load_config(path)).update(
        SettingsChange(revision=current.revision, settings=OperatorSettings.model_validate(data))
    )
    assert client.get("/api/settings").status_code == 400
    assert len(service.config.pipeline.jobs) == 3
    assert client.get("/api/dashboard").status_code == 200


def test_web_write_rechecks_exact_protected_file_and_stale_revision(tmp_path):
    path, service, client = running(tmp_path)
    current = service.settings()
    external_change(path, service)
    before = path.read_bytes()
    request = {"revision": current.revision, "settings": current.settings.model_dump(mode="json")}
    assert client.post("/api/settings", json=request).status_code == 409
    assert path.read_bytes() == before
    assert service.settings().settings.timezone == "UTC"
    path.write_text(
        path.read_text().replace('cache_path="cache.json"', 'cache_path="different-cache.json"')
    )
    request["revision"] = service.operator_store.revision()
    before = path.read_bytes()
    assert client.post("/api/settings", json=request).status_code == 400
    assert path.read_bytes() == before
    assert service.config.cache_path == tmp_path / "cache.json"


def test_cli_save_has_effect_on_already_running_service(tmp_path):
    path, service, client = running(tmp_path)
    current = service.settings()
    data = current.settings.model_dump(mode="json")
    data["timezone"] = "UTC"
    data["pipeline"]["environments"].append(
        {"name": "qa", "label": "Quality assurance", "ref_source": "branch"}
    )
    change = tmp_path / "change.json"
    change.write_text(json.dumps({"revision": current.revision, "settings": data}))
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "gspace",
            "settings-set",
            str(change),
            "--config",
            str(path),
            "--json",
        ],
        capture_output=True,
        text=True,
        timeout=20,
        env={**os.environ, "NO_COLOR": "1"},
    )
    assert result.returncode == 0 and result.stderr == ""
    assert json.loads(result.stdout)["settings"]["timezone"] == "UTC"
    assert client.get("/api/dashboard").status_code == 200
    assert service.config.timezone == "UTC"
    assert "environment:qa" in service.dashboard().columns


def test_validation_callback_prevents_atomic_replace(tmp_path):
    path, service, _client = running(tmp_path)
    before = path.read_bytes()
    current = service.settings()

    def refuse(_config):
        raise ValueError("Synthetic guard rejection")

    with pytest.raises(ValueError, match="Synthetic guard"):
        service.operator_store.update(
            SettingsChange(revision=current.revision, settings=current.settings), validate=refuse
        )
    assert path.read_bytes() == before
    assert not list(tmp_path.glob(".operator-*"))


def test_live_public_reload_is_local_and_remote_evidence_stays_cached(tmp_path, monkeypatch):
    path = tmp_path / "live-synthetic.toml"
    path.write_text(
        'mode="live"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n'
        '[live]\nhostname="gitlab.example.invalid"\n'
        'web_origin="https://gitlab.example.invalid"\n'
        '[[live.projects]]\nid={value=42}\npath="demo/flight-service"\n'
    )

    def deny_network(*_args, **_kwargs):
        raise AssertionError("Settings reload must not fetch remotely")

    monkeypatch.setattr(GlabAdapter, "snapshot", deny_network)
    service = Service(load_config(path), config_path=path)
    fixture = synthetic_snapshot()
    service._snapshot = type(fixture).model_validate(
        {
            **fixture.model_dump(),
            "source": "glab",
            "items": tuple(i for i in fixture.items if i.identity.project.value == 42),
        }
    )
    client = TestClient(create_app(service=service))
    old_snapshot = service.snapshot()
    external_change(path, service)
    response = client.get("/api/settings")
    assert response.status_code == 200 and response.json()["refresh_required"] is True
    assert service.config.timezone == "UTC"
    assert service.snapshot() is old_snapshot
    assert "environment:qa" in service.dashboard().columns
    assert service.settings().refresh_required is True
