// Overview: the question-first reading of the same records, filters and
// selection the Detailed views use. Work items stay adjacent columns read top
// to bottom: branch → MR → pipeline and jobs → publish → branch-ref
// environments (deployment record, deploy job, running version, manual test)
// → tag → tag pipeline → tag-ref environments. Each step shows one short
// line first; its evidence (commit letters, relations, provenance, every job)
// opens in place for the whole row, so related evidence stays side by side.
// The evidence is the Detailed stage renderer itself, not a second copy.
// Every fact keeps its own badge; nothing is merged into one health status,
// and 1:N, overrides and unknowns are shown, never filled in.

import type { ItemView, Job, Pipeline, Rebase } from './api';
import { versionParts } from './api';
import { attentionLine } from './attention';
import type { IconName, Kid, Tone } from './dom';
import { draftChip, h, icon, mrStateBadge, plural, STATUS, tone } from './dom';
import { evidence } from './evidence';
import type { Commit, DepNode, EnvDef, EnvNode, PipeNode, Proc, StageDef } from './model';
import { deployJobsOf, failedJobs, groupJobs, jobCfgOf, latestPerRef, processOf, scopeProjects, stageOrder, stagesFor, visibleEnvs } from './model';
import { commitEl, commitLetter, processNode, stageRun, versionIds } from './process';
import { render } from './render';
import type { ListUi } from './state';
import { branchHref, itemHref, jobHref, mrHref, pipeHref, S, to, wkStr } from './state';
import { mobileQuery, mxFrame } from './views';

export type Basis = 'root' | 'ref' | 'cand' | 'ind' | 'none';

/** One step: first-level content, a one-line form, a comparable outcome and a strip pill. */
interface Step {
  readonly basis: Basis;
  readonly nodes: Kid[];
  /** One line, used where every compared item has the same outcome. */
  readonly line: Kid;
  /** Status words only (never SHAs, IDs or names), to find rows with equal outcomes. */
  readonly outcome: string;
  readonly pill: Pill;
}
interface Pill {
  readonly tone: Tone;
  readonly text: string;
  readonly title: string;
  /** Separate facts (environments): never merged into one status. */
  readonly dots?: readonly Dot[];
}
/** One environment fact in a strip pill: visible short name, its own tone, full text alternative. */
interface Dot {
  readonly tone: Tone;
  readonly short: string;
  /** Commit relation of the deployment ("=", "≠", "?"), shown beside the record fact. */
  readonly mark: string | null;
  readonly label: string;
}

type RowId = 'branch' | 'mr' | 'pipeline' | 'publish' | 'tag' | 'tagpipe' | 'env';
interface Row {
  readonly id: RowId;
  /** Unique within a board: the row ID, or env:<name>. */
  readonly key: string;
  readonly env: EnvDef | null;
  readonly label: string;
  readonly icon: IconName;
  readonly hint: string;
}

const MAX = 2; // entities shown per step before "+n more"

const more = (n: number, href: string, what: string): Kid =>
  n > 0 ? h('a', { class: 'fl-more', href, title: `Open the item for every ${what}` }, `+${plural(n, `more ${what}`)}`) : null;

const statusTone = (s: Job['status']): Tone => STATUS[s][0];

/* ------------------------------------------------- evidence expansion */
// Row expansion is browser memory only: "<board>:<row key>", or "<board>:*"
// for every row of that board.

const isOpen = (board: string, key: string): boolean => S.expanded.has(`${board}:*`) || S.expanded.has(`${board}:${key}`);

function toggleRow(board: string, key: string, keys: readonly string[]): void {
  if (S.expanded.has(`${board}:*`)) {
    S.expanded.delete(`${board}:*`);
    for (const k of keys) if (k !== key) S.expanded.add(`${board}:${k}`);
  } else if (S.expanded.has(`${board}:${key}`)) S.expanded.delete(`${board}:${key}`);
  else S.expanded.add(`${board}:${key}`);
  render();
}

/** "Show all evidence" / "Hide evidence" for one board. */
export function evidenceToggle(board: string): HTMLButtonElement {
  const all = S.expanded.has(`${board}:*`);
  const any = all || [...S.expanded].some((k) => k.startsWith(`${board}:`));
  return h(
    'button',
    {
      class: 'btn sm ghost',
      type: 'button',
      'aria-pressed': String(all),
      'data-fk': `rx-all-${board}`,
      title: 'Opens or closes the full evidence (commits, relations, provenance, every job) of every row',
      onclick: () => {
        for (const k of [...S.expanded]) if (k.startsWith(`${board}:`)) S.expanded.delete(k);
        if (!any) S.expanded.add(`${board}:*`);
        render();
      },
    },
    icon(any ? 'up' : 'down', 'sm'),
    any ? 'Hide evidence' : 'Show all evidence',
  );
}

function rowToggle(board: string, r: Row, keys: readonly string[]): HTMLButtonElement {
  const open = isOpen(board, r.key);
  return h(
    'button',
    {
      class: 'rx',
      type: 'button',
      'aria-expanded': String(open),
      'data-fk': `rx-${board}-${r.key}`,
      title: `${r.hint}. ${open ? 'Hide' : 'Show'} the evidence of this row.`,
      onclick: () => toggleRow(board, r.key, keys),
    },
    icon(r.icon, 'sm'),
    h('span', { class: 'rx-l' }, r.label),
    icon(open ? 'down' : 'next', 'xs rx-chev'),
  );
}

// The Detailed stage renderer(s) behind each Overview row.
const STAGES_OF: Readonly<Record<RowId, readonly StageDef['id'][]>> = {
  branch: ['branch'],
  mr: ['mr'],
  pipeline: ['pipeline', 'jobs'],
  publish: ['publish'],
  tag: ['tag'],
  tagpipe: ['tagpipe'],
  env: ['deploy', 'runtime', 'apptest'],
};

function evidenceFor(P: Proc, r: Row, det: boolean): HTMLElement {
  const envs = r.env ? [r.env] : [];
  const defs = stagesFor(envs);
  const stages = STAGES_OF[r.id].flatMap((id) => defs.filter((s) => s.id === id));
  const o = { det, envs: envs.map((e) => e.name), envActions: false };
  return h(
    'div',
    { class: 'l2', role: 'group', 'aria-label': `${r.label}: evidence` },
    stages.map((st) => [stages.length > 1 ? h('div', { class: 'l2-h' }, st.label) : null, stageRun(P, st, o).nodes]),
  );
}

/* ------------------------------------------------------------ pieces */

/** Job chips for one pipeline: important jobs (or all), or only the given ones; retries and a link to the rest. */
export function jobDots(p: Pipeline, only: readonly Job[] | null = null): Kid {
  const jobs = p.jobs;
  if (!jobs.length) return h('span', { class: 'muted fl-sub' }, 'no jobs reported');
  const imp = (j: Job): boolean => jobCfgOf(p, j)?.important === true;
  const focus = !only && !S.allJobs && jobs.some(imp);
  const groups = stageOrder(jobs, p).flatMap((s) => groupJobs(jobs.filter((j) => j.stage === s)));
  const shown = only ? groups.filter((g) => only.includes(g.current)) : focus ? groups.filter((g) => g.attempts.some(imp)) : groups;
  const visible = shown.slice(0, 4);
  const hidden = groups.length - visible.length;
  return h(
    'span',
    { class: 'fl-jobs' },
    visible.map((g) => {
      const j = g.current;
      const [t, ico, label] = STATUS[j.status];
      const retries = g.attempts.length - 1;
      return h(
        'a',
        {
          class: `fl-job t-${t}`,
          href: to(jobHref(p.project.value, p.id.value, j.id.value)),
          title: `${j.name}: ${label}${retries ? `, ${plural(retries, 'earlier attempt')}` : ''}${j.failure_reason ? ` — ${j.failure_reason}` : ''}`,
        },
        icon(ico, 'xs'),
        h('span', null, j.name),
        retries ? h('span', { class: 'fl-retry' }, `↻${retries}`, h('span', { class: 'sr' }, ` ${plural(retries, 'earlier attempt')}`)) : null,
      );
    }),
    only?.length
      ? only
          .filter((j) => j.failure_reason)
          .slice(0, 1)
          .map((j) => h('span', { class: 'fl-why' }, j.failure_reason))
      : null,
    hidden > 0
      ? h(
          'a',
          { class: 'fl-more', href: to(pipeHref(p.project.value, p.id.value)), title: 'Every job and attempt is in the pipeline' },
          `+${plural(hidden, only || focus ? 'other job' : 'job')}`,
        )
      : null,
  );
}

const ev = (P: Proc, kind: string, id: string | number, a: Parameters<typeof evidence>[1], extra: readonly Kid[] = [], heading: string | null = null) =>
  evidence(`ev-v-${wkStr(P.it.identity)}-${kind}-${id}`, a, extra, heading);

function rebaseWord(r: Rebase): HTMLSpanElement {
  if (r.kind !== 'verified') return tone('unknown', 's_unknown', 'rebase unknown', r.reason);
  const title = `${r.source}; target ${r.target_branch}`;
  return r.required ? tone('warn', 'rebase', `rebase: ${r.behind} behind`, title) : tone('ok', 's_ok', 'up to date', title);
}
const rebaseKey = (r: Rebase): string => (r.kind !== 'verified' ? 'unknown' : r.required ? 'behind' : 'current');

/** Open an item at one environment (its card holds the exact-version test editor and history). */
export function openEnv(P: Proc, env: string): void {
  S.focusTarget = `env:${wkStr(P.it.identity)}:${env}`;
  const href = to(itemHref(P.it.identity));
  if (location.hash === href) render();
  else location.hash = href;
}

/* ------------------------------------------------------------ steps */

function stepBranch(P: Proc): Step {
  const list = P.branches;
  if (!list.length) return emptyStep('No branch linked', 'A branch whose name merely matches is not linked without evidence.');
  const first = list[0];
  const nodes: Kid[] = list
    .slice(0, MAX)
    .map(({ b }) =>
      processNode('root', [
        h(
          'div',
          { class: 'fl-main' },
          icon('branch', 'sm'),
          h('a', { class: 'mono strong', href: to(branchHref(b.project.value, b.name)) }, b.name),
          ev(P, 'branch', `${b.project.value}-${b.name}`, b.association),
          rebaseWord(b.rebase),
        ),
      ]),
    );
  nodes.push(more(list.length - MAX, to(itemHref(P.it.identity)), 'branch'));
  // The rebase warning is spelled out in the pill text, not carried by colour alone.
  const behind = list.filter((x) => x.b.rebase.kind === 'verified' && x.b.rebase.required).length;
  const r = first?.b.rebase;
  const name = list.length > 1 ? `${list.length} branches` : (first?.b.name ?? '');
  return {
    basis: 'root',
    nodes,
    line: h('div', { class: 'fl-main' }, icon('branch', 'sm'), h('span', { class: 'mono' }, name), first ? rebaseWord(first.b.rebase) : null),
    outcome: list.map((x) => rebaseKey(x.b.rebase)).join(','),
    pill: {
      tone: behind ? 'warn' : 'neutral',
      text: behind ? `${name} · rebase${list.length > 1 ? ` ×${behind}` : r?.kind === 'verified' ? ` (${r.behind} behind)` : ''}` : name,
      title: `Branch${list.length > 1 ? 'es' : ''}: ${list.map((x) => x.b.name).join(', ')}${behind ? `; rebase required for ${behind} of ${list.length}` : ''}`,
    },
  };
}

function stepMr(P: Proc): Step {
  const list = P.mrs;
  if (!list.length) return emptyStep('No merge request linked');
  const nodes: Kid[] = list.slice(0, MAX).map((x) => {
    const m = x.m;
    return processNode(x.br ? 'ref' : 'none', [
      h(
        'div',
        { class: 'fl-main' },
        icon('mr', 'sm'),
        h('a', { class: 'mono strong', href: to(mrHref(m.project.value, m.iid.value)), title: `MR !${m.iid.value}: ${m.title}` }, `!${m.iid.value}`),
        mrStateBadge(m),
        draftChip(m),
        ev(P, 'mr', `${m.project.value}-${m.iid.value}`, m.association),
        h('span', { class: 'muted fl-sub' }, `→ ${m.target_branch}`),
      ),
    ]);
  });
  nodes.push(more(list.length - MAX, to(itemHref(P.it.identity)), 'merge request'));
  const first = list[0]?.m;
  return {
    basis: list.some((x) => x.br) ? 'ref' : 'none',
    nodes,
    line: h(
      'div',
      { class: 'fl-main' },
      icon('mr', 'sm'),
      list.length > 1 ? `${list.length} MRs` : first ? [h('span', { class: 'mono' }, `!${first.iid.value}`), mrStateBadge(first), draftChip(first)] : null,
    ),
    outcome: list.map((x) => `${x.m.state}${x.m.draft ? '/draft' : ''}`).join(','),
    pill: {
      tone: first?.state === 'open' ? 'info' : first?.state === 'merged' ? 'manual' : 'muted',
      text: list.length > 1 ? `${list.length} MRs` : first ? `!${first.iid.value} ${first.draft ? 'draft' : first.state}` : '',
      title: list.map((x) => `!${x.m.iid.value} ${x.m.state}${x.m.draft ? ' (draft)' : ''}`).join(', '),
    },
  };
}

function pipeStep(P: Proc, list: readonly PipeNode[], emptyText: string, tagRow: boolean): Step {
  if (!list.length) return emptyStep(emptyText);
  // Newest pipeline per ref first; a newer pipeline on another ref says
  // nothing about this one, and older ones on the same ref stay counted.
  const latest = latestPerRef(list);
  const refs = new Set(list.map((x) => x.p.ref)).size;
  const shown = latest.slice(0, MAX);
  const nodes: Kid[] = shown.map((x) => {
    const p = x.p;
    const basis: Basis = tagRow ? 'ref' : x.kind === 'ambiguous' ? 'cand' : x.br || x.mrsByRef.length ? 'ref' : 'none';
    const [t, ico, label] = STATUS[p.status];
    const failed = failedJobs(p);
    return processNode(basis, [
      h(
        'div',
        { class: 'fl-main' },
        h('a', { class: 'strong', href: to(pipeHref(p.project.value, p.id.value)) }, 'Pipeline ', h('span', { class: 'mono' }, `#${p.id.value}`)),
        tone(t, ico, label),
        ev(P, tagRow ? 'tagpipe' : 'pipe', p.id.value, p.association),
      ),
      refs > 1 ? h('div', { class: 'fl-sub muted' }, `newest on ${p.ref}`) : null,
      failed.length ? jobDots(p, failed) : jobDots(p),
    ]);
  });
  nodes.push(more(list.length - shown.length, to(itemHref(P.it.identity)), 'pipeline'));
  const first = shown[0]?.p;
  return {
    basis: tagRow ? 'ref' : list.some((x) => x.br || x.mrsByRef.length) ? 'ref' : 'none',
    nodes,
    line: first
      ? h(
          'div',
          { class: 'fl-main' },
          tone(STATUS[first.status][0], STATUS[first.status][1], STATUS[first.status][2]),
          h('a', { class: 'mono', href: to(pipeHref(first.project.value, first.id.value)) }, `#${first.id.value}`),
          latest.length > 1 ? h('span', { class: 'muted' }, `+${latest.length - 1} on other refs`) : null,
        )
      : null,
    outcome: latest.map((x) => x.p.status).join(','),
    pill: {
      tone: first ? statusTone(first.status) : 'unknown',
      text: latest.length > 1 ? `${latest.length} pipelines` : first ? `#${first.id.value} ${STATUS[first.status][2].toLowerCase()}` : '',
      title: list.map((x) => `Pipeline #${x.p.id.value} on ${x.p.ref}: ${x.p.status}`).join(', '),
    },
  };
}

function stepPublish(P: Proc): Step {
  const list = P.pubs;
  // Absence of publish evidence is unknown, not proof that nothing was published.
  if (!list.length) return emptyStep('No publish evidence', 'Not proof that nothing was published; a successful job alone does not show it either.', true);
  const nodes: Kid[] = list.slice(0, MAX).map((x) => {
    const [t, ico, label] = STATUS[x.x.status];
    return processNode(x.job ? 'ref' : 'none', [
      h(
        'div',
        { class: 'fl-main' },
        icon('publish', 'sm'),
        x.x.status === 'success' ? tone(t, ico, 'Published') : tone(t, ico, `Publish ${label.toLowerCase()}`),
      ),
      h('code', { class: 'mono fl-art', title: x.x.artifact }, x.x.artifact),
    ]);
  });
  nodes.push(more(list.length - MAX, to(itemHref(P.it.identity)), 'publish'));
  const first = list[0]?.x;
  return {
    basis: list.some((x) => x.job) ? 'ref' : 'none',
    nodes,
    line: first
      ? h(
          'div',
          { class: 'fl-main' },
          tone(STATUS[first.status][0], STATUS[first.status][1], first.status === 'success' ? 'Published' : STATUS[first.status][2]),
          h('code', { class: 'mono fl-art-1', title: first.artifact }, first.artifact),
          list.length > 1 ? h('span', { class: 'muted' }, `+${list.length - 1}`) : null,
        )
      : null,
    outcome: list.map((x) => x.x.status).join(','),
    pill: {
      tone: first ? statusTone(first.status) : 'unknown',
      text: first ? `publish ${first.status}` : '',
      title: list.map((x) => `${x.x.artifact}: ${x.x.status}`).join(', '),
    },
  };
}

const TEST_TONE: Readonly<Record<'passed' | 'failed' | 'not_tested', Tone>> = { passed: 'ok', failed: 'fail', not_tested: 'unknown' };
const TEST_TEXT: Readonly<Record<'passed' | 'failed' | 'not_tested', string>> = { passed: 'passed', failed: 'failed', not_tested: 'not tested' };

interface Rel {
  readonly mark: string | null;
  readonly text: string;
  readonly tone: Tone;
  readonly icon: IconName;
}

// Commit relation of a deployment record, computed exactly as the detailed
// deployment stage does: the record's own SHA against the head of the branch,
// or the tag, that the record names. A matching ref name alone is not used.
function depRelation(dep: DepNode | null): Rel | null {
  if (!dep) return null;
  if (!dep.br && !dep.tg) return { mark: null, text: `ref ${dep.d.ref} not linked to this item`, tone: 'unknown', icon: 's_unknown' };
  const parent = dep.br ? dep.br.c : (dep.tg?.c ?? null);
  const what = dep.br ? 'branch head' : 'tag';
  if (!parent) return null;
  if (!dep.c) return { mark: '?', text: `SHA not established vs ${what}`, tone: 'unknown', icon: 's_unknown' };
  return dep.c === parent
    ? { mark: '=', text: `same SHA as ${what}`, tone: 'neutral', icon: 's_match' }
    : { mark: '≠', text: `SHA differs from ${what}`, tone: 'muted', icon: 's_mismatch' };
}

interface EnvFacts {
  readonly dep: { readonly tone: Tone; readonly text: string; readonly c: Commit | null; readonly title: string };
  readonly job: { readonly tone: Tone; readonly text: string; readonly short: string; readonly title: string };
  readonly run: { readonly tone: Tone; readonly text: string; readonly kids: Kid; readonly title: string };
  readonly test: { readonly tone: Tone; readonly text: string; readonly kids: Kid; readonly title: string };
  readonly rel: Rel | null;
}

// The four facts of one environment, each from its own typed source.
function envFacts(P: Proc, E: EnvNode): EnvFacts {
  const dep = E.deps[0] ?? null;
  const rel = depRelation(dep);
  const job = deployJobsOf(P, E.name)[0] ?? null;
  const obs = E.env?.observation ?? null;
  const cmp = E.cmp;
  const t = E.test;
  const depText = dep
    ? `${STATUS[dep.d.status][2].toLowerCase()} #${dep.d.id}${E.deps.length > 1 ? ` +${E.deps.length - 1}` : ''}`
    : E.env
      ? 'none'
      : 'not in snapshot';
  let run: EnvFacts['run'];
  if (obs?.kind === 'error') run = { tone: 'fail', text: 'read error', kids: `read error (${obs.code})`, title: obs.message };
  else if (cmp?.result === 'mismatch')
    run = {
      tone: 'warn',
      text: 'differs',
      kids: ['differs · runs ', commitLetter(E.obsC) ?? '?', ', expected ', commitLetter(E.expC) ?? '?'],
      title: cmp.reason,
    };
  else if (cmp?.result === 'match') run = { tone: 'ok', text: 'matches', kids: ['matches ', commitLetter(E.obsC ?? E.expC)], title: cmp.reason };
  else run = { tone: 'unknown', text: 'unknown', kids: 'unknown', title: cmp?.reason ?? (obs?.kind === 'unknown' ? obs.reason : 'No runtime comparison') };
  let test: EnvFacts['test'];
  if (t) {
    const cur = t.current;
    const c = cur ? E.curC : E.tC;
    const name = versionParts(cur ? cur.version : t.target);
    const nm = name.tag ?? name.version ?? name.branch;
    test = {
      tone: TEST_TONE[t.outcome],
      text: TEST_TEXT[t.outcome],
      kids: [
        TEST_TEXT[t.outcome],
        // The commit marker stays beside its version (one unit that may wrap only inside the name).
        c || nm ? [' · for ', h('span', { class: 'vpair' }, nm ? h('span', { class: 'mono' }, nm) : null, commitLetter(c))] : t.target ? null : ' · no target',
      ],
      title: t.reason,
    };
  } else {
    const txt = E.env ? `legacy ${E.env.application_test}` : 'no evidence';
    test = { tone: 'unknown', text: txt, kids: txt, title: 'No version-bound test evidence' };
  }
  return {
    dep: {
      tone: dep ? statusTone(dep.d.status) : 'unknown',
      text: depText,
      c: dep?.c ?? null,
      title: dep ? `${dep.d.source}. Deployed ref ${dep.d.ref}${rel ? `; ${rel.text}` : ''}` : 'No GitLab deployment record for this environment',
    },
    job: job
      ? {
          tone: statusTone(job.j.status),
          text: `${job.j.name} ${STATUS[job.j.status][2].toLowerCase()}`,
          short: STATUS[job.j.status][2].toLowerCase(),
          title: 'Operator-classified deploy job; a job is not a deployment record',
        }
      : { tone: 'unknown', text: 'not classified', short: 'not classified', title: 'No job is classified as this environment’s deploy job' },
    run,
    test,
    rel,
  };
}

function stepEnv(P: Proc, def: EnvDef, detail: boolean): Step {
  const E = P.envs.get(def.name);
  if (!E) return emptyStep(`${def.label} is not configured for this project`);
  const F = envFacts(P, E);
  const fact = (label: string, t: Tone, value: Kid, title: string): HTMLElement =>
    h(
      'li',
      { class: `envf-r t-${t}`, title },
      h('span', { class: 'envf-l' }, label),
      h('span', { class: 'envf-v' }, h('span', { class: 'fl-dot', 'aria-hidden': 'true' }), h('span', null, value)),
    );
  // The environment name opens the item at this environment (runtime read,
  // manual test); on the item page itself it is plain text.
  const heading = detail
    ? h('span', { class: 'strong' }, def.label)
    : h(
        'a',
        {
          class: 'strong',
          href: to(itemHref(P.it.identity)),
          title: `${def.label}: details, runtime read and manual test`,
          onclick: () => {
            S.focusTarget = `env:${wkStr(P.it.identity)}:${def.name}`;
          },
        },
        def.label,
      );
  const hasRecord = !!E.test?.current;
  const body = h(
    'ul',
    { class: 'envf', 'aria-label': `${def.label}: four separate facts` },
    fact('Deployed', F.dep.tone, h('span', { class: 'vpair' }, F.dep.text, commitLetter(F.dep.c)), F.dep.title),
    fact('Deploy job', F.job.tone, F.job.text, F.job.title),
    fact('Running', F.run.tone, F.run.kids, F.run.title),
    fact('Tested', F.test.tone, F.test.kids, F.test.title),
  );
  const head = h(
    'div',
    { class: 'fl-main' },
    icon('deploy', 'sm'),
    heading,
    h('span', { class: 'muted fl-sub' }, def.refSource ? `${def.refSource} ref` : 'ref source not configured'),
    detail || !E.env
      ? null
      : h(
          'button',
          {
            class: 'btn sm ghost envf-act',
            type: 'button',
            'data-fk': `rt-${wkStr(P.it.identity)}-${def.name}`,
            title: `Open #${P.it.identity.issue.value} at ${def.label}: exact-version manual test, history and runtime read`,
            onclick: () => openEnv(P, def.name),
          },
          icon('test', 'sm'),
          hasRecord ? 'Test result' : 'Record test',
        ),
  );
  const basis: Basis = E.deps[0] && (E.deps[0].br || E.deps[0].tg) ? 'ref' : 'none';
  const dot = (short: string, t: Tone, value: Kid): HTMLElement =>
    h('span', { class: `sp-f t-${t}` }, h('span', { class: 'sp-dot', 'aria-hidden': 'true' }), h('span', null, `${short} `, value));
  // Equal outcomes do not make identities equal. Even the folded row keeps
  // each item's observed runtime and exact test target visible.
  const observed = E.env?.observation.kind === 'observed' ? E.env.observation.value : null;
  const tested = E.test?.current?.version ?? E.test?.target ?? null;
  const testCommit = E.test?.current ? E.curC : E.tC;
  const deployment = E.deps[0] ?? null;
  return {
    basis,
    nodes: [processNode(basis, [head, body])],
    line: h(
      'div',
      { class: 'fl-line-f' },
      dot('Deployed', F.dep.tone, [F.dep.text, deployment ? [' ', h('span', { class: 'mono' }, deployment.d.ref), ' ', commitEl(deployment.c)] : null]),
      dot('Job', F.job.tone, F.job.text),
      dot('Running', F.run.tone, [F.run.text, observed ? [' ', versionIds(observed), ' ', commitEl(E.obsC, 'SHA unknown')] : null]),
      dot('Tested', F.test.tone, [F.test.text, tested ? [' · for ', versionIds(tested), ' ', commitEl(testCommit, 'SHA unknown')] : null]),
    ),
    outcome: `${E.deps[0]?.d.status ?? (E.env ? 'none' : 'absent')}|${F.job.short}|${F.run.text}|${F.test.text}`,
    pill: {
      tone: 'neutral',
      text: def.label,
      title: `${def.label}: deployment record ${F.dep.text}${F.rel ? ` (${F.rel.text})` : ''}; deploy job ${F.job.text}; running ${F.run.text}; test ${F.test.text}`,
      dots: [
        { tone: F.dep.tone, short: 'Dep', mark: F.rel?.mark ?? null, label: `deployment record ${F.dep.text}${F.rel ? `, ${F.rel.text}` : ''}` },
        { tone: F.job.tone, short: 'Job', mark: null, label: `deploy job ${F.job.text}` },
        { tone: F.run.tone, short: 'Run', mark: null, label: `running version ${F.run.text}` },
        { tone: F.test.tone, short: 'Test', mark: null, label: `manual test ${F.test.text}` },
      ],
    },
  };
}

function stepTag(P: Proc): Step {
  const list = P.tags;
  if (!list.length) return emptyStep('No tag linked');
  const nodes: Kid[] = list.slice(0, MAX).map((x) => {
    const heads = x.sameAs.map((y) => y.b.name).join(', ');
    return processNode(x.sameAs.length ? 'cand' : 'none', [
      h(
        'div',
        { class: 'fl-main' },
        icon('tag', 'sm'),
        h('span', { class: 'mono strong' }, x.t.name),
        ev(P, 'tag', x.t.name, x.t.association, [
          x.sameAs.length ? h('p', null, h('strong', null, 'Candidate only. '), `Same commit as the ${heads} head; equal SHA is not branch lineage.`) : null,
        ]),
        x.sameAs.length
          ? h('span', { class: 'chip cand', title: `Same commit as the ${heads} head; equal SHA is not branch lineage` }, 'candidate')
          : h('span', { class: 'muted fl-sub' }, 'not a branch head'),
      ),
    ]);
  });
  nodes.push(more(list.length - MAX, to(itemHref(P.it.identity)), 'tag'));
  // The one-line form keeps the same qualifier as the full step: equal SHA
  // with a branch head is a candidate, never a confirmed association.
  const first = list[0] ?? null;
  const overrides = list.filter((x) => x.t.association.origin === 'operator_override');
  const override = overrides[0] ?? null;
  const cands = list.filter((x) => x.sameAs.length).length;
  const candNote = 'Same commit as a listed branch head; equal SHA is not branch lineage';
  let qual: Kid;
  if (list.length > 1)
    qual = cands ? h('span', { class: 'chip cand', title: candNote }, `${cands} candidate`) : h('span', { class: 'muted fl-sub' }, 'not branch heads');
  else
    qual = first?.sameAs.length ? h('span', { class: 'chip cand', title: candNote }, 'candidate') : h('span', { class: 'muted fl-sub' }, 'not a branch head');
  return {
    basis: list.some((x) => x.sameAs.length) ? 'cand' : 'none',
    nodes,
    line: h(
      'div',
      { class: 'fl-main' },
      icon('tag', 'sm'),
      h('span', { class: 'mono' }, list.length > 1 ? `${list.length} tags` : (first?.t.name ?? '')),
      overrides.length > 1
        ? h(
            'span',
            { class: 'chip st t-manual', title: `Operator overrides: ${overrides.map((x) => x.t.name).join(', ')}. Open row evidence for their reasons.` },
            `${overrides.length} overrides`,
          )
        : override
          ? ev(P, 'tag', override.t.name, override.t.association, [h('p', null, 'Tag: ', h('code', null, override.t.name))])
          : null,
      qual,
    ),
    outcome: list.map((x) => (x.sameAs.length ? 'candidate' : 'tag')).join(','),
    pill: { tone: 'neutral', text: list.length > 1 ? `${list.length} tags` : (list[0]?.t.name ?? ''), title: list.map((x) => x.t.name).join(', ') },
  };
}

function emptyStep(text: string, hint: string | null = null, unknown = false): Step {
  const body = h('span', { class: unknown ? 'muted unk' : 'muted', title: hint }, text);
  return {
    basis: 'none',
    nodes: [processNode('empty', [body])],
    line: h('span', { class: 'muted' }, text),
    outcome: `none:${text}`,
    pill: { tone: 'unknown', text: 'none', title: hint ? `${text}. ${hint}` : text },
  };
}

// detail: rendering on the item's own page (environment names are not links to it).
function runRow(P: Proc, r: Row, detail = false): Step {
  switch (r.id) {
    case 'branch':
      return stepBranch(P);
    case 'mr':
      return stepMr(P);
    case 'pipeline':
      return pipeStep(
        P,
        P.pipes.filter((x) => x.kind !== 'tag'),
        'No branch or MR pipeline',
        false,
      );
    case 'publish':
      return stepPublish(P);
    case 'tag':
      return stepTag(P);
    case 'tagpipe':
      return pipeStep(
        P,
        P.pipes.filter((x) => x.kind === 'tag'),
        P.tags.length ? 'No pipeline on a tag ref' : 'No tag, so no tag pipeline',
        true,
      );
    case 'env':
      return r.env ? stepEnv(P, r.env, detail) : emptyStep('—');
  }
}

// Flow rows in reading order, limited to the fields the user shows (the
// same field selection as the Detailed view).
function flowRows(cols: readonly string[], envs: readonly EnvDef[]): Row[] {
  const has = (...c: string[]): boolean => c.some((x) => cols.includes(x));
  const env = (e: EnvDef): Row => ({
    id: 'env',
    key: `env:${e.name}`,
    env: e,
    label: e.label,
    icon: 'deploy',
    hint: `${e.label}: deployment record, configured deploy job, running version and manual application test, each shown separately`,
  });
  const row = (id: Exclude<RowId, 'env'>, label: string, ico: IconName, hint: string): Row => ({ id, key: id, env: null, label, icon: ico, hint });
  const rows: Row[] = [];
  if (has('branch')) rows.push(row('branch', 'Branch', 'branch', 'Branches linked to the work item and their rebase state'));
  if (has('mr')) rows.push(row('mr', 'Merge request', 'mr', 'Merge requests, their state and target'));
  if (has('pipeline', 'jobs')) rows.push(row('pipeline', 'Pipeline & jobs', 'pipeline', 'Newest branch or MR pipeline per ref with failed or important jobs'));
  if (has('publish')) rows.push(row('publish', 'Publish', 'publish', 'Published artifact evidence (e.g. Nexus) by pipeline and job ID'));
  rows.push(...envs.filter((e) => e.refSource === 'branch').map(env));
  if (has('ref')) {
    rows.push(row('tag', 'Tag', 'tag', 'Tags; equal SHA with a branch is only a candidate link'));
    rows.push(row('tagpipe', 'Tag pipeline', 'pipeline', 'Newest pipeline on each tag ref'));
  }
  rows.push(...envs.filter((e) => e.refSource === 'tag').map(env));
  rows.push(...envs.filter((e) => e.refSource === null).map(env));
  return rows;
}

/* ------------------------------------------------------------- board */

export interface FlowBoardOpts {
  readonly id: string;
  readonly label: string;
  readonly recs: readonly ItemView[];
  readonly ui: ListUi;
  readonly head: (v: ItemView) => Kid;
  readonly empty: HTMLElement;
  /** Expansion state key ("work_items" or "compare"). */
  readonly board: string;
  /** Compare: rows whose outcomes are equal for every item read as one line each. */
  readonly compare: boolean;
}

// Desktop columns: one column per work item, flow steps as aligned rows (a
// table, so each step lines up across the adjacent items). Rows orientation
// and narrow screens use one compact strip per item instead.
export function flowBoard(o: FlowBoardOpts): Kid {
  if (!o.recs.length) return o.empty;
  const envs = visibleEnvs(o.recs, o.ui.columns, scopeProjects());
  const rows = flowRows(o.ui.columns, envs);
  const keys = rows.map((r) => r.key);
  const procs = o.recs.map((v) => processOf(v));
  if (o.ui.orientation === 'rows' || mobileQuery.matches) {
    return h(
      'ul',
      { class: 'strips', 'aria-label': `${o.label} (overview, one strip per item)` },
      o.recs.map((v, i) => {
        const P = procs[i];
        return h(
          'li',
          { class: `strip${v.hidden ? ' is-hidden' : ''}` },
          h('div', { class: 'strip-h' }, o.head(v), attentionLine(v, 3, true)),
          P ? stripSteps(P, rows) : null,
        );
      }),
    );
  }
  const steps = rows.map((r) => procs.map((P) => runRow(P, r)));
  // Equal outcomes are folded into one line per item, never hidden: each
  // item's own version/ref stays visible and the evidence still opens.
  const same = rows.map((_, i) => {
    const outs = (steps[i] ?? []).map((s) => s.outcome);
    return o.compare && outs.length > 1 && outs.every((x) => x === outs[0]);
  });
  const wrap = h('div', { class: 'mx-wrap', tabindex: '0', role: 'region', 'aria-label': `${o.label} (overview)`, 'data-scroll': o.id });
  wrap.append(
    h(
      'table',
      { class: 'mx inv proc flowt' },
      h('caption', { class: 'sr' }, `${o.label}: overview, one column per work item, read top to bottom; each row opens its evidence`),
      h(
        'thead',
        null,
        h(
          'tr',
          null,
          h('th', { class: 'rh corner', scope: 'col' }, h('span', { class: 'muted' }, 'Flow')),
          o.recs.map((v) => h('th', { class: `colh${v.hidden ? ' is-hidden' : ''}`, scope: 'col' }, o.head(v), attentionLine(v, 3, true))),
        ),
      ),
      h(
        'tbody',
        null,
        rows.map((r, i) => {
          const open = isOpen(o.board, r.key);
          const folded = same[i] === true;
          return h(
            'tr',
            { class: `fr-${r.id}${folded ? ' same' : ''}${open ? ' open' : ''}` },
            h(
              'th',
              { class: 'rh', scope: 'row' },
              rowToggle(o.board, r, keys),
              folded
                ? h(
                    'span',
                    { class: 'same-l', title: 'Every compared item has the same outcome here. Versions, refs and commits may still differ.' },
                    'Same outcome; versions may differ',
                  )
                : o.compare && procs.length > 1
                  ? h('span', { class: 'diff-l' }, 'Differs')
                  : null,
            ),
            procs.map((P, j) => {
              const s = steps[i]?.[j];
              if (!s) return h('td', { class: 'stage lk-none' });
              return h(
                'td',
                { class: `stage lk-${s.basis}` },
                folded && !open ? processNode(s.basis, [s.line]) : s.nodes,
                open ? evidenceFor(P, r, false) : null,
              );
            }),
          );
        }),
      ),
    ),
  );
  return mxFrame(wrap, o.label);
}

// Step pills in a contained grid read left to right, row by row. A connector
// is drawn only between pills on the same grid row: the e-d/e-5/e-3/e-2
// classes mark the last pill of a row for the wide (up to 9 columns), 5-, 3-
// and 2-column layouts, so no connector points past a line end. An
// environment pill opens the item at that environment (manual test there).
const STRIP_COLS = 9;
function stripSteps(P: Proc, rows: readonly Row[]): HTMLElement {
  const cols = Math.max(1, Math.min(rows.length, STRIP_COLS));
  const last = rows.length - 1;
  const end = (i: number, n: number): boolean => i === last || i % n === n - 1;
  const ol = h(
    'ol',
    { class: 'sp-chain', 'aria-label': `Delivery flow of #${P.it.identity.issue.value}` },
    rows.map((r, i) => {
      const s = runRow(P, r);
      const p = s.pill;
      const ends = `${end(i, cols) ? ' e-d' : ''}${end(i, 5) ? ' e-5' : ''}${end(i, 3) ? ' e-3' : ''}${end(i, 2) ? ' e-2' : ''}`;
      const content: Kid[] = [
        h('span', { class: 'sp-l' }, icon(r.icon, 'xs'), r.label),
        p.dots
          ? h(
              'span',
              { class: 'sp-dots' },
              p.dots.map((d) =>
                h(
                  'span',
                  { class: `sp-f t-${d.tone}`, title: d.label },
                  h('span', { class: 'sp-dot', 'aria-hidden': 'true' }),
                  h('span', { class: 'sp-fl', 'aria-hidden': 'true' }, d.mark ? `${d.short} ${d.mark}` : d.short),
                  h('span', { class: 'sr' }, d.label),
                ),
              ),
            )
          : h('span', { class: 'sp-v' }, p.text),
      ];
      const env = r.env;
      return h(
        'li',
        { class: `sp lk-${s.basis} t-${p.tone}${p.text === 'none' ? ' sp-none' : ''}${ends}`, title: p.title },
        env && P.envs.has(env.name)
          ? h(
              'button',
              {
                class: 'sp-btn',
                type: 'button',
                'data-fk': `sp-${wkStr(P.it.identity)}-${env.name}`,
                'aria-label': `${p.title}. Open ${env.label}: manual test and runtime`,
                onclick: () => openEnv(P, env.name),
              },
              content,
            )
          : content,
      );
    }),
  );
  ol.style.setProperty('--n', String(cols));
  return ol;
}

/** One step of a resource card's vertical flow (merge request, branch, pipeline). */
export interface CardStep {
  readonly label: string;
  readonly icon: IconName;
  readonly basis: Basis;
  readonly body: Kid;
}

export function cardFlow(label: string, steps: readonly CardStep[]): HTMLElement {
  return h(
    'ol',
    { class: 'vc-flow', 'aria-label': label },
    steps.map((s) =>
      h('li', { class: `vc-step lk-${s.basis}` }, h('span', { class: 'vc-l' }, icon(s.icon, 'xs'), s.label), h('div', { class: 'vc-b' }, s.body)),
    ),
  );
}

/** Overview of one item (detail screen): every configured environment, each row opens its evidence. */
export function itemFlow(v: ItemView): HTMLElement {
  const P = processOf(v);
  const rows = flowRows(['branch', 'mr', 'pipeline', 'jobs', 'publish', 'ref'], P.envDefs);
  const keys = rows.map((r) => r.key);
  const board = 'item';
  return h(
    'ol',
    { class: 'lane flow-lane', 'aria-label': 'Delivery flow, read top to bottom; each step opens its evidence' },
    rows.map((r) => {
      const s = runRow(P, r, true);
      const open = isOpen(board, r.key);
      return h(
        'li',
        { class: `lane-step lk-${s.basis}${open ? ' open' : ''}` },
        h('div', { class: 'lane-label', title: r.hint }, rowToggle(board, r, keys)),
        h('div', { class: 'lane-body' }, s.nodes, open ? evidenceFor(P, r, true) : null),
      );
    }),
  );
}
