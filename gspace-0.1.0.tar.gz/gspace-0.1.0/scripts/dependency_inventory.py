"""Offline recursive lock/installed/bundled license evidence; no package imports or downloads."""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
import tomllib
from collections import defaultdict
from email.parser import BytesParser
from pathlib import Path
from typing import Literal
from zipfile import ZipFile

from packaging.licenses import InvalidLicenseExpression, canonicalize_license_expression
from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, model_validator

ROOT = Path(__file__).resolve().parents[1]
MAX_FILE = 8 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
MAX_RECORD_FILE = 256 * 1024 * 1024
MAX_RECORD_TOTAL = 1024 * 1024 * 1024
MAX_RECORD_ENTRIES = 50000
MAX_ARCHIVE_COMPRESSED = 128 * 1024 * 1024
MAX_ARCHIVE_FILE = 256 * 1024 * 1024
MAX_ARCHIVE_TOTAL = 512 * 1024 * 1024
MAX_ARTIFACT_TOTAL = 1024 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 50000
LICENSE_NAME = re.compile(
    r"(?:^|[._ -])(?:licen[cs]e|copying|copyright|notice|authors|"
    r"third[-_ ]?party(?:notices)?)(?:$|[._ -])",
    re.I,
)
SOURCE_SUFFIXES = {
    ".js",
    ".mjs",
    ".cjs",
    ".ts",
    ".tsx",
    ".jsx",
    ".py",
    ".pyi",
    ".pyc",
    ".c",
    ".cc",
    ".cpp",
    ".h",
    ".hpp",
    ".rs",
    ".go",
    ".rb",
    ".sh",
    ".ps1",
    ".bat",
    ".cmd",
    ".json",
    ".map",
    ".png",
    ".jpg",
    ".svg",
    ".woff",
    ".woff2",
    ".so",
    ".dylib",
    ".dll",
    ".exe",
    ".node",
}
DISTRIBUTED_ASSETS = (
    "index.html",
    "app.js",
    "theme.js",
    "styles.css",
    "gspace-wolf.svg",
    "gspace-wolf-gray.svg",
    "icon.svg",
)
JSON_OBJECT = TypeAdapter(dict[str, object])


class DTO(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)


class BomComponent(DTO):
    name: str
    version: str
    reference: str = Field(alias="bom-ref")
    purl: str


class BomEdge(DTO):
    ref: str
    dependencies: tuple[str, ...] = Field(default=(), alias="dependsOn")


class Bom(DTO):
    components: tuple[BomComponent, ...]
    dependencies: tuple[BomEdge, ...]


class NpmPackage(DTO):
    name: str | None = None
    version: str | None = None
    resolved: str | None = None
    integrity: str | None = None
    license: object = None
    dependencies: dict[str, str] = Field(default_factory=dict)
    optionalDependencies: dict[str, str] = Field(default_factory=dict)
    peerDependencies: dict[str, str] = Field(default_factory=dict)
    devDependencies: dict[str, str] = Field(default_factory=dict)
    dev: bool = False
    optional: bool = False
    os: tuple[str, ...] = ()
    cpu: tuple[str, ...] = ()


class NpmLock(DTO):
    lockfileVersion: int
    packages: dict[str, NpmPackage]


class Evidence(DTO):
    source: str
    raw: str
    interpretation: Literal[
        "declared_expression", "legacy_statement", "classifier", "package_field"
    ]


class TextRef(DTO):
    component: str
    occurrence: str
    path: str
    sha256: str
    size: int
    provenance: Literal[
        "python_RECORD", "npm_package_tree", "npm_artifact", "declared_file", "official_publisher"
    ]


class OfficialRecord(DTO):
    """Previously acquired publisher evidence; collection never dereferences its URL."""

    components: tuple[str, ...] = Field(min_length=1)
    source_url: str
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    file: str = Field(pattern=r"^[a-f0-9]{64}$")
    original_path: str
    provenance: str
    declarations: tuple[Evidence, ...] = ()

    @model_validator(mode="after")
    def checksum_filename(self) -> OfficialRecord:
        if self.file != self.sha256 or len(set(self.components)) != len(self.components):
            raise ValueError("Publisher evidence filename/identity differs from checksum")
        return self


class OfficialManifest(DTO):
    records: tuple[OfficialRecord, ...]


class RecordIntegrity(DTO):
    scope: Literal["installed RECORD entries; unrecorded files excluded"] = (
        "installed RECORD entries; unrecorded files excluded"
    )
    record_sha256: str
    verified_hashes: int
    verified_bytes: int
    unhashed_entries: int
    complete: bool


class ArtifactFile(DTO):
    sha256: str
    size: int


class NpmIntegrity(DTO):
    artifact_sha256: str
    artifact_size: int
    source_files: dict[str, ArtifactFile]
    installed_tree_verified: bool
    verified_installed_files: int
    verified_installed_bytes: int
    generated_exclusions: tuple[str, ...] = ()
    normalized_tar_aliases: tuple[str, ...] = ()


class Component(DTO):
    id: str
    ecosystem: Literal["python", "npm"]
    name: str
    version: str
    source: str | None
    integrity: str | None
    occurrence: str
    installed: bool
    installation_evidence: str | None
    scopes: tuple[str, ...]
    license_evidence: tuple[Evidence, ...]
    texts: tuple[TextRef, ...]
    requires_raw: tuple[str, ...] = ()
    gaps: tuple[str, ...] = ()
    record_integrity: RecordIntegrity | None = None
    npm_integrity: NpmIntegrity | None = None


class Edge(DTO):
    source: str
    target: str | None
    declared_name: str
    requirement: str
    kind: Literal["locked", "dependency", "optional", "peer", "dev_root"]


class BundledFile(DTO):
    component: str
    source_path: str
    source_sha256: str
    accepted_validator_sha256: str
    distributed_app_sha256: str
    evidence: Literal["two_stage_rebuild_byte_match"] = "two_stage_rebuild_byte_match"


class MetafileProof(DTO):
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    inputs: tuple[str, ...]


class BuildProof(DTO):
    app_matches_served: bool
    validator_matches_accepted_input: bool
    accepted_validator_sha256: str
    app_sha256: str
    inputs: dict[str, str] = Field(default_factory=dict)
    validator_input: str = "frontend-new/contracts/schema-validation.js"
    app_metafile: MetafileProof | None = Field(default=None, alias="accepted-app.metafile.json")
    validator_metafile: MetafileProof | None = Field(
        default=None, alias="accepted-validator.metafile.json"
    )


class BuildInput(DTO):
    bytes: int
    sha256: str | None = None


class Metafile(DTO):
    inputs: dict[str, BuildInput]


class BuildComponent(DTO):
    name: str
    version: str
    metadata_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    record_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")


class WheelProof(DTO):
    path: str
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    members: dict[str, str]


class PythonBuildProof(DTO):
    input_sha256: dict[str, str]
    build_group: Literal["build"]
    build_isolation: Literal["locked_uv_environment"]
    components: tuple[BuildComponent, ...]
    python_version: str
    interpreter_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    uv_version: str
    wheel: WheelProof
    sdist: WheelProof | None = None


class PackagedNotice(DTO):
    name: str
    version: str
    file: str
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    publisher_source: str
    scope: Literal["browser_bundled"]
    license: str


class NoticeManifest(DTO):
    components: tuple[PackagedNotice, ...]


class PackagedText(DTO):
    component: str
    member: str
    sha256: str
    wheel_sha256: str


class Inventory(DTO):
    components: tuple[Component, ...]
    edges: tuple[Edge, ...]
    input_sha256: dict[str, str]
    assets: dict[str, str]
    gaps: tuple[str, ...]
    bundled: tuple[BundledFile, ...] = ()
    official_sources: tuple[OfficialRecord, ...] = ()
    build_provenance: PythonBuildProof | None = None
    packaged_texts: tuple[PackagedText, ...] = ()
    first_party_license: Literal["undeclared_by_owner"] = "undeclared_by_owner"

    @model_validator(mode="after")
    def identities(self) -> Inventory:
        ids = {component.id for component in self.components}
        if len(ids) != len(self.components):
            raise ValueError("Duplicate component instance identity")
        if any(edge.target is not None and edge.target not in ids for edge in self.edges):
            raise ValueError("Dependency edge target is not inventoried")
        if any(text.component != c.id for c in self.components for text in c.texts):
            raise ValueError("License attribution identity differs from component")
        if any(binding.component not in ids for binding in self.bundled):
            raise ValueError("Bundled source component is not inventoried")
        if any(key not in ids for record in self.official_sources for key in record.components):
            raise ValueError("Publisher attribution component is not inventoried")
        if any(text.component not in ids for text in self.packaged_texts):
            raise ValueError("Packaged notice component is not inventoried")
        return self


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def declaration_gaps(evidence: list[Evidence], *, compare_sources: bool = False) -> list[str]:
    """Validate expressions without selecting an OR branch or inferring text terms."""
    gaps: list[str] = []
    declarations: dict[str, set[str]] = defaultdict(set)
    for item in evidence:
        if item.interpretation not in ("declared_expression", "package_field"):
            continue
        try:
            expression = canonicalize_license_expression(item.raw)
        except InvalidLicenseExpression:
            gaps.append(f"Unknown or non-SPDX declaration requires review: {item.source}")
        else:
            declarations[item.source].add(expression)
    if any(len(values) > 1 for values in declarations.values()):
        gaps.append("Conflicting declarations in one metadata source")
    expressions = {expression for values in declarations.values() for expression in values}
    if compare_sources and len(expressions) > 1:
        gaps.append("Conflicting SPDX license declarations: " + "; ".join(sorted(expressions)))
    return gaps


def is_license_text(name: str) -> bool:
    """Select notice filenames, retaining bundle.js.LICENSE but excluding license.js."""
    return Path(name).suffix.lower() not in SOURCE_SUFFIXES and bool(LICENSE_NAME.search(name))


def evidence_path(path: Path, boundary: Path, size_limit: int = MAX_FILE) -> Path:
    # Explicit roots may use macOS /tmp; package paths cannot escape through links.
    absolute, base = path.absolute(), boundary.absolute()
    if not absolute.is_relative_to(base):
        raise ValueError("Evidence path is outside its declared root")
    relative = absolute.relative_to(base)
    if ".." in relative.parts:
        raise ValueError("Evidence traversal is not allowed")
    current = base
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError("Symlink evidence is not allowed")
    if not absolute.resolve().is_relative_to(base.resolve()):
        raise ValueError("Resolved evidence escaped its root")
    if not path.is_file() or path.stat().st_size > size_limit:
        raise ValueError("Evidence file absent or exceeds size limit")
    return path


def read_bounded(path: Path, boundary: Path, size_limit: int | None = None) -> bytes:
    limit = MAX_FILE if size_limit is None else size_limit
    evidence_path(path, boundary, limit)
    payload = path.read_bytes()
    if len(payload) > limit:
        raise ValueError("Evidence file grew beyond size limit")
    return payload


def verify_python_record(
    info: Path, site: Path
) -> tuple[RecordIntegrity | None, list[str], list[list[str]]]:
    """Hash recorded files without importing packages or trusting RECORD paths."""
    record = info / "RECORD"
    if not record.is_file():
        return None, ["Installed distribution has no RECORD"], []
    body = read_bounded(record, site)
    rows = list(csv.reader(io.StringIO(body.decode("utf-8"))))
    if len(rows) > MAX_RECORD_ENTRIES:
        raise ValueError("Installed RECORD entry limit exceeded")
    # Wheel entrypoints commonly live in ../../../bin inside this same virtualenv.
    boundary = (
        site.parents[2]
        if site.name == "site-packages" and site.parent.parent.name in {"lib", "lib64"}
        else site
    )
    verified = total = unhashed = 0
    gaps: list[str] = []
    seen: set[str] = set()
    for row in rows:
        if len(row) != 3 or not row[0]:
            gaps.append("Malformed installed RECORD entry")
            continue
        name, expected_hash, expected_size = row
        try:
            if name in seen:
                raise ValueError("Duplicate RECORD path")
            seen.add(name)
            if Path(name).is_absolute() or "\\" in name:
                raise ValueError("Absolute or non-portable RECORD path")
            path = Path(os.path.abspath(site / name))
            evidence_path(path, boundary, MAX_RECORD_FILE)
            size = path.stat().st_size
            if expected_size and (not expected_size.isdecimal() or int(expected_size) != size):
                gaps.append(f"RECORD size mismatch: {name}")
            if not expected_hash:
                unhashed += 1
                if path != record and path.suffix != ".pyc":
                    gaps.append(f"RECORD entry has no hash: {name}")
                continue
            algorithm, separator, encoded = expected_hash.partition("=")
            if not separator or algorithm not in {"sha256", "sha384", "sha512"}:
                raise ValueError("Unsupported or malformed RECORD hash")
            if not re.fullmatch(r"[A-Za-z0-9_-]+", encoded):
                raise ValueError("Malformed RECORD digest")
            if total + size > MAX_RECORD_TOTAL:
                raise ValueError("Installed RECORD byte limit exceeded")
            hasher = hashlib.new(algorithm)
            count = 0
            with path.open("rb") as stream:
                while chunk := stream.read(1024 * 1024):
                    count += len(chunk)
                    if count > MAX_RECORD_FILE or total + count > MAX_RECORD_TOTAL:
                        raise ValueError("Installed RECORD file grew beyond size limit")
                    hasher.update(chunk)
            total += count
            actual = base64.urlsafe_b64encode(hasher.digest()).rstrip(b"=").decode("ascii")
            if actual != encoded:
                gaps.append(f"RECORD hash mismatch: {name}")
            elif count != size:
                gaps.append(f"RECORD file changed during hashing: {name}")
            else:
                verified += 1
        except (OSError, ValueError) as error:
            gaps.append(f"RECORD file rejected: {name}: {error}")
    if not rows:
        gaps.append("Installed RECORD is empty")
    if digest(read_bounded(record, site)) != digest(body):
        gaps.append("Installed RECORD changed during verification")
    return (
        RecordIntegrity(
            record_sha256=digest(body),
            verified_hashes=verified,
            verified_bytes=total,
            unhashed_entries=unhashed,
            complete=not gaps,
        ),
        gaps,
        rows,
    )


class TextCollector:
    def __init__(self) -> None:
        self.blobs: dict[str, bytes] = {}
        self.total: int = 0

    def add(
        self,
        component: str,
        occurrence: str,
        path: Path,
        boundary: Path,
        provenance: Literal[
            "python_RECORD",
            "npm_package_tree",
            "npm_artifact",
            "declared_file",
            "official_publisher",
        ],
    ) -> TextRef:
        payload = read_bounded(path, boundary)
        return self.add_payload(
            component, occurrence, path.relative_to(boundary).as_posix(), payload, provenance
        )

    def add_payload(
        self,
        component: str,
        occurrence: str,
        path: str,
        payload: bytes,
        provenance: Literal[
            "python_RECORD",
            "npm_package_tree",
            "npm_artifact",
            "declared_file",
            "official_publisher",
        ],
    ) -> TextRef:
        if len(payload) > MAX_FILE:
            raise ValueError("License evidence exceeds size limit")
        if not payload.strip() or b"\x00" in payload:
            raise ValueError("License evidence is empty or contains binary bytes")
        try:
            payload.decode("utf-8")
        except UnicodeDecodeError as error:
            raise ValueError("License evidence is not UTF-8 text") from error
        checksum = digest(payload)
        if checksum not in self.blobs:
            self.total += len(payload)
            if self.total > MAX_TOTAL:
                raise ValueError("Total license text limit exceeded")
            self.blobs[checksum] = payload
        return TextRef(
            component=component,
            occurrence=occurrence,
            path=path,
            sha256=checksum,
            size=len(payload),
            provenance=provenance,
        )


def apply_official_evidence(
    components: list[Component], texts: TextCollector, manifest_path: Path
) -> tuple[list[Component], tuple[OfficialRecord, ...]]:
    """Supplement passive installed evidence without pretending absent packages are installed."""
    if not manifest_path.exists():
        return components, ()
    root = manifest_path.parent
    manifest = OfficialManifest.model_validate_json(read_bounded(manifest_path, root))
    indexed = {component.id: component for component in components}
    for record in manifest.records:
        if any(key not in indexed for key in record.components):
            raise ValueError("Publisher attribution component is not inventoried")
        path = root / record.file
        payload = read_bounded(path, root)
        if not payload.strip() or digest(payload) != record.sha256:
            raise ValueError("Publisher evidence checksum differs from manifest")
        for key in record.components:
            component = indexed[key]
            ref = texts.add(key, component.occurrence, path, root, "official_publisher")
            evidence = [*component.license_evidence, *record.declarations]
            resolved = {
                "No package license/NOTICE text available",
                "No npm license/NOTICE text available",
                "Locked package not installed on current platform; artifact license unavailable",
                "Locked npm instance not installed on current platform",
            }
            if evidence:
                resolved.update(
                    {
                        "No installed license declaration evidence",
                        "No npm license declaration evidence",
                    }
                )
            indexed[key] = Component.model_validate(
                {
                    **component.model_dump(),
                    "texts": (*component.texts, ref),
                    "license_evidence": tuple(evidence),
                    "gaps": tuple(
                        dict.fromkeys(
                            [
                                *(gap for gap in component.gaps if gap not in resolved),
                                *declaration_gaps(evidence, compare_sources=True),
                            ]
                        )
                    ),
                }
            )
    return [indexed[component.id] for component in components], manifest.records


def npm_name(path: str) -> str:
    return path.rsplit("node_modules/", 1)[-1]


def resolve_npm(owner: str, name: str, packages: dict[str, NpmPackage]) -> str | None:
    current = owner
    while True:
        candidate = f"{current}/node_modules/{name}" if current else f"node_modules/{name}"
        if candidate in packages:
            return candidate
        if not current:
            return None
        current = current.rsplit("/node_modules/", 1)[0] if "/node_modules/" in current else ""


def export_uv(destination: Path, runtime: bool, *, group: str | None = None) -> Bom:
    argv = [
        "/opt/homebrew/bin/uv",
        "export",
        "--locked",
        "--offline",
        "--no-config",
        "--no-cache",
        "--keyring-provider",
        "disabled",
        "--no-python-downloads",
        *(
            ["--only-group", group]
            if group is not None
            else ["--no-default-groups"]
            if runtime
            else ["--all-groups", "--all-extras"]
        ),
        "--format",
        "cyclonedx1.5",
        "--output-file",
        str(destination),
    ]
    subprocess.run(
        argv,
        cwd=ROOT,
        env={"PATH": "/opt/homebrew/bin:/usr/bin:/bin"},
        check=True,
        timeout=30,
        capture_output=True,
    )
    return Bom.model_validate_json(destination.read_bytes())


def collect_python(
    all_bom: Bom,
    runtime_bom: Bom,
    site: Path,
    texts: TextCollector,
    *,
    build_bom: Bom | None = None,
    development_bom: Bom | None = None,
) -> tuple[list[Component], list[Edge], list[str]]:
    runtime = {(normalize(c.name), c.version) for c in runtime_bom.components}
    build: set[tuple[str, str]] = (
        {(normalize(c.name), c.version) for c in build_bom.components} if build_bom else set()
    )
    development = (
        {(normalize(c.name), c.version) for c in development_bom.components}
        if development_bom is not None
        else {(normalize(c.name), c.version) for c in all_bom.components} - runtime - build
    )
    installed: dict[tuple[str, str], Path] = {}
    for metadata in sorted(site.glob("*.dist-info/METADATA")):
        message = BytesParser().parsebytes(read_bounded(metadata, site))
        name, version = message.get("Name"), message.get("Version")
        if name and version:
            key = normalize(name), version
            if key in installed:
                raise ValueError("Duplicate Python installed distribution identity")
            installed[key] = metadata
    components: list[Component] = []
    refs: dict[str, str] = {}
    locked = {(normalize(c.name), c.version) for c in all_bom.components}
    extra = sorted(f"{n}@{v}" for n, v in installed if (n, v) not in locked and n != "gspace")
    gaps = [f"Installed Python outside lock: {name}" for name in extra]
    for raw in sorted(all_bom.components, key=lambda c: (c.name, c.version)):
        identity = f"python:{normalize(raw.name)}@{raw.version}"
        refs[raw.reference] = identity
        metadata = installed.get((normalize(raw.name), raw.version))
        evidence: list[Evidence] = []
        licenses: list[TextRef] = []
        missing: list[str] = []
        requirements: tuple[str, ...] = ()
        occurrence = metadata.parent.name if metadata else "locked-not-installed"
        meta_hash: str | None = None
        record_integrity: RecordIntegrity | None = None
        if metadata:
            payload = read_bounded(metadata, site)
            meta_hash = digest(payload)
            message = BytesParser().parsebytes(payload)
            fields: tuple[
                tuple[str, Literal["declared_expression", "legacy_statement", "classifier"]], ...
            ] = (
                ("License-Expression", "declared_expression"),
                ("License", "legacy_statement"),
                ("Classifier", "classifier"),
            )
            for field, interpretation in fields:
                for value in message.get_all(field, []):
                    if field != "Classifier" or value.startswith("License ::"):
                        evidence.append(
                            Evidence(
                                source=f"METADATA:{field}", raw=value, interpretation=interpretation
                            )
                        )
            requirements = tuple(message.get_all("Requires-Dist", []))
            record_integrity, integrity_gaps, rows = verify_python_record(metadata.parent, site)
            missing.extend(integrity_gaps)
            for row in rows:
                if not row or not is_license_text(Path(row[0]).name):
                    continue
                path = site / row[0]
                try:
                    licenses.append(texts.add(identity, occurrence, path, site, "python_RECORD"))
                except ValueError as error:
                    missing.append(f"License file rejected: {row[0]}: {error}")
            for declared in message.get_all("License-File", []):
                candidates = (metadata.parent / "licenses" / declared, metadata.parent / declared)
                if not any(p.is_file() for p in candidates):
                    missing.append(f"Declared license file unavailable: {declared}")
        else:
            missing.append(
                "Locked package not installed on current platform; artifact license unavailable"
            )
        if not evidence:
            missing.append("No installed license declaration evidence")
        missing.extend(declaration_gaps(evidence))
        if not licenses:
            missing.append("No package license/NOTICE text available")
        components.append(
            Component(
                id=identity,
                ecosystem="python",
                name=raw.name,
                version=raw.version,
                source=raw.purl,
                integrity=None,
                occurrence=occurrence,
                installed=metadata is not None,
                installation_evidence=meta_hash,
                scopes=(
                    "locked",
                    *(("runtime",) if (normalize(raw.name), raw.version) in runtime else ()),
                    *(
                        ("development",)
                        if (normalize(raw.name), raw.version) in development
                        else ()
                    ),
                    *(("build",) if (normalize(raw.name), raw.version) in build else ()),
                ),
                license_evidence=tuple(evidence),
                texts=tuple(sorted(set(licenses), key=lambda t: t.path)),
                requires_raw=requirements,
                gaps=tuple(missing),
                record_integrity=record_integrity,
            )
        )
    edges: list[Edge] = []
    for row in all_bom.dependencies:
        owner = refs.get(row.ref)
        if owner is None:
            # uv root/application is not a third-party component; retain root edges.
            owner = "application:gspace"
        for target in row.dependencies:
            resolved = refs.get(target)
            edges.append(
                Edge(
                    source=owner,
                    target=resolved,
                    declared_name=target,
                    requirement="uv locked graph",
                    kind="locked",
                )
            )
            if resolved is None:
                gaps.append(f"Unresolved Python lock edge: {row.ref} -> {target}")
    return components, edges, gaps


def installed_npm_instances(root: Path) -> set[str]:
    found: set[str] = set()
    pending = [root / "node_modules"]
    while pending:
        folder = pending.pop()
        if not folder.is_dir():
            continue
        if folder.is_symlink():
            raise ValueError("Installed npm tree cannot be a symlink")
        entries: list[Path] = []
        for entry in sorted(folder.iterdir()):
            if entry.name.startswith(".") or not entry.is_dir():
                continue
            if entry.is_symlink():
                raise ValueError("Installed npm package cannot be a symlink")
            if entry.name.startswith("@"):
                entries.extend(sorted(entry.iterdir()))
            else:
                entries.append(entry)
        for entry in entries:
            if (entry / "package.json").is_file():
                read_bounded(entry / "package.json", root)
                found.add(entry.relative_to(root).as_posix())
                pending.append(entry / "node_modules")
                if len(found) > 4096:
                    raise ValueError("Installed npm instance bound exceeded")
    return found


class ArtifactBudget:
    def __init__(self) -> None:
        self.bytes = 0

    def add(self, size: int) -> None:
        self.bytes += size
        if self.bytes > MAX_ARTIFACT_TOTAL:
            raise ValueError("Combined artifact byte limit exceeded")


def inspect_tar_members(
    payload: bytes, budget: ArtifactBudget, *, forbidden_parts: frozenset[str] = frozenset()
) -> tuple[dict[str, ArtifactFile], dict[str, bytes], tuple[str, ...]]:
    """Read and hash bounded regular tar streams; never extract to the filesystem."""
    files: dict[str, ArtifactFile] = {}
    captured: dict[str, bytes] = {}
    names: set[str] = set()
    directories: set[str] = set()
    aliases: list[str] = []
    total = 0
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz") as archive:
        for count, member in enumerate(archive, 1):
            raw_name = member.name.rstrip("/")
            raw_parts = raw_name.split("/")
            parts = [part for part in raw_parts if part != "."]
            name = "/".join(parts)
            if (
                not name
                or any(p in {"", ".."} for p in raw_parts)
                or "\\" in name
                or Path(raw_name).is_absolute()
                or raw_name in names
                or not (member.isfile() or member.isdir())
                or member.issparse()
            ):
                raise ValueError(f"Unsafe tar member: {member.name}")
            if forbidden_parts.intersection(parts):
                raise ValueError(f"Source archive contains excluded paths: {member.name}")
            if count > MAX_ARCHIVE_MEMBERS:
                raise ValueError("Tar member limit exceeded")
            names.add(raw_name)
            if member.isdir():
                if name in files:
                    raise ValueError(f"Unsafe tar member: {member.name}")
                directories.add(name)
                continue
            if name in directories:
                raise ValueError(f"Unsafe tar member: {member.name}")
            if member.size < 0 or member.size > MAX_ARCHIVE_FILE:
                raise ValueError("Tar member exceeds size limit")
            total += member.size
            if total > MAX_ARCHIVE_TOTAL:
                raise ValueError("Tar uncompressed byte limit exceeded")
            budget.add(member.size)
            stream = archive.extractfile(member)
            if stream is None:
                raise ValueError("Tar regular member is unreadable")
            capture = Path(name).name == "package.json" or is_license_text(Path(name).name)
            retained = bytearray()
            hasher = hashlib.sha256()
            size = 0
            with stream:
                while chunk := stream.read(1024 * 1024):
                    size += len(chunk)
                    if size > member.size:
                        raise ValueError("Tar member grew beyond declared size")
                    hasher.update(chunk)
                    if capture:
                        if size > MAX_FILE:
                            raise ValueError("Captured tar metadata exceeds size limit")
                        retained.extend(chunk)
            if size != member.size:
                raise ValueError("Tar member size differs from its header")
            value = ArtifactFile(sha256=hasher.hexdigest(), size=size)
            if name in files and files[name] != value:
                raise ValueError(f"Conflicting normalized tar members: {name}")
            if name != raw_name:
                aliases.append(raw_name + " -> " + name)
            files[name] = value
            if capture:
                captured[name] = bytes(retained)
    if not files or any(
        parent.as_posix() in files
        for name in files
        for parent in Path(name).parents
        if parent.as_posix() != "."
    ):
        raise ValueError("Tar file/directory paths conflict or archive is empty")
    return files, captured, tuple(sorted(aliases))


def cached_sri_payload(integrity: str | None, cache: Path) -> bytes:
    """Look up exact digest-derived content only, without reading npm cache indexes/config."""
    candidates: list[tuple[int, str, bytes]] = []
    for token in (integrity or "").split():
        algorithm, separator, encoded = token.partition("-")
        if not separator or algorithm not in {"sha256", "sha384", "sha512"}:
            raise ValueError("Unsupported or malformed npm SRI declaration")
        try:
            checksum = base64.b64decode(encoded, validate=True)
        except ValueError as error:
            raise ValueError("Malformed npm SRI digest") from error
        size = hashlib.new(algorithm).digest_size
        if len(checksum) != size:
            raise ValueError("Malformed npm SRI digest length")
        candidates.append((size, algorithm, checksum))
    if not candidates:
        raise ValueError("No npm SRI artifact declaration")
    strongest = max(size for size, _, _ in candidates)
    for size, algorithm, expected in sorted(candidates, key=lambda row: (row[1], row[2])):
        if size != strongest:
            continue
        encoded = expected.hex()
        path = cache / algorithm / encoded[:2] / encoded[2:4] / encoded[4:]
        if not path.is_file():
            continue
        payload = read_bounded(path, cache, MAX_ARCHIVE_COMPRESSED)
        if hashlib.new(algorithm, payload).digest() != expected:
            raise ValueError("npm SRI digest mismatch in public artifact cache")
        return payload
    raise ValueError("npm SRI artifact unavailable in supplied public content cache")


def verify_npm_integrity(
    raw: NpmPackage,
    occurrence: str,
    toolchain: Path,
    cache: Path,
    locked_instances: set[str],
    texts: TextCollector,
    budget: ArtifactBudget,
) -> tuple[NpmIntegrity | None, list[str], list[TextRef]]:
    gaps: list[str] = []
    notices: list[TextRef] = []
    try:
        payload = cached_sri_payload(raw.integrity, cache)
        archived, captured, aliases = inspect_tar_members(payload, budget)
        roots = {name.split("/")[0] for name in archived}
        if len(roots) != 1 or any("/" not in name for name in archived):
            raise ValueError("npm artifact must contain one package root")
        prefix = next(iter(roots)) + "/"
        files = {name.removeprefix(prefix): value for name, value in archived.items()}
        package_json = captured.get(prefix + "package.json")
        if package_json is None:
            raise ValueError("npm artifact lacks root package.json")
        identity = NpmPackage.model_validate_json(package_json)
        if identity.name != npm_name(occurrence) or identity.version != raw.version:
            raise ValueError("npm artifact identity differs from lock")
        if raw.license is not None and identity.license != raw.license:
            gaps.append("Conflicting npm lock/artifact license declarations")
        component_id = f"npm:{npm_name(occurrence)}@{raw.version}#{occurrence}"
        for name, body in sorted(captured.items()):
            if is_license_text(Path(name).name):
                notices.append(
                    texts.add_payload(component_id, occurrence, name, body, "npm_artifact")
                )
        nested = {
            path.removeprefix(occurrence + "/")
            for path in locked_instances
            if path.startswith(occurrence + "/node_modules/")
        }

        def separately_locked(name: str) -> bool:
            return any(name == path or name.startswith(path + "/") for path in nested)

        expected = {name: value for name, value in files.items() if not separately_locked(name)}
        directory = toolchain / occurrence
        installed = (directory / "package.json").is_file()
        found: dict[str, ArtifactFile] = {}
        ignored: list[str] = []
        if installed:
            pending = [directory]
            total = 0
            while pending:
                for path in sorted(pending.pop().iterdir()):
                    name = path.relative_to(directory).as_posix()
                    if separately_locked(name):
                        continue
                    if (
                        nested
                        and name in {"node_modules/.bin", "node_modules/.package-lock.json"}
                        and not any(key == name or key.startswith(name + "/") for key in expected)
                    ):
                        ignored.append(name)
                        continue
                    if path.is_symlink():
                        raise ValueError(
                            f"Installed npm link is not source artifact evidence: {name}"
                        )
                    if path.is_dir():
                        pending.append(path)
                        continue
                    evidence_path(path, toolchain, MAX_ARCHIVE_FILE)
                    size = path.stat().st_size
                    total += size
                    if total > MAX_ARCHIVE_TOTAL or len(found) >= MAX_ARCHIVE_MEMBERS:
                        raise ValueError("Installed npm tree evidence limit exceeded")
                    hasher = hashlib.sha256()
                    count = 0
                    with path.open("rb") as stream:
                        while chunk := stream.read(1024 * 1024):
                            count += len(chunk)
                            if count > MAX_ARCHIVE_FILE or count > size:
                                raise ValueError("Installed npm file grew during hashing")
                            hasher.update(chunk)
                    if count != size:
                        raise ValueError("Installed npm file changed during hashing")
                    found[name] = ArtifactFile(sha256=hasher.hexdigest(), size=count)
            gaps.extend(
                f"Missing installed npm file: {name}"
                for name in sorted(expected.keys() - found.keys())
            )
            gaps.extend(
                f"Unexpected installed npm file: {name}"
                for name in sorted(found.keys() - expected.keys())
            )
            gaps.extend(
                f"Installed npm file differs from source artifact: {name}"
                for name in sorted(found.keys() & expected.keys())
                if found[name] != expected[name]
            )
        verified = {name: value for name, value in found.items() if expected.get(name) == value}
        return (
            NpmIntegrity(
                artifact_sha256=digest(payload),
                artifact_size=len(payload),
                source_files=files,
                installed_tree_verified=installed and not gaps,
                verified_installed_files=len(verified),
                verified_installed_bytes=sum(value.size for value in verified.values()),
                generated_exclusions=tuple(sorted(ignored)),
                normalized_tar_aliases=aliases,
            ),
            gaps,
            notices,
        )
    except (OSError, ValueError, tarfile.TarError) as error:
        return None, [f"npm artifact/tree integrity failure: {error}"], []


def collect_npm(
    lock: NpmLock,
    toolchain: Path,
    texts: TextCollector,
    *,
    npm_cache: Path | None = None,
) -> tuple[list[Component], list[Edge], list[str]]:
    packages = lock.packages
    keys = {
        path: f"npm:{npm_name(path)}@{p.version}#{path}" for path, p in packages.items() if path
    }
    components: list[Component] = []
    edges: list[Edge] = []
    installed_instances = installed_npm_instances(toolchain)
    artifact_budget = ArtifactBudget()
    gaps = [
        f"Installed npm instance outside lock: {path}"
        for path in sorted(installed_instances - packages.keys())
    ]
    for path, raw in sorted(packages.items()):
        owner = keys.get(path, "toolchain:gspace")
        fields: tuple[
            tuple[dict[str, str], Literal["dependency", "optional", "peer", "dev_root"]], ...
        ] = (
            (raw.dependencies, "dependency"),
            (raw.optionalDependencies, "optional"),
            (raw.peerDependencies, "peer"),
            (raw.devDependencies, "dev_root"),
        )
        for field, kind in fields:
            for name, requirement in sorted(field.items()):
                resolved = resolve_npm(path, name, packages)
                edges.append(
                    Edge(
                        source=owner,
                        target=keys.get(resolved or ""),
                        declared_name=name,
                        requirement=requirement,
                        kind=kind,
                    )
                )
                if resolved is None and kind != "peer":
                    gaps.append(f"Unresolved npm {kind} edge: {owner} -> {name}")
        if not path:
            continue
        if raw.version is None:
            raise ValueError("npm component lacks exact version")
        directory = toolchain / path
        package_json = directory / "package.json"
        evidence: list[Evidence] = []
        if raw.license is not None:
            evidence.append(
                Evidence(
                    source="package-lock:license",
                    raw=str(raw.license),
                    interpretation="package_field",
                )
            )
        files: list[TextRef] = []
        missing: list[str] = []
        installed = package_json.is_file()
        meta_hash: str | None = None
        if installed:
            payload = read_bounded(package_json, toolchain)
            meta_hash = digest(payload)
            actual = NpmPackage.model_validate_json(payload)
            if actual.version != raw.version or actual.name != npm_name(path):
                missing.append("Installed npm package identity differs from lock")
            if actual.license is not None:
                evidence.append(
                    Evidence(
                        source="package.json:license",
                        raw=str(actual.license),
                        interpretation="package_field",
                    )
                )
                if raw.license is not None and actual.license != raw.license:
                    missing.append("Conflicting npm lock/installed license declarations")
            for candidate in sorted(directory.rglob("*")):
                relative = candidate.relative_to(directory)
                if "node_modules" in relative.parts or candidate.is_dir():
                    continue
                if is_license_text(candidate.name):
                    try:
                        files.append(
                            texts.add(owner, path, candidate, toolchain, "npm_package_tree")
                        )
                    except ValueError as error:
                        missing.append(f"License file rejected: {relative}: {error}")
        else:
            missing.append("Locked npm instance not installed on current platform")
        integrity: NpmIntegrity | None = None
        if npm_cache is not None:
            integrity, artifact_gaps, artifact_notices = verify_npm_integrity(
                raw, path, toolchain, npm_cache, set(keys), texts, artifact_budget
            )
            missing.extend(artifact_gaps)
            files.extend(artifact_notices)
            if integrity is not None and artifact_notices:
                missing = [
                    gap
                    for gap in missing
                    if gap != "Locked npm instance not installed on current platform"
                ]
        if not evidence:
            missing.append("No npm license declaration evidence")
        missing.extend(declaration_gaps(evidence))
        if not files:
            missing.append("No npm license/NOTICE text available")
        components.append(
            Component(
                id=owner,
                ecosystem="npm",
                name=npm_name(path),
                version=raw.version,
                source=raw.resolved,
                integrity=raw.integrity,
                occurrence=path,
                installed=installed,
                installation_evidence=meta_hash,
                scopes=(
                    "locked",
                    "development",
                ),
                license_evidence=tuple(evidence),
                texts=tuple(files),
                gaps=tuple(missing),
                npm_integrity=integrity,
            )
        )
    return components, edges, gaps


def proof_inputs(proof: BuildProof, project: Path = ROOT) -> dict[str, Path]:
    """Require current project files, including the validator actually used by the app."""
    if (
        not proof.inputs
        or proof.inputs.get(proof.validator_input) != proof.accepted_validator_sha256
    ):
        raise ValueError("Bundle provenance does not bind the current generated validator")
    paths: dict[str, Path] = {}
    for name, checksum in sorted(proof.inputs.items()):
        if Path(name).is_absolute():
            raise ValueError("Bundle provenance inputs must be project-relative")
        if not re.fullmatch(r"[a-f0-9]{64}", checksum):
            raise ValueError("Bundle provenance input checksum is malformed")
        path = project / name
        if digest(read_bounded(path, project)) != checksum:
            raise ValueError(f"Bundle provenance input differs from current file: {name}")
        paths["bundle-input:" + name] = path
    return paths


def bundle_bindings(
    destination: Path,
    toolchain: Path,
    components: list[Component],
    app_hash: str,
    *,
    project: Path = ROOT,
    provenance: Path | None = None,
) -> tuple[BundledFile, ...]:
    directory = provenance or destination / "bundled"
    proof = BuildProof.model_validate_json(read_bounded(directory / "report.json", project))
    if not proof.app_matches_served or not proof.validator_matches_accepted_input:
        raise ValueError("Accepted browser bundle provenance did not reproduce")
    if proof.app_sha256 != app_hash:
        raise ValueError("Provenance does not describe the distributed app")
    proof_inputs(proof, project)
    metafiles: dict[str, Metafile] = {}
    for name, expected in (
        ("accepted-app.metafile.json", proof.app_metafile),
        ("accepted-validator.metafile.json", proof.validator_metafile),
    ):
        payload = read_bounded(directory / name, project)
        if expected is None or digest(payload) != expected.sha256:
            raise ValueError(f"Bundle provenance does not bind its metafile: {name}")
        parsed = Metafile.model_validate_json(payload)
        if set(parsed.inputs) != set(expected.inputs):
            raise ValueError(f"Bundle provenance metafile input list differs: {name}")
        metafiles[name] = parsed
    metadata = metafiles["accepted-validator.metafile.json"]
    bindings: list[BundledFile] = []
    for path, item in sorted(metadata.inputs.items()):
        if "node_modules/" not in path:
            continue
        relative = path[path.index("node_modules/") :]
        candidates = [
            c
            for c in components
            if c.ecosystem == "npm" and relative.startswith(c.occurrence + "/")
        ]
        if not candidates:
            raise ValueError(f"Bundled source is outside the inventoried npm instances: {path}")
        component = max(candidates, key=lambda c: len(c.occurrence))
        payload = read_bounded(toolchain / relative, toolchain)
        if len(payload) != item.bytes:
            raise ValueError("Bundled source size changed after provenance rebuild")
        if item.sha256 is not None and digest(payload) != item.sha256:
            raise ValueError("Bundled source checksum changed after provenance rebuild")
        source_path = toolchain / relative
        expected_hash = (
            proof.inputs.get(source_path.relative_to(project).as_posix())
            if source_path.is_relative_to(project)
            else None
        )
        if expected_hash != digest(payload):
            raise ValueError("Bundle provenance does not bind the current npm source bytes")
        bindings.append(
            BundledFile(
                component=component.id,
                source_path=relative,
                source_sha256=digest(payload),
                accepted_validator_sha256=proof.accepted_validator_sha256,
                distributed_app_sha256=app_hash,
            )
        )
    if not bindings:
        raise ValueError("Validator provenance contains no inventoried npm source bindings")
    return tuple(bindings)


def validate_build_provenance(
    proof: PythonBuildProof,
    build_bom: Bom | None,
    components: list[Component],
    bundled: tuple[BundledFile, ...],
    assets: dict[str, str],
    *,
    project: Path = ROOT,
) -> tuple[PackagedText, ...]:
    """Bind the actual locked build and wheel to inventoried identities and notice bytes."""
    if set(proof.input_sha256) != {"pyproject.toml", "uv.lock"}:
        raise ValueError("Build provenance must bind pyproject.toml and uv.lock")
    for name, checksum in proof.input_sha256.items():
        if digest(read_bounded(project / name, project)) != checksum:
            raise ValueError(f"Build provenance input differs from current file: {name}")
    if not proof.python_version.startswith("3.12."):
        raise ValueError("Build provenance did not use the required Python 3.12")
    expected: set[tuple[str, str]] = (
        {(normalize(c.name), c.version) for c in build_bom.components}
        if build_bom is not None
        else set()
    )
    actual = {(normalize(c.name), c.version) for c in proof.components}
    if not expected or actual != expected or len(actual) != len(proof.components):
        raise ValueError("Build provenance components differ from the native locked build group")
    indexed = {c.id: c for c in components}
    if any(binding.distributed_app_sha256 != assets.get("app.js") for binding in bundled):
        raise ValueError("Build notice bindings do not describe the distributed app")
    for item in proof.components:
        component = indexed.get(f"python:{normalize(item.name)}@{item.version}")
        if component is None or component.installation_evidence != item.metadata_sha256:
            raise ValueError("Build component metadata differs from installed license evidence")
    if Path(proof.wheel.path).is_absolute():
        raise ValueError("Build artifact path must be project-relative")
    wheel = project / proof.wheel.path
    if digest(read_bounded(wheel, project)) != proof.wheel.sha256:
        raise ValueError("Build wheel checksum differs from provenance")
    with ZipFile(wheel) as archive:
        members: dict[str, str] = {}
        total = 0
        for member in archive.infolist():
            name = member.filename
            if name in members or Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("Build wheel contains duplicate or escaping members")
            total += member.file_size
            if member.file_size > MAX_FILE or total > MAX_TOTAL:
                raise ValueError("Build wheel exceeds evidence size limits")
            members[name] = digest(archive.read(member))
        if members != proof.wheel.members:
            raise ValueError("Build wheel members differ from provenance")
        if any(
            members.get("gspace/static/" + name) != checksum for name, checksum in assets.items()
        ):
            raise ValueError("Build wheel assets differ from the distributed browser inputs")
        required = {binding.component for binding in bundled}
        if not required:
            return ()
        manifest_name = "gspace/licenses/manifest.json"
        if manifest_name not in members:
            raise ValueError("Build wheel lacks the bundled dependency notice manifest")
        manifest = NoticeManifest.model_validate_json(archive.read(manifest_name))
        packaged: list[PackagedText] = []
        covered: set[str] = set()
        for notice in manifest.components:
            candidates = [
                indexed[key]
                for key in required
                if indexed[key].name == notice.name and indexed[key].version == notice.version
            ]
            if not candidates or Path(notice.file).name != notice.file:
                raise ValueError("Packaged notice does not identify a bundled dependency")
            member_name = "gspace/licenses/" + notice.file
            if members.get(member_name) != notice.sha256:
                raise ValueError("Packaged license bytes differ from their manifest")
            if digest(read_bounded(project / notice.publisher_source, project)) != notice.sha256:
                raise ValueError("Packaged license differs from current publisher evidence")
            for component in candidates:
                if component.id in covered or not any(
                    t.sha256 == notice.sha256 for t in component.texts
                ):
                    raise ValueError("Packaged license is duplicate or absent from collected texts")
                if not any(e.raw == notice.license for e in component.license_evidence):
                    raise ValueError("Packaged license declaration differs from collected evidence")
                covered.add(component.id)
                packaged.append(
                    PackagedText(
                        component=component.id,
                        member=member_name,
                        sha256=notice.sha256,
                        wheel_sha256=proof.wheel.sha256,
                    )
                )
        if covered != required:
            raise ValueError("Build wheel lacks a required bundled dependency notice")
    return tuple(sorted(packaged, key=lambda item: (item.component, item.member)))


def validate_source_artifact(
    proof: WheelProof,
    inputs: dict[str, str],
    assets: dict[str, str],
    *,
    project: Path = ROOT,
) -> None:
    """Verify exact sdist members and current canonical inputs without extracting files."""
    if Path(proof.path).is_absolute():
        raise ValueError("Source artifact path must be project-relative")
    payload = read_bounded(project / proof.path, project, MAX_ARCHIVE_COMPRESSED)
    if digest(payload) != proof.sha256:
        raise ValueError("Source archive checksum differs from build provenance")
    files, _, _ = inspect_tar_members(
        payload,
        ArtifactBudget(),
        forbidden_parts=frozenset(
            {
                ".git",
                ".venv",
                ".repos",
                ".state",
                "node_modules",
                "__pycache__",
                ".pytest_cache",
                "output",
                ".env",
                "gspace.toml",
            }
        ),
    )
    if {name: value.sha256 for name, value in files.items()} != proof.members:
        raise ValueError("Source archive members differ from build provenance")
    roots = {name.split("/")[0] for name in files}
    if len(roots) != 1 or any("/" not in name for name in files):
        raise ValueError("Source archive must have one project root")
    prefix = next(iter(roots)) + "/"
    for name, value in files.items():
        relative = name.removeprefix(prefix)
        if relative == "PKG-INFO":
            continue  # Generated package metadata is independently bound by the artifact manifest.
        current = (
            "frontend-new/" + relative.removeprefix("src/gspace/static/")
            if relative.startswith("src/gspace/static/")
            else relative
        )
        if digest(read_bounded(project / current, project)) != value.sha256:
            raise ValueError(f"Source archive file differs from current source: {relative}")
    if any(
        files.get(prefix + name) is None or files[prefix + name].sha256 != checksum
        for name, checksum in inputs.items()
    ):
        raise ValueError("Source archive canonical inputs differ from build provenance")
    if any(
        files.get(prefix + "src/gspace/static/" + name) is None
        or files[prefix + "src/gspace/static/" + name].sha256 != checksum
        for name, checksum in assets.items()
    ):
        raise ValueError("Source archive browser assets differ from current delivery")


def write_outputs(destination: Path, inventory: Inventory, texts: TextCollector) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    payload = inventory.model_dump(mode="json")
    (destination / "inventory.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n"
    )
    text_dir = destination / "texts/sha256"
    text_dir.mkdir(parents=True, exist_ok=True)
    for checksum, blob in sorted(texts.blobs.items()):
        (text_dir / checksum).write_bytes(blob)
    index = sorted(
        (text for c in inventory.components for text in c.texts),
        key=lambda t: (t.sha256, t.component, t.path),
    )
    (destination / "text-index.json").write_text(
        json.dumps([t.model_dump(mode="json") for t in index], indent=2, sort_keys=True) + "\n"
    )
    attribution: dict[str, set[str]] = defaultdict(set)
    for text in index:
        attribution[text.sha256].add(text.component)
    notices = bytearray(
        b"GSpace collected third-party evidence. Deduplication retains attribution obligations.\n"
    )
    for checksum, blob in sorted(texts.blobs.items()):
        notices.extend(
            (
                "\n==== SHA256 "
                + checksum
                + " ====\nComponents: "
                + ", ".join(sorted(attribution[checksum]))
                + "\n"
            ).encode()
        )
        notices.extend(blob)
        notices.extend(b"\n")
    (destination / "THIRD_PARTY_NOTICES.txt").write_bytes(notices)
    unknown = [{"component": c.id, "gaps": list(c.gaps)} for c in inventory.components if c.gaps]
    report = {
        "purpose": "Actual recursive offline lock/installed/bundled inventory evidence",
        "status": "incomplete_evidence"
        if unknown or inventory.gaps
        else "complete_for_declared_scope",
        "complete": not unknown and not inventory.gaps,
        "components": len(inventory.components),
        "python_locked": sum(c.ecosystem == "python" for c in inventory.components),
        "python_runtime": sum(
            c.ecosystem == "python" and "runtime" in c.scopes for c in inventory.components
        ),
        "python_build": sum(
            c.ecosystem == "python" and "build" in c.scopes for c in inventory.components
        ),
        "npm_locked_instances": sum(c.ecosystem == "npm" for c in inventory.components),
        "installed": sum(c.installed for c in inventory.components),
        "dependency_edges": len(inventory.edges),
        "text_occurrences": len(index),
        "unique_text_bytes": len(texts.blobs),
        "text_total_bytes": texts.total,
        "unknown": unknown,
        "gaps": list(inventory.gaps),
        "deduplication": "byte-identical SHA256 only; attribution retained",
        "network": (
            "collector only local reads and uv --locked --offline exports; no runtime downloads"
        ),
        "license_clearance": False,
        "bundled_source_bindings": len(inventory.bundled),
        "build_components": len(inventory.build_provenance.components)
        if inventory.build_provenance is not None
        else 0,
        "wheel_provenance_verified": inventory.build_provenance is not None,
        "source_archive_verified": (
            inventory.build_provenance is not None and inventory.build_provenance.sdist is not None
        ),
        "first_party_license": inventory.first_party_license,
        "first_party_license_grant": False,
        "packaged_bundled_notices": len(inventory.packaged_texts),
        "npm_artifacts_verified": sum(c.npm_integrity is not None for c in inventory.components),
        "npm_installed_trees_verified": sum(
            c.npm_integrity is not None and c.npm_integrity.installed_tree_verified
            for c in inventory.components
        ),
        "npm_verified_installed_files": sum(
            c.npm_integrity.verified_installed_files
            for c in inventory.components
            if c.npm_integrity is not None
        ),
        "npm_verified_installed_bytes": sum(
            c.npm_integrity.verified_installed_bytes
            for c in inventory.components
            if c.npm_integrity is not None
        ),
        "python_record_verified_hashes": sum(
            c.record_integrity.verified_hashes
            for c in inventory.components
            if c.record_integrity is not None
        ),
        "python_record_verified_distributions": sum(
            c.record_integrity is not None and c.record_integrity.complete
            for c in inventory.components
        ),
        "python_record_verified_bytes": sum(
            c.record_integrity.verified_bytes
            for c in inventory.components
            if c.record_integrity is not None
        ),
        "python_record_unhashed_entries": sum(
            c.record_integrity.unhashed_entries
            for c in inventory.components
            if c.record_integrity is not None
        ),
        "installed_python": sum(
            c.ecosystem == "python" and c.installed for c in inventory.components
        ),
        "installed_npm": sum(c.ecosystem == "npm" and c.installed for c in inventory.components),
    }
    (destination / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    summary = [
        "# Recursive dependency/license evidence",
        "",
        f"Components: {len(inventory.components)}; edges: {len(inventory.edges)}; "
        f"text occurrences: {len(index)}; byte-distinct texts: {len(texts.blobs)}.",
        "",
        (
            "Expressions below are raw evidence; AND/OR/WITH are preserved. No "
            "alternative selected or legal clearance claimed."
        ),
        "",
        "| Component | Scopes | Declared evidence | Texts | Gaps |",
        "|---|---|---|---|---|",
    ]
    for c in inventory.components:
        evidence = "; ".join(
            e.raw.replace("\n", " ").replace("|", "\\|")[:250] for e in c.license_evidence
        )
        summary.append(
            f"| {c.id} | {', '.join(c.scopes)} | {evidence or 'unknown'} | "
            f"{len(c.texts)} | {'; '.join(c.gaps)} |"
        )
    summary += ["", "## Artifact and scope gaps", *[f"- {gap}" for gap in inventory.gaps]]
    (destination / "summary.md").write_text("\n".join(summary) + "\n")
    # Fixed metadata, sorted contents; actual run timing is separate from reproducible artifacts.
    names = [
        "inventory.json",
        "text-index.json",
        "report.json",
        "summary.md",
        "THIRD_PARTY_NOTICES.txt",
        *[f"texts/sha256/{h}" for h in sorted(texts.blobs)],
    ]
    checksums = {name: digest((destination / name).read_bytes()) for name in sorted(names)}
    (destination / "SHA256SUMS").write_text("".join(f"{h}  {n}\n" for n, h in checksums.items()))
    with tarfile.open(destination / "evidence.tar", "w", format=tarfile.PAX_FORMAT) as tar:
        for name in sorted([*names, "SHA256SUMS"]):
            body = (destination / name).read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(body)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(body))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--toolchain", type=Path, default=ROOT / "frontend-new")
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    parser.add_argument(
        "--provenance", type=Path, help="Current bundle proof directory; defaults to OUTPUT/bundled"
    )
    parser.add_argument(
        "--supplemental",
        type=Path,
        default=ROOT / ".state/dependency-inventory/supplemental/manifest.json",
    )
    parser.add_argument("--build-provenance", type=Path)
    parser.add_argument(
        "--npm-cache",
        type=Path,
        default=ROOT / ".state/install/npm-cache/_cacache/content-v2",
        help="Project-owned public content-v2 artifacts only; no indexes/configuration are read",
    )
    parser.add_argument(
        "--site-packages", type=Path, default=ROOT / ".venv/lib/python3.12/site-packages"
    )
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/dependency-inventory"
    )
    args = parser.parse_args()
    toolchain = args.toolchain.absolute()
    npm_cache = Path(os.path.abspath(args.npm_cache))
    if not npm_cache.is_relative_to(ROOT) or not npm_cache.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("npm artifact cache must stay inside the owned project")
    asset_directory = args.assets.absolute()
    site = args.site_packages.absolute()
    destination = args.output.absolute()
    provenance = args.provenance.absolute() if args.provenance else destination / "bundled"
    if not destination.is_relative_to(ROOT) or destination.is_symlink():
        raise ValueError("Output must stay in owned workspace")
    destination.mkdir(parents=True, exist_ok=True)
    source_files = {
        "collector-source.py": Path(__file__).resolve(),
        "uv.lock": ROOT / "uv.lock",
        "pyproject.toml": ROOT / "pyproject.toml",
        "frontend-package.json": ROOT / "frontend-new/package.json",
        "toolchain-package.json": toolchain / "package.json",
        "toolchain-package-lock.json": toolchain / "package-lock.json",
        "generated-validator.js": ROOT / "frontend-new/contracts/schema-validation.js",
        "bundle-proof.json": provenance / "report.json",
        "validator-metafile.json": provenance / "accepted-validator.metafile.json",
        "app-metafile.json": provenance / "accepted-app.metafile.json",
        **{"asset:" + name: asset_directory / name for name in DISTRIBUTED_ASSETS},
    }
    proof = BuildProof.model_validate_json(read_bounded(provenance / "report.json", ROOT))
    source_files.update(proof_inputs(proof))
    supplemental = args.supplemental.absolute()
    if supplemental.exists():
        source_files["supplemental-manifest"] = supplemental
    build_manifest = (
        args.build_provenance.absolute()
        if args.build_provenance is not None
        else ROOT / "output/verification/build-provenance.json"
    )
    build_proof: PythonBuildProof | None = None
    if build_manifest.exists() or args.build_provenance is not None:
        build_proof = PythonBuildProof.model_validate_json(read_bounded(build_manifest, ROOT))
        source_files["build-provenance.json"] = build_manifest
        source_files["built-wheel"] = ROOT / build_proof.wheel.path
        if build_proof.sdist is not None:
            source_files["built-sdist"] = ROOT / build_proof.sdist.path
    frozen = {
        name: digest(read_bounded(path, ROOT if path.is_relative_to(ROOT) else toolchain))
        for name, path in source_files.items()
    }
    lock = NpmLock.model_validate_json(read_bounded(toolchain / "package-lock.json", toolchain))
    sbom = destination / "sbom"
    sbom.mkdir(exist_ok=True)
    all_bom = export_uv(sbom / "python-locked-all.cdx.json", False)
    runtime_bom = export_uv(sbom / "python-locked-runtime.cdx.json", True)
    groups = tomllib.loads(read_bounded(ROOT / "pyproject.toml", ROOT).decode()).get(
        "dependency-groups", {}
    )
    build_bom = (
        export_uv(sbom / "python-locked-build.cdx.json", False, group="build")
        if "build" in groups
        else None
    )
    development_bom = (
        export_uv(sbom / "python-locked-development.cdx.json", False, group="dev")
        if "dev" in groups
        else None
    )
    texts = TextCollector()
    python, py_edges, py_gaps = collect_python(
        all_bom, runtime_bom, site, texts, build_bom=build_bom, development_bom=development_bom
    )
    npm, npm_edges, npm_gaps = collect_npm(lock, toolchain, texts, npm_cache=npm_cache)
    components, official = apply_official_evidence(python + npm, texts, supplemental)
    assets = {name: frozen["asset:" + name] for name in sorted(DISTRIBUTED_ASSETS)}
    bundled = bundle_bindings(destination, toolchain, npm, assets["app.js"], provenance=provenance)
    bundled_ids = {binding.component for binding in bundled}
    components = [
        c.model_copy(update={"scopes": (*c.scopes, "browser_bundled")})
        if c.id in bundled_ids
        else c
        for c in components
    ]
    packaged_texts = (
        validate_build_provenance(build_proof, build_bom, components, bundled, assets)
        if build_proof is not None
        else ()
    )
    if build_proof is not None and build_proof.sdist is not None:
        validate_source_artifact(build_proof.sdist, build_proof.input_sha256, assets)
    gaps = [
        *py_gaps,
        *npm_gaps,
        (
            "AJV helpers have byte-matching two-stage attribution; full native/vendor "
            "subcomponent license detection remains outside package mapping"
        ),
        (
            "Interpreter/Bun/Node/Chrome/native binary attribution remains outside "
            "the verified Python-package/browser-helper scope"
        ),
        *(
            ["Exact locked build environment and packaged-notice provenance unavailable"]
            if build_proof is None
            else []
        ),
        *(
            ["Source-distribution provenance and exclusions have not been verified"]
            if build_proof is None or build_proof.sdist is None
            else []
        ),
        (
            "Python RECORD entries are hashed without covering unrecorded/generated files; "
            "binary vendor subcomponent discovery is not established by file integrity"
        ),
    ]
    for name, path in source_files.items():
        if (
            digest(read_bounded(path, ROOT if path.is_relative_to(ROOT) else toolchain))
            != frozen[name]
        ):
            raise RuntimeError("Inventory input changed during collection")
    inventory = Inventory(
        components=tuple(components),
        edges=tuple(py_edges + npm_edges),
        input_sha256=frozen,
        assets=assets,
        gaps=tuple(gaps),
        bundled=bundled,
        official_sources=official,
        build_provenance=build_proof,
        packaged_texts=packaged_texts,
    )
    write_outputs(destination, inventory, texts)
    # Preserve native graph exports and exact npm lock as raw source evidence.
    (destination / "npm-package-lock.json").write_bytes(
        read_bounded(toolchain / "package-lock.json", toolchain)
    )
    if supplemental.exists():
        (destination / "official-source-manifest.json").write_bytes(
            read_bounded(supplemental, supplemental.parent)
        )
    print((destination / "report.json").read_text())
    return 2 if inventory.gaps or any(c.gaps for c in inventory.components) else 0


if __name__ == "__main__":
    sys.exit(main())
