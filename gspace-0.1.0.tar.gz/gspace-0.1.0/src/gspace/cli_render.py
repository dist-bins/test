"""Pure Rich views over validated evidence; no fetching, effects or screen ownership."""

from __future__ import annotations

import unicodedata
from collections.abc import Sequence
from zoneinfo import ZoneInfo

from pydantic import BaseModel, JsonValue, TypeAdapter
from rich import box
from rich.console import Console
from rich.measure import Measurement
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

from gspace.actions import ProbeComparison
from gspace.catalog import AuthoredMr
from gspace.milestones import MilestoneCatalog
from gspace.models import (
    Association,
    Branch,
    Environment,
    Origin,
    PipelineGraph,
    PipelineNodeUnavailable,
    RebaseVerified,
    TriggerJob,
    Version,
)
from gspace.operator_settings import SettingsResponse
from gspace.pipeline_config import PipelineRules
from gspace.preferences import Filters
from gspace.resource_catalog import BranchCatalog, PipelineCatalog
from gspace.service import Dashboard, ItemView
from gspace.test_history import ApplicationTestHistory

THEME = Theme(
    {
        "gs.heading": "bold",
        "gs.id": "cyan",
        "gs.meta": "dim",
        "gs.ok": "bold green",
        "gs.error": "bold red",
        "gs.wait": "yellow",
        "gs.active": "bold cyan",
        "gs.merged": "magenta",
        "gs.unknown": "italic",
        "gs.frame": "dim",
    }
)


def safe(value: str) -> str:
    """Expose control/bidi characters literally, including ESC/OSC and line injection."""
    return "".join(
        (f"\\x{ord(char):02x}" if ord(char) <= 255 else f"\\u{ord(char):04x}")
        if unicodedata.category(char) in ("Cc", "Cf")
        else char
        for char in value
    )


def literal(value: str, style: str = "") -> Text:
    return Text(safe(value), style=style, overflow="fold")


def make_console(*, no_color: bool, width: int | None = None, stderr: bool = False) -> Console:
    return Console(
        stderr=stderr, no_color=no_color, width=width, highlight=False, markup=False, theme=THEME
    )


def state(value: str, prefix: str = "") -> Text:
    """ASCII cues accompany complete labels; unknown has its own neutral style."""
    if value in ("success", "passed", "match", "up to date", "confirmed", "allowed"):
        cue, role = "+", "gs.ok"
    elif value in ("failed", "mismatch", "error", "denied"):
        cue, role = "x", "gs.error"
    elif value in ("running", "open", "opened", "active", "current"):
        cue, role = ">", "gs.active"
    elif value == "merged":
        cue, role = "=", "gs.merged"
    elif value in ("pending", "manual", "created", "required", "draft", "stale"):
        cue, role = "!", "gs.wait"
    elif value in ("closed", "canceled", "skipped", "superseded", "not_tested"):
        cue, role = "-", "gs.meta"
    else:
        cue, role = "?", "gs.unknown"
    result = literal(prefix, "gs.meta")
    result.append_text(literal(f"{cue} {value}", role))
    return result


def lines(*values: Text) -> Text:
    return Text("\n").join(values)


def heading(console: Console, title: str, subtitle: str = "") -> None:
    console.print(literal(title, "gs.heading"))
    if subtitle:
        console.print(literal(subtitle, "gs.meta"))


def compact_table() -> Table:
    return Table(
        box=box.SIMPLE_HEAD,
        header_style="gs.heading",
        border_style="gs.frame",
        padding=(0, 1),
        pad_edge=False,
        collapse_padding=True,
        expand=False,
    )


def grid(console: Console, rows: Sequence[tuple[str, Text]]) -> None:
    table = Table.grid(padding=(0, 2))
    table.add_column(style="gs.meta", max_width=min(18, console.width // 3))
    table.add_column(overflow="fold")
    for label, value in rows:
        table.add_row(literal(label), value)
    console.print(table)


def records(console: Console, labels: Sequence[str], rows: Sequence[Sequence[Text]]) -> None:
    """Use a natural-width listing or labelled records when meaningful columns cannot fit."""
    if not rows:
        console.print(literal("No records in this scope.", "gs.meta"))
        return
    minima = [
        max(
            len(label),
            max(Measurement.get(console, console.options, cell[index]).minimum for cell in rows),
        )
        for index, label in enumerate(labels)
    ]
    if sum(minima) + len(labels) - 1 > console.width:
        for index, row in enumerate(rows):
            if index:
                console.print()
            grid(console, list(zip(labels, row, strict=True)))
        return
    table = compact_table()
    for label in labels:
        table.add_column(literal(label), overflow="fold")
    for row in rows:
        table.add_row(*row)
    console.print(table)


def association(value: Association, *, detail: bool = True) -> Text:
    result = literal(
        "override" if value.origin == Origin.OPERATOR else value.origin.value, "gs.meta"
    )
    if value.overrides and detail:
        result.append_text(literal(f" (overrides {value.overrides})", "gs.meta"))
    return result


def rebase(branch: Branch) -> Text:
    if isinstance(branch.rebase, RebaseVerified):
        result = state("required" if branch.rebase.required else "up to date", "Rebase ")
        if branch.rebase.required:
            result.append(f" ({branch.rebase.behind} behind)")
        return result
    return state("unknown", "Rebase ")


def version(value: Version | None) -> Text:
    if value is None:
        return state("unknown")
    return lines(
        *[
            literal(f"{name}: {content}", "gs.id" if name == "sha" else "")
            for name, content in (
                ("sha", value.sha),
                ("version", value.version),
                ("tag", value.tag),
                ("branch", value.branch),
            )
            if content is not None
        ]
    )


def environment_cell(view: ItemView, name: str) -> Text:
    environment = next((e for e in view.item.environments if e.name == name), None)
    if environment is None:
        return literal("not configured", "gs.meta")
    comparison = next(c for c in view.comparisons if c.name == name)
    deploy = max(environment.deployments, key=lambda d: d.id, default=None)
    return lines(
        state(comparison.result, "Runtime "),
        state(deploy.status if deploy else "unknown", "Deploy "),
        state(environment.application_test, "Test "),
    )


def item_cell(view: ItemView, column: str) -> Text:
    item = view.item
    unknown = state("unknown")
    match column:
        case "identity":
            marker = " · ".join(
                name for enabled, name in ((view.selected, "sel"), (view.pinned, "pin")) if enabled
            )
            identity = literal(item.identity.key, "gs.id")
            if marker:
                identity.append(f"  {marker}", style="gs.meta")
            return lines(identity, literal(item.title, "gs.heading"))
        case "title":
            return literal(item.title, "gs.heading")
        case "state":
            return state(item.state)
        case "project":
            return literal(item.project_path)
        case "branch":
            return (
                lines(
                    *[
                        lines(
                            literal(branch.name, "gs.id"),
                            rebase(branch),
                            literal(branch.sha[:12], "gs.meta")
                            + literal(" · ")
                            + association(branch.association, detail=False),
                        )
                        for branch in item.branches
                    ]
                )
                if item.branches
                else unknown
            )
        case "mr":
            return (
                lines(
                    *[
                        literal(f"!{mr.iid.value} ", "gs.id")
                        + (state("draft") + literal(" · ") if mr.draft else Text())
                        + state(mr.state)
                        + (
                            Text("\n") + association(mr.association, detail=False)
                            if mr.association.origin == Origin.OPERATOR
                            else Text()
                        )
                        for mr in item.merge_requests
                    ]
                )
                if item.merge_requests
                else unknown
            )
        case "pipeline":
            entries = [
                lines(
                    literal(f"#{pipeline.id.value} ", "gs.id") + state(pipeline.status),
                    literal(pipeline.ref, "gs.meta"),
                )
                for pipeline in item.pipelines
            ]
            # Publish is independent evidence, labelled with its actual source pipeline.
            entries.extend(
                state(publish.status, f"Nexus #{publish.pipeline.value} ")
                for publish in item.publishes
            )
            return lines(*entries) if entries else unknown
        case "publish":
            return (
                lines(
                    *[
                        state(publish.status, f"#{publish.pipeline.value} ")
                        + Text("\n")
                        + literal(publish.artifact)
                        for publish in item.publishes
                    ]
                )
                if item.publishes
                else unknown
            )
        case "sha":
            return (
                lines(*[literal(branch.sha[:12], "gs.id") for branch in item.branches]) or unknown
            )
        case "ref":
            return lines(*[literal(pipeline.ref) for pipeline in item.pipelines]) or unknown
        case "jobs":
            return (
                lines(
                    *[
                        literal(f"#{pipeline.id.value}/{job.id.value} ", "gs.id")
                        + state(job.status)
                        + Text("\n")
                        + literal(f"{job.name} · attempt {job.attempt}")
                        + (literal(" · superseded", "gs.meta") if job.retried else Text())
                        for pipeline in item.pipelines
                        for job in pipeline.jobs
                    ]
                )
                or unknown
            )
        case "dev" | "preprod":
            return environment_cell(view, column)
        case _:
            if column.startswith("environment:"):
                return environment_cell(view, column.removeprefix("environment:"))
            return unknown


def matrix(data: Dashboard, console: Console) -> None:
    heading(
        console,
        "GSpace · Work items",
        f"{len(data.views)} of {data.total} · {data.snapshot_source} · "
        f"GitLab {data.gitlab_version} · {data.cache_state}",
    )
    console.print(literal(f"Snapshot {data.fetched_at}", "gs.meta"))
    failed = sum(p.status == "failed" for v in data.views for p in v.item.pipelines)
    mismatches = sum(c.result == "mismatch" for v in data.views for c in v.comparisons)
    rebases = sum(
        isinstance(b.rebase, RebaseVerified) and b.rebase.required
        for v in data.views
        for b in v.item.branches
    )
    console.print(
        Text.assemble(
            (f"Failed pipelines {failed}", "gs.error" if failed else "gs.meta"),
            (" · ", "gs.meta"),
            (f"Runtime mismatches {mismatches}", "gs.error" if mismatches else "gs.meta"),
            (" · ", "gs.meta"),
            (f"Verified rebase needed {rebases}", "gs.wait" if rebases else "gs.meta"),
        )
    )
    labels = {
        "identity": "Work item",
        "title": "Title",
        "state": "State",
        "project": "Repository",
        "branch": "Branch / rebase",
        "mr": "Merge requests",
        "pipeline": "Pipelines / Nexus",
        "publish": "Nexus publish",
        "dev": "Dev",
        "preprod": "Preprod",
        "updated_at": "Updated",
        "sha": "SHA",
        "ref": "Ref",
        "jobs": "Jobs / attempts",
    }
    for descriptor in data.environment_columns:
        labels.setdefault(descriptor.column, descriptor.label)
    for column in data.columns:
        labels.setdefault(column, column.removeprefix("environment:"))
    if not data.views:
        console.print(literal("No matching items. Adjust saved filters or use --all."))
    elif data.orientation == "columns":
        # 24 cells per item preserves full status words and scoped identities.
        label_width = max(10, min(18, max(len(labels[c]) for c in data.columns)))
        per_page = max(1, (console.width - label_width - 2) // 24)
        pages = (len(data.views) + per_page - 1) // per_page
        for start in range(0, len(data.views), per_page):
            views = data.views[start : start + per_page]
            if pages > 1:
                console.print(
                    literal(
                        f"Columns {start + 1}–{start + len(views)} of {len(data.views)}", "gs.meta"
                    )
                )
            table = compact_table()
            table.add_column("Evidence", width=label_width, style="gs.meta", overflow="fold")
            for view in views:
                marker = " · sel" if view.selected else ""
                marker += " · pin" if view.pinned else ""
                table.add_column(
                    literal(view.item.identity.key + marker, "gs.id"), ratio=1, overflow="fold"
                )
            for column in data.columns:
                cells = [item_cell(view, column) for view in views]
                if column == "identity":
                    cells = [literal(view.item.title, "gs.heading") for view in views]
                table.add_row(literal(labels[column], "gs.meta"), *cells)
            console.print(table)
    else:
        # Field bands repeat identity; no configured evidence disappears at narrow widths.
        fields = [c for c in data.columns if c != "identity"]
        per_band = max(1, (console.width - 26) // 25)
        bands = [fields[i : i + per_band] for i in range(0, len(fields), per_band)] or [[]]
        for index, band in enumerate(bands):
            if len(bands) > 1:
                console.print(literal(f"Rows · fields {index + 1}/{len(bands)}", "gs.meta"))
            table = compact_table()
            table.add_column(
                "Work item",
                width=min(30, console.width // 2) if index == 0 else None,
                overflow="fold",
            )
            for column in band:
                table.add_column(literal(labels[column]), ratio=1, overflow="fold")
            for view in data.views:
                table.add_row(
                    item_cell(view, "identity")
                    if index == 0
                    else item_cell(view, "identity").split("\n")[0],
                    *[item_cell(view, column) for column in band],
                    end_section=True,
                )
            console.print(table)
    console.print(
        literal(
            "sel = selected · pin = pinned · + success · x failure · ! attention · ? unknown",
            "gs.meta",
        )
    )
    console.print(
        literal("Full evidence: gspace show PROJECT:IID · pipelines / environments", "gs.meta")
    )
    for warning in data.warnings:
        console.print(literal(warning, "gs.wait"))


def list_items(data: Dashboard, console: Console) -> None:
    heading(
        console,
        "GSpace · Work-item list",
        f"{len(data.views)} of {data.total} · {data.snapshot_source} · {data.cache_state}",
    )
    rows: list[list[Text]] = []
    for view in data.views:
        problems: list[Text] = [
            state(p.status, f"#{p.id.value} ") for p in view.item.pipelines if p.status == "failed"
        ]
        problems += [
            state(c.result, f"{c.name} ") for c in view.comparisons if c.result == "mismatch"
        ]
        problems += [
            state("required", f"Rebase {b.name}: ")
            for b in view.item.branches
            if isinstance(b.rebase, RebaseVerified) and b.rebase.required
        ]
        attention = lines(*problems) if problems else literal("no known failures", "gs.meta")
        key = item_cell(view, "identity").split("\n")[0]
        title = literal(view.item.title, "gs.heading")
        if console.width < 90:
            rows.append([key, lines(title, state(view.item.state), attention)])
        else:
            rows.append([key, title, state(view.item.state), attention])
    records(
        console,
        ("Work item", "Summary")
        if console.width < 90
        else ("Work item", "Title", "State", "Observed attention"),
        rows,
    )
    console.print(
        literal(
            "Unknown evidence is not a pass. Full process: dashboard; full item: show PROJECT:IID.",
            "gs.meta",
        )
    )
    for warning in data.warnings:
        console.print(literal(warning, "gs.wait"))


def environment_details(view: ItemView, environment: Environment, console: Console) -> None:
    comparison = next(c for c in view.comparisons if c.name == environment.name)
    console.print(Rule(literal(environment.name, "gs.heading"), align="left", style="gs.frame"))
    observation = environment.observation
    observed = (
        version(observation.value) if observation.kind == "observed" else state(observation.kind)
    )
    source = (
        lines(literal(observation.source), literal(observation.checked_at.isoformat()))
        if observation.kind != "unknown"
        else literal(observation.reason)
    )
    grid(
        console,
        [
            ("Runtime", state(comparison.result)),
            ("Comparison", literal(comparison.reason)),
            ("Expected", version(environment.expected)),
            ("Observed", observed),
            ("Source / checked", source),
            ("Application test", state(environment.application_test)),
        ],
    )
    if observation.kind == "error":
        grid(
            console,
            [
                (
                    "Observation error",
                    literal(f"{observation.code}: {observation.message}", "gs.error"),
                )
            ],
        )
    evidence = next((e for e in view.application_tests if e.environment == environment.name), None)
    if evidence:
        grid(console, [("Test evidence", literal(evidence.reason))])
    for deploy in environment.deployments:
        grid(
            console,
            [
                (f"Deploy #{deploy.id}", state(deploy.status)),
                ("Ref / SHA", literal(deploy.ref) + Text("\n") + literal(deploy.sha, "gs.id")),
                ("Deploy source", literal(deploy.source)),
                ("Deploy link", literal(deploy.link.url)),
            ],
        )
    if not environment.deployments:
        console.print(state("unknown", "Deploy record "))


def details(view: ItemView, console: Console, section: str) -> None:
    item = view.item
    heading(console, f"{item.identity.key} · {item.title}", item.project_path)
    console.print(literal(item.link.url, "gs.meta"))
    if section == "show":
        console.print(Rule("Branch / merge request / tag evidence", align="left", style="gs.frame"))
        for branch in item.branches:
            grid(
                console,
                [
                    ("Branch", literal(branch.name, "gs.id")),
                    ("SHA", literal(branch.sha)),
                    ("Rebase", rebase(branch)),
                    ("Association", association(branch.association)),
                    ("Reason", literal(branch.association.reason)),
                    ("Link", literal(branch.link.url)),
                ],
            )
            if isinstance(branch.rebase, RebaseVerified):
                grid(
                    console,
                    [
                        ("Verified against", literal(branch.rebase.target_branch)),
                        ("Ancestry source", literal(branch.rebase.source)),
                        ("Checked", literal(branch.rebase.checked_at.isoformat())),
                    ],
                )
            else:
                grid(console, [("Ancestry evidence", literal(branch.rebase.reason))])
            console.print()
        for mr in item.merge_requests:
            grid(
                console,
                [
                    (
                        f"MR !{mr.iid.value}",
                        (state("draft") + Text(" · ") if mr.draft else Text()) + state(mr.state),
                    ),
                    ("Source → target", literal(f"{mr.source_branch} → {mr.target_branch}")),
                    ("Source SHA", literal(mr.source_sha) if mr.source_sha else state("unknown")),
                    ("Association", association(mr.association)),
                    ("Reason", literal(mr.association.reason)),
                    ("Link", literal(mr.link.url)),
                ],
            )
            console.print()
        for tag in item.tags:
            grid(
                console,
                [
                    ("Tag", literal(tag.name, "gs.id")),
                    ("SHA", literal(tag.sha)),
                    ("Association", association(tag.association)),
                    ("Reason", literal(tag.association.reason)),
                    ("Link", literal(tag.link.url)),
                ],
            )
        console.print(
            Rule("Manual checklist · never changes draft", align="left", style="gs.frame")
        )
        grid(
            console,
            [
                (label, state("confirmed" if checked else "unconfirmed"))
                for label, checked in (
                    ("Local test", view.checklist.local_test),
                    ("Dev test", view.checklist.dev_test),
                    ("Preprod test", view.checklist.preprod_test),
                    ("Work confirmed", view.checklist.work_confirmed),
                )
            ],
        )
    if section in ("show", "pipelines"):
        for pipeline in item.pipelines:
            console.print(
                Rule(literal(f"Pipeline #{pipeline.id.value}"), align="left", style="gs.frame")
            )
            grid(
                console,
                [
                    ("Status", state(pipeline.status)),
                    ("Ref / source", literal(f"{pipeline.ref} · {pipeline.source}")),
                    ("SHA", literal(pipeline.sha, "gs.id")),
                    ("Association", association(pipeline.association)),
                    ("Reason", literal(pipeline.association.reason)),
                    ("Link", literal(pipeline.link.url)),
                ],
            )
            rows = [
                [
                    literal(str(job.id.value), "gs.id"),
                    literal(f"{job.stage} / {job.name}"),
                    state(job.status),
                    literal(f"{job.attempt}" + (" · superseded" if job.retried else "")),
                    literal(job.failure_reason or "not reported", "gs.meta"),
                ]
                for job in pipeline.jobs
            ]
            records(
                console, ("Job ID", "Stage / name", "Status", "Attempt", "Failure reason"), rows
            )
            if not pipeline.jobs:
                console.print(literal("No job evidence in this snapshot.", "gs.meta"))
        for publish in item.publishes:
            grid(
                console,
                [
                    (f"Nexus #{publish.pipeline.value}", state(publish.status)),
                    ("Publish job", literal(str(publish.job.value), "gs.id")),
                    ("Artifact", literal(publish.artifact)),
                    ("Source", literal(publish.source)),
                ],
            )
    if section in ("show", "environments"):
        for environment in item.environments:
            environment_details(view, environment, console)


def resource_catalog(result: BranchCatalog | PipelineCatalog, console: Console) -> None:
    heading(
        console,
        f"{result.kind.title()} · {result.total} of {result.scope_total}",
        f"{result.host} · {result.coverage} · {result.coverage_basis}",
    )
    console.print(literal("Configured project scope · search is a local display filter", "gs.meta"))
    rows: list[list[Text]] = []
    if isinstance(result, BranchCatalog):
        for row in result.rows:
            rows.append(
                [
                    literal(f"{row.branch.project.value} · {row.project_path}"),
                    literal(row.branch.name, "gs.id"),
                    literal(row.branch.sha[:12], "gs.meta"),
                    rebase(row.branch),
                ]
            )
        labels = ("Project", "Branch", "SHA", "Rebase evidence")
    else:
        for entry in result.rows:
            p = entry.pipeline
            rows.append(
                [
                    literal(f"{p.project.value} · {entry.project_path}"),
                    lines(literal(f"#{p.id.value}", "gs.id"), literal(p.ref)),
                    literal(p.sha[:12], "gs.meta"),
                    state(p.status),
                    lines(
                        literal(p.source, "gs.meta"),
                        literal(f"jobs: {entry.jobs_coverage}", "gs.meta"),
                    ),
                ]
            )
        labels = ("Project", "Pipeline / ref", "SHA", "Status", "Coverage / source")
    records(console, labels, rows)
    console.print(literal("Exact identities and links: repeat this command with --json", "gs.meta"))


def history(result: ApplicationTestHistory, console: Console) -> None:
    heading(console, f"Manual application tests · {result.key.key}", result.timezone)
    for index, entry in enumerate(result.entries):
        record = entry.record
        console.print(
            Rule(literal(f"{index + 1} · {record.environment}"), align="left", style="gs.frame")
        )
        grid(
            console,
            [
                ("Outcome", state(record.outcome)),
                ("Relationship", state(entry.state)),
                ("SHA / version", version(record.version)),
                (
                    "Checked",
                    literal(record.checked_at.astimezone(ZoneInfo(result.timezone)).isoformat()),
                ),
                ("Source", literal(record.source)),
                ("Notes", literal(record.notes or "none", "gs.meta")),
            ],
        )
    if not result.entries:
        console.print(literal("No manual application test records in this scope", "gs.meta"))
    console.print(literal("Outcome and current-version relationship are independent.", "gs.meta"))


def milestones(result: MilestoneCatalog, console: Console) -> None:
    heading(console, "Milestones", f"{result.timezone} · {result.date} · {result.issue_coverage}")
    rows: list[list[Text]] = []
    for entry in result.entries:
        m = entry.milestone
        owner = m.key.project.value if m.key.kind == "project" else m.key.group.value
        key = f"{m.key.kind}:{owner}:{m.key.id.value}"
        rows.append(
            [
                literal(key, "gs.id"),
                literal(m.title, "gs.heading"),
                state(m.state),
                literal(f"{m.start_date or '?'} → {m.due_date or '?'}"),
                literal(entry.date_current),
                literal(
                    f"{entry.work_items if entry.work_items is not None else 'unknown'} / "
                    f"{entry.visible_work_items}"
                ),
            ]
        )
    records(
        console,
        ("Scoped key", "Milestone", "State", "Dates", "Date current", "Items / visible"),
        rows,
    )
    for warning in result.warnings:
        console.print(literal(warning, "gs.wait"))


def merge_requests(rows: Sequence[AuthoredMr], host: str, console: Console) -> None:
    heading(console, f"Authored MRs · {len(rows)}", f"{host} · configured projects")
    records(
        console,
        ("MR / project", "Title", "State", "Branch", "Updated"),
        [
            [
                lines(
                    literal(f"{row.mr.project.value}:!{row.mr.iid.value}", "gs.id"),
                    literal(row.project_path, "gs.meta"),
                ),
                literal(row.mr.title, "gs.heading"),
                (state("draft") + Text("\n") if row.mr.draft else Text()) + state(row.mr.state),
                literal(row.mr.source_branch),
                literal(row.updated_at.isoformat(), "gs.meta"),
            ]
            for row in rows
        ],
    )


def probe_comparison(result: ProbeComparison, console: Console) -> None:
    heading(
        console,
        "GET-only permission comparison",
        f"{result.host} · project {result.project.value} · {result.action.kind}",
    )
    console.print(
        literal(
            "Ready, merge and rebase remain deferred. "
            "Allowed means current preconditions, not guaranteed effect.",
            "gs.meta",
        )
    )
    records(
        console,
        ("Profile", "Identity", "Permission", "Reason / evidence", "Checked"),
        [
            [
                literal(row.profile.name, "gs.id"),
                literal(str(row.identity.value)) if row.identity else state("unknown"),
                state(row.kind),
                lines(
                    *[literal(v) for v in (row.reason, *row.evidence, row.error_code or "") if v]
                ),
                literal(row.checked_at.isoformat(), "gs.meta"),
            ]
            for row in result.rows
        ],
    )


def model_report(result: BaseModel, title: str, console: Console) -> None:
    """Complete human view for settings/preferences/probes/previews, separate from raw JSON."""
    if isinstance(result, SettingsResponse):
        settings_report(result, console)
        return
    payload = TypeAdapter[dict[str, JsonValue]](dict[str, JsonValue]).validate_python(
        result.model_dump(mode="json")
    )
    heading(console, title)
    json_report(payload, console)


def pipeline_rules(rules: PipelineRules, console: Console) -> None:
    grid(
        console,
        [
            ("Stage order", literal(" → ".join(stage.name for stage in rules.stages))),
            (
                "Dependencies",
                lines(
                    *[
                        literal(f"{s.name} ← {', '.join(s.depends_on)}")
                        for s in rules.stages
                        if s.depends_on
                    ]
                )
                or literal("none"),
            ),
            ("Important jobs", literal(", ".join(rules.important_job_patterns) or "none")),
        ],
    )
    records(
        console,
        ("Job pattern", "Role", "Environment"),
        [
            [literal(j.pattern, "gs.id"), literal(j.role), literal(j.environment or "none")]
            for j in rules.jobs
        ],
    )
    records(
        console,
        ("Environment", "Label", "Expected ref"),
        [
            [literal(e.name, "gs.id"), literal(e.label), literal(e.ref_source)]
            for e in rules.environments
        ],
    )


def filters_report(filters: Filters, console: Console) -> None:
    heading(console, "Shared filters", "Used by web and CLI work-item views")
    milestone = filters.milestone.mode
    if filters.milestone.selected is not None:
        selected = filters.milestone.selected
        owner = selected.project.value if selected.kind == "project" else selected.group.value
        milestone += f" · {selected.kind}:{owner}:{selected.id.value}"
    grid(
        console,
        [
            ("State", state(filters.state)),
            ("Assignment", literal("Assigned to me" if filters.assigned else "Any assignment")),
            ("Search", literal(filters.search or "None")),
            ("Group", literal(filters.group or "Any group")),
            ("Hidden items", literal("Shown" if filters.show_hidden else "Excluded")),
            ("Milestone", literal(milestone)),
        ],
    )


def settings_report(result: SettingsResponse, console: Console) -> None:
    settings = result.settings
    heading(
        console,
        "Operator settings",
        "Local file · configured expectations, not observed pipeline dependencies",
    )
    grid(
        console,
        [
            ("Timezone", literal(settings.timezone)),
            ("Branch template", literal(settings.branch_template)),
            (
                "Tag component",
                literal(
                    f"{settings.tag_convention.component_from_right + 1} from right · "
                    f"increment {settings.tag_convention.increment}"
                ),
            ),
            (
                "Tag padding",
                literal(
                    "preserved" if settings.tag_convention.preserve_padding else "not preserved"
                ),
            ),
            ("Revision", literal(result.revision, "gs.meta")),
        ],
    )
    console.print(Rule("Global pipeline rules", align="left", style="gs.frame"))
    pipeline_rules(settings.pipeline, console)
    for effective in result.effective:
        console.print(
            Rule(
                literal(f"Project {effective.project.value} · effective rules"),
                align="left",
                style="gs.frame",
            )
        )
        grid(
            console,
            [
                (
                    "Rule sources",
                    lines(
                        *[
                            literal(f"{name}: {source}")
                            for name, source in effective.sources.items()
                        ]
                    ),
                )
            ],
        )
        if effective.rules == settings.pipeline:
            console.print(literal("Same effective rules as global configuration.", "gs.meta"))
        else:
            pipeline_rules(effective.rules, console)
    console.print(
        literal("Exact override definitions and metadata: settings show --json", "gs.meta")
    )


def json_report(payload: JsonValue, console: Console, prefix: str = "") -> None:
    if isinstance(payload, dict):
        simple: list[tuple[str, Text]] = []
        nested: list[tuple[str, JsonValue]] = []
        for name, value in payload.items():
            if isinstance(value, dict | list):
                nested.append((name, value))
            else:
                label = name.replace("_", " ")
                rendered = literal("unknown" if value is None else str(value))
                if isinstance(value, str) and name in ("kind", "status", "state", "outcome"):
                    rendered = state(value)
                simple.append((label, rendered))
        grid(console, simple)
        for name, value in nested:
            path = f"{prefix}.{name}" if prefix else name
            console.print(Rule(literal(path), align="left", style="gs.frame"))
            json_report(value, console, path)
    elif isinstance(payload, list):
        for index, value in enumerate(payload):
            if index:
                console.print()
            json_report(value, console, f"{prefix}[{index + 1}]")
        if not payload:
            console.print(literal("none", "gs.meta"))
    else:
        console.print(literal("unknown" if payload is None else str(payload)))


def pipeline_graph(graph: PipelineGraph, console: Console) -> None:
    """Each scoped node retains its own commit; edges do not certify app versions."""
    heading(console, "Native pipeline graph", f"{graph.source} · coverage {graph.coverage.kind}")
    console.print(
        literal("Trigger edges do not prove the deployed application version.", "gs.meta")
    )
    roots = {root.key: root.application_sha for root in graph.roots}
    table = compact_table()
    for name in ("Pipeline / project", "Commit / relationship", "Jobs / deployments"):
        table.add_column(name, overflow="fold")
    for node in graph.nodes:
        ref = node.reference
        identity = literal(ref.key.key, "gs.id")
        identity.append("\n")
        identity.append(safe(ref.project_path), style="gs.id")
        commit = literal(ref.sha or "Commit unknown")
        if ref.key in roots:
            commit.append("\nApplication root", style="gs.meta")
        if isinstance(node, PipelineNodeUnavailable):
            summary = literal(node.reason, "gs.unknown")
        else:
            summary = literal(f"{len(node.pipeline.jobs)} jobs ({node.jobs_coverage.kind})")
            summary.append("\n")
            summary.append(
                f"{len(node.deployments)} deploy records ({node.deployments_coverage.kind})"
            )
            for deployment in node.deployments:
                summary.append(
                    f"\n{safe(deployment.environment)}: {deployment.record.status.value}",
                    style="gs.meta",
                )
        table.add_row(identity, commit, summary)
    console.print(table)
    for edge in graph.edges:
        job = (
            f"job {edge.source_job.project.value}:{edge.source_job.id.value}"
            if isinstance(edge.source_job, TriggerJob)
            else "source job unknown"
        )
        console.print(
            literal(
                f"{edge.upstream.key} → {edge.downstream.key} · {job} · {edge.origin}", "gs.meta"
            )
        )
    for relation in graph.unknown_relations:
        console.print(
            literal(
                f"{relation.pipeline.key} {relation.direction}: {relation.reason}", "gs.unknown"
            )
        )
    for warning in graph.warnings:
        console.print(literal(warning, "gs.wait"))
