from datetime import UTC, datetime
from unittest.mock import patch

import pytest
from pydantic import ValidationError

from gspace.config import Endpoint, HtmlExtraction, HtmlField, JsonExtraction, JsonField
from gspace.models import EnvironmentName, IssueIid, Observed, ProjectId, WorkKey
from gspace.observation import (
    ObservationFailure,
    extract,
    fetch,
    observe,
    resolve_address,
    validate_url,
)


def endpoint(**changes):
    data = dict(
        name=EnvironmentName.DEV,
        key=WorkKey(project=ProjectId(value=42), issue=IssueIid(value=791)),
        url="https://swagger.example.invalid/openapi.json",
        allowed_origins=("https://swagger.example.invalid",),
        extraction=JsonExtraction(fields=(JsonField(field="version", path="info.version"),)),
    )
    data.update(changes)
    return Endpoint(**data)


def test_json_and_limited_html_extractors():
    assert extract(b'{"info":{"version":"2.4.09"}}', endpoint()).version == "2.4.09"
    html = endpoint(
        extraction=HtmlExtraction(
            kind="html", fields=(HtmlField(field="tag", selector="#build", pattern="Tag: {value}"),)
        )
    )
    assert extract(b'<div id="build">Tag: release-2.4.09</div>', html).tag == "release-2.4.09"
    with pytest.raises(ValidationError):
        HtmlField(field="tag", selector="div *", pattern="{value}")
    with pytest.raises(ValidationError):
        HtmlField(field="tag", selector="div", pattern="(.*)+")
    with pytest.raises(ObservationFailure):
        extract(b'<div id="build">Tag: release</div><div id="build">Tag: other</div>', html)


def test_extraction_rejects_absent_paths_nonstrings_and_oversized_response():
    for body in (b"{}", b'{"info":{"version":123}}'):
        with pytest.raises(ObservationFailure):
            extract(body, endpoint())
    with pytest.raises(ObservationFailure, match="byte limit"):
        extract(b"a" * 129, endpoint(max_bytes=128))


@pytest.mark.parametrize(
    "url",
    [
        "https://evil.invalid/openapi.json",
        "http://swagger.example.invalid/openapi.json",
        "https://user:secret@swagger.example.invalid/openapi.json",
        "file:///etc/passwd",
        "https://swagger.example.invalid/?token=secret",
        "https://swagger.example.invalid/#fragment",
        "https://swagger.example.invalid:443/\r\nInjected:yes",
    ],
)
def test_url_policy_is_fail_closed(url):
    with pytest.raises(ObservationFailure):
        validate_url(url, endpoint())


def test_internal_dns_requires_explicit_network_and_rejects_mixed_resolution():
    rows = [(2, 1, 6, "", ("10.20.30.40", 443))]
    with patch("socket.getaddrinfo", return_value=rows):
        with pytest.raises(ObservationFailure):
            resolve_address("swagger.example.invalid", 443, endpoint())
        assert (
            resolve_address(
                "swagger.example.invalid", 443, endpoint(allowed_networks=("10.20.0.0/16",))
            )
            == "10.20.30.40"
        )
    with (
        patch("socket.getaddrinfo", return_value=rows + [(2, 1, 6, "", ("127.0.0.1", 443))]),
        pytest.raises(ObservationFailure),
    ):
        resolve_address(
            "swagger.example.invalid", 443, endpoint(allowed_networks=("10.20.0.0/16",))
        )


def test_observation_error_is_timestamped_sanitized_and_no_retry():
    calls = []

    def broken(ep):
        calls.append(ep)
        raise OSError("credential=secret in unsafe transport message")

    observation = observe(endpoint(), broken)
    assert observation.kind == "error"
    assert observation.code == "transport"
    assert "secret" not in observation.model_dump_json()
    assert observation.checked_at.tzinfo is not None
    assert len(calls) == 1
    valid = observe(endpoint(), lambda _: b'{"info":{"version":"2.4.09"}}')
    assert isinstance(valid, Observed)
    assert "https://" not in valid.source


def test_redirect_destination_is_validated_before_connection():
    calls = []

    class Response:
        status = 302

        def getheader(self, name, default=None):
            return "https://evil.invalid/openapi.json" if name == "Location" else default

    class Connection:
        def __init__(self, *args):
            calls.append(args)

        def request(self, *args, **kwargs):
            pass

        def getresponse(self):
            return Response()

        def close(self):
            pass

    with (
        patch("gspace.observation.resolve_address", return_value="1.1.1.1"),
        patch("gspace.observation.PinnedTLS", Connection),
        pytest.raises(ObservationFailure, match="allowlisted"),
    ):
        fetch(endpoint())
    assert len(calls) == 1


def test_verified_tls_preserves_original_hostname():
    from gspace.observation import PinnedTLS

    with (
        patch("gspace.observation.socket.create_connection") as connect,
        patch("gspace.observation.ssl.create_default_context") as context,
    ):
        connection = PinnedTLS("swagger.example.invalid", 443, "10.20.30.40", 5)
        connection.connect()
        connect.assert_called_once_with(("10.20.30.40", 443), 5)
        context.return_value.wrap_socket.assert_called_once_with(
            connect.return_value, server_hostname="swagger.example.invalid"
        )


def test_configured_observation_changes_only_remote_state(service, key, tmp_path):
    from gspace.config import AppConfig
    from gspace.service import Service

    cfg = AppConfig(
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
        endpoints=(endpoint(),),
    )
    service = Service(cfg)
    observed = Observed(
        value=extract(b'{"info":{"version":"2.4.09"}}', endpoint()),
        source="synthetic",
        checked_at=datetime.now(UTC),
    )
    result = service.observe_environment(key, EnvironmentName.DEV, observer=lambda _: observed)
    assert result.environments[0].observation == observed
    assert not cfg.preferences_path.exists()
    assert not cfg.cache_path.exists()


@pytest.mark.parametrize("mode", ["fixture", "live"])
def test_custom_environment_observation_reaches_api_and_live_cache(tmp_path, monkeypatch, mode):
    from fastapi.testclient import TestClient

    from gspace.api import create_app
    from gspace.config import AppConfig
    from gspace.fixture import synthetic_snapshot
    from gspace.models import Snapshot, Version
    from gspace.pipeline_config import EnvironmentDefinition, PipelineRules
    from gspace.service import Service
    from tests.test_glab import live

    target = endpoint(name="qa", expected=Version(version="qa-build-7"))
    defaults = PipelineRules()
    rules = PipelineRules(
        environments=defaults.environments
        + (EnvironmentDefinition(name="qa", label="Quality assurance", ref_source="branch"),)
    )
    cfg = AppConfig(
        mode=mode,
        live=live() if mode == "live" else None,
        preferences_path=tmp_path / "prefs.toml",
        cache_path=tmp_path / "cache.json",
        pipeline=rules,
        endpoints=(target,),
    )
    service = Service(cfg)
    if mode == "live":
        payload = synthetic_snapshot().model_dump()
        payload["source"] = "glab"  # Injected remote snapshot, never a real GitLab call.
        service._snapshot = Snapshot.model_validate(payload)
    before = service.preferences.read()
    calls = []

    def fixture_fetch(configured):
        calls.append(configured)
        return b'{"info":{"version":"qa-build-7"}}'

    observe_environment = Service.observe_environment
    monkeypatch.setattr(
        Service,
        "observe_environment",
        lambda self, key, name: observe_environment(
            self, key, name, observer=lambda configured: observe(configured, fixture_fetch)
        ),
    )
    response = TestClient(create_app(service=service)).post("/api/items/42/791/observe/qa", json={})
    assert response.status_code == 200
    observed = next(e for e in response.json()["item"]["environments"] if e["name"] == "qa")
    assert observed["observation"]["kind"] == "observed"
    assert observed["observation"]["value"]["version"] == "qa-build-7"
    assert observed["expected"]["version"] == "qa-build-7"
    assert calls == [target]
    assert service.preferences.read() == before
    assert not cfg.preferences_path.exists()
    assert cfg.cache_path.exists() == (mode == "live")
    if mode == "live":
        restored = Service(cfg)
        cached = next(e for e in restored.item(target.key).environments if e.name == "qa")
        assert cached.observation.kind == "observed"


def test_explicit_probe_expectation_applies_to_new_configured_environment(tmp_path):
    from gspace.config import AppConfig
    from gspace.models import Version
    from gspace.pipeline_config import EnvironmentDefinition, PipelineRules
    from gspace.service import Service

    target = endpoint(name="qa", expected=Version(version="qa-build-7"))
    defaults = PipelineRules()
    service = Service(
        AppConfig(
            preferences_path=tmp_path / "prefs.toml",
            cache_path=tmp_path / "cache.json",
            endpoints=(target,),
            pipeline=PipelineRules(
                environments=defaults.environments
                + (EnvironmentDefinition(name="qa", label="QA", ref_source="branch"),)
            ),
        )
    )
    view = service.view(service.item(target.key), service.preferences.read())
    environment = next(e for e in view.item.environments if e.name == "qa")
    assert environment.expected == target.expected
    assert environment.observation.kind == "unknown"


def test_dns_has_a_bounded_deadline():
    import time

    def slow_dns(*_args, **_kwargs):
        time.sleep(0.2)
        return [(2, 1, 6, "", ("1.1.1.1", 443))]

    started = time.monotonic()
    with (
        patch("socket.getaddrinfo", side_effect=slow_dns),
        pytest.raises(ObservationFailure, match="DNS timeout"),
    ):
        resolve_address("swagger.example.invalid", 443, endpoint(), timeout=0.02)
    assert time.monotonic() - started < 0.15


def test_http_body_and_redirect_limits_are_enforced():
    class Response:
        def __init__(self, status, payload):
            self.status = status
            self.payload = payload

        def getheader(self, name, default=None):
            return "/redirect" if name == "Location" else default

        def read1(self, size):
            chunk, self.payload = self.payload[:size], self.payload[size:]
            return chunk

    class Connection:
        sock = None
        response = Response(200, b"x" * 129)

        def __init__(self, *_args):
            pass

        def request(self, *_args, **_kwargs):
            pass

        def getresponse(self):
            return self.response

        def close(self):
            pass

    with (
        patch("gspace.observation.resolve_address", return_value="1.1.1.1"),
        patch("gspace.observation.PinnedTLS", Connection),
        pytest.raises(ObservationFailure, match="byte limit"),
    ):
        fetch(endpoint(max_bytes=128))
    Connection.response = Response(302, b"")
    with (
        patch("gspace.observation.resolve_address", return_value="1.1.1.1"),
        patch("gspace.observation.PinnedTLS", Connection),
        pytest.raises(ObservationFailure, match="redirect limit"),
    ):
        fetch(endpoint(max_redirects=0))
