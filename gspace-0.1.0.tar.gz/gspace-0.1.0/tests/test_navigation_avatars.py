import hashlib
import json
import struct
import subprocess
import sys
import zlib
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from gspace.api import create_app
from gspace.avatar_policy import AvatarPolicy
from gspace.avatars import (
    ProjectAvatarDTO,
    ProjectAvatars,
    ProjectPresentation,
    avatar_request,
    sanitize_png,
)
from gspace.models import ProjectId
from gspace.navigation import (
    Bookmark,
    BookmarkTarget,
    NavigationDecoration,
    SavedView,
    SavedViewTarget,
    WorkReference,
)
from gspace.observation import ObservationFailure, fetch, resolve_address
from gspace.preferences import PreferenceConflict, StoredPreferences
from gspace.service import (
    BookmarkDelete,
    BookmarkSet,
    FlagChange,
    NavigationDecorationSet,
    SavedViewDelete,
    SavedViewSet,
)


def png(width=1, height=1, metadata=False, raw=None):
    def chunk(kind, body):
        return (
            struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body))
        )

    header = chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
    data = zlib.compress(raw if raw is not None else b"\0" + b"\xff\0\0\xff")
    return (
        b"\x89PNG\r\n\x1a\n"
        + header
        + (chunk(b"tEXt", b"Comment\0untrusted metadata") if metadata else b"")
        + chunk(b"IDAT", data)
        + chunk(b"IEND", b"")
    )


def seed(service, key):
    reference = WorkReference(key=key)
    service.change(
        BookmarkSet(
            revision=0, bookmark=Bookmark(host="fixture", reference=reference, label="Flight")
        )
    )
    target = BookmarkTarget(host="fixture", reference=reference)
    service.change(
        NavigationDecorationSet(
            revision=1,
            decoration=NavigationDecoration(
                target=target, icon="rocket", color="teal", pinned=True, order=4
            ),
        )
    )
    return target


def test_navigation_shared_storage_api_projection_and_cascade(service, key):
    target = seed(service, key)
    client = TestClient(create_app(service=service))
    assert client.get("/api/navigation").json()["decorations"][0]["target"] == target.model_dump(
        mode="json"
    )
    assert "navigation_decorations" not in client.get("/api/preferences").json()
    assert "navigation_decorations" not in client.get("/api/dashboard").json()["preferences"]
    assert service.preferences.read().navigation_decorations[0].icon == "rocket"
    assert "navigation_decorations" in service.preferences.path.read_text()
    service.change(FlagChange(revision=2, operation="select", key=key, enabled=True))
    assert service.navigation().decorations[0].color == "teal"
    with pytest.raises(PreferenceConflict):
        service.change(
            NavigationDecorationSet(revision=2, decoration=NavigationDecoration(target=target))
        )
    service.change(BookmarkDelete(revision=3, reference=target.reference))
    assert not service.navigation().decorations


@pytest.mark.parametrize(
    "changes",
    [
        {"icon": "https://evil.invalid/icon.svg"},
        {"color": "url(https://evil.invalid)"},
        {"order": True},
        {"order": 1001},
        {"pinned": "true"},
        {"html": "<svg>"},
    ],
)
def test_decoration_rejects_arbitrary_content_and_coercion(key, changes):
    data = NavigationDecoration(
        target=BookmarkTarget(host="fixture", reference=WorkReference(key=key))
    ).model_dump()
    with pytest.raises(ValidationError):
        NavigationDecoration.model_validate({**data, **changes})


def test_navigation_targets_are_real_scoped_and_migrated(service, key):
    target = BookmarkTarget(host="fixture", reference=WorkReference(key=key))
    with pytest.raises(ValueError, match="does not exist"):
        service.change(
            NavigationDecorationSet(revision=0, decoration=NavigationDecoration(target=target))
        )
    assert not service.preferences.path.exists()
    with pytest.raises(ValueError, match="another instance"):
        service.change(
            NavigationDecorationSet(
                revision=0,
                decoration=NavigationDecoration(target=SavedViewTarget(host="other", name="Daily")),
            )
        )
    service.change(
        SavedViewSet(
            revision=0,
            view=SavedView(
                host="fixture", name="Daily", scope="work_items", projects=(key.project,)
            ),
        )
    )
    service.change(
        NavigationDecorationSet(
            revision=1,
            decoration=NavigationDecoration(
                target=SavedViewTarget(host="fixture", name="Daily"), order=1
            ),
        )
    )
    service.change(SavedViewDelete(revision=2, name="Daily"))
    assert not service.preferences.read().navigation_decorations
    assert StoredPreferences.model_validate({"revision": 0}).navigation_decorations == ()
    with pytest.raises(ValidationError, match="duplicate"):
        StoredPreferences(
            bookmarks=(Bookmark(host="fixture", reference=target.reference, label="Flight"),),
            navigation_decorations=(
                NavigationDecoration(target=target),
                NavigationDecoration(target=target),
            ),
        )


def test_cli_navigation_reads_and_updates_same_toml(service, key, tmp_path):
    seed(service, key)
    config = tmp_path / "fixture.toml"
    config.write_text(
        f'mode="fixture"\npreferences_path="{service.preferences.path}"\n'
        f'cache_path="{tmp_path / "cache.json"}"\n'
    )
    command = [sys.executable, "-m", "gspace", "navigation", "--config", str(config), "--json"]
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    assert not result.stderr
    assert json.loads(result.stdout)["decorations"][0]["pinned"] is True
    decoration = service.navigation().decorations[0].model_dump(mode="json")
    decoration["color"] = "purple"
    payload = tmp_path / "decoration.json"
    payload.write_text(json.dumps(decoration))
    changed = subprocess.run(
        [
            sys.executable,
            "-m",
            "gspace",
            "navigation-set",
            "--config",
            str(config),
            str(payload),
            "--json",
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    assert not changed.stderr
    assert service.preferences.read().navigation_decorations[0].color == "purple"


def test_avatar_api_fallback_is_local_and_scoped_without_provider_call(service):
    client = TestClient(create_app(service=service))
    with patch.object(service, "_avatar_metadata", side_effect=AssertionError("No network")):
        data = client.get("/api/projects/42/presentation").json()
        assert data["avatar"]["kind"] == "fallback" and data["avatar"]["reason"] == "fixture"
        assert data["avatar_src"] == "/api/projects/42/avatar"
        image = client.get(data["avatar_src"] + "?url=https://evil.invalid/secret")
        assert image.status_code == 200 and image.headers["content-type"].startswith(
            "image/svg+xml"
        )
    assert client.get("/api/projects/999/presentation").status_code == 400
    with pytest.raises(ValidationError):
        ProjectPresentation.model_validate({**data, "avatar_src": "https://evil.invalid/avatar"})


@pytest.mark.parametrize(
    "url",
    [
        "https://evil.invalid/uploads/-/system/project/avatar/42/icon.png",
        "https://gitlab.example.invalid/uploads/-/system/project/avatar/99/icon.png",
        "https://gitlab.example.invalid/uploads/-/system/project/avatar/42/../icon.png",
        "https://gitlab.example.invalid/uploads/-/system/project/avatar/42/%2Ficon.png",
        "https://gitlab.example.invalid/uploads/-/system/project/avatar/42/icon.png?secret=x",
        "http://gitlab.example.invalid/uploads/-/system/project/avatar/42/icon.png",
    ],
)
def test_avatar_url_never_accepts_foreign_origin_or_arbitrary_paths(url):
    with pytest.raises(ObservationFailure):
        avatar_request(
            url, "https://gitlab.example.invalid", ProjectId(value=42), AvatarPolicy(enabled=True)
        )


def test_avatar_opt_in_cache_sanitization_capacity_ttl_and_failure():
    project = ProjectId(value=42)
    now = [1.0]
    calls = []

    def provider(key):
        calls.append(key)
        return ProjectAvatarDTO(
            id=key.value,
            avatar_url=f"https://gitlab.example.invalid/uploads/-/system/project/avatar/{key.value}/icon.png",
        )

    getter_calls = []

    def getter(request):
        assert request.max_redirects == 0
        getter_calls.append(request)
        return png(metadata=True)

    policy = AvatarPolicy(enabled=True, ttl_seconds=10, max_cached=1)
    avatars = ProjectAvatars(
        "https://gitlab.example.invalid",
        policy,
        fixture=False,
        provider=provider,
        getter=getter,
        clock=lambda: now[0],
    )
    first = avatars.get(project, "demo/flight")
    assert first.presentation.avatar.kind == "cached_png"
    assert b"untrusted metadata" not in first.body
    assert first.presentation.avatar.sha256 == hashlib.sha256(first.body).hexdigest()
    assert avatars.get(project, "demo/flight") is first and len(getter_calls) == 1
    now[0] = 12
    assert avatars.get(project, "demo/flight") is not first and len(getter_calls) == 2
    avatars.get(ProjectId(value=99), "demo/deploy")
    avatars.get(project, "demo/flight")
    assert calls == [project, project, ProjectId(value=99), project]
    disabled = ProjectAvatars(
        "https://gitlab.example.invalid",
        AvatarPolicy(),
        fixture=False,
        provider=lambda _: pytest.fail("disabled provider"),
    )
    assert disabled.get(project, "demo/flight").presentation.avatar.reason == "disabled"
    rejected = ProjectAvatars(
        "https://gitlab.example.invalid",
        policy,
        fixture=False,
        provider=provider,
        getter=lambda _: b"<svg><script>bad</script></svg>",
    )
    assert rejected.get(project, "demo/flight").presentation.avatar.reason == "rejected"
    mismatch = ProjectAvatars(
        "https://gitlab.example.invalid",
        policy,
        fixture=False,
        provider=lambda _: ProjectAvatarDTO(id=99),
    )
    assert mismatch.get(project, "demo/flight").presentation.avatar.reason == "rejected"


@pytest.mark.parametrize(
    "body",
    [
        b"<svg/>",
        png(width=1025),
        png(raw=b"\0" + b"x" * 100000),
        png() + b"trailing",
        png()[:-1],
        png().replace(b"IHDR", b"BAD!"),
    ],
)
def test_png_bounds_crc_decoded_bomb_and_invalid_body(body):
    with pytest.raises((ValueError, zlib.error)):
        sanitize_png(body, AvatarPolicy())


def test_avatar_fetch_uses_existing_pinned_tls_dns_redirect_and_bytes_guards():
    request = avatar_request(
        "https://gitlab.example.invalid/uploads/-/system/project/avatar/42/icon.png",
        "https://gitlab.example.invalid",
        ProjectId(value=42),
        AvatarPolicy(enabled=True),
    )
    with (
        patch(
            "gspace.observation.socket.getaddrinfo",
            return_value=[(None, None, None, None, ("10.2.3.4", 443))],
        ),
        pytest.raises(ObservationFailure, match="not allowed"),
    ):
        resolve_address("gitlab.example.invalid", 443, request)

    class Response:
        status = 302

        def getheader(self, name, default=None):
            return "https://evil.invalid/icon.png" if name == "Location" else default

    class Connection:
        sock = None

        def __init__(self, *args):
            pass

        def request(self, *args, **kwargs):
            assert "Authorization" not in kwargs.get("headers", {})

        def getresponse(self):
            return Response()

        def close(self):
            pass

    with (
        patch("gspace.observation.resolve_address", return_value="93.184.216.34"),
        patch("gspace.observation.PinnedTLS", Connection),
        pytest.raises(ObservationFailure, match="redirect limit"),
    ):
        fetch(request)


def test_navigation_preserves_archived_targets_but_filters_catalog_scope(service, key):
    from gspace.models import IssueIid, WorkKey
    from gspace.navigation import NavigationCatalog

    allowed = WorkReference(key=key)
    archived = WorkReference(key=WorkKey(project=ProjectId(value=999), issue=IssueIid(value=791)))
    bookmarks = (
        Bookmark(host="fixture", reference=allowed, label="Allowed"),
        Bookmark(host="fixture", reference=archived, label="Archived"),
    )
    decorations = tuple(
        NavigationDecoration(target=BookmarkTarget(host="fixture", reference=b.reference))
        for b in bookmarks
    )
    service.preferences.update(
        lambda _: StoredPreferences(
            instance_origin="fixture", bookmarks=bookmarks, navigation_decorations=decorations
        )
    )
    catalog = service.navigation()
    assert len(catalog.bookmarks) == len(catalog.decorations) == 1
    assert len(service.preferences.read().navigation_decorations) == 2
    with pytest.raises(ValidationError, match="scope"):
        NavigationCatalog.model_validate({**catalog.model_dump(), "bookmarks": bookmarks})


def test_navigation_catalog_serves_selectable_icons_and_colors(service):
    from gspace.navigation import NavigationCatalog

    catalog = TestClient(create_app(service=service)).get("/api/navigation").json()
    assert len(catalog["icons"]) == 16 and {"calendar", "rocket"} <= set(catalog["icons"])
    assert len(catalog["colors"]) == 10 and {"purple", "teal"} <= set(catalog["colors"])
    for field in ("icons", "colors"):
        with pytest.raises(ValidationError, match="must not be empty"):
            NavigationCatalog.model_validate({**catalog, field: []})
