// Stage renderers for the vertical process reading (matrix cells and the
// item lane), plus the manual version-bound application-test controls.
// Every relation shown here comes from typed fields; a name match alone is
// never commit identity, and an override or convention association never
// creates a solid edge by itself.

import { actionEntry, editDraftEntry } from './access';
import type { ApplicationTestEvidence, ApplicationTestRecord, Association, Job, Link, Pipeline, Version } from './api';
import { versionParts } from './api';
import { attentionOf } from './attention';
import type { Kid } from './dom';
import {
  appTestBadge,
  breakable,
  compareBadge,
  controlValue,
  draftChip,
  extLink,
  fmtTime,
  h,
  icon,
  legacyAppTestBadge,
  line,
  lineOpt,
  lines,
  mrStateBadge,
  none,
  openOf,
  plural,
  rebaseBadge,
  STATUS,
  sha,
  sourceLabel,
  statusBadge,
  tone,
} from './dom';
import { evidence } from './evidence';
import { observe, reloadItemData } from './load';
import type { Commit, EnvNode, JobGroup, PipeNode, Proc, StageDef } from './model';
import { deployJobsOf, envLabel, groupJobs, jobCfgOf, mrSha, stageDeps, stageOrder } from './model';
import { render } from './render';
import type { AppTestDraft, Outcome } from './state';
import { branchHref, jobHref, mrHref, pipeHref, pref, S, say, sectionOpen, to, wkStr } from './state';

/* ---------------------------------------------------------- results */

// basis: root (start), ref (linked by record fields), cand (equal SHA/name
// only), ind (independent evidence), none (no link in data)
export type Basis = 'root' | 'ref' | 'cand' | 'ind' | 'none' | 'summary';
type NodeKind = Exclude<Basis, 'summary'> | 'empty';
export interface StageResult {
  readonly basis: Basis;
  readonly nodes: readonly Kid[];
}
type Pair = readonly [Exclude<Basis, 'summary'>, HTMLElement];
/**
 * det: detail lane with reasons and actions; envs: environments shown;
 * envActions: false where the item's Environments panel already holds the
 * runtime read and manual test controls (no duplicate controls on a page).
 */
export interface StageOpts {
  readonly det: boolean;
  readonly envs: readonly string[];
  readonly envActions?: boolean;
}

const BASIS_ORDER: readonly Exclude<Basis, 'summary'>[] = ['root', 'ref', 'cand', 'ind', 'none'];
const nd = (kind: NodeKind, kids: Kid): HTMLDivElement => h('div', { class: `pn k-${kind}` }, kids);
/** A process node (rail marker + content) for lanes outside the item process. */
export const processNode = nd;

function resOf(pairs: readonly Pair[]): StageResult {
  const bs = pairs.map((p) => p[0]);
  return { basis: BASIS_ORDER.find((b) => bs.includes(b)) ?? 'none', nodes: pairs.map((p) => p[1]) };
}
function emptyRes(text: string, hint: string | null = null): StageResult {
  return { basis: 'none', nodes: [nd('empty', [none(text), hint ? h('div', { class: 'reason' }, hint) : null])] };
}
const via = (text: string): HTMLDivElement => h('div', { class: 'via' }, text);

export function commitEl(c: Commit | null, missing = 'Commit not supplied'): HTMLSpanElement {
  if (!c) return h('span', { class: 'cmt' }, h('span', { class: 'cm cm-u', 'aria-hidden': 'true' }, '?'), h('span', { class: 'muted' }, missing));
  return h(
    'span',
    { class: 'cmt', title: `Commit ${c.letter}: ${c.sha}` },
    h('span', { class: `cm cm-${c.idx < 6 ? c.idx : 'x'}`, 'aria-hidden': 'true' }, c.letter),
    h('code', { class: 'mono' }, c.sha.slice(0, 8)),
    h('span', { class: 'sr' }, `, commit ${c.letter}`),
  );
}

/** Only the per-item commit letter (the SHA is in its title and in the evidence). */
export function commitLetter(c: Commit | null): HTMLSpanElement | null {
  if (!c) return null;
  return h(
    'span',
    { class: 'cmt', title: `Commit ${c.letter}: ${c.sha}` },
    h('span', { class: `cm cm-${c.idx < 6 ? c.idx : 'x'}`, 'aria-hidden': 'true' }, c.letter),
    h('span', { class: 'sr' }, `commit ${c.letter}`),
  );
}

// Compact cells skip the "not established" chip when the commit itself is
// missing; the commit line already says so. Detail views keep it.
function relChip(c: Commit | null, parent: Commit | null | undefined, what: string, det = true): HTMLSpanElement | null {
  if (!parent || (!c && !det)) return null;
  if (!c)
    return h(
      'span',
      { class: 'chip st t-unknown', title: `Commit identity with the ${what} is not established` },
      icon('s_unknown', 'sm'),
      h('span', null, 'SHA not established'),
    );
  if (c === parent)
    return h(
      'span',
      { class: 'chip st t-neutral', title: `Same commit ${c.letter} as the ${what}` },
      icon('s_match', 'sm'),
      h('span', null, `same SHA as ${what}`),
    );
  return h(
    'span',
    { class: 'chip st t-muted', title: `Commit ${c.letter} differs from the ${what} (${parent.letter})` },
    icon('s_mismatch', 'sm'),
    h('span', null, `SHA differs from ${what}`),
  );
}

/* -------------------------------------------------------------- jobs */

export function cfgMarks(p: Pipeline, j: Job, withRole: boolean): Kid {
  const c = jobCfgOf(p, j);
  if (!c) return null;
  const env = c.environment ? envLabel(c.environment) : null;
  return [
    c.important ? h('span', { class: 'imp', title: 'Important job (operator setting)' }, icon('star', 'xs'), h('span', { class: 'sr' }, ', important')) : null,
    withRole && c.role === 'publish' ? h('span', { class: 'role', title: 'Configured publish job' }, 'publish') : null,
    withRole && c.role === 'deploy'
      ? h('span', { class: 'role', title: `Configured deploy job for ${env ?? 'an environment that is not named'}` }, `deploy → ${env ?? '?'}`)
      : null,
  ];
}

function jobMini(g: JobGroup, p: Pipeline, withRole = false): HTMLDivElement {
  const j = g.current;
  const [t, ico, label] = STATUS[j.status];
  const earlier = g.attempts.filter((a) => a !== j);
  return h(
    'div',
    { class: 'jm' },
    h(
      'a',
      {
        class: `jm-link t-${t}`,
        href: to(jobHref(p.project.value, p.id.value, j.id.value)),
        title: `${j.name}: ${label}, attempt ${j.attempt}${j.failure_reason ? ` — ${j.failure_reason}` : ''}`,
      },
      icon(ico, 'sm'),
      h('span', { class: 'jm-name' }, j.name),
      h('span', { class: 'sr' }, `: ${label}`),
    ),
    cfgMarks(p, j, withRole),
    j.attempt > 1 ? h('span', { class: 'jm-att', title: `Attempt ${j.attempt}` }, `try ${j.attempt}`) : null,
    earlier.length
      ? h(
          'span',
          { class: 'jm-att', title: earlier.map((a) => `attempt ${a.attempt}: ${a.status}`).join(', ') },
          icon('retry', 'sm'),
          h('span', null, String(earlier.length)),
          h('span', { class: 'sr' }, ` earlier attempt${earlier.length === 1 ? '' : 's'} superseded`),
        )
      : null,
    j.status === 'failed' && j.failure_reason ? h('span', { class: 'jm-fail' }, j.failure_reason) : null,
  );
}

// Compact cells summarise operator-marked important jobs when a
// classification exists, and always link to the pipeline with every job.
// "Show all jobs" (Fields menu) turns the summary off.
export function jobsBlock(p: Pipeline, compact = false): HTMLElement {
  const jobs = p.jobs;
  if (!jobs.length) return none('No jobs reported');
  const imp = (j: Job): boolean => jobCfgOf(p, j)?.important === true;
  const focus = compact && !S.allJobs && jobs.some(imp);
  const rows = stageOrder(jobs, p).map((s) => {
    let gs = groupJobs(jobs.filter((j) => j.stage === s));
    if (focus) gs = gs.filter((g) => g.attempts.some(imp));
    if (!gs.length) return null;
    const deps = stageDeps(p, jobs, s);
    return h(
      'div',
      { class: 'jb-row' },
      h(
        'span',
        { class: 'jb-stage', title: `Stage ${s}${deps.length ? ` · expected after ${deps.join(', ')} (operator expectation, not the observed CI DAG)` : ''}` },
        s,
      ),
      h(
        'div',
        { class: 'jb-jobs' },
        gs.map((g) => jobMini(g, p, !compact)),
      ),
    );
  });
  const other = focus ? groupJobs(jobs).filter((g) => !g.attempts.some(imp)).length : 0;
  return h(
    'div',
    { class: 'jb' },
    rows,
    other
      ? h(
          'a',
          { class: 'jb-more', href: to(pipeHref(p.project.value, p.id.value)), title: 'Open the pipeline to see every job and attempt' },
          `+${plural(other, 'other job')}`,
        )
      : null,
  );
}

// The evidence trigger stays glued to its identity link (`#9201 ⓘ`), so only
// the qualifier text can wrap and the trigger never jumps to its own line.
const idPair = (...kids: Kid[]): HTMLSpanElement => h('span', { class: 'idp' }, kids);

function pipeHead(x: PipeNode, ev: Kid, link: Kid = null): HTMLDivElement {
  return line(
    statusBadge(x.p.status, { prefix: 'Pipeline' }),
    idPair(h('a', { class: 'mono strong', href: to(pipeHref(x.p.project.value, x.p.id.value)) }, `#${x.p.id.value}`), ev),
    h('span', { class: 'muted' }, sourceLabel(x.p.source)),
    link,
  );
}

const evKey = (P: Proc, o: StageOpts, kind: string, id: string | number): string => `ev-${o.det ? 'd' : 'c'}-${wkStr(P.it.identity)}-${kind}-${id}`;

// Provenance of the record's own link, shown inside evidence popovers.
function linkNote(link: Link | null | undefined): HTMLParagraphElement | null {
  if (!link?.url) return null;
  return link.verification === 'fixture'
    ? h('p', null, h('span', { class: 'muted' }, 'Link: '), 'synthetic fixture address, deliberately unavailable.')
    : h('p', null, h('span', { class: 'muted' }, 'Link: '), 'validated against the configured instance.');
}

const ev = (key: string, a: Association | null, extra: readonly Kid[] = [], heading: string | null = null): HTMLButtonElement | null =>
  evidence(key, a, extra, heading);

/* ------------------------------------------------------------ stages */

function stBranch(P: Proc, o: StageOpts): StageResult {
  if (!P.branches.length) return emptyRes('No associated branch', o.det ? 'A branch whose name merely matches is not linked without evidence.' : null);
  return resOf(
    P.branches.map(
      ({ b, c }): Pair => [
        'root',
        nd('root', [
          line(
            icon('branch', 'sm'),
            idPair(
              h('a', { class: 'mono strong', href: to(branchHref(b.project.value, b.name)) }, b.name),
              ev(evKey(P, o, 'branch', `${b.project.value}-${b.name}`), b.association, [
                b.rebase.kind === 'verified'
                  ? h(
                      'p',
                      null,
                      h('span', { class: 'muted' }, 'Rebase evidence: '),
                      b.rebase.source,
                      ' · ',
                      h('span', { class: 'nowrap' }, fmtTime(b.rebase.checked_at) ?? 'time not supplied'),
                    )
                  : null,
                linkNote(b.link),
              ]),
            ),
            o.det ? extLink(b.link, 'Branch') : null,
          ),
          line(commitEl(c), rebaseBadge(b.rebase)),
          o.det && b.rebase.kind !== 'verified' ? h('div', { class: 'reason' }, b.rebase.reason) : null,
          o.det
            ? lineOpt(
                actionEntry('run_pipeline', { project: b.project.value, branch: b.name, expected_sha: b.sha }, 'Run pipeline…'),
                actionEntry('create_tag', { project: b.project.value, branch: b.name, expected_sha: b.sha }, 'Create tag…'),
              )
            : null,
        ]),
      ],
    ),
  );
}

function stMr(P: Proc, o: StageOpts): StageResult {
  if (!P.mrs.length) return emptyRes('No associated merge request');
  return resOf(
    P.mrs.map((x): Pair => {
      const m = x.m;
      const basis = x.br ? 'ref' : 'none';
      const src = x.src;
      return [
        basis,
        nd(basis, [
          line(
            idPair(
              h('a', { class: 'mono strong', href: to(mrHref(m.project.value, m.iid.value)) }, `!${m.iid.value}`),
              ev(evKey(P, o, 'mr', `${m.project.value}-${m.iid.value}`), m.association, [
                src.known ? h('p', null, 'Source commit ', h('code', { class: 'mono' }, src.sha), ` reported by the ${src.from}.`) : null,
                x.oc ? h('p', null, 'Authored catalog reports ', h('code', { class: 'mono' }, x.oc.sha), '.') : null,
                h('p', null, x.row ? 'In your authored catalog.' : 'Not in your authored catalog (unrelated to its source commit).'),
                linkNote(m.link),
              ]),
            ),
            mrStateBadge(m),
            draftChip(m),
            o.det ? extLink(m.link, 'MR') : null,
          ),
          o.det ? h('div', { class: 'ttl' }, m.title) : null,
          via(
            x.br
              ? `source ${m.source_branch} → ${m.target_branch}`
              : `source ${m.source_branch} → ${m.target_branch}; the source is not one of this item's branches`,
          ),
          line(commitEl(x.c, 'Source commit unknown'), relChip(x.c, x.br?.c, 'branch head', false)),
          x.oc && src.known
            ? line(
                tone('warn', 's_mismatch', 'catalog source differs', `The authored catalog reports ${x.oc.sha}; the MR record reports ${src.sha}`),
                commitEl(x.oc),
              )
            : null,
          o.det && !src.known ? h('div', { class: 'reason' }, src.why) : null,
          o.det ? lineOpt(editDraftEntry(m, mrSha(src))) : null,
        ]),
      ];
    }),
  );
}

function pipeVia(x: PipeNode): readonly [Exclude<Basis, 'summary'>, string] {
  const p = x.p;
  if (x.kind === 'ambiguous') return ['cand', `ref ${p.ref} matches both a branch and a tag name`];
  if (x.br) return ['ref', `ran on branch ${p.ref}`];
  if (x.mrsByRef.length) return ['ref', `ran on ${p.ref}, the source branch of ${x.mrsByRef.map((y) => `!${y.m.iid.value}`).join(', ')}`];
  return ['none', `ref ${p.ref} is not one of this item's branches or tags`];
}

function stPipeline(P: Proc, o: StageOpts): StageResult {
  const list = P.pipes.filter((x) => x.kind !== 'tag');
  if (!list.length) return emptyRes('No branch or MR pipeline');
  return resOf(
    list.map((x): Pair => {
      const [basis, text] = pipeVia(x);
      return [
        basis,
        nd(basis, [
          pipeHead(x, ev(evKey(P, o, 'pipe', x.p.id.value), x.p.association, [linkNote(x.p.link)]), o.det ? extLink(x.p.link, 'Pipeline') : null),
          via(text),
          line(commitEl(x.c), relChip(x.c, x.br?.c, 'branch head', o.det)),
          o.det
            ? lineOpt(
                actionEntry('change_pipeline', { project: x.p.project.value, id: x.p.id.value, expected_sha: x.p.sha, operation: 'retry' }, 'Retry or cancel…'),
              )
            : null,
        ]),
      ];
    }),
  );
}

function stJobs(P: Proc, o: StageOpts): StageResult {
  const list = P.pipes.filter((x) => x.kind !== 'tag');
  if (!list.length) return emptyRes('No pipeline, so no jobs');
  return resOf(list.map((x): Pair => ['ref', nd('ref', [list.length > 1 || o.det ? via(`jobs of pipeline #${x.p.id.value}`) : null, jobsBlock(x.p, !o.det)])]));
}

function stPublish(P: Proc, o: StageOpts): StageResult {
  if (!P.pubs.length) return emptyRes('No publish evidence', o.det ? 'A successful pipeline or job alone does not show that an artifact was published.' : null);
  return resOf(
    P.pubs.map((x): Pair => {
      const basis = x.job ? 'ref' : 'none';
      return [
        basis,
        nd(basis, [
          line(statusBadge(x.x.status, { prefix: 'Publish' })),
          o.det ? h('code', { class: 'mono art-b' }, breakable(x.x.artifact)) : h('code', { class: 'mono art', title: x.x.artifact }, x.x.artifact),
          via(
            x.job
              ? `from job ${x.job.name} #${x.x.job.value} in pipeline #${x.x.pipeline.value}`
              : x.pp
                ? `references job #${x.x.job.value}, which pipeline #${x.x.pipeline.value} does not list`
                : `references pipeline #${x.x.pipeline.value}, which is not in this item's data`,
          ),
          o.det ? h('div', { class: 'reason' }, x.x.source) : null,
          o.det ? line(x.x.link ? extLink(x.x.link, 'Artifact') : none('No artifact link')) : null,
        ]),
      ];
    }),
  );
}

// An environment shown for other items may not exist for this item's project.
const notHere = (n: string): Pair => ['none', nd('empty', [line(h('span', { class: 'lbl' }, envLabel(n)), none('Not configured for this project'))])];

function stDeploy(P: Proc, name: string, o: StageOpts): StageResult {
  const E = P.envs.get(name);
  const label = E?.def.label ?? envLabel(name);
  if (!E) return emptyRes(`${label} is not configured for this project`);
  if (!E.env) return emptyRes(`No ${label} environment in the snapshot`);
  if (!E.deps.length) {
    return emptyRes('No deployment record', o.det ? `Manual deploy jobs, if any, appear under jobs; a job status is not a ${label} deployment record.` : null);
  }
  return resOf(
    E.deps.map((x): Pair => {
      const d = x.d;
      const basis = x.br || x.tg ? 'ref' : 'none';
      const parent = x.br ? x.br.c : x.tg ? x.tg.c : null;
      return [
        basis,
        nd(basis, [
          line(
            statusBadge(d.status, { prefix: 'Record' }),
            idPair(
              h('span', { class: 'mono muted' }, `#${d.id}`),
              ev(
                evKey(P, o, `dep-${name}`, d.id),
                null,
                [h('p', null, `${d.source}.`), h('p', null, 'The record does not name the pipeline or job that created it.'), linkNote(d.link)],
                'Deployment record',
              ),
            ),
            o.det ? extLink(d.link, 'Deployment') : null,
          ),
          via(x.br ? `deployed branch ${d.ref}` : x.tg ? `deployed tag ${d.ref}` : `deployed ref ${d.ref}, which is not one of this item's branches or tags`),
          line(commitEl(x.c), relChip(x.c, parent, x.br ? 'branch head' : 'tag', o.det)),
        ]),
      ];
    }),
  );
}

function stTag(P: Proc, o: StageOpts): StageResult {
  if (!P.tags.length) return emptyRes('No associated tag');
  return resOf(
    P.tags.map((x): Pair => {
      const basis = x.sameAs.length ? 'cand' : 'none';
      const heads = x.sameAs.map((y) => y.b.name).join(', ');
      return [
        basis,
        nd(basis, [
          line(
            icon('tag', 'sm'),
            idPair(
              h('span', { class: 'mono strong' }, x.t.name),
              ev(evKey(P, o, 'tag', x.t.name), x.t.association, [
                x.sameAs.length
                  ? h(
                      'p',
                      null,
                      h('strong', null, 'Candidate only. '),
                      `The tag points at the same commit as the ${heads} head. Equal SHA does not show the tag was created from that branch (no branch lineage).`,
                    )
                  : null,
                linkNote(x.t.link),
              ]),
            ),
            o.det ? extLink(x.t.link, 'Tag') : null,
          ),
          line(commitEl(x.c)),
          via(x.sameAs.length ? `candidate · same SHA as ${heads} head` : 'its commit is not the head of any listed branch'),
        ]),
      ];
    }),
  );
}

function stTagPipe(P: Proc, o: StageOpts): StageResult {
  const list = P.pipes.filter((x) => x.kind === 'tag');
  if (!list.length) return emptyRes(P.tags.length ? 'No pipeline on a tag ref' : 'No tag, so no tag pipeline');
  return resOf(
    list.map(
      (x): Pair => [
        'ref',
        nd('ref', [
          pipeHead(x, ev(evKey(P, o, 'pipe', x.p.id.value), x.p.association, [linkNote(x.p.link)]), o.det ? extLink(x.p.link, 'Pipeline') : null),
          via(`ran on tag ${x.p.ref}`),
          line(commitEl(x.c), relChip(x.c, x.tg?.c, 'tag', o.det)),
          jobsBlock(x.p, !o.det),
        ]),
      ],
    ),
  );
}

// Exact identity of a version: tag/branch/version text (the commit is shown separately).
export function versionIds(v: Version | null | undefined): Kid[] {
  const p = versionParts(v);
  const out: Kid[] = [];
  if (p.tag) out.push(h('span', { class: 'mono', title: 'tag' }, p.tag));
  if (p.branch) out.push(h('span', { class: 'mono', title: 'branch' }, p.branch));
  if (p.version) out.push(h('span', { class: 'mono', title: 'version' }, p.version));
  return out;
}

function stRuntime(P: Proc, o: StageOpts): StageResult {
  if (!o.envs.length) return emptyRes('No environment selected');
  return resOf(
    o.envs.map((n): Pair => {
      const E = P.envs.get(n);
      if (!E) return notHere(n);
      const label = E.def.label;
      const obs = E.env?.observation ?? null;
      let obsEl: Kid;
      if (!E.env || !obs) obsEl = none('Environment not in snapshot');
      else if (obs.kind === 'observed') {
        obsEl = lines(
          line(h('span', { class: 'muted' }, 'advertises'), versionIds(obs.value), commitEl(E.obsC, 'no commit advertised')),
          o.det ? h('div', { class: 'reason' }, `${obs.source} · ${fmtTime(obs.checked_at) ?? 'time not supplied'}`) : null,
        );
      } else if (obs.kind === 'error') {
        obsEl = lines(
          tone('fail', 's_fail', `Observation error: ${obs.code}`, obs.message),
          h('div', { class: 'reason' }, obs.message),
          o.det ? h('div', { class: 'reason' }, `${obs.source} · ${fmtTime(obs.checked_at) ?? 'time not supplied'}`) : null,
        );
      } else obsEl = h('div', { class: 'reason' }, obs.reason);
      const busy = S.observing.has(`${wkStr(P.it.identity)}:${n}`);
      const exp = E.env?.expected ?? null;
      const expIds = versionIds(exp);
      return [
        'ind',
        nd('ind', [
          line(h('span', { class: 'lbl' }, label), compareBadge(E.cmp)),
          obsEl,
          // The comparison reason is shown once: when it repeats the
          // observation's own reason (e.g. "No preprod version observation
          // available"), the line above already says it.
          E.cmp?.reason && (o.det || E.cmp.result !== 'unknown') && !(obs?.kind === 'unknown' && obs.reason.trim() === E.cmp.reason.trim())
            ? h('div', { class: 'reason' }, E.cmp.reason)
            : null,
          o.det
            ? line(
                h('span', { class: 'muted' }, 'expected'),
                expIds.length || versionParts(exp).sha ? [expIds, commitEl(E.expC, 'no commit expected')] : none('nothing specified'),
              )
            : null,
          o.det && E.env && o.envActions !== false ? readRuntimeBtn(P, n, label, busy) : null,
        ]),
      ];
    }),
  );
}

function readRuntimeBtn(P: Proc, n: string, label: string, busy: boolean): HTMLButtonElement {
  return h(
    'button',
    {
      class: 'btn sm',
      type: 'button',
      disabled: busy,
      'data-fk': `obs-${n}`,
      title: 'Reads the operator-configured runtime endpoint; changes nothing',
      onclick: () => void observe(P.v, n),
    },
    icon('observe', 'sm'),
    busy ? 'Reading…' : `Read ${label} runtime`,
  );
}

/* ------------------------------------------------- application tests */

const SOURCE_REC: Readonly<Record<ApplicationTestRecord['source'], string>> = { operator: 'operator (manual)', fixture: 'fixture (synthetic)' };

function testRecordLines(r: ApplicationTestRecord): Kid[] {
  const vs = versionParts(r.version).sha;
  return [
    h('p', null, h('span', { class: 'muted' }, 'Outcome: '), r.outcome === 'not_tested' ? 'not tested (explicit reset)' : r.outcome),
    h('p', null, h('span', { class: 'muted' }, 'Version: '), versionIds(r.version), vs ? [' ', h('code', { class: 'mono' }, vs)] : ' (no commit SHA)'),
    h(
      'p',
      null,
      h('span', { class: 'muted' }, 'Recorded: '),
      h('span', { class: 'nowrap' }, fmtTime(r.checked_at) ?? r.checked_at),
      ' · ',
      SOURCE_REC[r.source],
    ),
    r.notes ? h('p', null, h('span', { class: 'muted' }, 'Notes: '), r.notes) : null,
  ];
}

/** Version-bound evidence, or a blank one for a configured environment the server sent none for. */
type TestView = Pick<ApplicationTestEvidence, 'outcome' | 'target' | 'current' | 'history' | 'reason'>;

function stAppTest(P: Proc, o: StageOpts): StageResult {
  if (!o.envs.length) return emptyRes('No environment selected');
  const ck = P.v.checklist;
  return resOf(
    o.envs.map((n): Pair => {
      const E = P.envs.get(n);
      if (!E) return notHere(n);
      const label = E.def.label;
      const t = E.test;
      const local = n === 'dev' ? ck.dev_test : n === 'preprod' ? ck.preprod_test : false;
      let body: Kid;
      if (t) {
        const cur = t.current;
        const tSha = versionParts(t.target).sha;
        body = [
          line(
            h('span', { class: 'lbl' }, label),
            idPair(
              appTestBadge(t.outcome),
              ev(
                evKey(P, o, 'at', n),
                null,
                [
                  h('p', null, t.reason),
                  cur ? testRecordLines(cur) : null,
                  t.target
                    ? h(
                        'p',
                        null,
                        h('span', { class: 'muted' }, 'Current target: '),
                        versionIds(t.target),
                        tSha ? [' ', h('code', { class: 'mono' }, tSha)] : ' (no exact commit)',
                      )
                    : h('p', null, 'No current target version is known.'),
                  h(
                    'p',
                    null,
                    `${plural(t.history.length, 'record')} in history. Manual records are not automated checks, deployments or checklist confirmations.`,
                  ),
                ],
                `${label} application test`,
              ),
            ),
            cur ? h('span', { class: 'muted nowrap' }, fmtTime(cur.checked_at)) : null,
          ),
          cur
            ? line(h('span', { class: 'muted' }, 'for'), versionIds(cur.version), commitEl(E.curC, 'no SHA recorded'))
            : t.target
              ? line(h('span', { class: 'muted' }, 'target'), versionIds(t.target), commitEl(E.tC, 'no exact commit'))
              : none('No exact target version'),
          o.det ? (o.envActions === false ? panelPointer(label) : [appTestControls(P, E, t, label), testHistory(P, E, t)]) : null,
        ];
      } else {
        // No version-bound evidence from the server. A configured environment
        // still accepts a manual record, but only for an exact SHA/version the
        // operator types; nothing is taken from names.
        const blank: TestView = {
          outcome: 'not_tested',
          target: null,
          current: null,
          history: [],
          reason: 'The server sent no version-bound test evidence for this environment.',
        };
        body = [
          line(h('span', { class: 'lbl' }, label), E.env ? legacyAppTestBadge(E.env.application_test) : none('No test evidence')),
          o.det && E.env ? h('div', { class: 'reason' }, 'Legacy compatibility value; it is not bound to a version.') : null,
          o.det && E.def.configured ? (o.envActions === false ? panelPointer(label) : appTestControls(P, E, blank, label)) : null,
        ];
      }
      return ['ind', nd('ind', [body, local ? h('div', { class: 'reason' }, `Checklist note: marked tested on ${label} (not test evidence)`) : null])];
    }),
  );
}

type RecordVersion = { readonly ok: true; readonly version: Version } | { readonly ok: false; readonly problem: string };

// Version for a new record: the server's exact target when it names a SHA or
// version; otherwise only what the operator typed. A branch or tag name
// alone never supports a result, and nothing is inferred from names.
function atVersion(t: TestView | null, d: AppTestDraft, reset: boolean): RecordVersion {
  const tg = versionParts(t?.target);
  if (tg.sha || tg.version) return { ok: true, version: { tag: tg.tag, branch: tg.branch, version: tg.version, sha: tg.sha } };
  if (reset && t?.current) {
    const cv = versionParts(t.current.version);
    if (cv.sha || cv.version) return { ok: true, version: t.current.version };
  }
  const s = d.sha.trim().toLowerCase();
  const ver = d.version.trim();
  if (s && !/^[0-9a-f]{40}$/.test(s)) return { ok: false, problem: 'The commit SHA must be the full 40-character hexadecimal SHA.' };
  if (ver.length > 500) return { ok: false, problem: 'The version string is longer than 500 characters.' };
  if (!s && !ver) return { ok: false, problem: 'Enter the exact commit SHA or version that was tested. A branch or tag name alone is not enough.' };
  return { ok: true, version: { tag: null, branch: null, version: ver || null, sha: s || null } };
}

const OUTCOME_TEXT: Readonly<Record<Outcome, string>> = { passed: 'passed', failed: 'failed', not_tested: 'not tested' };
const blankDraft = (): AppTestDraft => ({ sha: '', version: '', notes: '' });

async function submitAppTest(P: Proc, env: string, outcome: Outcome): Promise<void> {
  const id = P.v.item.identity;
  const k = `${wkStr(id)}:${env}`;
  if (S.atBusy.has(k)) return;
  const t = P.v.application_tests.find((x) => x.environment === env) ?? null;
  const d = S.atDraft.get(k) ?? blankDraft();
  // A save that starts or fails always shows its editor: an earlier explicit
  // close of the "Record result" disclosure is forgotten at that moment, so
  // the open-by-default rule (error, busy, typed draft) applies again. A
  // deliberate close made after this point is kept as usual.
  const reopen = (): void => {
    S.sections.delete(recordKey(k));
  };
  const r = atVersion(t, d, outcome === 'not_tested');
  if (!r.ok) {
    S.atErr.set(k, r.problem);
    reopen();
    render();
    return;
  }
  const record: ApplicationTestRecord = {
    key: { project: { value: id.project.value }, issue: { value: id.issue.value } },
    environment: env,
    version: r.version,
    outcome,
    checked_at: new Date().toISOString(),
    source: 'operator',
    notes: d.notes.slice(0, 1000),
  };
  S.atErr.delete(k);
  S.atBusy.add(k);
  reopen();
  render();
  const ok = await pref({ operation: 'application_test', record }, `${envLabel(env)} application test for #${id.issue.value}`);
  S.atBusy.delete(k);
  if (ok) {
    S.atDraft.delete(k);
    say(`${envLabel(env)} application test recorded as ${OUTCOME_TEXT[outcome]} for #${id.issue.value}.`);
    await reloadItemData(id, 'Application test');
  } else {
    S.atErr.set(k, 'Not saved. Your notes are kept; see the problem list for the reason.');
    // A close made while the save was in flight does not hide its failure.
    reopen();
  }
  render();
}

function appTestControls(P: Proc, E: EnvNode, t: TestView, label: string): HTMLDivElement {
  const n = E.name;
  const id = P.v.item.identity;
  const k = `${wkStr(id)}:${n}`;
  const d = S.atDraft.get(k) ?? blankDraft();
  const busy = S.atBusy.has(k) || !S.prefs;
  const err = S.atErr.get(k);
  const tg = versionParts(t.target);
  const exact = !!(tg.sha || tg.version);
  const setD = (patch: Partial<AppTestDraft>): void => {
    S.atDraft.set(k, { ...(S.atDraft.get(k) ?? blankDraft()), ...patch });
  };
  const cur = t.current;
  const btn = (outcome: Outcome, ico: 's_ok' | 's_fail' | 's_unknown', text: string): HTMLButtonElement =>
    h(
      'button',
      {
        class: `btn sm at-${outcome}`,
        type: 'button',
        disabled: busy,
        'data-fk': `at-${outcome}-${k}`,
        onclick: () => void submitAppTest(P, n, outcome),
      },
      icon(ico, 'sm'),
      text,
    );
  return h(
    'div',
    { class: 'at' },
    h('div', { class: 'reason' }, t.reason),
    exact
      ? h(
          'div',
          { class: 'line' },
          h('span', { class: 'muted' }, 'Records against'),
          versionIds(t.target),
          tg.sha ? h('code', { class: 'mono at-sha', title: tg.sha }, tg.sha) : null,
        )
      : [
          h(
            'p',
            { class: 'reason' },
            tg.branch || tg.tag
              ? `The target names only ${tg.tag ? `tag ${tg.tag}` : `branch ${tg.branch ?? ''}`}; a branch or tag alone cannot support a result. Enter the exact commit SHA or version you tested.`
              : 'No target version is known. Enter the exact commit SHA or version you tested.',
          ),
          h(
            'div',
            { class: 'at-ver' },
            h(
              'label',
              { class: 'field' },
              h('span', null, 'Commit SHA'),
              h('input', {
                class: 'input mono',
                value: d.sha,
                maxlength: '40',
                spellcheck: 'false',
                autocomplete: 'off',
                placeholder: '40 hex characters',
                'data-fk': `at-sha-${k}`,
                oninput: (e: Event) => setD({ sha: controlValue(e) }),
              }),
            ),
            h(
              'label',
              { class: 'field' },
              h('span', null, 'Version'),
              h('input', {
                class: 'input mono',
                value: d.version,
                maxlength: '500',
                autocomplete: 'off',
                placeholder: 'e.g. 2.4.8',
                'data-fk': `at-ver-${k}`,
                oninput: (e: Event) => setD({ version: controlValue(e) }),
              }),
            ),
          ),
        ],
    h(
      'label',
      { class: 'field' },
      h('span', null, 'Notes (optional)'),
      h('input', {
        class: 'input',
        value: d.notes,
        maxlength: '1000',
        autocomplete: 'off',
        'data-fk': `at-notes-${k}`,
        oninput: (e: Event) => setD({ notes: controlValue(e) }),
      }),
    ),
    h(
      'div',
      { class: 'line', role: 'group', 'aria-label': `Record the ${label} application test outcome` },
      btn('passed', 's_ok', 'Passed'),
      btn('failed', 's_fail', 'Failed'),
      btn('not_tested', 's_unknown', cur ? 'Reset to not tested' : 'Not tested'),
      S.atBusy.has(k) ? h('span', { class: 'muted', role: 'status' }, 'Saving…') : null,
    ),
    err ? h('div', { class: 'inline-err', role: 'alert' }, icon('s_fail', 'sm'), h('div', null, err)) : null,
    // The full meaning of a manual record is stated once in the Environments
    // panel's evidence; each editor keeps the part that matters here.
    h('p', { class: 'hint' }, 'Manual record for this exact version. A different commit starts as not tested.'),
  );
}

/** Every earlier manual record of one environment; reachable without opening the editor. */
function testHistory(P: Proc, E: EnvNode, t: TestView): HTMLDetailsElement | null {
  const k = `${wkStr(P.v.item.identity)}:${E.name}`;
  const tg = versionParts(t.target);
  const hist = [...t.history].sort((a, b) => b.checked_at.localeCompare(a.checked_at));
  if (!hist.length) return null;
  return h(
    'details',
    {
      class: 'at-hist',
      open: S.atHist.has(k),
      ontoggle: (e: Event) => {
        if (openOf(e)) S.atHist.add(k);
        else S.atHist.delete(k);
      },
    },
    h('summary', { 'data-fk': `at-hist-${k}` }, icon('history', 'sm'), `History (${hist.length})`),
    h(
      'ol',
      { class: 'list' },
      hist.map((r) => {
        const rs = versionParts(r.version).sha;
        return h(
          'li',
          null,
          appTestBadge(r.outcome),
          versionIds(r.version),
          sha(rs, 'no SHA'),
          tg.sha && rs && rs !== tg.sha ? h('span', { class: 'chip', title: 'Recorded for a different commit than the current target' }, 'other commit') : null,
          h('span', { class: 'muted nowrap' }, fmtTime(r.checked_at) ?? 'time not supplied'),
          h('span', { class: 'muted' }, SOURCE_REC[r.source]),
          r.notes ? h('span', { class: 'reason grow' }, r.notes) : null,
        );
      }),
    ),
  );
}

/**
 * The manual-record editor behind an explicit "Record result" disclosure.
 * Open by default while it holds typed text, an error or a save in flight,
 * and after navigation to this environment (focusOnce); the reader's own
 * toggle is kept in browser memory. The draft itself lives in S.atDraft, so
 * closing, re-rendering or leaving the page never loses typed text.
 */
function recordDisclosure(P: Proc, E: EnvNode, t: TestView, label: string): HTMLDetailsElement {
  const k = `${wkStr(P.v.item.identity)}:${E.name}`;
  const d = S.atDraft.get(k);
  const typed = !!d && !!(d.sha.trim() || d.version.trim() || d.notes.trim());
  const dflt = typed || S.atErr.has(k) || S.atBusy.has(k);
  const sk = recordKey(k);
  const tg = versionParts(t.target);
  const exact = !!(tg.sha || tg.version);
  return h(
    'details',
    {
      class: 'at-rec',
      open: sectionOpen(sk, dflt),
      ontoggle: (e: Event) => {
        const o = openOf(e);
        if (o === dflt) S.sections.delete(sk);
        else S.sections.set(sk, o);
      },
    },
    h(
      'summary',
      { class: 'btn sm', 'data-fk': `at-rec-${k}` },
      icon('test', 'sm'),
      'Record result',
      h('span', { class: 'sr' }, ` for ${label}`),
      exact ? null : h('span', { class: 'muted' }, '· exact SHA or version needed'),
      S.atErr.has(k) ? h('span', { class: 'chip st t-fail' }, h('span', null, 'not saved')) : null,
    ),
    appTestControls(P, E, t, label),
  );
}

/** Section key of an environment's "Record result" disclosure ("<project>/<issue>:<env>"). */
export const recordKey = (envKey: string): string => `item:record:${envKey}`;

const panelPointer = (label: string): HTMLDivElement =>
  h('div', { class: 'reason' }, `Record or reset the ${label} result under Environments at the top of this page.`);

// Version-bound evidence, or a blank one for a configured environment the
// server sent none for (the operator then types the exact SHA/version).
function testView(E: EnvNode): TestView | null {
  if (E.test) return E.test;
  return E.def.configured
    ? { outcome: 'not_tested', target: null, current: null, history: [], reason: 'The server sent no version-bound test evidence for this environment.' }
    : null;
}

/* ------------------------------------------------- environments panel */
// The item's first section: one card per environment configured for its
// project, with four separate facts (deployment record, operator-classified
// deploy job, running version, manual test) and the exact-version test
// editor and history. Reachable in Overview and Detailed alike.

function envCard(P: Proc, E: EnvNode): HTMLElement {
  const n = E.name;
  const label = E.def.label;
  const id = P.v.item.identity;
  const key = `${wkStr(id)}:${n}`;
  const obs = E.env?.observation ?? null;
  const jobs = deployJobsOf(P, n);
  const t = testView(E);

  const deployed: Kid = !E.env
    ? none(`No ${label} environment in the snapshot`)
    : E.deps.length
      ? E.deps.map((x) => {
          const parent = x.br ? x.br.c : x.tg ? x.tg.c : null;
          return lines(
            line(
              statusBadge(x.d.status, { prefix: 'Record' }),
              idPair(
                h('span', { class: 'mono muted' }, `#${x.d.id}`),
                ev(
                  `ev-env-${key}-dep-${x.d.id}`,
                  null,
                  [h('p', null, `${x.d.source}.`), h('p', null, 'The record does not name the pipeline or job that created it.'), linkNote(x.d.link)],
                  'Deployment record',
                ),
              ),
              extLink(x.d.link, 'Deployment'),
            ),
            line(
              h(
                'span',
                { class: 'muted' },
                x.br ? `deployed branch ${x.d.ref}` : x.tg ? `deployed tag ${x.d.ref}` : `deployed ref ${x.d.ref} (not this item’s)`,
              ),
              commitEl(x.c),
              relChip(x.c, parent, x.br ? 'branch head' : 'tag', true),
            ),
          );
        })
      : // The rule "a deploy job is not a deployment record" is stated once in
        // the panel's evidence; here it stays as the text alternative.
        h('span', { class: 'muted', title: `A deploy job status is not a ${label} deployment record.` }, 'No deployment record');

  const job: Kid = jobs.length
    ? jobs.map(({ p, j }) =>
        line(
          h(
            'a',
            {
              class: 'mono',
              href: to(jobHref(p.project.value, p.id.value, j.id.value)),
              title: 'Operator-classified deploy job. A job is not a deployment record.',
            },
            j.name,
          ),
          statusBadge(j.status),
          h('span', { class: 'muted' }, `in pipeline #${p.id.value}`),
        ),
      )
    : none('No job is classified as this environment’s deploy job');

  let observed: Kid;
  if (!E.env || !obs) observed = none('Not in the snapshot');
  else if (obs.kind === 'observed')
    observed = line(h('span', { class: 'muted' }, 'advertises'), versionIds(obs.value), commitEl(E.obsC, 'no commit advertised'));
  else if (obs.kind === 'error') observed = lines(tone('fail', 's_fail', `Read error: ${obs.code}`, obs.message), h('div', { class: 'reason' }, obs.message));
  else observed = h('div', { class: 'reason' }, obs.reason);
  const exp = E.env?.expected ?? null;
  const expIds = versionIds(exp);
  const busy = S.observing.has(key);
  const running: Kid = [
    line(compareBadge(E.cmp)),
    observed,
    E.cmp?.reason && !(obs?.kind === 'unknown' && obs.reason.trim() === E.cmp.reason.trim()) ? h('div', { class: 'reason' }, E.cmp.reason) : null,
    line(
      h('span', { class: 'muted' }, 'expected'),
      expIds.length || versionParts(exp).sha ? [expIds, commitEl(E.expC, 'no commit expected')] : none('nothing specified'),
    ),
    obs && obs.kind !== 'unknown' ? h('div', { class: 'reason' }, `${obs.source} · ${fmtTime(obs.checked_at) ?? 'time not supplied'}`) : null,
    E.env ? line(readRuntimeBtn(P, n, label, busy)) : null,
  ];

  const local = n === 'dev' ? P.v.checklist.dev_test : n === 'preprod' ? P.v.checklist.preprod_test : false;
  let tested: Kid;
  if (!t)
    tested = E.env
      ? line(legacyAppTestBadge(E.env.application_test), h('span', { class: 'reason' }, 'Legacy value, not bound to a version.'))
      : none('No test evidence');
  else {
    const cur = t.current;
    tested = [
      line(
        appTestBadge(t.outcome),
        cur ? h('span', { class: 'muted' }, 'for') : t.target ? h('span', { class: 'muted' }, 'target') : null,
        cur
          ? h('span', { class: 'vpair' }, versionIds(cur.version), commitEl(E.curC, 'no SHA recorded'))
          : t.target
            ? h('span', { class: 'vpair' }, versionIds(t.target), commitEl(E.tC, 'no exact commit'))
            : none('no exact target version'),
        cur ? h('span', { class: 'muted nowrap' }, fmtTime(cur.checked_at)) : null,
      ),
      // Data entry is a disclosure; the facts above and the history stay outside it.
      recordDisclosure(P, E, t, label),
      testHistory(P, E, t),
      local ? h('div', { class: 'reason' }, `Checklist note: marked tested on ${label} (not test evidence).`) : null,
    ];
  }
  // A result names what was tested. When the running service advertises a
  // different commit, both identities stay visible and nothing is reconciled.
  const testedC = E.tC ?? E.curC;
  const split =
    testedC && E.obsC && testedC !== E.obsC
      ? h(
          'div',
          { class: 'inline-err note env-split' },
          icon('info', 'sm'),
          h(
            'div',
            null,
            `The test target is commit ${testedC.letter}; ${label} advertises commit ${E.obsC.letter}. A manual result records what you tested, not what is running.`,
          ),
        )
      : null;

  const facts = attentionOf(P.v).filter((f) => f.env === n);
  return h(
    'article',
    { class: 'env-card box', id: `env-card-${n}`, tabindex: '-1', 'aria-label': `${label} environment` },
    h(
      'div',
      { class: 'env-h' },
      icon('deploy', 'sm'),
      h('h3', null, label),
      h('span', { class: 'muted' }, E.def.refSource ? `deploys a ${E.def.refSource} ref` : 'ref source not configured'),
      facts.map((f) => h('span', { class: `chip st t-${f.tone}`, title: f.title }, h('span', null, f.text))),
    ),
    h(
      'dl',
      { class: 'env-facts' },
      h('dt', null, 'Deployed'),
      h('dd', null, deployed),
      h('dt', null, 'Deploy job'),
      h('dd', null, job),
      h('dt', null, 'Running'),
      h('dd', null, running),
      h('dt', null, 'Tested'),
      h('dd', null, tested),
    ),
    split,
  );
}

export function environmentsPanel(P: Proc): HTMLElement {
  const cards = P.envDefs.map((d) => P.envs.get(d.name)).filter((E): E is EnvNode => E !== undefined);
  return h(
    'section',
    { class: 'sec env-panel', 'aria-label': 'Environments' },
    h(
      'div',
      { class: 'sec-h' },
      icon('deploy', 'sm'),
      h('h2', null, 'Environments'),
      h('span', { class: 'muted env-sub' }, 'Deployment record, deploy job, running version and manual test are separate facts'),
      // The full rules are stated once, in evidence, not repeated per card.
      cards.length
        ? evidence(
            `ev-env-rules-${wkStr(P.v.item.identity)}`,
            null,
            [
              h(
                'p',
                null,
                'A deployment record comes from GitLab. A deploy job is classified by the operator rules; a job status is never a deployment record.',
              ),
              h('p', null, 'The running version is read from the environment and compared with the expected one; a read error is not a mismatch.'),
              h(
                'p',
                null,
                'Manual test results are saved in shared preferences for one exact commit or version. A branch or tag name alone cannot support a result. Recording one never deploys, reads the runtime, completes the checklist or marks anything ready, and a different commit starts as not tested.',
              ),
            ],
            'How environment facts relate',
          )
        : null,
    ),
    cards.length
      ? h(
          'div',
          { class: 'env-cards' },
          cards.map((E) => envCard(P, E)),
        )
      : none('No environment is configured for this project.'),
  );
}

/* ----------------------------------------------------------- commits */

function stCommits(P: Proc): StageResult {
  if (!P.commits.length) return emptyRes('No commit identity supplied');
  return { basis: 'summary', nodes: P.commits.map((c) => h('div', { class: 'cline' }, commitEl(c), h('span', { class: 'reason' }, c.where.join(' · ')))) };
}

export function stageRun(P: Proc, st: StageDef, o: StageOpts): StageResult {
  switch (st.id) {
    case 'deploy':
      return st.env ? stDeploy(P, st.env, o) : emptyRes('—');
    case 'branch':
      return stBranch(P, o);
    case 'mr':
      return stMr(P, o);
    case 'pipeline':
      return stPipeline(P, o);
    case 'jobs':
      return stJobs(P, o);
    case 'publish':
      return stPublish(P, o);
    case 'tag':
      return stTag(P, o);
    case 'tagpipe':
      return stTagPipe(P, o);
    case 'runtime':
      return stRuntime(P, o);
    case 'apptest':
      return stAppTest(P, o);
    case 'commits':
      return stCommits(P);
  }
}

export function stageLabel(st: StageDef): HTMLDivElement {
  return h('div', { class: 'stl', title: st.hint }, icon(st.icon, 'sm'), h('span', null, st.label));
}

// Collapsed by default; the open state is shared by every process view.
export function legendEl(): HTMLDetailsElement {
  return h(
    'details',
    {
      class: 'legend-d',
      open: S.legendOpen,
      ontoggle: (e: Event) => {
        S.legendOpen = openOf(e);
      },
    },
    h('summary', { class: 'btn sm ghost', 'data-fk': 'legend' }, icon('info', 'sm'), 'How to read the process'),
    h(
      'div',
      { class: 'legend', role: 'note', 'aria-label': 'How to read the process' },
      h('span', { class: 'lg lg-ref' }, 'Linked by record fields'),
      h('span', { class: 'lg lg-cand' }, 'Candidate: equal SHA or ref name only'),
      h('span', { class: 'lg lg-ind' }, 'Independent evidence'),
      h('span', { class: 'lg lg-none' }, 'No link in the data'),
      h('span', { class: 'lg-cm' }, h('span', { class: 'cm cm-0', 'aria-hidden': 'true' }, 'A'), 'Same letter means the same commit within one item'),
      h('span', { class: 'lg-ev' }, icon('info', 'sm'), 'Evidence: origin, reason, overrides and link provenance'),
      h('span', { class: 'lg-ev' }, h('span', { class: 'imp' }, icon('star', 'xs')), 'Important job (operator setting)'),
      h(
        'span',
        { class: 'lg-note' },
        'Equal SHA between a tag and a branch is a candidate, not branch lineage. Stage dependencies are operator expectations, not the observed CI DAG.',
      ),
    ),
  );
}
