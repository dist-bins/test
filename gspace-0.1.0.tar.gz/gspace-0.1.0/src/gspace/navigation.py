"""Typed instance/project-scoped local navigation; no remote action capability."""

from __future__ import annotations

from typing import Annotated, Literal, Self, get_args

from pydantic import Field, TypeAdapter, model_validator

from gspace.models import MilestoneFilter, Model, MrIid, PipelineId, ProjectId, Text, WorkKey

type ViewScope = Literal["work_items", "mrs", "branches", "pipelines"]
type Column = (
    Literal[
        "identity",
        "title",
        "state",
        "project",
        "branch",
        "mr",
        "pipeline",
        "publish",
        "dev",
        "preprod",
        "updated_at",
        "sha",
        "ref",
        "jobs",
    ]
    | Annotated[str, Field(strict=True, pattern=r"^environment:[a-z][a-z0-9_-]{0,63}$")]
)


class WorkReference(Model, frozen=True):
    kind: Literal["work_item"] = "work_item"
    key: WorkKey


class MrReference(Model, frozen=True):
    kind: Literal["mr"] = "mr"
    project: ProjectId
    iid: MrIid


class BranchReference(Model, frozen=True):
    kind: Literal["branch"] = "branch"
    project: ProjectId
    name: Text


class PipelineReference(Model, frozen=True):
    kind: Literal["pipeline"] = "pipeline"
    project: ProjectId
    id: PipelineId


type ResourceReference = Annotated[
    WorkReference | MrReference | BranchReference | PipelineReference,
    Field(discriminator="kind"),
]


def reference_project(reference: ResourceReference) -> ProjectId:
    return reference.key.project if isinstance(reference, WorkReference) else reference.project


class Bookmark(Model, frozen=True):
    host: Text
    reference: ResourceReference
    label: Text


class ViewFilters(Model, frozen=True):
    milestone: MilestoneFilter = MilestoneFilter()
    state: Literal[
        "all",
        "opened",
        "open",
        "closed",
        "merged",
        "success",
        "failed",
        "running",
        "pending",
        "manual",
        "skipped",
        "canceled",
        "created",
        "unknown",
    ] = "all"
    search: Annotated[str, Field(max_length=200)] = ""
    assigned: bool = Field(default=True, strict=True)
    group: Annotated[str, Field(max_length=80)] = ""
    show_hidden: bool = Field(default=False, strict=True)
    authored: bool = Field(default=True, strict=True)


class SavedView(Model, frozen=True):
    name: Text
    host: Text
    scope: ViewScope
    projects: tuple[ProjectId, ...] = ()
    filters: ViewFilters = ViewFilters()
    sort: Literal["identity", "title", "state", "project", "updated_at"] = "identity"
    descending: bool = Field(default=False, strict=True)
    columns: tuple[Column, ...] = ("identity", "title", "state", "project")
    orientation: Literal["rows", "columns"] = "rows"

    @model_validator(mode="after")
    def coherent(self) -> Self:
        if len(set(self.projects)) != len(self.projects):
            raise ValueError("duplicate saved-view project")
        if not self.columns or len(set(self.columns)) != len(self.columns):
            raise ValueError("saved-view columns must be nonempty and unique")
        if self.sort == "updated_at" and self.scope != "mrs":
            raise ValueError("Updated-at sorting requires timestamped authored MR evidence")
        if self.scope == "work_items" and self.filters.state not in ("all", "opened", "closed"):
            raise ValueError("invalid work-item view state")
        if self.scope == "mrs":
            if self.filters.state not in ("all", "open", "merged", "closed", "unknown"):
                raise ValueError("invalid MR view state")
            if not self.filters.authored:
                raise ValueError("MR catalog covers only authored MRs in configured projects")
        if self.scope == "branches" and self.filters.state != "all":
            raise ValueError("branch views do not have a lifecycle state")
        return self


class BookmarkTarget(Model, frozen=True):
    kind: Literal["bookmark"] = "bookmark"
    host: Text
    reference: ResourceReference


class SavedViewTarget(Model, frozen=True):
    kind: Literal["saved_view"] = "saved_view"
    host: Text
    name: Text


type NavigationTarget = Annotated[BookmarkTarget | SavedViewTarget, Field(discriminator="kind")]
type DecorationIcon = Literal[
    "bookmark",
    "star",
    "flag",
    "folder",
    "calendar",
    "list",
    "code",
    "rocket",
    "issue",
    "branch",
    "mr",
    "pipeline",
    "job",
    "tag",
    "layers",
    "clock",
]
type DecorationColor = Literal[
    "neutral",
    "slate",
    "blue",
    "teal",
    "green",
    "amber",
    "orange",
    "red",
    "purple",
    "pink",
]


# PEP695 aliases are TypeAliasType objects; get_args(alias) itself is empty.
# This finite introspection boundary validates the resolved literal values before export.
DECORATION_ICONS: tuple[DecorationIcon, ...] = TypeAdapter(
    tuple[DecorationIcon, ...]
).validate_python(get_args(DecorationIcon.__value__))
DECORATION_COLORS: tuple[DecorationColor, ...] = TypeAdapter(
    tuple[DecorationColor, ...]
).validate_python(get_args(DecorationColor.__value__))


class NavigationDecoration(Model, frozen=True):
    target: NavigationTarget
    icon: DecorationIcon = "bookmark"
    color: DecorationColor = "neutral"
    pinned: bool = Field(default=False, strict=True)
    order: int = Field(default=0, strict=True, ge=0, le=1000)


class NavigationCatalog(Model, frozen=True):
    host: Text
    projects: tuple[ProjectId, ...]
    revision: int = Field(strict=True, ge=0)
    bookmarks: tuple[Bookmark, ...]
    saved_views: tuple[SavedView, ...]
    decorations: tuple[NavigationDecoration, ...]
    icons: tuple[DecorationIcon, ...]
    colors: tuple[DecorationColor, ...]

    @model_validator(mode="after")
    def scoped_targets(self) -> Self:
        if len(set(self.projects)) != len(self.projects):
            raise ValueError("duplicate navigation project")
        if any(
            b.host != self.host or reference_project(b.reference) not in self.projects
            for b in self.bookmarks
        ):
            raise ValueError("navigation bookmark exceeds catalog scope")
        if any(
            v.host != self.host or any(p not in self.projects for p in v.projects)
            for v in self.saved_views
        ):
            raise ValueError("navigation view exceeds catalog scope")
        targets = {
            *(BookmarkTarget(host=b.host, reference=b.reference) for b in self.bookmarks),
            *(SavedViewTarget(host=v.host, name=v.name) for v in self.saved_views),
        }
        if len({d.target for d in self.decorations}) != len(self.decorations):
            raise ValueError("duplicate navigation decoration")
        if any(d.target not in targets for d in self.decorations):
            raise ValueError("navigation decoration target is absent")
        if not self.icons or not self.colors:
            raise ValueError("navigation choice catalog must not be empty")
        if len(set(self.icons)) != len(self.icons) or len(set(self.colors)) != len(self.colors):
            raise ValueError("duplicate navigation choice")
        return self
