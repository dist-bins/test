"""Closed immutable domain models; remote DTOs are parsed by the adapter."""

from __future__ import annotations

import re
from datetime import date
from enum import StrEnum
from typing import Annotated, Literal, Self, assert_never
from urllib.parse import urlsplit

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, model_validator

type PositiveInt = Annotated[int, Field(strict=True, gt=0)]
type Text = Annotated[str, Field(strict=True, min_length=1, max_length=500)]
type Sha = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{40}$")]
type EnvironmentLabel = Annotated[str, Field(strict=True, pattern=r"^[a-z][a-z0-9_-]{0,63}$")]


class Model(BaseModel, frozen=True):
    model_config = ConfigDict(extra="forbid")


class GitLabRelease(Model, frozen=True):
    raw: Text
    release: Text
    edition: Literal["ce", "ee", "unknown"]

    @model_validator(mode="after")
    def consistent(self) -> Self:
        match = re.fullmatch(r"(\d+\.\d+\.\d+)(?:-(ce|ee))?", self.raw)
        if match is None or self.release != match[1] or self.edition != (match[2] or "unknown"):
            raise ValueError("GitLab release and edition do not match raw metadata")
        return self


class UserId(Model, frozen=True):
    value: PositiveInt


class ProjectId(Model, frozen=True):
    value: PositiveInt


class GroupId(Model, frozen=True):
    value: PositiveInt


class MilestoneId(Model, frozen=True):
    value: PositiveInt


class MilestoneIid(Model, frozen=True):
    value: PositiveInt


class ProjectMilestoneKey(Model, frozen=True):
    kind: Literal["project"] = "project"
    project: ProjectId
    id: MilestoneId


class GroupMilestoneKey(Model, frozen=True):
    kind: Literal["group"] = "group"
    group: GroupId
    id: MilestoneId


type MilestoneKey = Annotated[ProjectMilestoneKey | GroupMilestoneKey, Field(discriminator="kind")]


class IssueIid(Model, frozen=True):
    value: PositiveInt


class MrIid(Model, frozen=True):
    value: PositiveInt


class PipelineId(Model, frozen=True):
    value: PositiveInt


class PipelineIid(Model, frozen=True):
    value: PositiveInt


class PipelineKey(Model, frozen=True):
    project: ProjectId
    pipeline: PipelineId

    @property
    def key(self) -> str:
        return f"{self.project.value}:{self.pipeline.value}"


class JobId(Model, frozen=True):
    value: PositiveInt


class WorkKey(Model, frozen=True):
    project: ProjectId
    issue: IssueIid

    @property
    def key(self) -> str:
        return f"{self.project.value}:{self.issue.value}"


class Link(Model, frozen=True):
    url: Text
    verification: Literal["source_contract", "fixture"] = "source_contract"

    @model_validator(mode="after")
    def safe_link(self) -> Self:
        if "\\" in self.url or any(ord(character) < 33 for character in self.url):
            raise ValueError("unsafe character in HTTP link")
        parts = urlsplit(self.url)
        if parts.scheme not in ("https", "http") or not parts.hostname:
            raise ValueError("invalid HTTP link")
        if parts.username or parts.password or parts.fragment or parts.query:
            raise ValueError("credentials, query and fragment prohibited in links")
        return self


class Milestone(Model, frozen=True):
    key: MilestoneKey
    iid: MilestoneIid
    title: Text
    state: Literal["active", "closed"]
    start_date: date | None = None
    due_date: date | None = None
    link: Link

    @model_validator(mode="after")
    def dates(self) -> Self:
        if (
            self.start_date is not None
            and self.due_date is not None
            and self.start_date > self.due_date
        ):
            raise ValueError("Milestone start date exceeds due date")
        return self


class MilestoneFilter(Model, frozen=True):
    mode: Literal["all", "active", "date_current", "selected", "unassigned"] = "all"
    selected: MilestoneKey | None = None

    @model_validator(mode="after")
    def selection(self) -> Self:
        if (self.mode == "selected") != (self.selected is not None):
            raise ValueError("Explicit milestone selection requires exactly one scoped key")
        return self


class Origin(StrEnum):
    CONVENTION = "convention"
    API = "api"
    OPERATOR = "operator_override"
    FIXTURE = "fixture"


class Association(Model, frozen=True):
    origin: Origin
    reason: Text
    overrides: str | None = None


class Unknown(Model, frozen=True):
    kind: Literal["unknown"] = "unknown"
    reason: Text


class RebaseVerified(Model, frozen=True):
    kind: Literal["verified"] = "verified"
    required: bool = Field(strict=True)
    behind: Annotated[int, Field(strict=True, ge=0)]
    source_sha: Sha
    target_branch: Text
    source: Text
    checked_at: AwareDatetime

    @model_validator(mode="after")
    def coherent(self) -> Self:
        if self.required != (self.behind > 0):
            raise ValueError("rebase required must agree with verified behind count")
        return self


type Rebase = Annotated[Unknown | RebaseVerified, Field(discriminator="kind")]


class Branch(Model, frozen=True):
    project: ProjectId
    name: Text
    sha: Sha
    association: Association
    rebase: Rebase
    link: Link


class MrState(StrEnum):
    OPEN = "open"
    MERGED = "merged"
    CLOSED = "closed"
    UNKNOWN = "unknown"


class MergeRequest(Model, frozen=True):
    project: ProjectId
    source_project: ProjectId
    iid: MrIid
    title: Text
    state: MrState
    draft: bool = Field(strict=True)
    source_branch: Text
    target_branch: Text
    source_sha: Sha | None = None
    association: Association
    link: Link


class Status(StrEnum):
    SUCCESS = "success"
    FAILED = "failed"
    RUNNING = "running"
    PENDING = "pending"
    MANUAL = "manual"
    SKIPPED = "skipped"
    CANCELED = "canceled"
    CREATED = "created"
    UNKNOWN = "unknown"


class Job(Model, frozen=True):
    project: ProjectId
    id: JobId
    name: Text
    stage: Text
    status: Status
    attempt: PositiveInt
    retried: bool = Field(strict=True)
    failure_reason: str | None = None
    link: Link


class Pipeline(Model, frozen=True):
    project: ProjectId
    id: PipelineId
    ref: Text
    sha: Sha
    source: Text
    status: Status
    jobs: tuple[Job, ...] = ()
    association: Association
    link: Link

    @model_validator(mode="after")
    def same_project(self) -> Self:
        if any(job.project != self.project for job in self.jobs):
            raise ValueError("job project does not match pipeline")
        if len({job.id for job in self.jobs}) != len(self.jobs):
            raise ValueError("duplicate job identity")
        return self


class Tag(Model, frozen=True):
    project: ProjectId
    name: Text
    sha: Sha
    association: Association
    link: Link


class Publish(Model, frozen=True):
    pipeline: PipelineId
    job: JobId
    status: Status
    artifact: Text
    source: Text
    link: Link | None = None


class Version(Model, frozen=True):
    model_config = ConfigDict(
        json_schema_extra={
            "anyOf": [
                {"type": "object", "required": [name], "properties": {name: {"type": "string"}}}
                for name in ("tag", "branch", "version", "sha")
            ]
        }
    )
    tag: Text | None = None
    branch: Text | None = None
    version: Text | None = None
    sha: Sha | None = None

    @model_validator(mode="after")
    def not_empty(self) -> Self:
        if not any((self.tag, self.branch, self.version, self.sha)):
            raise ValueError("version evidence must contain a value")
        return self


class Observed(Model, frozen=True):
    kind: Literal["observed"] = "observed"
    value: Version
    source: Text
    checked_at: AwareDatetime


class ObservationError(Model, frozen=True):
    kind: Literal["error"] = "error"
    code: Literal["configuration", "transport", "http", "extraction", "limit"]
    message: Text
    source: Text
    checked_at: AwareDatetime


type Observation = Annotated[Unknown | Observed | ObservationError, Field(discriminator="kind")]


class Deployment(Model, frozen=True):
    project: ProjectId
    id: PositiveInt
    status: Status
    ref: Text
    sha: Sha
    source: Text
    link: Link


class EnvironmentName(StrEnum):
    DEV = "dev"
    PREPROD = "preprod"


class Environment(Model, frozen=True):
    name: EnvironmentLabel
    expected: Version | None = None
    observation: Observation
    deployments: tuple[Deployment, ...] = ()
    application_test: Literal["unconfirmed", "passed", "failed"] = "unconfirmed"


class CompleteRead(Model, frozen=True):
    kind: Literal["complete"] = "complete"
    basis: Literal["bounded_returned_records"] = "bounded_returned_records"


type ReadCoverage = Annotated[CompleteRead | Unknown, Field(discriminator="kind")]


class GraphPipelineReference(Model, frozen=True):
    key: PipelineKey
    project_path: Text
    iid: PipelineIid | None = None
    sha: Sha | None = None
    status: Status = Status.UNKNOWN
    link: Link


class TriggerJob(Model, frozen=True):
    kind: Literal["source_job"] = "source_job"
    project: ProjectId
    id: JobId
    job_kind: Literal["build", "bridge", "unknown"]
    retried: bool = Field(strict=True)


type TriggerEvidence = Annotated[TriggerJob | Unknown, Field(discriminator="kind")]


class PipelineEdge(Model, frozen=True):
    upstream: PipelineKey
    downstream: PipelineKey
    source_job: TriggerEvidence
    origin: Literal["graphql_native", "fixture"] = "graphql_native"

    @model_validator(mode="after")
    def scoped_job(self) -> Self:
        if (
            isinstance(self.source_job, TriggerJob)
            and self.source_job.project != self.upstream.project
        ):
            raise ValueError("Trigger job does not belong to the upstream project")
        return self


class GraphDeployment(Model, frozen=True):
    pipeline: PipelineKey
    environment: EnvironmentLabel
    record: Deployment

    @model_validator(mode="after")
    def scope(self) -> Self:
        if self.record.project != self.pipeline.project:
            raise ValueError("Deployment and pipeline projects differ")
        return self


class PipelineNodeAvailable(Model, frozen=True):
    kind: Literal["available"] = "available"
    reference: GraphPipelineReference
    pipeline: Pipeline
    jobs_coverage: ReadCoverage
    deployments_coverage: ReadCoverage
    deployments: tuple[GraphDeployment, ...] = ()

    @model_validator(mode="after")
    def scope(self) -> Self:
        key = PipelineKey(project=self.pipeline.project, pipeline=self.pipeline.id)
        if key != self.reference.key or any(d.pipeline != key for d in self.deployments):
            raise ValueError("Pipeline node hydration exceeds its scoped identity")
        if self.reference.sha is not None and self.reference.sha != self.pipeline.sha:
            raise ValueError("Pipeline SHA changed between graph and detail reads")
        return self


class PipelineNodeUnavailable(Model, frozen=True):
    kind: Literal["unavailable"] = "unavailable"
    reference: GraphPipelineReference
    reason: Text


type PipelineNode = Annotated[
    PipelineNodeAvailable | PipelineNodeUnavailable, Field(discriminator="kind")
]


class PipelineRoot(Model, frozen=True):
    key: PipelineKey
    application_sha: Sha


class UnknownPipelineRelation(Model, frozen=True):
    pipeline: PipelineKey
    direction: Literal["upstream", "downstream"]
    reason: Text


class PipelineGraph(Model, frozen=True):
    source: Literal["glab", "fixture"] = "glab"
    release: GitLabRelease | None = None
    roots: tuple[PipelineRoot, ...]
    nodes: tuple[PipelineNode, ...]
    edges: tuple[PipelineEdge, ...]
    coverage: ReadCoverage
    fetched_at: AwareDatetime
    warnings: tuple[Text, ...] = ()
    unknown_relations: tuple[UnknownPipelineRelation, ...] = ()
    application_binding: Literal["edge_does_not_prove_deployed_application_version"] = (
        "edge_does_not_prove_deployed_application_version"
    )

    @model_validator(mode="after")
    def integrity(self) -> Self:
        if self.source == "glab" and self.release is None:
            raise ValueError("Remote graph requires exact raw release evidence")
        keys = {node.reference.key for node in self.nodes}
        if len(keys) != len(self.nodes) or len({root.key for root in self.roots}) != len(
            self.roots
        ):
            raise ValueError("Duplicate pipeline graph identity")
        if any(root.key not in keys for root in self.roots):
            raise ValueError("Pipeline graph root is missing")
        pairs = [(edge.upstream, edge.downstream) for edge in self.edges]
        if len(set(pairs)) != len(pairs):
            raise ValueError("Duplicate pipeline edge")
        if any(source not in keys or target not in keys for source, target in pairs):
            raise ValueError("Dangling pipeline graph edge")
        if any(relation.pipeline not in keys for relation in self.unknown_relations):
            raise ValueError("Unknown relation owner is missing")
        refs = {node.reference.key: node.reference for node in self.nodes}
        if any(refs[root.key].sha != root.application_sha for root in self.roots):
            raise ValueError("Application root SHA differs from its pipeline reference")
        if len({(r.pipeline, r.direction, r.reason) for r in self.unknown_relations}) != len(
            self.unknown_relations
        ):
            raise ValueError("Duplicate unknown pipeline relation")
        if isinstance(self.coverage, CompleteRead) and (
            self.unknown_relations
            or self.warnings
            or any(isinstance(edge.source_job, Unknown) for edge in self.edges)
            or any(
                isinstance(node, PipelineNodeUnavailable)
                or isinstance(node.jobs_coverage, Unknown)
                or isinstance(node.deployments_coverage, Unknown)
                for node in self.nodes
            )
        ):
            raise ValueError("Complete graph coverage contradicts partial evidence")
        return self


class ApplicationTestRecord(Model, frozen=True):
    key: WorkKey
    environment: EnvironmentLabel
    version: Version = Field(
        json_schema_extra={
            "anyOf": [
                {"type": "object", "required": [name], "properties": {name: {"type": "string"}}}
                for name in ("sha", "version")
            ]
        }
    )
    outcome: Literal["passed", "failed", "not_tested"]
    checked_at: AwareDatetime
    source: Literal["operator", "fixture"] = "operator"
    notes: str = Field(default="", max_length=1000)

    @model_validator(mode="after")
    def exact_version(self) -> Self:
        if self.version.sha is None and self.version.version is None:
            raise ValueError(
                "Application tests require an exact SHA or version, not a branch/tag alone"
            )
        return self


class ApplicationTestEvidence(Model, frozen=True):
    environment: EnvironmentLabel
    outcome: Literal["passed", "failed", "not_tested"]
    target: Version | None
    current: ApplicationTestRecord | None
    history: tuple[ApplicationTestRecord, ...]
    reason: Text


class WorkItem(Model, frozen=True):
    identity: WorkKey
    project_path: Text
    title: Text
    state: Literal["opened", "closed"]
    assigned_to_me: bool = Field(strict=True)
    labels: tuple[str, ...] = ()
    milestone: MilestoneKey | None = None
    link: Link
    branches: tuple[Branch, ...] = ()
    merge_requests: tuple[MergeRequest, ...] = ()
    pipelines: tuple[Pipeline, ...] = ()
    publishes: tuple[Publish, ...] = ()
    tags: tuple[Tag, ...] = ()
    environments: tuple[Environment, ...] = ()

    @model_validator(mode="after")
    def consistent_graph(self) -> Self:
        project = self.identity.project
        related = (*self.branches, *self.merge_requests, *self.pipelines, *self.tags)
        if any(entity.project != project for entity in related):
            raise ValueError("association crosses project boundary")
        for environment in self.environments:
            if any(deploy.project != project for deploy in environment.deployments):
                raise ValueError("deployment crosses project boundary")
        if len({mr.iid for mr in self.merge_requests}) != len(self.merge_requests):
            raise ValueError("duplicate MR IID")
        if len({p.id for p in self.pipelines}) != len(self.pipelines):
            raise ValueError("duplicate pipeline ID")
        if len({env.name for env in self.environments}) != len(self.environments):
            raise ValueError("duplicate environment")
        for publish in self.publishes:
            pipeline = next((p for p in self.pipelines if p.id == publish.pipeline), None)
            if pipeline is None or not any(j.id == publish.job for j in pipeline.jobs):
                raise ValueError("publish must reference an existing pipeline job")
        return self


class Snapshot(Model, frozen=True):
    schema_version: Literal[1] = 1
    source: Literal["fixture", "glab"]
    gitlab_version: str
    fetched_at: AwareDatetime
    items: tuple[WorkItem, ...]
    warnings: tuple[str, ...] = ()
    milestones: tuple[Milestone, ...] = ()
    issue_coverage: Literal["complete_configured_projects", "unknown"] = "unknown"
    application_tests: tuple[ApplicationTestRecord, ...] = ()

    @model_validator(mode="after")
    def unique_items(self) -> Self:
        if len({item.identity for item in self.items}) != len(self.items):
            raise ValueError("duplicate work item identity")
        if len({milestone.key for milestone in self.milestones}) != len(self.milestones):
            raise ValueError("duplicate milestone identity")
        if len({m.key.id for m in self.milestones}) != len(self.milestones):
            raise ValueError("Milestone global ID has conflicting ownership")
        for item in self.items:
            if (
                isinstance(item.milestone, ProjectMilestoneKey)
                and item.milestone.project != item.identity.project
            ):
                raise ValueError("Work item milestone belongs to another project")
            if item.milestone is not None and item.milestone not in {
                m.key for m in self.milestones
            }:
                raise ValueError("Work item milestone has no catalog evidence")
        return self


class Comparison(StrEnum):
    MATCH = "match"
    MISMATCH = "mismatch"
    UNKNOWN = "unknown"


def compare_version(expected: Version | None, observation: Observation) -> tuple[Comparison, str]:
    match observation:
        case Unknown(reason=reason):
            return Comparison.UNKNOWN, reason
        case ObservationError(message=message):
            return Comparison.UNKNOWN, message
        case Observed(value=observed):
            if expected is None:
                return Comparison.UNKNOWN, "No expected version selected"
            fields = (
                ("sha", expected.sha, observed.sha),
                ("tag", expected.tag, observed.tag),
                ("version", expected.version, observed.version),
                ("branch", expected.branch, observed.branch),
            )
            compared: list[str] = []
            missing: list[str] = []
            for field, wanted, actual in fields:
                if wanted is not None:
                    if actual is None:
                        missing.append(field)
                    elif actual != wanted:
                        return Comparison.MISMATCH, f"Observed {field} differs from expected"
                    else:
                        compared.append(field)
            if missing:
                return Comparison.UNKNOWN, "Observed evidence missing: " + ", ".join(missing)
            if compared == ["branch"]:
                return Comparison.UNKNOWN, "Branch matches; commit identity is not proven"
            return Comparison.MATCH, "Version identity matches: " + ", ".join(compared)
    assert_never(observation)
