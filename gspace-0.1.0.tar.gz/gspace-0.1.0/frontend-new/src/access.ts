// Access: redacted profiles, read-only doctor, permission probe, preview and
// the confirm-gated execute. Nothing here asks for or stores credentials,
// nothing is retried, and availability is never proof of permission. Only a
// confirmable preview can be submitted, once, after explicit confirmation.

import type { Action, ActionPlan, MergeRequest, Permission, ProbeComparison, ProbeComparisonRow, ProfileSummary } from './api';
import { errorMessage, errorStatus, http } from './api';
import type { Kid } from './dom';
import { checkedOf, controlValue, fmtTime, h, icon, line, none, plural, sha, tone } from './dom';
import { refreshSnapshot } from './load';
import { projectPath } from './model';
import { render } from './render';
import type { ActionDraft, ActionField, ActionKind } from './state';
import { S, say, to } from './state';
import { dialog, emptyState, sec, simpleTable } from './ui';

export const ACTION_KINDS: Readonly<Record<ActionKind, { readonly label: string; readonly fields: readonly ActionField[] }>> = {
  create_draft_mr: { label: 'Create draft MR', fields: ['source_branch', 'target_branch', 'title', 'description'] },
  edit_draft_mr: { label: 'Edit draft MR', fields: ['iid', 'title', 'description'] },
  create_tag: { label: 'Create tag', fields: ['branch', 'tag'] },
  run_pipeline: { label: 'Run pipeline', fields: ['branch'] },
  change_pipeline: { label: 'Retry or cancel pipeline', fields: ['id', 'operation'] },
  change_job: { label: 'Retry, cancel or play job', fields: ['id', 'pipeline', 'operation'] },
};
const isActionKind = (s: string): s is ActionKind => Object.hasOwn(ACTION_KINDS, s);
const FIELD_LABEL: Readonly<Record<ActionField | 'profile', string>> = {
  profile: 'Profile',
  source_branch: 'Source branch',
  target_branch: 'Target branch',
  title: 'Title',
  description: 'Description',
  iid: 'MR IID',
  branch: 'Branch',
  tag: 'Tag name',
  id: 'ID',
  pipeline: 'Pipeline ID',
  operation: 'Operation',
};
const PIPE_OPS = ['retry', 'cancel'] as const;
const JOB_OPS = ['retry', 'cancel', 'play'] as const;
const opsFor = (k: ActionKind): readonly string[] => (k === 'change_pipeline' ? PIPE_OPS : k === 'change_job' ? JOB_OPS : []);

function advertisedActions(): ActionKind[] {
  return (S.caps?.actions ?? []).filter(isActionKind);
}

export function actionsAvailable(kind: ActionKind): boolean {
  return S.caps?.write_scope === 'isolated_synthetic_lab' && advertisedActions().includes(kind) && (S.profiles ?? []).length > 0;
}

export interface Prefill {
  readonly project?: number;
  readonly expected_sha?: string;
  readonly source_branch?: string;
  readonly target_branch?: string;
  readonly title?: string;
  readonly iid?: number;
  readonly branch?: string;
  readonly id?: number;
  readonly pipeline?: number;
  readonly operation?: string;
}

// Context entry points appear only when the server advertises the action and
// a profile exists; availability is never proof of permission.
export function actionEntry(kind: ActionKind, prefill: Prefill, label: string): HTMLButtonElement | null {
  if (!actionsAvailable(kind)) return null;
  return h(
    'button',
    {
      class: 'btn sm',
      type: 'button',
      onclick: () => openAction(kind, prefill),
      title: 'Opens the permission check and preview; nothing is sent until you confirm',
    },
    icon('shield', 'sm'),
    label,
  );
}

// Edit draft guards on the MR's real source commit. With none reported the
// entry is shown disabled and says why instead of guessing an expected SHA.
export function editDraftEntry(m: MergeRequest, s: string | null): Kid {
  if (!m.draft || !actionsAvailable('edit_draft_mr')) return null;
  if (s) return actionEntry('edit_draft_mr', { project: m.project.value, iid: m.iid.value, expected_sha: s, title: m.title }, 'Edit draft…');
  return [
    h('button', { class: 'btn sm', type: 'button', disabled: true }, icon('shield', 'sm'), 'Edit draft…'),
    h('span', { class: 'reason' }, 'Unavailable: no source commit is reported, so there is no expected SHA to guard the edit.'),
  ];
}

function blankDraft(kind: ActionKind, profile: string, project: string): ActionDraft {
  return {
    kind,
    profile,
    project,
    expected_sha: '',
    source_branch: '',
    target_branch: '',
    title: '',
    description: '',
    iid: '',
    branch: '',
    tag: '',
    id: '',
    pipeline: '',
    operation: opsFor(kind)[0] ?? '',
  };
}

function openAction(kind: ActionKind, prefill: Prefill): void {
  const profiles = S.profiles ?? [];
  const prof = profiles.find((p) => p.write_enabled && p.projects.some((x) => x.value === prefill.project)) ?? profiles[0];
  const project = prefill.project ?? S.scope.project;
  const s = (x: string | number | undefined): string => (x === undefined ? '' : String(x));
  S.act = {
    draft: {
      ...blankDraft(kind, prof?.name ?? '', project == null ? '' : String(project)),
      expected_sha: s(prefill.expected_sha),
      source_branch: s(prefill.source_branch),
      target_branch: s(prefill.target_branch),
      title: s(prefill.title),
      iid: s(prefill.iid),
      branch: s(prefill.branch),
      id: s(prefill.id),
      pipeline: s(prefill.pipeline),
      operation: prefill.operation ?? opsFor(kind)[0] ?? '',
    },
    probe: null,
    plan: null,
    exec: null,
  };
  location.hash = to('#/access');
}

type Built = { readonly ok: true; readonly action: Action } | { readonly ok: false; readonly problems: readonly string[] };

const posInt = (x: string): boolean => /^[1-9]\d*$/.test(x.trim());

// Builds the typed, discriminated Action from the free-form draft after the
// local checks; the request validator checks it again before it is sent.
function buildAction(d: ActionDraft): Built {
  const problems: string[] = [];
  if (!d.profile) problems.push('Choose a profile.');
  if (!posInt(d.project)) problems.push('Choose a project.');
  const expected = d.expected_sha.trim();
  if (!/^[0-9a-f]{40}$/.test(expected)) problems.push('Expected SHA must be a full 40-character lowercase commit SHA.');
  for (const f of ACTION_KINDS[d.kind].fields) {
    const v = d[f].trim();
    if (f === 'description') {
      if (v.length > 10000) problems.push('Description is longer than 10000 characters.');
      continue;
    }
    if (f === 'iid' || f === 'id' || f === 'pipeline') {
      if (!posInt(v)) problems.push(`${FIELD_LABEL[f]} must be a positive number.`);
      continue;
    }
    if (f === 'tag' && !/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/.test(v)) {
      problems.push('Tag must start with a letter or digit and use only letters, digits, "_", "." and "-".');
      continue;
    }
    if (f === 'operation' && !opsFor(d.kind).includes(v)) {
      problems.push('Choose an operation.');
      continue;
    }
    if (f === 'title' && v.length > 200) {
      problems.push('Title is longer than 200 characters.');
      continue;
    }
    if (!v) problems.push(`${FIELD_LABEL[f]} is required.`);
  }
  if (problems.length) return { ok: false, problems };
  const base = { profile: d.profile, project: { value: Number(d.project) }, expected_sha: expected };
  const num = (x: string): { value: number } => ({ value: Number(x.trim()) });
  switch (d.kind) {
    case 'create_draft_mr':
      return {
        ok: true,
        action: {
          kind: 'create_draft_mr',
          ...base,
          source_branch: d.source_branch.trim(),
          target_branch: d.target_branch.trim(),
          title: d.title.trim(),
          description: d.description,
        },
      };
    case 'edit_draft_mr':
      return { ok: true, action: { kind: 'edit_draft_mr', ...base, iid: num(d.iid), title: d.title.trim(), description: d.description } };
    case 'create_tag':
      return { ok: true, action: { kind: 'create_tag', ...base, branch: d.branch.trim(), tag: d.tag.trim() } };
    case 'run_pipeline':
      return { ok: true, action: { kind: 'run_pipeline', ...base, branch: d.branch.trim() } };
    case 'change_pipeline': {
      const op = d.operation === 'cancel' ? 'cancel' : d.operation === 'retry' ? 'retry' : null;
      return op ? { ok: true, action: { kind: 'change_pipeline', ...base, id: num(d.id), operation: op } } : { ok: false, problems: ['Choose an operation.'] };
    }
    case 'change_job': {
      const op = d.operation === 'cancel' ? 'cancel' : d.operation === 'retry' ? 'retry' : d.operation === 'play' ? 'play' : null;
      return op
        ? { ok: true, action: { kind: 'change_job', ...base, id: num(d.id), pipeline: num(d.pipeline), operation: op } }
        : { ok: false, problems: ['Choose an operation.'] };
    }
  }
}

async function loadProfiles(): Promise<void> {
  try {
    S.profiles = await http.profiles();
    S.profilesError = null;
  } catch (e) {
    S.profilesError = errorMessage(e);
  }
  render();
}

async function runDoctor(name: string): Promise<void> {
  S.doctor.set(name, { kind: 'loading' });
  render();
  try {
    S.doctor.set(name, { kind: 'result', result: await http.doctor(name) });
  } catch (e) {
    S.doctor.set(name, { kind: 'error', error: errorMessage(e), status: errorStatus(e) });
  }
  render();
}

async function probeAction(): Promise<void> {
  const A = S.act;
  if (!A.draft) return;
  const b = buildAction(A.draft);
  if (!b.ok) {
    A.probe = { kind: 'error', error: b.problems.join(' '), status: null };
    render();
    return;
  }
  A.probe = { kind: 'loading' };
  render();
  try {
    A.probe = { kind: 'result', result: await http.probe(b.action) };
  } catch (e) {
    A.probe = { kind: 'error', error: errorMessage(e), status: errorStatus(e) };
  }
  render();
}

async function previewAction(): Promise<void> {
  const A = S.act;
  if (!A.draft) return;
  const b = buildAction(A.draft);
  if (!b.ok) {
    A.plan = { kind: 'error', error: b.problems.join(' '), status: null };
    render();
    return;
  }
  A.plan = { kind: 'loading' };
  A.exec = null;
  render();
  try {
    const r = await http.actionPreview(b.action);
    A.plan = { kind: 'result', result: r };
    if (r.kind === 'confirmable') ensureTick();
  } catch (e) {
    A.plan = { kind: 'error', error: errorMessage(e), status: errorStatus(e) };
  }
  render();
}

const remaining = (expiresAt: string): number => Math.max(0, Math.floor((Date.parse(expiresAt) - Date.now()) / 1000));

let tick = 0;
function ensureTick(): void {
  if (tick) return;
  tick = window.setInterval(() => {
    const plan = S.act.plan;
    if (plan?.kind !== 'result' || plan.result.kind !== 'confirmable') {
      window.clearInterval(tick);
      tick = 0;
      return;
    }
    const left = remaining(plan.result.expires_at);
    for (const el of document.querySelectorAll('[data-countdown]')) el.textContent = left > 0 ? `${left} s left` : 'Expired';
    if (left <= 0) {
      window.clearInterval(tick);
      tick = 0;
      render();
    }
  }, 1000);
}

type Confirmable = Extract<ActionPlan, { kind: 'confirmable' }>;

function executeDialog(plan: Confirmable): void {
  const ack = h('input', { type: 'checkbox', name: 'ack', 'data-fk': 'exec-ack' });
  dialog(
    'Submit to GitLab?',
    [
      h('p', null, plan.summary),
      actionKv(plan.action),
      h(
        'p',
        { class: 'hint' },
        'The server revalidates permission and the expected commit immediately before use. The confirmation is single-use. GitLab only reports whether it accepted the request; acceptance is not job, deployment or test success. Nothing is retried.',
      ),
      h('label', { class: 'check bare ack' }, ack, 'I reviewed this preview and want GitLab to perform it'),
    ],
    {
      okLabel: 'Submit to GitLab',
      danger: true,
      onOk: () => {
        if (!ack.checked) return 'Tick the confirmation box first.';
        if (remaining(plan.expires_at) <= 0) return 'This confirmation expired. Close and preview again.';
        void executeAction(plan);
        return null;
      },
    },
  );
}

async function executeAction(plan: Confirmable): Promise<void> {
  const A = S.act;
  A.plan = null; // single use, whatever the outcome
  A.exec = { kind: 'loading' };
  render();
  try {
    const r = await http.execute(plan.confirmation);
    A.exec = { kind: 'result', result: r };
    say(`GitLab accepted the ${r.action} request. Acceptance is not completion.`);
  } catch (e) {
    A.exec = { kind: 'error', error: errorMessage(e), status: errorStatus(e) };
  }
  render();
}

function actionKv(a: Action): HTMLDListElement {
  const rows: (readonly [string, Kid])[] = [
    ['Action', ACTION_KINDS[a.kind].label],
    ['Profile', a.profile],
    ['Project', projectPath(a.project.value)],
    ['Expected commit', sha(a.expected_sha)],
  ];
  switch (a.kind) {
    case 'create_draft_mr':
      rows.push(['Source branch', a.source_branch], ['Target branch', a.target_branch], ['Title', a.title]);
      if (a.description) rows.push(['Description', `${a.description.slice(0, 120)}${a.description.length > 120 ? '…' : ''}`]);
      break;
    case 'edit_draft_mr':
      rows.push(['MR IID', String(a.iid.value)], ['Title', a.title]);
      if (a.description) rows.push(['Description', `${a.description.slice(0, 120)}${a.description.length > 120 ? '…' : ''}`]);
      break;
    case 'create_tag':
      rows.push(['Branch', a.branch], ['Tag name', a.tag]);
      break;
    case 'run_pipeline':
      rows.push(['Branch', a.branch]);
      break;
    case 'change_pipeline':
      rows.push(['ID', String(a.id.value)], ['Operation', a.operation]);
      break;
    case 'change_job':
      rows.push(['ID', String(a.id.value)], ['Pipeline ID', String(a.pipeline.value)], ['Operation', a.operation]);
      break;
  }
  return h(
    'dl',
    { class: 'kv' },
    rows.map(([k, v]) => [h('dt', null, k), h('dd', null, v)]),
  );
}

const PERM: Readonly<Record<Permission['kind'], readonly ['ok' | 'fail' | 'unknown', 's_ok' | 's_fail' | 's_unknown', string]>> = {
  supported: ['ok', 's_ok', 'Permission supported'],
  denied: ['fail', 's_fail', 'Permission denied'],
  unknown: ['unknown', 's_unknown', 'Permission unknown'],
};

function permissionEl(perm: Permission): HTMLDivElement {
  const [t, ico, label] = PERM[perm.kind];
  const sc = perm.scope;
  return h(
    'div',
    { class: 'perm' },
    line(tone(t, ico, label), h('span', { class: 'muted' }, `checked ${fmtTime(perm.checked_at) ?? 'time not supplied'}`)),
    h('p', null, perm.reason),
    h(
      'dl',
      { class: 'kv' },
      h('dt', null, 'Profile'),
      h('dd', null, sc.profile),
      h('dt', null, 'Host'),
      h('dd', { class: 'mono' }, sc.host),
      h('dt', null, 'Project'),
      h('dd', null, projectPath(sc.project.value)),
      h('dt', null, 'Identity'),
      h('dd', { class: 'mono' }, `user ${sc.identity.value}`),
    ),
    perm.evidence.length
      ? h(
          'div',
          null,
          h('h3', null, 'Evidence'),
          h(
            'ul',
            { class: 'bullets' },
            perm.evidence.map((x) => h('li', null, x)),
          ),
        )
      : h('p', { class: 'muted' }, 'No evidence supplied.'),
  );
}

export function accessScreen(): HTMLElement {
  const C = S.caps;
  const profiles = S.profiles ?? [];
  const kinds = advertisedActions();
  const writeLab = C?.write_scope === 'isolated_synthetic_lab';
  const status = sec(
    'Write capability',
    'shield',
    h(
      'div',
      { class: 'box pad lines' },
      C
        ? [
            line(
              C.remote_mutations ? tone('warn', 'warning', 'Remote mutations possible') : tone('neutral', 'lock', 'Remote mutations off'),
              h('span', { class: 'chip' }, writeLab ? 'Scope: isolated synthetic lab' : 'Scope: disabled'),
              C.remote_read_only ? h('span', { class: 'chip' }, 'Remote read-only') : null,
            ),
            h(
              'p',
              null,
              writeLab
                ? 'Only an explicitly configured, write-enabled PAT profile on the isolated loopback lab can execute, after a fresh permission check, a preview and your confirmation.'
                : 'Remote writes are disabled. Work-item planning previews remain available and are never executed.',
            ),
            h(
              'dl',
              { class: 'kv' },
              h('dt', null, 'Advertised actions'),
              h('dd', null, kinds.length ? kinds.map((k) => ACTION_KINDS[k].label).join(', ') : none('None')),
              h('dt', null, 'Deferred'),
              h('dd', null, C.deferred_actions.join(', ')),
              h('dt', null, 'Confirmation'),
              h('dd', null, 'Required'),
              h('dt', null, 'Permission check'),
              h('dd', null, 'Required'),
            ),
          ]
        : h('p', { class: 'muted' }, `Capabilities unavailable: ${S.capsError ?? 'not loaded'}. Everything is treated as read-only.`),
    ),
  );

  const profileSec = sec(
    'Access profiles',
    'server',
    S.profilesError
      ? h(
          'div',
          { class: 'inline-err' },
          icon('s_fail', 'sm'),
          h('div', null, h('strong', null, 'Profiles unavailable. '), S.profilesError),
          h('button', { class: 'btn sm', type: 'button', onclick: () => void loadProfiles() }, 'Try again'),
        )
      : !profiles.length
        ? emptyState({
            title: 'No access profiles are configured',
            body: 'Fixture mode has none. Profiles (glab wrappers or a PAT for the isolated lab) are configured by the operator on the server as redacted descriptors; this UI never asks for or stores tokens or credentials.',
          })
        : h('div', { class: 'lines' }, profiles.map(profileCard)),
  );

  const actionSec = !profiles.length
    ? null
    : !kinds.length
      ? sec('Check and preview one action', 'eye', h('p', { class: 'muted box pad' }, 'The server advertises no remote actions.'))
      : actionForm(kinds, profiles);

  // One column in reading order: what is possible at all, which profiles
  // exist, how they compare for one action, then one profile's own flow.
  return h(
    'div',
    { class: 'screen' },
    h(
      'div',
      { class: 'sh' },
      h('div', { class: 'sh-title' }, h('h1', null, 'Access and actions'), h('span', { class: 'count' }, S.host ? `host ${S.host}` : 'host unknown')),
    ),
    h('div', { class: 'acc-col' }, status, profileSec, compareSection(profiles), actionSec),
  );
}

/* -------------------------------------------- permission comparison */
// POST /api/access/compare: one typed action and 2–16 explicitly selected
// configured profiles sharing its host and project. The server makes GET-only
// permission probes: nothing is executed, no confirmation is issued and
// nothing is retried. Each profile's row keeps its own result and error code.

const COMPARE_KINDS = Object.keys(ACTION_KINDS).filter(isActionKind);
let comparisonSequence = 0;

function cmpDraft(): ActionDraft {
  const C = S.cmp;
  if (!C.draft) C.draft = blankDraft(COMPARE_KINDS[0] ?? 'run_pipeline', '', S.scope.project == null ? '' : String(S.scope.project));
  return C.draft;
}

// Any edit invalidates a shown result; it never re-runs on its own.
function cmpChanged(rerender: boolean): void {
  comparisonSequence++;
  const had = S.cmp.result !== null;
  if (had) S.cmp.result = null;
  if (rerender || had) render();
}

async function runCompare(): Promise<void> {
  const C = S.cmp;
  const d = cmpDraft();
  if (C.result?.kind === 'loading') return;
  const names = C.selected;
  if (names.length < 2 || names.length > 16) {
    C.result = { kind: 'error', error: 'Choose between 2 and 16 configured profiles.', status: null };
    render();
    return;
  }
  // The action names the first selected profile; the request lists them all.
  const b = buildAction({ ...d, profile: names[0] ?? '' });
  if (!b.ok) {
    C.result = { kind: 'error', error: b.problems.join(' '), status: null };
    render();
    return;
  }
  C.result = { kind: 'loading' };
  const sequence = ++comparisonSequence;
  render();
  try {
    const result = await http.compareAccess({ action: b.action, profiles: names });
    if (sequence !== comparisonSequence) return;
    C.result = { kind: 'result', result };
    say('Permission comparison checked. Nothing was executed.');
  } catch (e) {
    if (sequence !== comparisonSequence) return;
    C.result = { kind: 'error', error: errorMessage(e), status: errorStatus(e) };
  }
  render();
}

const CMP_KIND: Readonly<Record<ProbeComparisonRow['kind'], readonly ['ok' | 'fail' | 'unknown', 's_ok' | 's_fail' | 's_unknown', string]>> = {
  allowed: ['ok', 's_ok', 'Allowed'],
  denied: ['fail', 's_fail', 'Denied'],
  unknown: ['unknown', 's_unknown', 'Unknown'],
};

function cmpResult(r: ProbeComparison): HTMLElement {
  const deferred = Array.isArray(r.deferred_actions) ? r.deferred_actions : [];
  return h(
    'div',
    { class: 'lines' },
    simpleTable(
      ['Profile', 'Project', 'Identity', 'Result', 'Reason', 'Evidence', 'Checked'],
      r.rows.map((x) => {
        const [t, ico, label] = CMP_KIND[x.kind];
        return [
          h(
            'div',
            { class: 'lines' },
            line(h('strong', null, x.profile.name), h('span', { class: 'chip' }, x.profile.kind === 'pat' ? 'PAT' : 'glab'), writeChip(x.profile, true)),
            h('span', { class: 'mono muted' }, x.profile.host),
          ),
          projectPath(x.project.value),
          x.identity ? h('span', { class: 'mono' }, `user ${x.identity.value}`) : none('unknown'),
          // An error is isolated to its row and never reads as "denied".
          line(
            tone(t, ico, label),
            x.error_code
              ? h('span', { class: 'chip st t-fail', title: 'Error reported for this profile only' }, h('span', null, `error: ${x.error_code}`))
              : null,
          ),
          h('span', { class: 'reason' }, x.reason),
          x.evidence.length
            ? h(
                'details',
                { class: 'cmp-ev' },
                h('summary', null, plural(x.evidence.length, 'evidence item')),
                h(
                  'ul',
                  { class: 'bullets' },
                  x.evidence.map((e) => h('li', null, e)),
                ),
              )
            : none('none supplied'),
          h('span', { class: 'nowrap' }, fmtTime(x.checked_at) ?? 'time not supplied'),
        ];
      }),
      'The server returned no rows.',
      { label: 'Permission comparison' },
    ),
    line(
      tone('neutral', 'lock', 'Not executed'),
      h('span', { class: 'chip' }, 'No confirmation issued'),
      h('span', { class: 'chip mono' }, r.host),
      h('span', { class: 'chip' }, projectPath(r.project.value)),
      deferred.length ? h('span', { class: 'muted' }, `Deferred: ${deferred.join(', ')}`) : null,
      h('span', { class: 'muted' }, `checked ${fmtTime(r.checked_at) ?? 'time not supplied'}`),
    ),
    h('p', { class: 'hint' }, 'Allowed is a fresh GET-only permission check, not a grant and not a test write. Unknown stays unknown.'),
  );
}

function compareSection(profiles: readonly ProfileSummary[]): HTMLElement {
  const title = 'Compare permissions (GET only)';
  if (profiles.length < 2) {
    return sec(
      title,
      'shield',
      h(
        'div',
        { class: 'box pad lines' },
        h(
          'p',
          null,
          `Comparison needs at least two configured profiles; ${profiles.length ? 'one is' : 'none are'} configured on this server, so nothing can be compared.`,
        ),
        h('p', { class: 'hint' }, 'Profiles are operator configuration on the server. None is invented here and no credential is asked for.'),
      ),
    );
  }
  const C = S.cmp;
  const d = cmpDraft();
  // Only configured profiles that still exist; one host for the whole request.
  C.selected = C.selected.filter((n) => profiles.some((p) => p.name === n));
  const chosen = profiles.filter((p) => C.selected.includes(p.name));
  const host = chosen[0]?.host ?? null;
  const shared = chosen.length
    ? (chosen[0]?.projects ?? []).map((x) => x.value).filter((id) => chosen.every((p) => p.projects.some((y) => y.value === id)))
    : [];
  const busy = C.result?.kind === 'loading';
  const fld = (label: string, el: HTMLElement, wide = false): HTMLLabelElement =>
    h('label', { class: `field${wide ? ' wide' : ''}` }, h('span', null, label), el);
  const setF = (k: 'project' | 'expected_sha' | ActionField, v: string, rerender = false): void => {
    d[k] = v;
    cmpChanged(rerender);
  };
  const input = (k: ActionField, mono: boolean, numeric = false): HTMLInputElement =>
    h('input', {
      class: `input${mono ? ' mono' : ''}`,
      value: d[k],
      autocomplete: 'off',
      inputmode: numeric ? 'numeric' : null,
      'data-fk': `cmp-${k}`,
      oninput: (e: Event) => setF(k, controlValue(e)),
    });
  const fields = ACTION_KINDS[d.kind].fields.map((k) => {
    if (k === 'operation')
      return fld(
        FIELD_LABEL[k],
        h(
          'select',
          { class: 'select', 'data-fk': 'cmp-op', onchange: (e: Event) => setF(k, controlValue(e), true) },
          opsFor(d.kind).map((op) => h('option', { value: op, selected: d.operation === op }, op)),
        ),
      );
    if (k === 'description')
      return fld(
        FIELD_LABEL[k],
        h('textarea', { class: 'input', rows: '2', maxlength: '10000', 'data-fk': 'cmp-desc', oninput: (e: Event) => setF(k, controlValue(e)) }, d.description),
        true,
      );
    if (k === 'iid' || k === 'id' || k === 'pipeline') return fld(FIELD_LABEL[k], input(k, true, true));
    return fld(FIELD_LABEL[k], input(k, k !== 'title'));
  });
  const R = C.result;
  return sec(
    title,
    'shield',
    h(
      'div',
      { class: 'box pad lines' },
      h(
        'p',
        { class: 'hint' },
        'Checks one identical action for each selected configured profile on one host and project. The server only reads permissions; nothing is executed.',
      ),
      h(
        'fieldset',
        { class: 'fs' },
        h('legend', null, `Profiles (${chosen.length} of 2–16 selected)`),
        h(
          'div',
          { class: 'cmp-profiles' },
          profiles.map((p) => {
            const other = host !== null && p.host !== host;
            return h(
              'label',
              { class: 'check', title: other ? `Another host (${p.host}); one comparison covers one host` : p.host },
              h('input', {
                type: 'checkbox',
                checked: C.selected.includes(p.name),
                disabled: other || busy,
                'data-fk': `cmp-p-${p.name}`,
                onchange: (e: Event) => {
                  C.selected = checkedOf(e) ? [...C.selected, p.name] : C.selected.filter((n) => n !== p.name);
                  cmpChanged(true);
                },
              }),
              h('span', null, p.name),
              h('span', { class: 'muted' }, `${p.kind === 'pat' ? 'PAT' : 'glab'}${other ? ' · other host' : ''}`),
            );
          }),
        ),
      ),
      h(
        'div',
        { class: 'form-grid' },
        fld(
          'Action',
          h(
            'select',
            {
              class: 'select',
              'data-fk': 'cmp-kind',
              onchange: (e: Event) => {
                const v = controlValue(e);
                if (!isActionKind(v)) return;
                d.kind = v;
                d.operation = opsFor(v)[0] ?? '';
                cmpChanged(true);
              },
            },
            COMPARE_KINDS.map((k) => h('option', { value: k, selected: k === d.kind }, ACTION_KINDS[k].label)),
          ),
        ),
        fld(
          'Project (shared by the selected profiles)',
          h(
            'select',
            { class: 'select', 'data-fk': 'cmp-project', onchange: (e: Event) => setF('project', controlValue(e), true) },
            h('option', { value: '' }, chosen.length ? (shared.length ? 'Choose…' : 'No project shared by all selected') : 'Select profiles first'),
            shared.map((id) => h('option', { value: String(id), selected: String(id) === d.project }, projectPath(id))),
          ),
        ),
        fld(
          'Expected commit SHA',
          h('input', {
            class: 'input mono',
            value: d.expected_sha,
            autocomplete: 'off',
            maxlength: '40',
            spellcheck: 'false',
            'data-fk': 'cmp-expected_sha',
            oninput: (e: Event) => setF('expected_sha', controlValue(e)),
          }),
          true,
        ),
        fields,
      ),
      h(
        'div',
        { class: 'line' },
        h(
          'button',
          {
            class: 'btn primary',
            type: 'button',
            disabled: busy || chosen.length < 2 || !d.project,
            'data-fk': 'cmp-run',
            onclick: () => void runCompare(),
          },
          icon('shield', 'sm'),
          busy ? 'Checking…' : 'Check permissions (GET only)',
        ),
        chosen.length < 2 ? h('span', { class: 'muted' }, 'Select at least two profiles.') : null,
      ),
      R?.kind === 'error'
        ? h(
            'div',
            { class: 'inline-err', role: 'alert' },
            icon('s_fail', 'sm'),
            h(
              'div',
              null,
              h('strong', null, 'Comparison not available. '),
              R.error,
              h('div', { class: 'reason' }, 'Nothing was executed and nothing is retried automatically.'),
            ),
          )
        : null,
      R?.kind === 'result' ? cmpResult(R.result) : null,
    ),
  );
}

/** True only when the server reports remote mutations on and the isolated synthetic lab scope. */
const liveWrite = (): boolean => S.caps?.remote_mutations === true && S.caps.write_scope === 'isolated_synthetic_lab';

// A profile configured for writes is only a live write path when the server
// capability is actually enabled; otherwise the configured fact stays, in a
// neutral tone, without suggesting that writes are possible here.
function writeChip(p: { readonly write_enabled: boolean }, short = false): HTMLSpanElement {
  if (!p.write_enabled) return h('span', { class: 'chip' }, short ? 'read only' : 'Read only');
  if (liveWrite())
    return h(
      'span',
      { class: 'chip st t-warn', title: 'Configuration allows writes; permission is still checked per action' },
      h('span', null, short ? 'write enabled' : 'Write enabled by configuration'),
    );
  return h(
    'span',
    { class: 'chip', title: 'The profile is configured for writes, but remote mutations are off for this server scope; nothing can be written here' },
    short ? 'write configured · inactive' : 'Write configured · inactive here',
  );
}

function profileCard(p: ProfileSummary): HTMLDivElement {
  const dr = S.doctor.get(p.name) ?? null;
  const rep = dr?.kind === 'result' ? dr.result : null;
  return h(
    'div',
    { class: 'box pad lines' },
    // Identity and chips wrap on their own; the tool keeps one place (top right) at every width.
    h(
      'div',
      { class: 'pc-head' },
      line(h('strong', null, p.name), h('span', { class: 'chip' }, p.kind === 'pat' ? 'PAT' : 'glab'), writeChip(p)),
      h(
        'button',
        {
          class: 'btn sm',
          type: 'button',
          disabled: dr?.kind === 'loading',
          onclick: () => void runDoctor(p.name),
          title: 'Read-only diagnostics; no write is attempted',
        },
        icon('pulse', 'sm'),
        dr?.kind === 'loading' ? 'Checking…' : 'Run doctor',
      ),
    ),
    h(
      'dl',
      { class: 'kv' },
      h('dt', null, 'Host'),
      h('dd', { class: 'mono' }, p.host),
      h('dt', null, 'Projects'),
      h('dd', null, p.projects.length ? p.projects.map((x) => projectPath(x.value)).join(', ') : none('None')),
    ),
    dr?.kind === 'error' ? h('div', { class: 'inline-err' }, icon('s_fail', 'sm'), h('div', null, dr.error)) : null,
    rep
      ? h(
          'div',
          { class: 'perm' },
          line(tone('neutral', 'pulse', `Doctor: ${rep.kind}`), h('span', { class: 'muted' }, `checked ${fmtTime(rep.checked_at) ?? 'time not supplied'}`)),
          h(
            'dl',
            { class: 'kv' },
            h('dt', null, 'API version'),
            h('dd', null, rep.api_version || none('—')),
            h('dt', null, 'Identity'),
            h('dd', { class: 'mono' }, `user ${rep.identity.value}`),
            h('dt', null, 'Executable'),
            h('dd', null, rep.kind === 'glab' ? `${rep.executable} ${rep.executable_version}` : none('None (PAT profile)')),
            h('dt', null, 'Write transport'),
            h('dd', null, rep.write_transport),
          ),
          h('p', { class: 'hint' }, rep.message),
        )
      : null,
  );
}

function actionForm(kinds: readonly ActionKind[], profiles: readonly ProfileSummary[]): HTMLElement {
  const A = S.act;
  const first = kinds[0];
  const firstProfile = profiles[0];
  if (first && firstProfile && (!A.draft || !kinds.includes(A.draft.kind))) {
    A.draft = blankDraft(first, firstProfile.name, S.scope.project == null ? '' : String(S.scope.project));
  }
  const d = A.draft;
  if (!d) return sec('Action check and preview', 'eye', h('p', { class: 'muted box pad' }, 'The server advertises no remote actions.'));
  const prof = profiles.find((p) => p.name === d.profile);
  // A changed action invalidates checks.
  const setF = (k: 'profile' | 'project' | 'expected_sha' | ActionField, val: string, rerender = false): void => {
    d[k] = val;
    const invalidated = A.plan?.kind === 'result' || A.probe?.kind === 'result';
    if (invalidated) {
      A.plan = null;
      A.probe = null;
    }
    if (rerender || invalidated) render();
  };
  const fld = (label: string, input: HTMLElement): HTMLLabelElement => h('label', { class: 'field' }, h('span', null, label), input);
  const monoField = (k: ActionField): boolean => k === 'source_branch' || k === 'target_branch' || k === 'branch' || k === 'tag';
  const txt = (
    k: ActionField,
    extra: { readonly maxlength?: string; readonly mono?: boolean; readonly numeric?: boolean; readonly pattern?: string } = {},
  ): HTMLInputElement =>
    h('input', {
      class: `input${monoField(k) || extra.mono ? ' mono' : ''}`,
      value: d[k],
      autocomplete: 'off',
      'data-fk': `act-${k}`,
      maxlength: extra.maxlength ?? null,
      inputmode: extra.numeric ? 'numeric' : null,
      pattern: extra.pattern ?? null,
      oninput: (e: Event) => setF(k, controlValue(e)),
    });
  const projectOpts = prof?.projects.length ? prof.projects.map((x) => x.value) : S.projects.map((x) => x.id.value);
  const fields = ACTION_KINDS[d.kind].fields.map((k) => {
    if (k === 'operation')
      return fld(
        FIELD_LABEL[k],
        h(
          'select',
          { class: 'select', 'data-fk': 'act-op', onchange: (e: Event) => setF(k, controlValue(e), true) },
          opsFor(d.kind).map((op) => h('option', { value: op, selected: d.operation === op }, op)),
        ),
      );
    if (k === 'description')
      return fld(
        FIELD_LABEL[k],
        h('textarea', { class: 'input', rows: '3', maxlength: '10000', 'data-fk': 'act-desc', oninput: (e: Event) => setF(k, controlValue(e)) }, d.description),
      );
    if (k === 'iid' || k === 'id' || k === 'pipeline') return fld(FIELD_LABEL[k], txt(k, { numeric: true, mono: true }));
    if (k === 'title') return fld(FIELD_LABEL[k], txt(k, { maxlength: '200' }));
    if (k === 'tag') return fld(FIELD_LABEL[k], txt(k, { maxlength: '128', pattern: '[A-Za-z0-9][A-Za-z0-9_.\\-]{0,127}' }));
    return fld(FIELD_LABEL[k], txt(k));
  });

  const probe = A.probe;
  const plan = A.plan;
  const ex = A.exec;
  let planEl: Kid = null;
  if (plan?.kind === 'loading') planEl = h('p', { class: 'hint', role: 'status' }, 'Requesting preview…');
  else if (plan?.kind === 'error')
    planEl = h('div', { class: 'inline-err', role: 'alert' }, icon('s_fail', 'sm'), h('div', null, h('strong', null, 'Preview failed. '), plan.error));
  else if (plan?.kind === 'result') {
    const P = plan.result;
    if (P.kind === 'blocked') {
      planEl = h(
        'div',
        { class: 'plan blocked' },
        line(tone('fail', 'lock', 'Blocked — cannot execute'), h('span', { class: 'muted' }, 'Preview only; nothing was sent')),
        h('p', null, P.summary),
        permissionEl(P.permission),
      );
    } else {
      const left = remaining(P.expires_at);
      planEl = h(
        'div',
        { class: 'plan confirmable' },
        line(
          tone('neutral', 'eye', 'Ready to confirm'),
          h('span', { class: 'muted' }, 'Preview only; nothing was sent'),
          h('span', { class: 'chip', 'data-countdown': '' }, left > 0 ? `${left} s left` : 'Expired'),
        ),
        h('p', null, P.summary),
        actionKv(P.action),
        permissionEl(P.permission),
        h(
          'div',
          { class: 'line' },
          h(
            'button',
            {
              class: 'btn danger',
              type: 'button',
              disabled: left <= 0 || ex?.kind === 'loading',
              'data-fk': 'act-exec',
              onclick: () => executeDialog(P),
            },
            icon('send', 'sm'),
            'Submit to GitLab…',
          ),
          left <= 0 ? h('span', { class: 'muted' }, 'Expired — preview again for a new confirmation.') : null,
        ),
      );
    }
  }
  let exEl: Kid = null;
  if (ex?.kind === 'loading') exEl = h('p', { class: 'hint', role: 'status' }, 'Submitting once to GitLab…');
  else if (ex?.kind === 'error') {
    exEl = h(
      'div',
      { class: 'inline-err', role: 'alert' },
      icon('s_fail', 'sm'),
      h(
        'div',
        null,
        h('strong', null, 'Not accepted. '),
        ex.error,
        h(
          'div',
          { class: 'reason' },
          ex.status === 409
            ? 'The confirmation was stale, expired or already used. Preview again if still needed.'
            : 'Nothing is retried automatically. Check permission and preview again if still needed.',
        ),
      ),
    );
  } else if (ex?.kind === 'result') {
    const r = ex.result;
    exEl = h(
      'div',
      { class: 'plan accepted' },
      line(tone('info', 'send', 'Accepted by GitLab'), h('span', { class: 'muted' }, `at ${fmtTime(r.accepted_at) ?? 'time not supplied'}`)),
      h('p', null, r.message),
      h(
        'dl',
        { class: 'kv' },
        h('dt', null, 'Action'),
        h('dd', null, r.action),
        h('dt', null, 'Profile'),
        h('dd', null, r.profile),
        h('dt', null, 'Host'),
        h('dd', { class: 'mono' }, r.host),
        h('dt', null, 'Project'),
        h('dd', null, projectPath(r.project.value)),
        h('dt', null, 'Identity'),
        h('dd', { class: 'mono' }, `user ${r.identity.value}`),
      ),
      h('p', { class: 'hint' }, 'Acceptance is not job, deployment or application-test success. Refresh explicitly to read new evidence.'),
      h('button', { class: 'btn sm', type: 'button', onclick: () => void refreshSnapshot(), disabled: S.sync.busy }, icon('refresh', 'sm'), 'Refresh snapshot'),
    );
  }

  return sec(
    'Action check and preview',
    'eye',
    h(
      'div',
      { class: 'box pad lines' },
      h(
        'p',
        { class: 'hint' },
        'Check permission and preview make fresh read-only requests. Only a confirmable preview can be submitted, once, after you confirm.',
      ),
      h(
        'div',
        { class: 'form-grid' },
        fld(
          FIELD_LABEL.profile,
          h(
            'select',
            { class: 'select', 'data-fk': 'act-profile', onchange: (e: Event) => setF('profile', controlValue(e), true) },
            profiles.map((p) =>
              h('option', { value: p.name, selected: p.name === d.profile }, `${p.name} · ${p.kind}${p.write_enabled ? '' : ' · read only'}`),
            ),
          ),
        ),
        h(
          'label',
          { class: 'field' },
          h('span', null, 'Action'),
          h(
            'select',
            {
              class: 'select',
              'data-fk': 'act-kind',
              onchange: (e: Event) => {
                const v = controlValue(e);
                if (!isActionKind(v)) return;
                d.kind = v;
                d.operation = opsFor(v)[0] ?? '';
                A.plan = null;
                A.probe = null;
                render();
              },
            },
            kinds.map((k) => h('option', { value: k, selected: k === d.kind }, ACTION_KINDS[k].label)),
          ),
        ),
        h(
          'label',
          { class: 'field' },
          h('span', null, 'Project'),
          h(
            'select',
            { class: 'select', 'data-fk': 'act-project', onchange: (e: Event) => setF('project', controlValue(e), true) },
            h('option', { value: '' }, 'Choose…'),
            projectOpts.map((id) => h('option', { value: String(id), selected: String(id) === d.project }, projectPath(id))),
          ),
        ),
        h(
          'label',
          { class: 'field wide' },
          h('span', null, 'Expected commit SHA'),
          h('input', {
            class: 'input mono',
            value: d.expected_sha,
            autocomplete: 'off',
            maxlength: '40',
            spellcheck: 'false',
            'data-fk': 'act-expected_sha',
            oninput: (e: Event) => setF('expected_sha', controlValue(e)),
          }),
        ),
        fields,
      ),
      prof && !prof.write_enabled ? h('p', { class: 'hint' }, 'This profile is read only by configuration; the server will not allow it to execute.') : null,
      h(
        'div',
        { class: 'line' },
        h(
          'button',
          { class: 'btn', type: 'button', disabled: probe?.kind === 'loading', onclick: () => void probeAction(), 'data-fk': 'act-probe' },
          icon('shield', 'sm'),
          probe?.kind === 'loading' ? 'Checking…' : 'Check permission',
        ),
        h(
          'button',
          { class: 'btn primary', type: 'button', disabled: plan?.kind === 'loading', onclick: () => void previewAction(), 'data-fk': 'act-preview' },
          icon('eye', 'sm'),
          plan?.kind === 'loading' ? 'Previewing…' : 'Preview',
        ),
      ),
      probe?.kind === 'error'
        ? h('div', { class: 'inline-err', role: 'alert' }, icon('s_fail', 'sm'), h('div', null, h('strong', null, 'Permission check failed. '), probe.error))
        : null,
      probe?.kind === 'result' ? permissionEl(probe.result) : null,
      planEl,
      exEl,
    ),
  );
}
