"""Run under the owned macOS loopback-only process profile; prove blocked IP attempts."""

from __future__ import annotations

import errno
import hashlib
import json
import socket
import subprocess
import sys
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import Error, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output/verification/offline-runtime"


def blocked(kind: int) -> dict[str, object]:
    with socket.socket(socket.AF_INET, kind) as connection:
        connection.settimeout(0.5)
        try:
            if kind == socket.SOCK_DGRAM:
                connection.sendto(b"gspace-negative-control", ("192.0.2.1", 53))
            else:
                connection.connect(("192.0.2.1", 443))
        except OSError as error:
            return {
                "kind": "UDP" if kind == socket.SOCK_DGRAM else "TCP",
                "errno": error.errno,
                "denied_by_os": error.errno == errno.EPERM,
            }
    return {"denied_by_os": False}


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    controls = [blocked(socket.SOCK_STREAM), blocked(socket.SOCK_DGRAM)]
    assert all(control["denied_by_os"] for control in controls)
    child = subprocess.run(
        [
            sys.executable,
            "-c",
            "import socket; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); "
            "\ntry:s.sendto(b'gspace-child-control',('192.0.2.1',53));raise RuntimeError('Allowed')"
            "\nexcept PermissionError:print('EPERM')",
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=3,
        env={"PATH": "/usr/bin:/bin"},
    )
    assert child.stdout.strip() == "EPERM"
    report: dict[str, object] = {
        "enforcement": "macOS process sandbox inherited by children",
        "blocked_attempts": controls,
        "child_control": "EPERM",
        "profile_sha256": hashlib.sha256(
            (ROOT / "integration/runtime-network-loopback.sb").read_bytes()
        ).hexdigest(),
        "global_settings_changed": False,
        "container_test": "not run; OS process enforcement instead",
    }
    with fixture_server(ROOT / "src/gspace/static") as port, sync_playwright() as engine:
        origin = f"http://127.0.0.1:{port}"
        with urlopen(origin + "/api/dashboard", timeout=3) as response:
            assert response.status == 200
            report["loopback_server"] = "200 with typed fixture dashboard"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(service_workers="block")
        page = context.new_page()
        # No route interception for this negative control: kernel denial must stop it.
        failure: list[str] = []
        page.on("requestfailed", lambda request: failure.append(request.failure or "unknown"))
        try:
            page.goto("http://192.0.2.1:443/", timeout=3000)
            raise AssertionError("Reserved non-loopback browser request unexpectedly succeeded")
        except Error as error:
            report["browser_negative"] = str(error).split("\n", 1)[0]
        report["browser_request_failure"] = failure
        assert any("NETWORK_ACCESS_DENIED" in f or "ACCESS_DENIED" in f for f in failure)
        context.close()
        browser.close()
    report["limitations"] = [
        "Allows loopback and temporary Unix IPC for Chrome; not a machine-wide firewall",
        (
            "This probe covers TCP/UDP/browser; the separate "
            "glab-dns-redirect-probe covers system DNS denial"
        ),
        (
            "Production DevPod OS enforcement and glab redirect "
            "scope remain unverified; local helper relays are unaudited"
        ),
        "Browser regression request interception is a separate application-level assertion",
    ]
    (OUTPUT / "os-denial-probe.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
