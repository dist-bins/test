// Typed UI state. Validated remote DTOs (readonly, from src/api.ts) are kept
// apart from mutable UI state, edit drafts and local loading/error states.

import type {
  ActionPlan,
  ActionResult,
  CapabilitiesResponse,
  Checklist,
  Column,
  Dashboard,
  DoctorReport,
  Filters,
  ItemView,
  MilestoneCatalog,
  MilestoneFilter,
  MilestoneKey,
  MRCatalogResponse,
  NavigationCatalog,
  Permission,
  PipelineGraph,
  PreferenceCommand,
  Preferences,
  Preview,
  PreviewRequest,
  ProbeComparison,
  ProfileSummary,
  ProjectConfig,
  ProjectPresentation,
  ResourceReference,
  SavedView,
  SettingsResponse,
  ViewFilters,
  ViewScope,
  WorkKey,
} from './api';
import { errorMessage, http, StaleError } from './api';
import type { Derived } from './model';
import { render } from './render';

/* ============================================================ unions */

export type Scope = ViewScope;
export type UiKey = Scope | 'compare';
export type Sort = SavedView['sort'];
export type ViewState = ViewFilters['state'];
export type WorkState = Filters['state'];
export type Orientation = SavedView['orientation'];
export type PreviewAction = PreviewRequest['action'];
export type ChecklistField = keyof Omit<Checklist, 'key'>;
export type Outcome = 'passed' | 'failed' | 'not_tested';
export type ProblemTone = 'fail' | 'warn';
/**
 * Two readings of the same data, filters and selection: the Overview (stored
 * value "visual"), which shows the facts that answer each page's question
 * first and opens evidence in place, and the Detailed evidence tables.
 * Browser-local appearance (like the theme); it changes no shared preference.
 */
export type DisplayMode = 'visual' | 'detailed';

/**
 * Attention categories, derived only from typed fields (src/attention.ts).
 * Unknown is missing evidence: never healthy and never counted as a problem.
 */
export type AttnKind = 'failing' | 'rebase' | 'differs' | 'readerr' | 'testfail' | 'totest' | 'unknown';

/** Normalised milestone filter: `selected` exists exactly in selected mode. */
export type MsFilter =
  | { readonly mode: 'all' | 'active' | 'date_current' | 'unassigned'; readonly selected: null }
  | { readonly mode: 'selected'; readonly selected: MilestoneKey };

/** Local asynchronous state: nothing yet, in flight, failed or a validated result. */
export type Async<T> =
  | null
  | { readonly kind: 'loading' }
  | { readonly kind: 'error'; readonly error: string; readonly status: number | null }
  | { readonly kind: 'result'; readonly result: T };

export type ItemLoad =
  | { readonly kind: 'loading' }
  | { readonly kind: 'ok' }
  | { readonly kind: 'error'; readonly error: string; readonly status: number | null };

export type PreviewState =
  | { readonly action: PreviewAction; readonly kind: 'loading' }
  | { readonly action: PreviewAction; readonly kind: 'error'; readonly error: string }
  | { readonly action: PreviewAction; readonly kind: 'result'; readonly result: Preview };

/* ============================================================== ui */

export interface UiFilters {
  state: ViewState;
  search: string;
  assigned: boolean;
  group: string;
  show_hidden: boolean;
  milestone: MsFilter;
}

export interface ListUi {
  filters: UiFilters;
  sort: Sort;
  descending: boolean;
  columns: Column[];
  orientation: Orientation;
  view: string | null;
  projectSet: Set<number> | null;
  /**
   * True until the user picks fields or applies a saved view: configured
   * environment columns reported by the dashboard are then shown by default.
   */
  autoEnv: boolean;
}

export interface Problem {
  readonly id: number;
  readonly op: string;
  readonly key: string;
  readonly title: string;
  readonly detail: string;
  readonly tone: ProblemTone;
  count: number;
  readonly first: number;
  last: number;
  retry: (() => void) | null;
  /** Visible name of the retry action ("Retry" unless the screen uses another verb, e.g. "Reload"). */
  retryLabel: string;
}

/* ------------------------------------------------- settings edit drafts */
// Mutable form state, separate from the validated SettingsResponse DTO.

export type JobRole = 'normal' | 'publish' | 'deploy';
export type RefSource = 'branch' | 'tag';
export interface StageDraft {
  name: string;
  depends_on: string[];
}
export interface JobDraft {
  pattern: string;
  role: JobRole;
  environment: string | null;
}
export interface EnvDraft {
  name: string;
  label: string;
  ref_source: RefSource;
}
export interface RulesDraft {
  stages: StageDraft[];
  important_job_patterns: string[];
  jobs: JobDraft[];
  environments: EnvDraft[];
}
export interface OverrideDraft {
  project: number;
  stages: StageDraft[] | null;
  important_job_patterns: string[] | null;
  jobs: JobDraft[] | null;
  environments: EnvDraft[] | null;
}
export interface SettingsDraft {
  timezone: string;
  branch_template: string;
  tag_convention: { component_from_right: number; increment: number; preserve_padding: boolean };
  pipeline: RulesDraft;
  project_pipeline_overrides: OverrideDraft[];
}
export interface SavedNotice {
  readonly at: number;
  /** "save": this form saved; "external": a reload found a newer valid file revision. */
  readonly origin: 'save' | 'external';
  readonly revision: string;
  readonly refresh_required: boolean;
  readonly refreshed: boolean;
  /** Local re-read of the views after the save: in flight, done, failed, or not applicable. */
  readonly views: 'pending' | boolean | null;
}
export interface SettingsState {
  resp: SettingsResponse | null;
  error: string | null;
  /** HTTP status of the last failed read (400: the file is invalid; the service keeps the last valid one). */
  errorStatus: number | null;
  loading: boolean;
  draft: SettingsDraft | null;
  base: SettingsDraft | null;
  conflict: { readonly message: string; readonly at: number } | null;
  saving: boolean;
  saveError: string | null;
  saved: SavedNotice | null;
  rebased: boolean;
  adv: { text: string; error: string | null } | null;
}

/* ------------------------------------------------------- action drafts */

export type ActionKind = 'create_draft_mr' | 'edit_draft_mr' | 'create_tag' | 'run_pipeline' | 'change_pipeline' | 'change_job';
export type ActionField = 'source_branch' | 'target_branch' | 'title' | 'description' | 'iid' | 'branch' | 'tag' | 'id' | 'pipeline' | 'operation';
/** Free-form action form; every field is text until actionBody() builds the typed Action. */
export interface ActionDraft {
  kind: ActionKind;
  profile: string;
  project: string;
  expected_sha: string;
  source_branch: string;
  target_branch: string;
  title: string;
  description: string;
  iid: string;
  branch: string;
  tag: string;
  id: string;
  pipeline: string;
  operation: string;
}
export type ExecState =
  | null
  | { readonly kind: 'loading' }
  | { readonly kind: 'error'; readonly error: string; readonly status: number | null }
  | { readonly kind: 'result'; readonly result: ActionResult };

export interface AppTestDraft {
  sha: string;
  version: string;
  notes: string;
}

/* ============================================================ routes */

export const KNOWN = ['work', 'compare', 'item', 'milestones', 'mrs', 'branches', 'pipelines', 'bookmarks', 'views', 'settings', 'sources', 'access'] as const;
export type KnownScreen = (typeof KNOWN)[number];
export type ScreenName = KnownScreen | 'missing';
export interface Route {
  readonly screen: ScreenName;
  readonly args: readonly string[];
  readonly project: number | null;
}
export const isKnown = (s: string): s is KnownScreen => KNOWN.some((x) => x === s);

/* ======================================================== constants */

export const SCOPES: readonly Scope[] = ['work_items', 'mrs', 'branches', 'pipelines'];
export const isScope = (s: string): s is Scope => SCOPES.some((x) => x === s);
export const SCOPE_LABEL: Readonly<Record<Scope, string>> = { work_items: 'Work items', mrs: 'Merge requests', branches: 'Branches', pipelines: 'Pipelines' };
export const SCOPE_ROUTE: Readonly<Record<Scope, KnownScreen>> = { work_items: 'work', mrs: 'mrs', branches: 'branches', pipelines: 'pipelines' };
export const SCOPE_ICON = { work_items: 'work', mrs: 'mr', branches: 'branch', pipelines: 'pipeline' } as const;

// Column IDs are the closed set exported by the contract.
export const COLS: Readonly<Record<Scope, readonly Column[]>> = {
  work_items: ['identity', 'title', 'state', 'project', 'branch', 'mr', 'pipeline', 'jobs', 'publish', 'dev', 'ref', 'preprod', 'sha'],
  mrs: ['identity', 'title', 'state', 'project', 'branch', 'sha', 'pipeline', 'updated_at'],
  branches: ['identity', 'title', 'project', 'sha', 'state', 'mr', 'pipeline'],
  pipelines: ['identity', 'title', 'state', 'project', 'ref', 'sha', 'jobs', 'publish'],
};
export const DEFAULT_COLS: Readonly<Record<Scope, readonly Column[]>> = {
  work_items: ['title', 'state', 'branch', 'mr', 'pipeline', 'jobs', 'publish', 'dev', 'ref', 'preprod', 'sha'],
  mrs: ['title', 'state', 'project', 'branch', 'sha', 'pipeline', 'updated_at'],
  branches: ['title', 'project', 'sha', 'state', 'mr', 'pipeline'],
  pipelines: ['title', 'state', 'project', 'ref', 'sha', 'jobs', 'publish'],
};
const COL_LABEL: Readonly<Record<Scope, Partial<Record<Column, string>>>> = {
  work_items: {
    identity: 'Item',
    title: 'Title',
    state: 'State',
    project: 'Project',
    branch: 'Branch & commit',
    mr: 'Merge request',
    pipeline: 'Branch/MR pipeline',
    jobs: 'Jobs & attempts',
    publish: 'Publish',
    dev: 'Dev & branch-ref environments',
    ref: 'Tag & tag pipeline',
    preprod: 'Preprod & tag-ref environments',
    sha: 'Commits',
  },
  mrs: {
    identity: 'MR',
    title: 'Title · work items',
    state: 'State',
    project: 'Project',
    branch: 'Source → target',
    sha: 'Source commit',
    pipeline: 'Pipeline on source ref',
    updated_at: 'Updated',
  },
  branches: {
    identity: 'Branch',
    title: 'Work items',
    project: 'Project',
    sha: 'Head commit',
    state: 'Rebase',
    mr: 'MRs from this branch',
    pipeline: 'Pipelines on this ref',
  },
  pipelines: { identity: 'Pipeline', title: 'Work items', state: 'Status', project: 'Project', ref: 'Ref', sha: 'Commit', jobs: 'Jobs', publish: 'Publish' },
};
/* ------------------------------------------------ environment columns */
// Dashboard.environment_columns describes, per project, which column shows
// each configured environment: dev and preprod keep their keys, any other
// environment uses the bounded `environment:<name>` key.

export const ENV_PREFIX = 'environment:';
export const isEnvColumn = (c: Column): boolean => c === 'dev' || c === 'preprod' || c.startsWith(ENV_PREFIX);

/** Custom (non dev/preprod) environment columns reported for the current scope, in dashboard order. */
export function customEnvColumns(): { readonly column: Column; readonly label: string }[] {
  const out: { column: Column; label: string }[] = [];
  for (const e of S.dash?.environment_columns ?? []) {
    if (e.column === 'dev' || e.column === 'preprod') continue;
    if (!out.some((x) => x.column === e.column)) out.push({ column: e.column, label: e.label });
  }
  return out;
}

/** Fields offered for a scope; work items add the configured custom environments. */
export function colsFor(scope: Scope): readonly Column[] {
  if (scope !== 'work_items') return COLS[scope];
  const base = COLS.work_items;
  const extra = customEnvColumns().map((x) => x.column);
  const at = base.indexOf('sha');
  return [...base.slice(0, at), ...extra.filter((c) => !base.includes(c)), ...base.slice(at)];
}

export function colLabel(scope: Scope, c: Column): string {
  const fixed = COL_LABEL[scope][c];
  if (fixed) return fixed;
  if (c.startsWith(ENV_PREFIX)) {
    const d = customEnvColumns().find((x) => x.column === c);
    return `${d?.label ?? c.slice(ENV_PREFIX.length)} environment`;
  }
  return c;
}

/** Adds newly reported custom environment columns to lists the user has not customised. */
export function adoptEnvColumns(): void {
  const extra = customEnvColumns().map((x) => x.column);
  for (const key of ['work_items', 'compare'] as const) {
    const ui = S.ui[key];
    if (!ui.autoEnv) continue;
    const missing = extra.filter((c) => !ui.columns.includes(c));
    if (!missing.length) continue;
    const at = ui.columns.indexOf('sha');
    ui.columns = at < 0 ? [...ui.columns, ...missing] : [...ui.columns.slice(0, at), ...missing, ...ui.columns.slice(at)];
  }
}

export const SORTS: Readonly<Record<Scope, readonly Sort[]>> = {
  work_items: ['identity', 'title', 'state', 'project'],
  mrs: ['updated_at', 'identity', 'title', 'state', 'project'],
  branches: ['identity', 'project'],
  pipelines: ['identity', 'state', 'project'],
};
export const SORT_LABEL: Readonly<Record<Sort, string>> = { identity: 'Identity', title: 'Title', state: 'State', project: 'Project', updated_at: 'Updated' };
// Allowed saved-view states per scope (subset of the contract's ViewFilters.state).
export const STATES: Readonly<Record<Scope, readonly ViewState[]>> = {
  work_items: ['opened', 'closed', 'all'],
  mrs: ['all', 'open', 'merged', 'closed', 'unknown'],
  branches: ['all'],
  pipelines: ['all', 'success', 'failed', 'running', 'pending', 'manual', 'skipped', 'canceled', 'created', 'unknown'],
};
export const WORK_STATES: readonly WorkState[] = ['opened', 'closed', 'all'];
export const isWorkState = (s: string): s is WorkState => WORK_STATES.some((x) => x === s);

export const PREVIEW_ACTIONS: readonly PreviewAction[] = ['tag', 'rebase', 'retry', 'deploy-dev', 'deploy-preprod', 'ready', 'merge'];
export const PREVIEW_LABEL: Readonly<Record<PreviewAction, string>> = {
  tag: 'Tag',
  rebase: 'Rebase',
  retry: 'Retry pipeline',
  'deploy-dev': 'Deploy dev',
  'deploy-preprod': 'Deploy preprod',
  ready: 'Mark ready',
  merge: 'Merge',
};
export const CHECKLIST: readonly (readonly [ChecklistField, string])[] = [
  ['local_test', 'Tested locally'],
  ['dev_test', 'Tested on dev'],
  ['preprod_test', 'Tested on preprod'],
  ['work_confirmed', 'Work confirmed'],
];

export function defaultUi(scope: Scope): ListUi {
  return {
    filters: {
      state: scope === 'work_items' ? 'opened' : 'all',
      search: '',
      assigned: false,
      group: '',
      show_hidden: false,
      milestone: { mode: 'all', selected: null },
    },
    sort: SORTS[scope][0] ?? 'identity',
    descending: scope === 'mrs' || scope === 'pipelines',
    columns: [...DEFAULT_COLS[scope]],
    orientation: scope === 'work_items' ? 'columns' : 'rows',
    view: null,
    projectSet: null,
    autoEnv: scope === 'work_items',
  };
}

// A fresh browser opens the Overview; an explicitly stored choice (either
// stored value) is always honoured and never rewritten.
function storedMode(): DisplayMode {
  try {
    return window.localStorage.getItem('gspace.mode') === 'detailed' ? 'detailed' : 'visual';
  } catch {
    return 'visual'; // storage unavailable
  }
}

/* ============================================================== state */

export interface State {
  booting: boolean;
  // repository scope
  host: string | null;
  projects: readonly ProjectConfig[];
  coverage: string;
  projectsError: string | null;
  scope: { project: number | null };
  scopeError: string | null;
  gen: number;
  ctrl: AbortController | null;
  // scoped data (validated DTOs)
  dash: Dashboard | null;
  dashError: string | null;
  loading: boolean;
  mrs: MRCatalogResponse | null;
  mrsError: string | null;
  mrsLoading: boolean;
  items: Map<string, ItemView>;
  itemState: Map<string, ItemLoad>;
  previews: Map<string, PreviewState>;
  prevTag: Map<string, string>;
  observing: Set<string>;
  // global data
  prefs: Preferences | null;
  caps: CapabilitiesResponse | null;
  capsError: string | null;
  profiles: readonly ProfileSummary[] | null;
  profilesError: string | null;
  doctor: Map<string, Async<DoctorReport>>;
  act: { draft: ActionDraft | null; probe: Async<Permission>; plan: Async<ActionPlan>; exec: ExecState };
  // feedback
  sync: { busy: boolean; okAt: number | null };
  problems: Problem[];
  trayOpen: boolean;
  pending: number;
  openMenu: string | null;
  pop: { readonly key: string } | null;
  legendOpen: boolean;
  allJobs: boolean;
  // milestones (scoped) and operator settings (global, local file)
  ms: MilestoneCatalog | null;
  msError: string | null;
  msLoading: boolean;
  set: SettingsState;
  // manual version-bound application tests: per item:env draft/busy/error
  atDraft: Map<string, AppTestDraft>;
  atBusy: Set<string>;
  atErr: Map<string, string>;
  atHist: Set<string>;
  ui: Record<UiKey, ListUi>;
  filterSeq: number;
  filterSaved: number;
  route: Route;
  d: Derived | null;
  // visual overview / detailed view (browser-local appearance)
  mode: DisplayMode;
  // shared navigation catalog (bookmark/view decorations, pins, order)
  nav: NavigationCatalog | null;
  navError: string | null;
  // project presentation (safe avatar) per configured project
  presentations: Map<number, Async<ProjectPresentation>>;
  // native pipeline graph per work item ("project/issue")
  graphs: Map<string, Async<PipelineGraph>>;
  // --- progressive disclosure (browser memory only; never persisted) ---
  /** Attention filter per process screen: this browser only, separate from the shared filters. */
  attn: Record<'work_items' | 'compare', AttnKind | null>;
  /** Aligned evidence rows that are open: "<board>:<row>" or "<board>:*" for every row. */
  expanded: Set<string>;
  /** Section open state that differs from its default ("<screen>:<section>" → open). */
  sections: Map<string, boolean>;
  /** Pipeline-graph section open state per item ("project/issue"). */
  graphOpen: Map<string, boolean>;
  /** One-shot scroll target after navigation: "env:<p>/<i>:<env>" or "graph:<p>/<i>". */
  focusTarget: string | null;
  /** Announced repository-scope change (saved view or bookmark), shown on that screen. */
  scopeNotice: { readonly text: string; readonly screen: ScreenName } | null;
  // GET-only permission comparison across configured profiles
  cmp: { selected: string[]; draft: ActionDraft | null; result: Async<ProbeComparison> };
}

export const S: State = {
  booting: true,
  host: null,
  projects: [],
  coverage: 'configured_projects',
  projectsError: null,
  scope: { project: null },
  scopeError: null,
  gen: 0,
  ctrl: null,
  dash: null,
  dashError: null,
  loading: false,
  mrs: null,
  mrsError: null,
  mrsLoading: false,
  items: new Map(),
  itemState: new Map(),
  previews: new Map(),
  prevTag: new Map(),
  observing: new Set(),
  prefs: null,
  caps: null,
  capsError: null,
  profiles: null,
  profilesError: null,
  doctor: new Map(),
  act: { draft: null, probe: null, plan: null, exec: null },
  sync: { busy: false, okAt: null },
  problems: [],
  trayOpen: false,
  pending: 0,
  openMenu: null,
  pop: null,
  legendOpen: false,
  allJobs: false,
  ms: null,
  msError: null,
  msLoading: false,
  set: {
    resp: null,
    error: null,
    errorStatus: null,
    loading: false,
    draft: null,
    base: null,
    conflict: null,
    saving: false,
    saveError: null,
    saved: null,
    rebased: false,
    adv: null,
  },
  atDraft: new Map(),
  atBusy: new Set(),
  atErr: new Map(),
  atHist: new Set(),
  ui: {
    work_items: defaultUi('work_items'),
    compare: { ...defaultUi('work_items'), orientation: 'columns' },
    mrs: defaultUi('mrs'),
    branches: defaultUi('branches'),
    pipelines: defaultUi('pipelines'),
  },
  filterSeq: 0,
  filterSaved: 0,
  route: { screen: 'work', args: [], project: null },
  d: null,
  mode: storedMode(),
  nav: null,
  navError: null,
  presentations: new Map(),
  graphs: new Map(),
  attn: { work_items: null, compare: null },
  expanded: new Set(),
  sections: new Map(),
  graphOpen: new Map(),
  focusTarget: null,
  scopeNotice: null,
  cmp: { selected: [], draft: null, result: null },
};

/** Open state of a collapsible section: the user's toggle, otherwise its default. */
export const sectionOpen = (key: string, dflt: boolean): boolean => S.sections.get(key) ?? dflt;
export function toggleSection(key: string, dflt: boolean): void {
  const next = !sectionOpen(key, dflt);
  if (next === dflt) S.sections.delete(key);
  else S.sections.set(key, next);
  render();
}

export function setMode(mode: DisplayMode): void {
  S.mode = mode;
  try {
    window.localStorage.setItem('gspace.mode', mode);
  } catch {
    // storage unavailable: the choice lasts for this page only
  }
  render();
}

/* ============================================================== keys */

export const wkStr = (k: WorkKey): string => `${k.project.value}/${k.issue.value}`;
export const itemHref = (k: WorkKey): string => `#/item/${k.project.value}/${k.issue.value}`;
export const mrHref = (p: number, iid: number): string => `#/mrs/${p}/${iid}`;
export const branchHref = (p: number, name: string): string => `#/branches/${p}/${encodeURIComponent(name)}`;
export const pipeHref = (p: number, id: number): string => `#/pipelines/${p}/${id}`;
export const jobHref = (p: number, id: number, jid: number): string => `#/pipelines/${p}/${id}/job/${jid}`;
export const sameKey = (a: WorkKey, b: WorkKey): boolean => a.project.value === b.project.value && a.issue.value === b.issue.value;

// Every in-app link carries the repository scope so reloads and shared
// addresses keep the same host/project selection.
export function to(path: string, project: number | null = S.scope.project): string {
  return project == null ? path : `${path}?project=${project}`;
}

export function refKey(r: ResourceReference): string {
  switch (r.kind) {
    case 'work_item':
      return `w:${wkStr(r.key)}`;
    case 'mr':
      return `m:${r.project.value}/${r.iid.value}`;
    case 'branch':
      return `b:${r.project.value}/${r.name}`;
    case 'pipeline':
      return `p:${r.project.value}/${r.id.value}`;
  }
}
export const refProject = (r: ResourceReference): number => (r.kind === 'work_item' ? r.key.project.value : r.project.value);

// Milestone keys: group and project IIDs can collide, so identity is always
// the typed key (kind + owner + milestone ID), never the IID or title.
export function msKeyStr(k: MilestoneKey | null | undefined): string {
  if (!k) return '';
  return k.kind === 'group' ? `g:${k.group.value}:${k.id.value}` : `p:${k.project.value}:${k.id.value}`;
}
export function msKeyFromStr(s: string): MilestoneKey | null {
  const m = /^([gp]):(\d+):(\d+)$/.exec(s);
  if (!m?.[1] || !m[2] || !m[3]) return null;
  const owner = Number(m[2]);
  const id = Number(m[3]);
  if (!(owner > 0 && id > 0)) return null;
  return m[1] === 'g' ? { kind: 'group', group: { value: owner }, id: { value: id } } : { kind: 'project', project: { value: owner }, id: { value: id } };
}
export function normMs(m: MilestoneFilter | MsFilter | null | undefined): MsFilter {
  if (!m) return { mode: 'all', selected: null };
  if (m.mode === 'selected') return m.selected ? { mode: 'selected', selected: m.selected } : { mode: 'all', selected: null };
  return { mode: m.mode, selected: null };
}

/* ===================================================== feedback model */
// One coherent treatment: refresh success updates the inline sync status
// (no toast); problems are deduplicated per operation, capped, compact,
// dismissible and cleared when the same operation later succeeds.

let problemSeq = 0;
const lastSaid: Record<'live' | 'alert', string> = { live: '', alert: '' };

export function say(msg: string, region: 'live' | 'alert' = 'live'): void {
  if (!msg || lastSaid[region] === msg) return;
  lastSaid[region] = msg;
  const el = document.getElementById(region === 'alert' ? 'alert-live' : 'live');
  if (el) el.textContent = msg;
}
export const forgetAlert = (): void => {
  lastSaid.alert = '';
};

export function report(op: string, title: string, detail: string, opts: { tone?: ProblemTone; retry?: (() => void) | null; retryLabel?: string } = {}): void {
  const key = `${title}\n${detail}`;
  const now = Date.now();
  const p = S.problems.find((x) => x.op === op);
  if (p && p.key === key) {
    p.count++;
    p.last = now;
    p.retry = opts.retry ?? null;
  } else {
    S.problems = S.problems.filter((x) => x.op !== op);
    S.problems.push({
      id: ++problemSeq,
      op,
      key,
      title,
      detail,
      tone: opts.tone ?? 'fail',
      count: 1,
      first: now,
      last: now,
      retry: opts.retry ?? null,
      retryLabel: opts.retryLabel ?? 'Retry',
    });
    while (S.problems.length > 6) S.problems.shift();
    say(`${title}. ${detail}`, 'alert');
  }
  render();
}

export function resolve(...ops: string[]): void {
  const before = S.problems.length;
  S.problems = S.problems.filter((x) => !ops.includes(x.op));
  if (S.problems.length !== before) {
    lastSaid.alert = ''; // a recurrence after recovery is news again
    if (!S.problems.length) S.trayOpen = false;
    render();
  }
}

export function dismissProblem(id: number): void {
  S.problems = S.problems.filter((x) => x.id !== id);
  lastSaid.alert = '';
  if (!S.problems.length) S.trayOpen = false;
  render();
  document.getElementById('main')?.focus({ preventScroll: true });
}

/* ============================================== repository-scoped calls */

// Repository-scoped request: aborted on a repository switch and rejected as
// stale if the generation changed while it was in flight.
export async function scoped<T>(run: (signal: AbortSignal | null) => Promise<T>): Promise<T> {
  const gen = S.gen;
  let value: T;
  try {
    value = await run(S.ctrl?.signal ?? null);
  } catch (e) {
    if (gen !== S.gen) throw new StaleError();
    throw e;
  }
  if (gen !== S.gen) throw new StaleError();
  return value;
}

/* ======================================================= preferences */

export const blankChecklist = (key: WorkKey): Checklist => ({ key, local_test: false, dev_test: false, preprod_test: false, work_confirmed: false });

function filtersFromPrefs(f: Filters): UiFilters {
  return { state: f.state, assigned: f.assigned, search: f.search, group: f.group, show_hidden: f.show_hidden, milestone: normMs(f.milestone) };
}

// Overlays the shared flags onto the item views. DTOs are never mutated:
// each view is replaced by an updated copy.
export function applyPrefs(): void {
  const P = S.prefs;
  if (!P) return;
  const keys = (arr: readonly WorkKey[]): Set<string> => new Set(arr.map(wkStr));
  const pin = keys(P.pinned);
  const hid = keys(P.hidden);
  const sel = keys(P.selected);
  const groups = new Map<string, string[]>();
  for (const g of P.groups) {
    for (const m of g.members) {
      const k = wkStr(m);
      const list = groups.get(k) ?? [];
      list.push(g.name);
      groups.set(k, list);
    }
  }
  const checks = new Map(P.checklists.map((c) => [wkStr(c.key), c] as const));
  const upd = (v: ItemView): ItemView => {
    const k = wkStr(v.item.identity);
    return {
      ...v,
      pinned: pin.has(k),
      hidden: hid.has(k),
      selected: sel.has(k),
      groups: groups.get(k) ?? [],
      checklist: checks.get(k) ?? blankChecklist(v.item.identity),
    };
  };
  if (S.dash) S.dash = { ...S.dash, views: S.dash.views.map(upd) };
  for (const [k, v] of S.items) S.items.set(k, upd(v));
  if (S.filterSaved === S.filterSeq) S.ui.work_items.filters = { ...S.ui.work_items.filters, ...filtersFromPrefs(P.filters) };
}

let afterPrefs: () => void = () => {};
/** Registers the derivation step that must follow every preference change. */
export function onPrefsChanged(fn: () => void): void {
  afterPrefs = fn;
}

export async function reloadPrefs(): Promise<void> {
  S.prefs = await http.preferences();
  S.filterSaved = S.filterSeq;
  applyPrefs();
}

type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never;
/** A preference command before the queue adds the latest revision. */
export type PrefCmd = DistributiveOmit<PreferenceCommand, 'revision'>;

// One command at a time, each carrying the latest known revision. A 409
// cancels everything still queued and reloads; nothing is retried.
let prefChain: Promise<boolean> = Promise.resolve(true);
let prefEpoch = 0;

function withRevision(cmd: PrefCmd, revision: number): PreferenceCommand {
  return { ...cmd, revision };
}

export function pref(cmd: PrefCmd, label: string): Promise<boolean> {
  const epoch = prefEpoch;
  S.pending++;
  render();
  const run = prefChain
    .then(async (): Promise<boolean> => {
      if (epoch !== prefEpoch) return false;
      if (!S.prefs) {
        report('prefs', `Not saved: ${label}`, 'Preferences are not loaded, so there is no revision to write against. Reload the page.');
        return false;
      }
      try {
        S.prefs = await http.changePreferences(withRevision(cmd, S.prefs.revision));
        applyPrefs();
        afterPrefs();
        resolve('prefs');
        return true;
      } catch (e) {
        if (e instanceof Error && 'status' in e && e.status === 409) {
          prefEpoch++;
          const before = S.prefs.revision;
          try {
            await reloadPrefs();
            afterPrefs();
          } catch (re) {
            report('prefs-reload', 'Preferences could not be reloaded after a conflict', errorMessage(re));
          }
          report(
            'prefs-conflict',
            `Not saved: ${label}`,
            `Preferences changed elsewhere (revision ${before} → ${S.prefs?.revision ?? 'unknown'}). Current values were reloaded and queued changes were dropped. Repeat the change if it is still needed.`,
            { tone: 'warn' },
          );
        } else {
          report('prefs', `Not saved: ${label}`, errorMessage(e));
        }
        return false;
      }
    })
    .finally(() => {
      S.pending--;
      render();
    });
  prefChain = run.catch(() => false);
  return run;
}
