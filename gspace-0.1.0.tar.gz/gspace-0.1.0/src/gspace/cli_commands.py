"""Discoverable command taxonomy over the existing typed compatibility commands."""

from __future__ import annotations

from collections.abc import Sequence

from rich.console import Console

from gspace.cli_render import compact_table, heading, literal
from gspace.models import Model


class Command(Model, frozen=True):
    verb: str
    target: str
    description: str
    arguments: str = ""


class Group(Model, frozen=True):
    name: str
    description: str
    commands: tuple[Command, ...]


def command(verb: str, target: str, description: str, arguments: str = "") -> Command:
    return Command(verb=verb, target=target, description=description, arguments=arguments)


DAILY = (
    command("dashboard", "dashboard", "Active assigned work items; shared filters"),
    command("list", "list", "Compact scan with observed attention; same shared filters"),
    command("show", "show", "Full work-item evidence and direct links", "PROJECT:IID"),
    command("compare", "compare", "Selected work items side by side"),
)

GROUPS = (
    Group(
        name="pipelines",
        description="General catalog or work-item jobs / Nexus",
        commands=(
            command(
                "list", "pipeline-catalog", "General configured-project catalog; jobs not loaded"
            ),
            command(
                "show",
                "pipelines",
                "Work-item pipelines, jobs, attempts and publications",
                "PROJECT:IID",
            ),
            command(
                "graph",
                "pipeline-graph",
                "Native project relationships and bounded coverage",
                "PROJECT:IID",
            ),
        ),
    ),
    Group(
        name="branches",
        description="General branch catalog / rebase evidence",
        commands=(
            command("list", "branches", "List scoped branches; --project and --search available"),
        ),
    ),
    Group(
        name="mrs",
        description="Authored merge requests",
        commands=(command("list", "mrs", "Authored MRs; --project and --state available"),),
    ),
    Group(
        name="milestones",
        description="Scoped dates and work-item counts",
        commands=(
            command("list", "milestones", "Milestone catalog with honest coverage and dates"),
        ),
    ),
    Group(
        name="environments",
        description="Runtime, deploy and test evidence",
        commands=(
            command(
                "show",
                "environments",
                "Expected / observed versions and deployment records",
                "PROJECT:IID",
            ),
            command(
                "observe",
                "observe",
                "Read only the operator-configured endpoint",
                "PROJECT:IID NAME",
            ),
        ),
    ),
    Group(
        name="views",
        description="Shared saved views",
        commands=(
            command("list", "views", "List saved views"),
            command("save", "view-save", "Save a local view from JSON", "FILE"),
            command("delete", "view-delete", "Delete a local saved view", "NAME"),
        ),
    ),
    Group(
        name="navigation",
        description="Scoped shared shortcuts and appearance",
        commands=(
            command("list", "navigation", "List scoped shortcuts and decoration choices"),
            command("set", "navigation-set", "Set a shared local decoration from JSON", "FILE"),
            command("delete", "navigation-delete", "Remove a shared local decoration", "FILE"),
        ),
    ),
    Group(
        name="bookmarks",
        description="Shared scoped bookmarks",
        commands=(
            command("list", "bookmarks", "List bookmarks"),
            command("add", "bookmark-set", "Add a local bookmark from JSON", "FILE"),
            command("remove", "bookmark-delete", "Remove a local scoped bookmark", "FILE"),
        ),
    ),
    Group(
        name="settings",
        description="Local operator configuration",
        commands=(
            command("show", "settings", "Show operator settings and effective rules"),
            command(
                "set", "settings-set", "Update local settings with a revisioned JSON file", "FILE"
            ),
        ),
    ),
    Group(
        name="tests",
        description="Version-bound manual application results",
        commands=(
            command(
                "history", "app-history", "Outcome / version relationship history", "PROJECT:IID"
            ),
            command("record", "app-test", "Record a local exact-version manual result", "FILE"),
            command(
                "checklist",
                "checklist",
                "Manual confirmation; never changes MR draft",
                "PROJECT:IID FIELD",
            ),
        ),
    ),
    Group(
        name="preferences",
        description="Shared local selection and organization",
        commands=(
            command("show", "preferences", "Show shared preferences"),
            command("navigation", "navigation", "Scoped shortcuts and shared decorations"),
            command("select", "select", "Set comparison selection; --off clears it", "PROJECT:IID"),
            command("pin", "pin", "Pin locally; --off clears it", "PROJECT:IID"),
            command("hide", "hide", "Hide locally; --off clears it", "PROJECT:IID"),
            command(
                "group", "group", "Set local group membership; --off removes it", "PROJECT:IID NAME"
            ),
            command("filters", "filters", "Update shared local filters"),
            command(
                "override",
                "override",
                "Record a local association override with --reason",
                "PROJECT:IID KIND VALUE",
            ),
        ),
    ),
    Group(
        name="access",
        description="Configured-profile diagnostics / GET-only probes",
        commands=(
            command("profiles", "profiles", "List redacted configured access profiles"),
            command("doctor", "doctor", "Read-only diagnostics for a configured profile", "NAME"),
            command("probe", "probe", "GET-only precondition probe from JSON", "FILE"),
            command(
                "compare", "probe-compare", "Same action across explicit profiles, GET-only", "FILE"
            ),
        ),
    ),
    Group(
        name="actions",
        description="Explicit previews; isolated lab actions only",
        commands=(
            command(
                "preview", "preview", "Suggestion only; no remote execution", "PROJECT:IID ACTION"
            ),
            command(
                "plan",
                "action",
                "Preview action JSON; finite lab writes need --execute / --confirm",
                "FILE",
            ),
        ),
    ),
)
LEGACY = (
    {c.target for group in GROUPS for c in group.commands}
    | {c.target for c in DAILY}
    | {"projects", "refresh", "serve"}
)


def prepare(argv: Sequence[str]) -> tuple[list[str], str | None, str | None]:
    """Normalize only explicit verbs; legacy flags/positionals keep their parsing contract."""
    arguments = list(argv)
    if not arguments or arguments[0] in ("-h", "--help"):
        return arguments, "", None
    first = arguments[0]
    if first == "web":
        return ["serve", *arguments[1:]], None, "gspace web"
    if first == "help":
        if len(arguments) > 2:
            raise ValueError("Use gspace help [GROUP|compatibility]")
        topic = arguments[1] if len(arguments) == 2 else ""
        if topic and topic != "compatibility" and topic not in {g.name for g in GROUPS}:
            raise ValueError(f"Unknown help topic {topic!r}; use gspace --help")
        return arguments, topic, None
    group = next((g for g in GROUPS if g.name == first), None)
    if group:
        if len(arguments) > 1 and arguments[1] in ("-h", "--help"):
            return arguments, first, None
        if len(arguments) == 1 and (first not in LEGACY or first in ("pipelines", "environments")):
            return arguments, first, None
        if len(arguments) > 1:
            leaf = next((c for c in group.commands if c.verb == arguments[1]), None)
            if leaf:
                return [leaf.target, *arguments[2:]], None, f"gspace {first} {leaf.verb}"
            if not arguments[1].startswith("-") and first not in ("pipelines", "environments"):
                raise ValueError(
                    f"Unknown {first} command {arguments[1]!r}; use gspace {first} --help"
                )
    if first not in LEGACY:
        raise ValueError(f"Unknown command {first!r}; use gspace --help")
    return arguments, None, None


def help_page(topic: str, console: Console) -> None:
    def listing(title: str, rows: Sequence[tuple[str, str]]) -> None:
        heading(console, title)
        table = compact_table()
        table.show_header = False
        table.add_column(style="gs.id", max_width=min(40, console.width // 2))
        table.add_column(overflow="fold")
        for name, description in rows:
            table.add_row(literal(name, "gs.id"), literal(description))
        console.print(table)

    if topic == "compatibility":
        heading(console, "Compatibility aliases · unchanged argument / JSON forms")
        listing(
            "Legacy → preferred",
            [(c.target, f"{g.name} {c.verb}") for g in GROUPS for c in g.commands],
        )
        return
    group = next((g for g in GROUPS if g.name == topic), None)
    if group:
        heading(console, f"gspace {group.name} COMMAND [OPTIONS]", group.description)
        listing(
            "Commands", [(f"{c.verb} {c.arguments}".strip(), c.description) for c in group.commands]
        )
        console.print(
            literal(f"Details: gspace {group.name} {group.commands[0].verb} --help", "gs.meta")
        )
    else:
        heading(console, "GSpace · GitLab work-item cockpit", "Usage: gspace COMMAND [OPTIONS]")
        listing("Daily", [(f"{c.verb} {c.arguments}".strip(), c.description) for c in DAILY])
        listing("Resources", [(g.name, g.description) for g in GROUPS[:5]])
        listing("Local organization", [(g.name, g.description) for g in GROUPS[5:10]])
        listing(
            "Operator / advanced",
            [(g.name, g.description) for g in GROUPS[10:]]
            + [
                ("projects", "Configured project scope"),
                ("refresh", "Refresh remote read-only evidence"),
                ("serve", "Start the loopback web UI"),
            ],
        )
        listing(
            "Examples",
            [
                ("dashboard --orientation columns", "Compare the process from top to bottom"),
                ("show 42:791", "Inspect full evidence for one work item"),
                ("pipelines list --project 42", "General pipeline catalog"),
                ("pipelines show 42:791", "Work-item pipeline and job evidence"),
            ],
        )
    console.print(
        literal("Options: --config/-c FILE · --json/-j · --no-color/-N · --width/-w N", "gs.meta")
    )
    console.print(
        literal("Global: --help/-h · --version/-V · aliases are case-sensitive", "gs.meta")
    )
    console.print(literal("Help: gspace GROUP --help · gspace help compatibility", "gs.meta"))
    console.print(
        literal("No arguments shows this help; no config or services are loaded.", "gs.meta")
    )
