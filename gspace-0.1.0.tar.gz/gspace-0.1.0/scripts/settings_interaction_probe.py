"""Reproduce actual first-click settings behavior using owned synthetic loopback data."""

from __future__ import annotations

import json
from pathlib import Path

from playwright.sync_api import sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]


def main():
    report = {}
    with fixture_server() as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        page = browser.new_page(viewport={"width": 1600, "height": 1100})
        page.goto(base + "/#/settings")
        page.wait_for_selector('[data-fk="g-environments-en-1"]')
        page.locator('[data-fk="g-important_job_patterns-ip-0"]').fill("unit-tests*")
        add = page.locator('[data-fk="g-environments-e-add"]')
        add.click()
        report["third_environment_after_first_click"] = page.locator(
            '[data-fk="g-environments-en-2"]'
        ).count()
        add.click()
        report["third_environment_after_second_click"] = page.locator(
            '[data-fk="g-environments-en-2"]'
        ).count()
        page.reload()
        page.wait_for_selector('[data-fk="set-branch"]')
        submissions = []
        page.on(
            "request",
            lambda request: (
                submissions.append(request.method)
                if request.url == base + "/api/settings" and request.method == "POST"
                else None
            ),
        )
        page.locator('[data-fk="set-branch"]').fill("task-{iid}")
        save = page.locator('[data-fk="set-save"]')
        report["save_enabled_after_valid_typing"] = save.is_enabled()
        page.locator('[data-fk="set-branch"]').press("Tab")
        report["save_enabled_after_blur"] = save.is_enabled()
        save.click()
        page.wait_for_timeout(300)
        report["settings_post_after_first_click"] = len(submissions)
        report["source"] = "actual synthetic loopback browser, no remote effects"
        browser.close()
    output = ROOT / "output/verification/settings-first-click.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
