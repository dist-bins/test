"""Verify known, absent and differing MR source evidence with typed fixture browser variants."""

from __future__ import annotations

import argparse
import copy
import json
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen

from playwright.sync_api import expect, sync_playwright

from gspace.actions import ProfileSummary
from gspace.api_contracts import CapabilitiesResponse, MRCatalogResponse
from gspace.models import ProjectId
from gspace.service import Dashboard


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=Path("frontend-new"))
    parser.add_argument(
        "--output", type=Path, default=Path("output/verification/mr-source-browser")
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    checks: list[str] = []
    outside: list[str] = []
    errors: list[str] = []
    with tempfile.TemporaryDirectory(prefix="gspace-source-browser-") as temporary:
        config = Path(temporary) / "fixture.toml"
        config.write_text(
            'mode = "fixture"\npreferences_path = "prefs.toml"\ncache_path = "cache.json"\n'
        )
        with socket.socket() as allocator:
            allocator.bind(("127.0.0.1", 0))
            port = allocator.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        source = (
            "import sys; from pathlib import Path; import uvicorn; import gspace.api as api; "
            "from gspace.config import load_config; api.STATIC=Path(sys.argv[1]); "
            "uvicorn.run(api.create_app(load_config(Path(sys.argv[2]))), "
            "host='127.0.0.1',port=int(sys.argv[3]),access_log=False)"
        )
        server = subprocess.Popen(
            [sys.executable, "-c", source, str(args.assets.resolve()), str(config), str(port)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            for _ in range(100):
                try:
                    with urlopen(base + "/api/dashboard?all=true", timeout=0.2) as response:
                        dashboard = json.load(response)
                    break
                except OSError:
                    if server.poll() is not None:
                        raise RuntimeError("Fixture server exited") from None
                    time.sleep(0.1)
            else:
                raise RuntimeError("Fixture server unavailable")
            with urlopen(base + "/api/merge-requests", timeout=3) as response:
                catalog = json.load(response)
            variants = {}
            for variant in ("known", "non_authored", "unknown", "different", "catalog_stale"):
                dash = copy.deepcopy(dashboard)
                cat = copy.deepcopy(catalog)
                if variant == "non_authored":
                    cat["rows"] = [
                        r
                        for r in cat["rows"]
                        if not (
                            r["mr"]["project"]["value"] == 42 and r["mr"]["iid"]["value"] == 154
                        )
                    ]
                    cat["total"] = len(cat["rows"])
                elif variant in ("unknown", "different", "catalog_stale"):
                    sha = None if variant == "unknown" else "f" * 40
                    for view in dash["views"]:
                        for mr in view["item"]["merge_requests"]:
                            if mr["project"]["value"] == 42 and mr["iid"]["value"] == 154:
                                mr["source_sha"] = sha
                    for row in cat["rows"] if variant != "catalog_stale" else ():
                        if row["mr"]["project"]["value"] == 42 and row["mr"]["iid"]["value"] == 154:
                            row["source_sha"] = row["mr"]["source_sha"] = sha
                variants[variant] = (
                    Dashboard.model_validate(dash).model_dump(mode="json"),
                    MRCatalogResponse.model_validate(cat).model_dump(mode="json"),
                )
            state = {"variant": "known"}
            action_caps = CapabilitiesResponse(
                remote_read_only=False,
                remote_mutations=True,
                previews=(),
                write_scope="isolated_synthetic_lab",
                actions=("edit_draft_mr",),
            )
            profile = ProfileSummary(
                name="synthetic",
                kind="pat",
                host="http://127.0.0.1:8929",
                projects=(ProjectId(value=42),),
                write_enabled=True,
            )
            with sync_playwright() as engine:
                browser = engine.chromium.launch(
                    executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                    headless=True,
                )
                context = browser.new_context(viewport={"width": 1600, "height": 1100})

                def guard(route):
                    parsed = urlsplit(route.request.url)
                    if parsed.hostname != "127.0.0.1" or parsed.port != port:
                        outside.append(route.request.url)
                        route.abort()
                    elif parsed.path == "/api/dashboard":
                        route.fulfill(json=variants[state["variant"]][0])
                    elif parsed.path == "/api/merge-requests":
                        route.fulfill(json=variants[state["variant"]][1])
                    elif state["variant"] == "unknown" and parsed.path == "/api/capabilities":
                        route.fulfill(json=action_caps.model_dump(mode="json"))
                    elif state["variant"] == "unknown" and parsed.path == "/api/access/profiles":
                        route.fulfill(json=[profile.model_dump(mode="json")])
                    elif parsed.path.startswith(("/api/actions/", "/api/access/doctor/")):
                        route.fulfill(
                            status=403, json={"detail": "Source browser gate blocks remote effects"}
                        )
                    else:
                        route.continue_()

                context.route("**/*", guard)
                page = context.new_page()
                page.on("pageerror", lambda error: errors.append(str(error)))
                for variant in variants:
                    state["variant"] = variant
                    page.goto(base + "/#/work")
                    page.reload()
                    expect(page.locator(".mx.proc thead th.colh")).to_have_count(4)
                    cell = (
                        page.locator(".mx.proc tbody tr")
                        .filter(has=page.locator("th.rh", has_text="Merge request"))
                        .locator("td")
                        .first
                    )
                    expect(page.locator("#topbar")).to_contain_text("Demo")
                    expect(page.locator("#topbar")).to_contain_text("synthetic")
                    expect(page.locator(".legend-d")).not_to_have_attribute("open", "")
                    expect(page.locator(".legend")).not_to_be_visible()
                    if variant in ("known", "non_authored"):
                        expect(cell).not_to_contain_text("Source commit unknown")
                        expect(cell).not_to_contain_text("Catalog has no source SHA")
                        expect(cell).to_contain_text(
                            dashboard["views"][0]["item"]["merge_requests"][0]["source_sha"][:8]
                        )
                        checks.append(
                            variant
                            + ": reported MR source retained independently of authored catalog"
                        )
                        trigger = cell.locator("button[data-ev]").first
                        if trigger.count():
                            expect(trigger).to_have_attribute("aria-expanded", "false")
                            trigger.focus()
                            page.keyboard.press("Enter")
                            evidence = page.locator("#ev-pop")
                            expect(evidence).to_be_visible()
                            expect(evidence).to_contain_text("Source commit")
                            expect(evidence).to_contain_text("Reason:")
                            page.keyboard.press("Escape")
                            expect(trigger).to_be_focused()
                        else:
                            details = cell.locator("details.ev").first
                            expect(details).not_to_have_attribute("open", "")
                            details.locator("summary").focus()
                            page.keyboard.press("Enter")
                            expect(details.locator(".ev-body")).to_be_visible()
                            expect(details.locator(".ev-body")).to_contain_text("Source commit")
                            expect(details.locator(".ev-body")).to_contain_text("Reason:")
                            page.keyboard.press("Enter")
                        checks.append(
                            variant + ": keyboard disclosure retains provenance and raw SHA"
                        )
                    elif variant == "unknown":
                        expect(cell).to_contain_text("Source commit unknown")
                        assert cell.inner_text().count("Source commit unknown") == 1
                        expect(cell).not_to_contain_text("commit not established")
                        checks.append("unknown: one concise state, no fabricated branch SHA")
                        cell.get_by_role("link", name="!154", exact=True).click()
                        expect(page.locator(".inspector")).to_contain_text("Source commit unknown")
                        expect(page.locator(".inspector")).to_contain_text("null or missing")
                        expect(
                            page.locator(".inspector").get_by_role(
                                "button", name="Edit draft…", exact=True
                            )
                        ).to_be_disabled()
                        expect(page.locator(".inspector")).to_contain_text("no expected SHA")
                        checks.append("unknown: detail retains the missing-source explanation")
                        checks.append(
                            "unknown: edit action disabled with its actual SHA precondition"
                        )
                    else:
                        expect(cell).to_contain_text("ffffffff")
                        expect(cell).to_contain_text("differs from branch head")
                        checks.append("different: MR/branch mismatch remains visible")
                        if variant == "catalog_stale":
                            expect(cell).to_contain_text("catalog source differs")
                            checks.append(
                                "catalog_stale: independently stale catalog evidence is visible"
                            )
                    page.screenshot(path=str(args.output / (variant + ".png")), full_page=True)
                page.set_viewport_size({"width": 390, "height": 844})
                page.reload()
                expect(page.locator("#topbar")).to_contain_text("Demo")
                expect(page.locator("#topbar .src-badge .src-text")).to_be_visible()
                expect(page.locator("#topbar .src-badge .src-text")).to_have_text(
                    "Demo · synthetic data"
                )
                page.screenshot(path=str(args.output / "mobile-source.png"), full_page=True)
                checks.append("synthetic source remains visible on mobile")
                assert not outside and not errors
                checks.append("no outbound requests or JavaScript errors")
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)
    report = {
        "result": "passed",
        "checks": checks,
        "external_requests": outside,
        "javascript_errors": errors,
        "source_variants": "typed synthetic responses, not actual GitLab integration",
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
