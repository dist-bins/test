"""Repeat critical actual operator journeys in both themes/desktop/mobile.

All configuration, records and profile evidence use owned temporary fixtures.
No corporate service, credential environment or action-effect transport is used.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import traceback
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from recovery_fixture import INERT_MARKER, ROOT, recovery_fixture


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    if not output.is_relative_to(ROOT / "output/verification"):
        parser.error("Output must be owned verification evidence")
    output.mkdir(parents=True, exist_ok=True)
    checks = []
    errors = []
    outside = []
    requests = []
    with recovery_fixture() as fixture, sync_playwright() as engine:
        base = fixture.base
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        for theme, width, timezone in (
            ("light", 1600, "Pacific/Kiritimati"),
            ("dark", 1600, "America/Adak"),
            ("light", 390, "Europe/Zurich"),
            ("dark", 390, "UTC"),
        ):
            context = browser.new_context(
                viewport={"width": width, "height": 844 if width == 390 else 1100},
                service_workers="block",
            )

            def guard(route):
                request = route.request
                parsed = urlsplit(request.url)
                if request.url.startswith(base + "/"):
                    requests.append({"method": request.method, "path": parsed.path})
                    route.continue_()
                else:
                    outside.append(request.url)
                    route.abort()

            context.route("**/*", guard)
            page = context.new_page()
            page.set_default_timeout(5000)
            page.on("pageerror", lambda error: errors.append(str(error)))

            def route(path, page=page):
                page.goto(base + "/#/" + path)
                page.wait_for_selector("main")
                page.wait_for_timeout(300)

            def check(name, operation, theme=theme, width=width):
                try:
                    operation()
                    checks.append({"check": name, "theme": theme, "width": width, "passed": True})
                except Exception as error:
                    checks.append(
                        {
                            "check": name,
                            "theme": theme,
                            "width": width,
                            "passed": False,
                            "error": str(error)[:1300],
                            "trace": traceback.format_exc()[-1700:],
                        }
                    )

            route("work")
            page.locator('[data-fk="theme"]').click()
            page.locator(f'[data-fk="ap-th-{theme}"]').click()
            page.keyboard.press("Escape")
            expect(page.locator("html")).to_have_attribute("data-theme", theme)

            def manual_test(page=page, theme=theme, width=width, route=route):
                route("item/42/791")
                group = page.get_by_role(
                    "group", name="Record the Dev application test outcome", include_hidden=True
                )
                if not group.is_visible():
                    group.locator("xpath=ancestor::details[1]/summary").click()
                expect(group).to_be_visible()
                page.locator('[data-fk="at-notes-42/791:dev"]').fill(
                    f"Actual {theme}/{width} journey"
                )
                with page.expect_response(
                    lambda r: r.url == base + "/api/preferences" and r.request.method == "POST"
                ) as saved:
                    group.get_by_role("button", name="Passed", exact=True).click()
                assert saved.value.status == 200
                page.wait_for_timeout(250)
                data = page.request.get(base + "/api/items/42/791").json()
                test = data["application_tests"][0]
                assert test["outcome"] == "passed" and test["current"]["version"] == test["target"]
                assert (
                    not data["checklist"]["dev_test"] and data["item"]["merge_requests"][0]["draft"]
                )
                page.reload()
                page.wait_for_timeout(300)
                history = page.locator('[data-fk="at-hist-42/791:dev"]')
                history.click()
                expect(page.locator(".at-hist[open]")).to_contain_text(
                    f"Actual {theme}/{width} journey"
                )
                page.screenshot(path=str(output / f"manual-test-{theme}-{width}.png"))

            check("Exact-version Overview test and history", manual_test)

            def settings(page=page, width=width, timezone=timezone, theme=theme):
                # Use discoverable navigation, including the real mobile Menu.
                if width == 390:
                    page.locator('[data-fk="appmenu"]').click()
                    page.locator('[data-fk="menu-settings"]').click()
                else:
                    page.locator("nav").get_by_role("link", name="Settings", exact=True).click()
                page.wait_for_timeout(300)
                page.locator('[data-fk="set-tz"]').fill(timezone)
                start = len(requests)
                with page.expect_response(
                    lambda r: r.url == base + "/api/settings" and r.request.method == "POST"
                ) as saved:
                    page.locator('[data-fk="set-save"]').click()
                assert saved.value.status == 200
                expect(page.locator("main")).to_contain_text("In use locally")
                page.wait_for_timeout(350)
                assert fixture.service.config.timezone == timezone
                assert timezone in fixture.config_path.read_text()
                assert {"method": "GET", "path": "/api/dashboard"} in requests[start:]
                assert {"method": "POST", "path": "/api/refresh"} not in requests[start:]
                # Work's date-current filter consumes the milestone catalog. It
                # must use the newly applied date/timezone without a remote refresh.
                page.locator(".brand").click()
                page.wait_for_timeout(300)
                if width == 390:
                    page.locator('[data-fk="w-more"]').click()
                page.locator('[data-ev="ev-ms-filter"]').click()
                expect(page.locator("#ev-pop")).to_contain_text(timezone)
                page.keyboard.press("Escape")
                page.screenshot(path=str(output / f"settings-runtime-{theme}-{width}.png"))

            check("Settings save and date-current catalog use the applied timezone", settings)

            def compare(page=page, theme=theme, width=width, route=route):
                route("access")
                for profile in ("owner", "readonly", "limited", "unavailable"):
                    page.locator(f'[data-fk="cmp-p-{profile}"]').check()
                page.locator('[data-fk="cmp-kind"]').select_option("run_pipeline")
                page.locator('[data-fk="cmp-project"]').select_option("42")
                page.locator('[data-fk="cmp-branch"]').fill("issue-791")
                page.locator('[data-fk="cmp-expected_sha"]').fill(
                    fixture.service.snapshot().items[0].branches[0].sha
                )
                with page.expect_response(base + "/api/access/compare") as compared:
                    page.locator('[data-fk="cmp-run"]').click()
                assert compared.value.status == 200
                result = page.get_by_role("region", name="Permission comparison", exact=True)
                expect(result).to_contain_text("Allowed")
                expect(result).to_contain_text("Denied")
                expect(result).to_contain_text("Unknown")
                expect(result).to_contain_text("missing_secret")
                expect(page.locator("body")).not_to_contain_text(INERT_MARKER)
                assert page.evaluate("document.documentElement.scrollWidth") <= width + 1
                page.screenshot(path=str(output / f"profiles-{theme}-{width}.png"))
                result.scroll_into_view_if_needed()
                page.screenshot(path=str(output / f"profiles-results-{theme}-{width}.png"))

            check("Four-profile fresh GET comparison with isolated error", compare)
            context.close()
        calls = list(fixture.calls)
        browser.close()
    report = {
        "checks": checks,
        "browser_errors": errors,
        "outside": outside,
        "requests": requests,
        "mock_remote_calls": calls,
        "synthetic_only": True,
        "compiled_assets": {
            name: hashlib.sha256((ROOT / "frontend-new" / name).read_bytes()).hexdigest()
            for name in ("index.html", "app.js", "theme.js", "styles.css")
        },
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    failed = sum(not c["passed"] for c in checks) + len(errors) + len(outside)
    print(
        json.dumps({"checks": len(checks), "failed": failed, "report": str(output / "report.json")})
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
