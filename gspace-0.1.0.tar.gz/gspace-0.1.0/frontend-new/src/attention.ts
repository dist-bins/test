// Attention: what in a work item needs a person, derived only from typed
// fields. A failed pipeline does not make publish or deployment fail; a
// runtime read error is not a version mismatch; superseded (retried) job
// attempts never count; unknown is missing evidence, never "fine" and never
// counted as a problem. The attention filter is browser-local and separate
// from the shared work-item filters: it never writes preferences.

import type { ItemView } from './api';
import type { IconName, Kid, Tone } from './dom';
import { h, icon, plural } from './dom';
import { evidence } from './evidence';
import type { Proc } from './model';
import { failedJobs, latestPerRef, processOf } from './model';
import { render } from './render';
import type { AttnKind } from './state';
import { S, wkStr } from './state';

export interface AttnFact {
  readonly kind: AttnKind;
  readonly tone: Tone;
  /** Short visible text, e.g. "Pipeline #9201 failed (unit-tests)". */
  readonly text: string;
  readonly title: string;
  /** Environment the fact belongs to, or null for an item-level fact. */
  readonly env: string | null;
  /** The individual missing pieces of evidence (unknown facts only). */
  readonly parts?: readonly string[];
}

interface KindInfo {
  readonly label: string;
  /** Visible label of the screen-level chip on narrow screens. */
  readonly short: string;
  readonly tone: Tone;
  readonly icon: IconName;
  readonly unit: 'item' | 'environment';
  readonly hint: string;
}

export const ATTN: Readonly<Record<AttnKind, KindInfo>> = {
  failing: {
    label: 'Failing',
    short: 'Failing',
    tone: 'fail',
    icon: 's_fail',
    unit: 'item',
    hint: 'The newest pipeline on one of the item’s refs failed. Publish and deployment are separate facts.',
  },
  rebase: {
    label: 'Needs rebase',
    short: 'Rebase',
    tone: 'warn',
    icon: 'rebase',
    unit: 'item',
    hint: 'Verified rebase evidence says a branch is behind its target.',
  },
  differs: {
    label: 'Running version differs',
    short: 'Differs',
    tone: 'warn',
    icon: 's_mismatch',
    unit: 'environment',
    hint: 'The runtime comparison reports that the observed identity differs from the expected one.',
  },
  readerr: {
    label: 'Runtime read error',
    short: 'Read error',
    tone: 'fail',
    icon: 'warning',
    unit: 'environment',
    hint: 'Reading the running version failed. This is not evidence of a different version.',
  },
  testfail: {
    label: 'Test failed',
    short: 'Test failed',
    tone: 'fail',
    icon: 's_fail',
    unit: 'environment',
    hint: 'The manual application test record for the current target failed.',
  },
  totest: {
    label: 'Still to test',
    short: 'To test',
    tone: 'info',
    icon: 'test',
    unit: 'environment',
    hint: 'A target version is known and no manual result is recorded for it.',
  },
  unknown: {
    label: 'Unknown evidence',
    short: 'Unknown',
    tone: 'unknown',
    icon: 's_unknown',
    unit: 'item',
    hint: 'The running version or the rebase state is not known. Unknown is never treated as fine and is not counted as a problem.',
  },
};

export const ATTN_ORDER: readonly AttnKind[] = ['failing', 'rebase', 'differs', 'readerr', 'testfail', 'totest', 'unknown'];

const cache = new WeakMap<Proc, readonly AttnFact[]>();

export function attentionOf(v: ItemView): readonly AttnFact[] {
  const P = processOf(v);
  const hit = cache.get(P);
  if (hit) return hit;
  const out: AttnFact[] = [];
  // Only the newest pipeline per ref counts; an older failure on the same ref
  // and superseded job attempts are history, not current attention.
  for (const x of latestPerRef(P.pipes)) {
    if (x.p.status !== 'failed') continue;
    const jobs = failedJobs(x.p).map((j) => j.name);
    const what = x.kind === 'tag' ? 'Tag pipeline' : 'Pipeline';
    out.push({
      kind: 'failing',
      tone: 'fail',
      text: `${what} #${x.p.id.value} failed${jobs.length ? ` (${jobs.slice(0, 2).join(', ')}${jobs.length > 2 ? ', …' : ''})` : ''}`,
      title: `Newest pipeline on ${x.p.ref}. Its failure does not mean that publish or a deployment failed; those are separate facts.`,
      env: null,
    });
  }
  const unknown: string[] = [];
  for (const b of P.branches) {
    const r = b.b.rebase;
    if (r.kind === 'verified' && r.required) {
      out.push({ kind: 'rebase', tone: 'warn', text: `Rebase ${b.b.name}: ${r.behind} behind ${r.target_branch}`, title: `Source: ${r.source}`, env: null });
    } else if (r.kind === 'unknown') unknown.push(`rebase of ${b.b.name}`);
  }
  for (const def of P.envDefs) {
    const E = P.envs.get(def.name);
    if (!E) continue;
    const obs = E.env?.observation ?? null;
    if (obs?.kind === 'error') {
      out.push({ kind: 'readerr', tone: 'fail', text: `${def.label}: runtime read error`, title: `${obs.code}: ${obs.message}`, env: def.name });
    } else if (E.cmp?.result === 'mismatch') {
      out.push({ kind: 'differs', tone: 'warn', text: `${def.label} runs a different version`, title: E.cmp.reason, env: def.name });
    } else if (!E.cmp || E.cmp.result === 'unknown') unknown.push(`${def.label} running version`);
    const t = E.test;
    if (t?.outcome === 'failed') out.push({ kind: 'testfail', tone: 'fail', text: `${def.label} test failed`, title: t.reason, env: def.name });
    else if (t?.outcome === 'not_tested' && t.target)
      out.push({ kind: 'totest', tone: 'info', text: `${def.label} still to test`, title: t.reason, env: def.name });
  }
  if (unknown.length) {
    out.push({
      kind: 'unknown',
      tone: 'unknown',
      text: `Unknown: ${unknown.join(', ')}`,
      title: 'Missing evidence. Unknown is never treated as fine and is not counted as a problem.',
      env: null,
      parts: unknown,
    });
  }
  cache.set(P, out);
  return out;
}

export const hasAttention = (v: ItemView, k: AttnKind): boolean => attentionOf(v).some((f) => f.kind === k);

export interface AttnCount {
  readonly items: number;
  readonly envs: number;
}

export function attentionSummary(vs: readonly ItemView[]): Map<AttnKind, AttnCount> {
  const m = new Map<AttnKind, { items: number; envs: number }>();
  for (const v of vs) {
    const facts = attentionOf(v);
    for (const k of ATTN_ORDER) {
      const mine = facts.filter((f) => f.kind === k);
      if (!mine.length) continue;
      const c = m.get(k) ?? { items: 0, envs: 0 };
      c.items++;
      c.envs += mine.filter((f) => f.env !== null).length;
      m.set(k, c);
    }
  }
  return m;
}

const countText = (k: AttnKind, c: AttnCount): string =>
  ATTN[k].unit === 'environment' ? `${plural(c.envs, 'environment')} in ${plural(c.items, 'item')}` : plural(c.items, 'item');

// Compact unknown for column and strip heads: a count that stays visibly
// "unknown" (never fine), its list for screen readers, and the full list in
// the evidence popover, which opens by click, keyboard or touch (a sheet on
// narrow screens), so hover is never the only route to the reasons.
function unknownCompact(v: ItemView, f: AttnFact): HTMLElement {
  const parts = f.parts ?? [];
  return h(
    'span',
    { class: 'attn-unk' },
    h(
      'span',
      { class: 'chip st t-unknown attn-c', title: f.text },
      icon('s_unknown', 'sm'),
      h('span', null, `${parts.length || 1} unknown`),
      h('span', { class: 'sr' }, `: ${parts.join(', ') || f.text}`),
    ),
    evidence(
      `ev-unk-${wkStr(v.item.identity)}`,
      null,
      [
        h(
          'ul',
          { class: 'bullets' },
          (parts.length ? parts : [f.text]).map((p) => h('li', null, p)),
        ),
        h('p', null, f.title),
      ],
      'Unknown evidence',
    ),
  );
}

/**
 * One item's attention as short chips (column heads, strips, item header).
 * compact: column and strip heads show unknown evidence as a count with its
 * list one activation away; the item header keeps the full sentence.
 */
export function attentionLine(v: ItemView, max = 4, compact = false): HTMLElement {
  const facts = attentionOf(v);
  const real = facts.filter((f) => f.kind !== 'unknown');
  const unk = facts.find((f) => f.kind === 'unknown') ?? null;
  const P = processOf(v);
  // A failing pipeline next to a successful publish is shown together, so
  // neither fact hides the other.
  const pubOk = real.some((f) => f.kind === 'failing') && P.pubs.some((x) => x.x.status === 'success');
  const shown = real.slice(0, max);
  const kids: Kid[] = shown.map((f) =>
    h('span', { class: `chip st t-${f.tone} attn-c`, title: f.title }, icon(ATTN[f.kind].icon, 'sm'), h('span', null, f.text)),
  );
  if (pubOk)
    kids.splice(1, 0, h('span', { class: 'chip attn-ctx', title: 'Publish evidence is a separate fact from the pipeline status' }, 'publish succeeded'));
  if (real.length > shown.length)
    kids.push(
      h(
        'span',
        {
          class: 'muted attn-more',
          title: real
            .slice(max)
            .map((f) => f.text)
            .join('; '),
        },
        `+${real.length - shown.length}`,
      ),
    );
  if (!real.length) kids.push(h('span', { class: 'muted attn-none' }, 'Nothing failing, behind, differing or failed in the evidence'));
  if (unk)
    kids.push(
      compact ? unknownCompact(v, unk) : h('span', { class: 'chip st t-unknown attn-c', title: unk.title }, icon('s_unknown', 'sm'), h('span', null, unk.text)),
    );
  return h('div', { class: 'attn-line', 'aria-label': `Attention for #${v.item.identity.issue.value}` }, kids);
}

/**
 * Screen-level summary of the shown items with a browser-local filter. The
 * counts come from the records after the shared filters, before this one.
 */
export function attentionBar(vs: readonly ItemView[], key: 'work_items' | 'compare'): HTMLElement | null {
  if (!vs.length) return null;
  const sum = attentionSummary(vs);
  const active = S.attn[key];
  const chip = (k: AttnKind): HTMLButtonElement | null => {
    const c = sum.get(k);
    if (!c) return null;
    const info = ATTN[k];
    return h(
      'button',
      {
        type: 'button',
        class: `attn-f chip st t-${info.tone}`,
        'aria-pressed': String(active === k),
        'data-fk': `attn-${key}-${k}`,
        title: `${info.hint} Activate to show only these items (this browser only).`,
        onclick: () => {
          S.attn[key] = active === k ? null : k;
          render();
        },
      },
      icon(info.icon, 'sm'),
      // Narrow screens show the short form (CSS); the accessible name and
      // the filter are identical in both forms.
      h('span', { class: 'attn-full', 'aria-hidden': 'true' }, `${info.label} · ${countText(k, c)}`),
      h('span', { class: 'attn-short', 'aria-hidden': 'true' }, `${info.short} ${info.unit === 'environment' ? c.envs : c.items}`),
      h('span', { class: 'sr' }, `${info.label} · ${countText(k, c)}`),
    );
  };
  const problems = ATTN_ORDER.filter((k) => k !== 'unknown' && k !== 'totest' && sum.has(k));
  return h(
    'section',
    { class: 'attn-bar', 'aria-label': 'Attention in the shown items' },
    h('span', { class: 'attn-h' }, 'Needs attention'),
    problems.length
      ? problems.map(chip)
      : h('span', { class: 'muted' }, 'No failing pipeline, rebase, differing version, read error or failed test in the shown items.'),
    chip('totest'),
    chip('unknown'),
    active
      ? h(
          'span',
          { class: 'attn-on' },
          h('span', { class: 'muted' }, `Showing only “${ATTN[active].label}” · this browser only`),
          h(
            'button',
            {
              class: 'btn sm ghost',
              type: 'button',
              'data-fk': `attn-${key}-clear`,
              onclick: () => {
                S.attn[key] = null;
                render();
              },
            },
            icon('close', 'sm'),
            'Show all',
          ),
        )
      : null,
  );
}
