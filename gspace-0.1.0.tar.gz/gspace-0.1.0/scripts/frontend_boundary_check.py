"""Actual generated-validator positives/negatives using isolated Pydantic fixture data."""

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path

from gspace.config import AppConfig
from gspace.service import Service

ROOT = Path(__file__).resolve().parents[1]
SOURCE = r"""
import {readFile} from "node:fs/promises";
import {pathToFileURL} from "node:url";
const [modulePath, fixturePath] = process.argv.slice(1);
const {schemas,requests,responses}=await import(pathToFileURL(modulePath));
const fixture=JSON.parse(await readFile(fixturePath,"utf8"));
const checks=[];
function check(name, operation) { if(!operation()) throw new Error(name); checks.push(name); }
check("Native graph HTTP response validates",()=>responses[
  "GET /api/items/{project}/{issue}/pipeline-graph 200"](fixture.graph));
const graphId=structuredClone(fixture.graph);graphId.nodes[0].reference.key.pipeline.value="9201";
check("Native graph nominal ID rejects",()=>!schemas.PipelineGraph(graphId));
const graphKind=structuredClone(fixture.graph);graphKind.nodes[0].kind="guessed";
check("Native graph unknown node discriminator rejects",()=>!schemas.PipelineGraph(graphKind));
check("Pydantic Dashboard validates",()=>schemas.Dashboard(fixture.dashboard));
check("HTTP Dashboard response validates",
  ()=>responses["GET /api/dashboard 200"](fixture.dashboard));
check("Pydantic SettingsResponse validates",()=>schemas.SettingsResponse(fixture.settings));
check("Empty profile array validates",()=>responses["GET /api/access/profiles 200"]([]));
check("Wrong profile container rejects",
  ()=>!responses["GET /api/access/profiles 200"]({profiles:[]}));
const id=structuredClone(fixture.dashboard);
id.views[0].item.identity.project.value="42";
check("String ID rejects without coercion",
  ()=>!schemas.Dashboard(id)&&id.views[0].item.identity.project.value==="42");
const extra={...fixture.dashboard,unexpected:true};
check("Unexpected local DTO field rejects",()=>!schemas.Dashboard(extra)&&extra.unexpected===true);
const change={operation:"select",revision:0,
  key:{project:{value:42},issue:{value:791}},enabled:true};
check("Typed preferences union validates",()=>requests["POST /api/preferences"](change));
check("Unknown operation rejects",
  ()=>!requests["POST /api/preferences"]({...change,operation:"merge"}));
check("Negative nominal ID rejects",()=>!schemas.ProjectId({value:0}));
check("Empty version rejects",()=>!schemas.Version({}));
check("Branch-only manual result rejects",()=>!schemas.ApplicationTestRecord({
  key:change.key,environment:"dev",version:{branch:"issue-791"},outcome:"passed",
  checked_at:"2026-10-06T12:00:00Z",source:"operator",notes:""}));
check("General branch catalog validates",()=>responses["GET /api/branches 200"](fixture.branches));
check("General pipeline catalog validates",
  ()=>responses["GET /api/pipelines 200"](fixture.pipelines));
check("Manual history validates",()=>responses[
  "GET /api/items/{project}/{issue}/application-tests 200"](fixture.history));
check("Comparison request validates",()=>requests["POST /api/access/compare"](fixture.comparison));
check("Deferred comparison action rejects",()=>!requests["POST /api/access/compare"]({
  ...fixture.comparison,action:{...fixture.comparison.action,kind:"ready"}}));
check("Custom environment column validates",()=>schemas.EnvironmentColumn({
  project:{value:42},name:"qa",label:"QA",column:"environment:qa"}));
check("Arbitrary URL column rejects",()=>!schemas.EnvironmentColumn({
  project:{value:42},name:"qa",label:"QA",column:"environment:https://evil.invalid"}));
console.log(JSON.stringify({passed:checks.length,checks,
  source:"actual generated validators and Pydantic fixtures; no remote calls"}));
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/frontend-boundary.json"
    )
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="gspace-boundary-") as temporary:
        directory = Path(temporary)
        service = Service(
            AppConfig(
                preferences_path=directory / "prefs.toml", cache_path=directory / "cache.json"
            )
        )
        fixture = directory / "fixtures.json"
        fixture.write_text(
            json.dumps(
                {
                    "dashboard": service.dashboard().model_dump(mode="json"),
                    "graph": service.pipeline_graph(
                        service.snapshot().items[0].identity
                    ).model_dump(mode="json"),
                    "settings": service.settings().model_dump(mode="json"),
                    "branches": service.resource_catalog("branches").model_dump(mode="json"),
                    "pipelines": service.resource_catalog("pipelines").model_dump(mode="json"),
                    "history": service.application_test_history(
                        service.snapshot().items[0].identity
                    ).model_dump(mode="json"),
                    "comparison": {
                        "action": {
                            "kind": "create_tag",
                            "profile": "synthetic",
                            "project": {"value": 42},
                            "branch": "issue-791",
                            "expected_sha": "a" * 40,
                            "tag": "demo-7",
                        },
                        "profiles": ["synthetic", "reader"],
                    },
                }
            )
        )
        result = subprocess.run(
            [
                "/opt/homebrew/bin/node",
                "--input-type=module",
                "-e",
                SOURCE,
                str(ROOT / "frontend-new/contracts/schema-validation.js"),
                str(fixture),
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
            env={"PATH": "/opt/homebrew/bin:/usr/bin:/bin"},
        )
        if result.returncode:
            print(result.stderr)
            return result.returncode
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(json.loads(result.stdout), indent=2) + "\n")
        print(result.stdout.strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
