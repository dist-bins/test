"""One fixed native pipeline read query; no caller-supplied GraphQL operations."""

from __future__ import annotations

from gspace.config import ProjectConfig
from gspace.models import PipelineKey

PAGE_SIZE = 25
PIPELINE_QUERY = """query GSpacePipelineEdges(
  $projectPath: ID!, $pipelineId: CiPipelineID!, $first: Int!, $after: String
) {
  project(fullPath: $projectPath) {
    id fullPath
    pipeline(id: $pipelineId) {
      id iid path sha ref source status
      project { id fullPath }
      sourceJob { id kind retried }
      upstream { id iid path sha ref source status project { id fullPath } }
      downstream(first: $first, after: $after) {
        nodes {
          id iid path sha ref source status
          project { id fullPath }
          sourceJob { id kind retried }
        }
        pageInfo { hasNextPage endCursor }
      }
    }
  }
}"""


def pipeline_variables(
    project: ProjectConfig, key: PipelineKey, cursor: str | None
) -> dict[str, object]:
    if project.id != key.project:
        raise ValueError("Pipeline request project identity differs")
    if cursor is not None and (
        not 1 <= len(cursor) <= 512 or any(ord(c) < 33 or ord(c) > 126 for c in cursor)
    ):
        raise ValueError("Invalid bounded pipeline cursor")
    return {
        "projectPath": project.path,
        "pipelineId": f"gid://gitlab/Ci::Pipeline/{key.pipeline.value}",
        "first": PAGE_SIZE,
        "after": cursor,
    }


def pipeline_argv(
    launcher: list[str], hostname: str, project: ProjectConfig, key: PipelineKey, cursor: str | None
) -> list[str]:
    values = pipeline_variables(project, key, cursor)
    argv = [*launcher, "api", "--hostname", hostname, "--method", "POST", "graphql"]
    argv.extend(["-f", f"query={PIPELINE_QUERY}"])
    for name in ("projectPath", "pipelineId"):
        argv.extend(["-f", f"{name}={values[name]}"])
    argv.extend(["-F", f"first={PAGE_SIZE}"])
    if cursor is not None:
        argv.extend(["-f", f"after={cursor}"])
    return argv
