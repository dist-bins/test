"""Verify the integrated renderer with the shared synthetic browser acceptance gate."""

from __future__ import annotations

import sys

from frontend_review import main

from gspace.api import STATIC

if __name__ == "__main__":
    sys.argv[1:1] = ["--assets", str(STATIC)]
    raise SystemExit(main())
