"""Review the new Claude frontend read-only against the actual typed fixture API.

The frontend directory is never modified. Preference writes affect only a temporary
synthetic configuration. Expected contract failures are recorded, not hidden.
"""

from __future__ import annotations

import argparse
import json
import re
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    parser.add_argument("--output", type=Path, default=ROOT / "output/frontend-review")
    parser.add_argument(
        "--browser", default="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    results = []
    errors = []
    outside = []
    writes = []
    refresh_metrics = {}
    with tempfile.TemporaryDirectory(prefix="gspace-frontend-review-") as temporary:
        directory = Path(temporary)
        config = directory / "fixture.toml"
        config.write_text(
            'mode = "fixture"\npreferences_path = "prefs.toml"\ncache_path = "cache.json"\n'
        )
        with socket.socket() as allocator:
            allocator.bind(("127.0.0.1", 0))
            port = allocator.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        source = (
            "import sys; from pathlib import Path; import uvicorn; import gspace.api as api; "
            "from gspace.config import load_config; api.STATIC=Path(sys.argv[1]); "
            "uvicorn.run(api.create_app(load_config(Path(sys.argv[2]))), "
            "host='127.0.0.1', port=int(sys.argv[3]), access_log=False)"
        )
        server = subprocess.Popen(
            [sys.executable, "-c", source, str(args.assets.resolve()), str(config), str(port)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            for _ in range(100):
                if server.poll() is not None:
                    raise RuntimeError("Review fixture server exited")
                try:
                    with urlopen(base + "/api/dashboard", timeout=0.2) as response:
                        if response.status == 200:
                            break
                except OSError:
                    time.sleep(0.1)
            else:
                raise RuntimeError("Review fixture server did not start")
            with sync_playwright() as engine:
                browser = engine.chromium.launch(executable_path=args.browser, headless=True)
                context = browser.new_context(
                    viewport={"width": 1600, "height": 1100}, service_workers="block"
                )

                def guard(route):
                    parsed = urlsplit(route.request.url)
                    if (
                        parsed.scheme != "http"
                        or parsed.hostname != "127.0.0.1"
                        or parsed.port != port
                    ):
                        outside.append(route.request.url)
                        route.abort()
                    else:
                        route.continue_()

                context.route("**/*", guard)
                page = context.new_page()
                page.on("pageerror", lambda error: errors.append(str(error)))

                def record_response(response):
                    if response.request.method == "POST" and "/api/preferences" in response.url:
                        writes.append(
                            {"status": response.status, "body": response.request.post_data_json}
                        )

                page.on("response", record_response)

                def check(name, operation):
                    try:
                        operation()
                        results.append({"check": name, "result": "passed"})
                    except Exception as error:
                        results.append(
                            {"check": name, "result": "failed", "error": str(error)[:900]}
                        )

                page.goto(base)
                page.wait_for_selector(".mx tbody tr", timeout=10000)
                check(
                    "four active assigned work items",
                    lambda: expect(page.locator(".mx.proc thead th.colh")).to_have_count(4),
                )
                page.get_by_role("button", name="Rows", exact=True).click()
                check(
                    "normal work-item rows remain available",
                    lambda: expect(page.locator(".mx:not(.inv) tbody tr")).to_have_count(4),
                )
                page.get_by_role("button", name="Process columns", exact=True).click()
                check(
                    "process stages have coherent shared vertical order",
                    lambda: assert_true(
                        page.locator(".mx.proc tbody th.rh").all_text_contents()
                        == [
                            "Branch & commit",
                            "Merge request",
                            "Branch/MR pipeline",
                            "Jobs & attempts",
                            "Publish",
                            "Dev deployment",
                            "Tag",
                            "Tag pipeline",
                            "Preprod deployment",
                            "Runtime identity",
                            "Application tests",
                            "Commits",
                        ]
                    ),
                )
                page.screenshot(path=str(args.output / "desktop.png"), full_page=True)
                check(
                    "repository selector",
                    lambda: expect(
                        page.get_by_role("combobox", name="Repository", exact=True)
                    ).to_be_visible(timeout=1000),
                )
                for iid in range(791, 795):
                    with page.expect_response(base + "/api/preferences") as saved:
                        page.get_by_role(
                            "checkbox", name=f"Select #{iid} for comparison", exact=True
                        ).check()
                    assert saved.value.status == 200
                page.get_by_role("link", name="Compare", exact=False).first.click()
                check(
                    "four-item inverted comparison",
                    lambda: expect(page.locator(".mx.inv thead th.colh")).to_have_count(4),
                )
                page.screenshot(path=str(args.output / "columns.png"), full_page=True)
                check(
                    "pipeline failure stays distinct from a successful dev record",
                    lambda: assert_true(
                        "Pipeline failed"
                        in page.locator(".mx.proc tbody tr").nth(2).locator("td").first.inner_text()
                        and "Record success"
                        in page.locator(".mx.proc tbody tr").nth(5).locator("td").first.inner_text()
                    ),
                )

                def tag_candidate_evidence():
                    cell = page.locator(".mx.proc tbody tr").nth(6).locator("td").first
                    if cell.locator("button[data-ev]").count():
                        expect(cell).to_contain_text("candidate")
                        cell.locator("button[data-ev]").first.click()
                        expect(page.locator("#ev-pop")).to_contain_text("no branch lineage")
                        page.keyboard.press("Escape")
                    else:
                        expect(cell).to_contain_text("Equal SHA is not branch lineage")

                check(
                    "equal tag SHA is explicitly a candidate rather than branch lineage",
                    tag_candidate_evidence,
                )
                check(
                    "work-item identity headers align at the same top edge",
                    lambda: assert_true(
                        max(
                            node.bounding_box()["y"]
                            for node in page.locator(".mx.proc thead .colh .idc").all()
                        )
                        - min(
                            node.bounding_box()["y"]
                            for node in page.locator(".mx.proc thead .colh .idc").all()
                        )
                        <= 1
                    ),
                )
                page.get_by_role("button", name="Theme:", exact=False).click()
                page.get_by_role("button", name="Theme:", exact=False).click()
                check(
                    "theme control",
                    lambda: expect(page.locator("html")).to_have_attribute("data-theme", "dark"),
                )
                page.screenshot(path=str(args.output / "dark.png"), full_page=True)
                page.goto(base + "/#/mrs")
                check(
                    "historical unlinked authored MR",
                    lambda: expect(page.locator(".mx")).to_contain_text(
                        "Synthetic authored MR without a linked work item"
                    ),
                )
                page.get_by_role("button", name="Merged", exact=True).click()
                check(
                    "merged history visible",
                    lambda: expect(page.locator(".mx")).to_contain_text(
                        "Archived synthetic migration"
                    ),
                )
                page.goto(base + "/#/work")
                page.get_by_role("button", name="Save view", exact=True).click()
                page.get_by_role("textbox", name="Name", exact=True).fill("Review reproduction")
                page.get_by_role("dialog").get_by_role(
                    "button", name="Save view", exact=True
                ).click()
                page.wait_for_timeout(350)
                check(
                    "save-view typed API compatibility",
                    lambda: expect(page.get_by_role("dialog")).to_have_count(0, timeout=1000),
                )
                page.keyboard.press("Escape")
                page.goto(base + "/#/item/42/791")
                page.get_by_role("button", name="Bookmark", exact=True).click()
                page.wait_for_timeout(350)
                check(
                    "bookmark typed API compatibility",
                    lambda: expect(
                        page.get_by_role("button", name="Bookmarked", exact=True)
                    ).to_be_visible(timeout=1000),
                )
                check(
                    "separate application test evidence",
                    lambda: expect(page.locator("#main")).to_contain_text(
                        re.compile(r"App test (?:not tested|unconfirmed)")
                    ),
                )
                with page.expect_response(base + "/api/preferences") as saved:
                    page.get_by_role("checkbox", name="Tested locally", exact=True).check()
                assert saved.value.status == 200
                check(
                    "manual checklist retains draft and unconfirmed application test",
                    lambda: assert_true(
                        "Draft" in page.locator("#main").inner_text()
                        and re.search(
                            r"App test (?:not tested|unconfirmed)",
                            page.locator("#main").inner_text(),
                        )
                        and page.request.get(base + "/api/items/42/791").json()[
                            "application_tests"
                        ][0]["outcome"]
                        == "not_tested"
                    ),
                )
                page.get_by_role("textbox", name="New group name", exact=True).fill(
                    "Browser review"
                )
                with page.expect_response(base + "/api/preferences") as saved:
                    page.get_by_role("button", name="Add", exact=True).click()
                assert saved.value.status == 200
                cli = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "gspace",
                        "dashboard",
                        "--config",
                        str(config),
                        "--json",
                    ],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                shared = json.loads(cli.stdout)["preferences"]
                check(
                    "CLI sees web selection, scoped view, bookmark, checklist and group",
                    lambda: assert_true(
                        len(shared["selected"]) == 4
                        and shared["saved_views"][0]["host"] == "fixture"
                        and shared["bookmarks"][0]["host"] == "fixture"
                        and shared["checklists"][0]["local_test"] is True
                        and shared["groups"][0]["name"] == "Browser review"
                    ),
                )
                page.get_by_role("button", name="Preview tag", exact=True).click()
                check(
                    "preview remains unexecuted",
                    lambda: expect(page.locator(".preview-result")).to_contain_text("Not executed"),
                )
                page.keyboard.press("Escape")
                page.goto(base + "/#/pipelines/42/9201")

                def pipeline_failure_evidence():
                    expect(page.locator(".pg")).to_contain_text("deploy-dev")
                    failed = page.locator('.pg .jc[title*="script_failure"]').first
                    expect(failed).to_be_visible()
                    failed.click()
                    expect(page.locator(".jd")).to_contain_text("script_failure")
                    page.goto(base + "/#/pipelines/42/9201")

                check(
                    "pipeline detail represents stage jobs and reported failure",
                    pipeline_failure_evidence,
                )
                page.screenshot(path=str(args.output / "pipeline-detail.png"), full_page=True)
                page.goto(base + "/#/pipelines/42/9221")
                check(
                    "pipeline detail identifies that a prior job attempt exists",
                    lambda: expect(page.locator("#main")).to_contain_text("earlier attempt"),
                )
                page.goto(base + "/#/pipelines/42/9221/job/92209")
                expect(page.locator(".jd")).to_be_visible()
                check(
                    "historical job detail retains both superseded and current attempts",
                    lambda: assert_true(
                        "Superseded attempt" in page.locator(".jd").inner_text()
                        and "attempt 1 · retried" in page.locator(".jd").inner_text()
                        and "attempt 2 · current" in page.locator(".jd").inner_text()
                        and "#92210" in page.locator(".jd").inner_text()
                    ),
                )
                page.screenshot(path=str(args.output / "job-attempts.png"), full_page=True)
                page.goto(base + "/#/access")
                check(
                    "fixture access UI truthfully disables remote effects and credential input",
                    lambda: assert_true(
                        "Remote mutations off" in page.locator("#main").inner_text()
                        and page.locator('input[type="password"]').count() == 0
                        and page.get_by_role("button", name="Execute", exact=True).count() == 0
                    ),
                )
                page.screenshot(path=str(args.output / "access-disabled.png"), full_page=True)
                page.goto(base + "/#/work")
                with page.expect_response(base + "/api/preferences") as saved:
                    page.get_by_role("checkbox", name="Assigned to me", exact=True).uncheck()
                assert saved.value.status == 200
                page.get_by_role("combobox", name="Repository", exact=True).select_option("99")
                expect(page.locator(".mx.proc thead th.colh")).to_have_count(1)
                check(
                    "repository switch separates repeated issue IID identity",
                    lambda: assert_true(
                        page.locator('.mx.proc thead .idc a[href*="#/item/99/791"]').count() == 1
                        and "Revise ground handling dispatch" in page.locator(".mx").inner_text()
                        and "Preserve passenger preferences" not in page.locator(".mx").inner_text()
                    ),
                )
                page.get_by_role("combobox", name="Repository", exact=True).select_option("42")
                expect(page.locator(".mx.proc thead th.colh")).to_have_count(5)
                check(
                    "previous repository data does not appear under new scope",
                    lambda: expect(page.locator(".mx")).not_to_contain_text("ground-service"),
                )
                with page.expect_response(base + "/api/preferences") as saved:
                    page.get_by_role("checkbox", name="Assigned to me", exact=True).check()
                assert saved.value.status == 200
                page.get_by_role("combobox", name="Repository", exact=True).select_option("")
                expect(page.locator(".mx.proc thead th.colh")).to_have_count(4)
                page.set_viewport_size({"width": 390, "height": 844})
                page.goto(base + "/#/work")
                page.wait_for_selector(".mx")
                page.screenshot(path=str(args.output / "mobile.png"), full_page=True)
                check(
                    "mobile has no body overflow",
                    lambda: assert_true(
                        page.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
                    ),
                )
                # Reproduce the reported refresh-notification accumulation. Only
                # the temporary fixture response is changed; assets stay read-only.
                page.set_viewport_size({"width": 1600, "height": 1100})
                page.reload()
                page.wait_for_selector(".mx")
                initial_y = page.locator(".mx").evaluate("e => e.getBoundingClientRect().y")

                def repeated_refresh():
                    for _ in range(10):
                        button = page.locator('button[data-fk="refresh"]')
                        with page.expect_response(
                            lambda response: response.url == base + "/api/refresh"
                        ):
                            button.click()
                        expect(page.locator('button[data-fk="refresh"]')).to_be_enabled()

                repeated_refresh()
                expect(page.locator(".mx")).to_be_visible()
                refresh_metrics["success_notices"] = page.locator("#tray .prob").count()
                refresh_metrics["success_shift_px"] = (
                    page.locator(".mx").evaluate("e => e.getBoundingClientRect().y") - initial_y
                )
                page.screenshot(path=str(args.output / "refresh-success-ten.png"), full_page=True)
                check(
                    "ten successful refreshes produce no repeated notices",
                    lambda: assert_true(refresh_metrics["success_notices"] == 0),
                )
                check(
                    "successful refresh produces no layout shift",
                    lambda: assert_true(abs(refresh_metrics["success_shift_px"]) <= 1),
                )
                page.reload()
                page.wait_for_selector(".mx")

                def fail_refresh(route):
                    route.fulfill(
                        status=502,
                        content_type="application/json",
                        body=json.dumps(
                            {
                                "code": "synthetic_refresh_error",
                                "message": "Synthetic unavailable source",
                            }
                        ),
                    )

                page.route(base + "/api/refresh", fail_refresh)
                repeated_refresh()
                refresh_metrics["error_notices"] = page.locator("#tray .prob").count()
                page.screenshot(path=str(args.output / "refresh-error-ten.png"), full_page=True)
                check(
                    "ten failed refreshes deduplicate one operation error",
                    lambda: assert_true(refresh_metrics["error_notices"] <= 1),
                )
                page.set_viewport_size({"width": 390, "height": 844})
                notice_box = page.locator("#tray").bounding_box()
                refresh_metrics["mobile_notice_height_px"] = (
                    notice_box["height"] if notice_box else 0
                )
                page.screenshot(path=str(args.output / "refresh-errors-mobile.png"), full_page=True)
                check(
                    "refresh errors use at most a quarter of mobile height",
                    lambda: assert_true(refresh_metrics["mobile_notice_height_px"] <= 211),
                )
                page.unroute(base + "/api/refresh", fail_refresh)
                repeated_refresh()
                refresh_metrics["recovered_error_notices"] = page.locator("#tray .t-fail").count()
                refresh_metrics["recovered_total_notices"] = page.locator("#tray .prob").count()
                check(
                    "refresh recovery clears obsolete errors without notice accumulation",
                    lambda: assert_true(
                        refresh_metrics["recovered_error_notices"] == 0
                        and refresh_metrics["recovered_total_notices"] <= 1
                    ),
                )
                check("no external requests", lambda: assert_true(not outside))
                check("no JavaScript errors", lambda: assert_true(not errors))
                context.close()
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)
    report = {
        "result": "passed" if all(r["result"] == "passed" for r in results) else "incompatible",
        "frontend": str(args.assets.resolve()),
        "browser": "installed Chrome",
        "viewports": ["1600x1100", "390x844"],
        "checks": results,
        "preference_requests": writes,
        "javascript_errors": errors,
        "external_requests": outside,
        "frontend_files_modified": False,
        "refresh_reproduction": refresh_metrics,
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if report["result"] == "passed" else 1


def assert_true(condition):
    if not condition:
        raise AssertionError("condition is false")


if __name__ == "__main__":
    raise SystemExit(main())
