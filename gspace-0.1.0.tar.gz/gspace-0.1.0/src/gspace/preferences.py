"""Only local preferences. POSIX lock + revision check + fsync/replace TOML."""

from __future__ import annotations

import fcntl
import os
import tempfile
import tomllib
from collections.abc import Callable
from pathlib import Path
from typing import Literal, Self

import tomli_w
from pydantic import Field, model_validator

from gspace.models import ApplicationTestRecord, MilestoneFilter, Model, Text, WorkKey
from gspace.navigation import (
    Bookmark,
    BookmarkTarget,
    NavigationDecoration,
    SavedView,
    SavedViewTarget,
)


class Checklist(Model, frozen=True):
    key: WorkKey
    local_test: bool = Field(default=False, strict=True)
    dev_test: bool = Field(default=False, strict=True)
    preprod_test: bool = Field(default=False, strict=True)
    work_confirmed: bool = Field(default=False, strict=True)

    @property
    def complete(self) -> bool:
        return self.local_test and self.dev_test and self.preprod_test and self.work_confirmed


class Group(Model, frozen=True):
    name: Text
    members: tuple[WorkKey, ...] = ()


class Override(Model, frozen=True):
    key: WorkKey
    kind: Literal["branch", "mr", "tag"]
    value: Text
    reason: Text


class Filters(Model, frozen=True):
    state: Literal["opened", "closed", "all"] = "opened"
    assigned: bool = Field(default=True, strict=True)
    search: str = Field(default="", max_length=200)
    group: str = Field(default="", max_length=80)
    show_hidden: bool = Field(default=False, strict=True)
    milestone: MilestoneFilter = MilestoneFilter()


class Preferences(Model, frozen=True):
    schema_version: Literal[1] = 1
    revision: int = Field(default=0, strict=True, ge=0)
    instance_origin: Text | None = None
    filters: Filters = Filters()
    pinned: tuple[WorkKey, ...] = ()
    hidden: tuple[WorkKey, ...] = ()
    selected: tuple[WorkKey, ...] = ()
    groups: tuple[Group, ...] = ()
    checklists: tuple[Checklist, ...] = ()
    overrides: tuple[Override, ...] = ()
    saved_views: tuple[SavedView, ...] = ()
    bookmarks: tuple[Bookmark, ...] = ()
    application_tests: tuple[ApplicationTestRecord, ...] = ()

    @model_validator(mode="after")
    def unique(self) -> Self:
        for keys in (self.pinned, self.hidden, self.selected):
            if len(set(keys)) != len(keys):
                raise ValueError("duplicate preference identity")
        if len({g.name for g in self.groups}) != len(self.groups):
            raise ValueError("duplicate group")
        if len({c.key for c in self.checklists}) != len(self.checklists):
            raise ValueError("duplicate checklist")
        if len({(v.host, v.name) for v in self.saved_views}) != len(self.saved_views):
            raise ValueError("duplicate saved view")
        if len({(b.host, b.reference) for b in self.bookmarks}) != len(self.bookmarks):
            raise ValueError("duplicate bookmark")
        return self


class PreferenceConflict(ValueError):
    pass


class StoredPreferences(Preferences, frozen=True):
    """Storage/CLI extension. Legacy HTTP Preferences deliberately retain their existing shape.

    HTTP clients obtain decoration through the dedicated scoped NavigationCatalog contract.
    Pydantic's declared-base serialization prevents leaking added storage fields into old views.
    """

    navigation_decorations: tuple[NavigationDecoration, ...] = Field(default=(), max_length=128)

    @model_validator(mode="after")
    def navigation_targets(self) -> Self:
        targets = {decoration.target for decoration in self.navigation_decorations}
        if len(targets) != len(self.navigation_decorations):
            raise ValueError("duplicate navigation decoration target")
        for target in targets:
            if isinstance(target, BookmarkTarget):
                exists = any(
                    (b.host, b.reference) == (target.host, target.reference) for b in self.bookmarks
                )
            else:
                assert isinstance(target, SavedViewTarget)
                exists = any(
                    (v.host, v.name) == (target.host, target.name) for v in self.saved_views
                )
            if not exists:
                raise ValueError("navigation decoration target does not exist")
        return self


class PreferenceStore:
    def __init__(self, path: Path, instance_origin: str | None = None) -> None:
        self.path = path
        self.instance_origin = instance_origin

    def read(self) -> StoredPreferences:
        if not self.path.exists():
            return StoredPreferences(instance_origin=self.instance_origin)
        with self.path.open("rb") as file:
            prefs = StoredPreferences.model_validate(tomllib.load(file))
        if self.instance_origin is not None:
            if prefs.instance_origin is not None and prefs.instance_origin != self.instance_origin:
                raise ValueError("Preference file belongs to another GitLab instance")
            if (
                prefs.instance_origin is None
                and self.instance_origin != "fixture"
                and prefs != StoredPreferences()
            ):
                raise ValueError("Legacy preferences have no instance scope; use a new file")
            data = prefs.model_dump()
            data["instance_origin"] = self.instance_origin
            return StoredPreferences.model_validate(data)
        return prefs

    def update(
        self,
        transform: Callable[[StoredPreferences], Preferences],
        expected_revision: int | None = None,
    ) -> StoredPreferences:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.with_suffix(".lock").open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            old = self.read()
            if expected_revision is not None and old.revision != expected_revision:
                raise PreferenceConflict("Preferences changed; reload and reapply your change")
            candidate = transform(old)
            if (
                self.instance_origin is not None
                and candidate.instance_origin != self.instance_origin
            ):
                raise ValueError("Preference instance scope cannot change")
            data = {**old.model_dump(mode="json"), **candidate.model_dump(mode="json")}
            data["revision"] = old.revision + 1
            new = StoredPreferences.model_validate(data)
            payload = tomli_w.dumps(new.model_dump(mode="json", exclude_none=True)).encode()
            descriptor, temporary = tempfile.mkstemp(dir=self.path.parent, prefix=".prefs-")
            try:
                with os.fdopen(descriptor, "wb") as file:
                    file.write(payload)
                    file.flush()
                    os.fsync(file.fileno())
                os.replace(temporary, self.path)
                directory = os.open(self.path.parent, os.O_RDONLY)
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
            return new
