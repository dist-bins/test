"""GitLab 18.11.12 GET adapter. Auth remains entirely owned by glab on the DevPod."""

from __future__ import annotations

import json
import os
import re
import selectors
import shutil
import subprocess
import sys
import time
from collections.abc import Callable
from datetime import UTC, date, datetime
from functools import partial
from pathlib import Path
from typing import Literal, TypeVar
from urllib.parse import quote, urlencode, urlsplit

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError

from gspace.config import AppConfig, LiveConfig, ProjectConfig
from gspace.gitlab_release import read_release
from gspace.models import (
    Association,
    Branch,
    Deployment,
    Environment,
    GroupId,
    GroupMilestoneKey,
    IssueIid,
    Job,
    JobId,
    Link,
    MergeRequest,
    Milestone,
    MilestoneId,
    MilestoneIid,
    Model,
    MrIid,
    MrState,
    Origin,
    Pipeline,
    PipelineId,
    PipelineKey,
    PositiveInt,
    ProjectId,
    ProjectMilestoneKey,
    Publish,
    Rebase,
    RebaseVerified,
    Sha,
    Snapshot,
    Status,
    Tag,
    Text,
    Unknown,
    Version,
    WorkItem,
    WorkKey,
)
from gspace.pipeline_query import pipeline_argv, pipeline_variables
from gspace.preferences import Preferences


class AdapterError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class RunResult(Model, frozen=True):
    code: int
    stdout: bytes


def run_argv(
    argv: list[str],
    timeout: float,
    *,
    api_protocol: Literal["https", "http"] = "https",
    reject_redirects: bool = False,
) -> RunResult:
    """Read bounded stdout; discard stderr so glab diagnostics cannot leak credentials."""
    started = time.monotonic()
    command = list(argv)
    if reject_redirects and command[0] == "glab":
        companion = Path(sys.executable).parent / "gspace-glab"
        private = str(companion) if companion.is_file() else shutil.which("gspace-glab")
        if private is None:
            raise AdapterError(
                "unavailable", "Private guarded glab is missing; run poe install --guarded-glab"
            )
        command[0] = private
    if reject_redirects and "api" in command:
        api_index = command.index("api")
        identity = run_argv(
            [*command[:api_index], "--version"], min(timeout, 5), api_protocol=api_protocol
        )
        if (
            identity.code
            or re.match(
                rb"^glab(?: version)? 0\.0\.0-gspace-no-redirects\.1(?:[\s(]|$)", identity.stdout
            )
            is None
        ):
            raise AdapterError(
                "launcher",
                "Configured launcher does not identify as guarded glab; API request was not sent",
            )
        timeout -= time.monotonic() - started
        if timeout <= 0:
            raise AdapterError("timeout", "glab GET timed out; no automatic retry")
    environment = {
        **os.environ,
        "GLAB_CHECK_UPDATE": "false",
        "CHECK_UPDATE": "false",
        "GLAB_SKIP_TLS_VERIFY": "false",
        "SKIP_TLS_VERIFY": "false",
        "GLAB_NO_PROMPT": "true",
        "GLAB_SEND_TELEMETRY": "false",
        "GLAB_API_PROTOCOL": api_protocol,
        "API_PROTOCOL": api_protocol,
        "GITLAB_SUBFOLDER": "/",
    }
    if "--hostname" in argv:
        index = argv.index("--hostname") + 1
        if index >= len(argv):
            raise AdapterError("configuration", "glab hostname argument is absent")
        environment["GITLAB_API_HOST"] = argv[index]
        # Pinned glab rejects ':' in --hostname; API authority retains its explicit port.
        hostname = urlsplit("//" + argv[index]).hostname
        if hostname is None:
            raise AdapterError("configuration", "glab hostname argument is invalid")
        command[index] = hostname
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            shell=False,
            env=environment,
        )
    except OSError as error:
        raise AdapterError(
            "unavailable", "glab is unavailable; install it on the operator's DevPod"
        ) from error
    deadline = time.monotonic() + timeout
    output = bytearray()
    try:
        if process.stdout is None:
            raise AdapterError("transport", "glab stdout unavailable")
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise AdapterError("timeout", "glab GET timed out; no automatic retry")
                if not selector.select(remaining):
                    raise AdapterError("timeout", "glab GET timed out; no automatic retry")
                chunk = os.read(process.stdout.fileno(), 65536)
                if not chunk:
                    break
                output.extend(chunk)
                if len(output) > 5_000_000:
                    raise AdapterError("limit", "glab response exceeds byte limit")
        code = process.wait(timeout=max(0.01, deadline - time.monotonic()))
        return RunResult(code=code, stdout=bytes(output))
    except subprocess.TimeoutExpired as error:
        raise AdapterError("timeout", "glab GET timed out; no automatic retry") from error
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        if process.stdout is not None:
            process.stdout.close()


class DTO(BaseModel):
    model_config = ConfigDict(extra="ignore")


class UserDTO(DTO):
    id: PositiveInt


class VersionDTO(DTO):
    version: Text


class MilestoneDTO(DTO):
    id: PositiveInt
    iid: PositiveInt
    project_id: PositiveInt | None = None
    group_id: PositiveInt | None = None
    title: Text
    state: Literal["active", "closed"]
    start_date: date | None = None
    due_date: date | None = None
    web_url: Text


class IssueDTO(DTO):
    iid: PositiveInt
    project_id: PositiveInt
    title: Text
    state: Literal["opened", "closed"]
    assignees: tuple[UserDTO, ...] = ()
    labels: tuple[str, ...] = ()
    milestone: MilestoneDTO | None = None


class CommitDTO(DTO):
    id: Sha


class BranchDTO(DTO):
    name: Text
    commit: CommitDTO


class MrDTO(DTO):
    iid: PositiveInt
    project_id: PositiveInt
    source_project_id: PositiveInt
    sha: Sha
    title: Text
    state: str
    draft: bool = Field(default=False, strict=True)
    source_branch: Text
    target_branch: Text
    diverged_commits_count: int | None = Field(default=None, strict=True, ge=0)
    rebase_in_progress: bool | None = Field(default=None, strict=True)


class PipelineDTO(DTO):
    id: PositiveInt
    ref: Text
    sha: Sha
    source: str = "unknown"
    status: str


class JobDTO(DTO):
    id: PositiveInt
    name: Text
    stage: Text
    status: str
    retried: bool = Field(default=False, strict=True)
    failure_reason: str | None = None


class TagDTO(DTO):
    name: Text
    commit: CommitDTO


class EnvironmentDTO(DTO):
    id: PositiveInt
    name: Text


class DeployDTO(DTO):
    id: PositiveInt
    status: str
    ref: Text
    sha: Sha
    environment: EnvironmentDTO


D = TypeVar("D", bound=BaseModel)
Runner = Callable[[list[str], float], RunResult]
GraphRunner = Callable[[ProjectConfig, PipelineKey, str | None], bytes]


def status(raw: str) -> Status:
    try:
        return Status(raw)
    except ValueError:
        return Status.UNKNOWN


class GlabAdapter:
    def __init__(
        self, config: LiveConfig, runner: Runner = run_argv, graph_runner: GraphRunner | None = None
    ) -> None:
        self.config = config
        self.runner = (
            partial(
                run_argv,
                api_protocol="http" if config.transport == "isolated_loopback_http" else "https",
                reject_redirects=config.reject_redirects,
            )
            if runner is run_argv
            else runner
        )
        self.graph_runner = graph_runner

    def graph_page(self, project: ProjectConfig, key: PipelineKey, cursor: str | None) -> bytes:
        if project not in self.config.projects or key.project != project.id:
            raise AdapterError("scope", "Pipeline graph exceeds configured project/path scope")
        pipeline_variables(project, key, cursor)
        if self.graph_runner is not None:
            output = self.graph_runner(project, key, cursor)
        else:
            result = self.runner(
                pipeline_argv(["glab"], self.config.hostname, project, key, cursor),
                self.config.timeout_seconds,
            )
            output = result.stdout
            if result.code:
                try:
                    body = TypeAdapter[dict[str, object]](dict[str, object]).validate_python(
                        json.loads(output)
                    )
                except (ValueError, ValidationError) as error:
                    raise AdapterError("transport", "Native pipeline graph read failed") from error
                if not body.get("data") or not body.get("errors"):
                    raise AdapterError("transport", "Native pipeline graph read failed")
        if len(output) > 5_000_000:
            raise AdapterError("limit", "Pipeline graph response exceeds byte limit")
        return output

    def get(self, path: str, params: dict[str, str] | None = None) -> bytes:
        # Only the fixed read contracts below can reach the process boundary.
        allowed = re.fullmatch(
            r"(?:version|user|projects/\d+(?:/(?:issues|repository/branches|repository/tags|"
            r"issues/\d+/(?:related_merge_requests|closed_by)|milestones|"
            r"merge_requests(?:/\d+(?:/pipelines)?)?|pipelines(?:/\d+/jobs)?|deployments))?)",
            path,
        )
        if allowed is None:
            raise AdapterError("configuration", "Unsupported GET endpoint")
        project_match = re.match(r"projects/(\d+)(?:/|$)", path)
        if project_match and int(project_match.group(1)) not in {
            p.id.value for p in self.config.projects
        }:
            raise AdapterError("configuration", "GET exceeds configured project scope")
        endpoint = path + ("?" + urlencode(params) if params else "")
        result = self.runner(
            ["glab", "api", "--hostname", self.config.hostname, "--method", "GET", endpoint],
            self.config.timeout_seconds,
        )
        if result.code != 0:
            raise AdapterError("transport", "glab GET failed; check operator access and endpoint")
        if len(result.stdout) > 5_000_000:
            raise AdapterError("limit", "glab response exceeds byte limit")
        return result.stdout

    def single(self, path: str, dto: type[D], params: dict[str, str] | None = None) -> D:
        try:
            return dto.model_validate_json(self.get(path, params))
        except ValidationError as error:
            raise AdapterError(
                "validation", "GitLab response does not match the GET contract"
            ) from error

    def pages(self, path: str, dto: type[D], params: dict[str, str] | None = None) -> tuple[D, ...]:
        adapter = TypeAdapter(list[dto])
        collected: list[D] = []
        for page in range(1, self.config.max_pages + 1):
            query = {**(params or {}), "per_page": "100", "page": str(page)}
            try:
                values = adapter.validate_json(self.get(path, query))
            except ValidationError as error:
                raise AdapterError("validation", "GitLab list response is invalid") from error
            collected.extend(values)
            if len(values) < 100:
                return tuple(collected)
        raise AdapterError("limit", "GitLab pagination limit reached; snapshot is not complete")

    def link(self, project: ProjectConfig, path: str) -> Link:
        return Link(url=f"{self.config.web_origin.rstrip('/')}/{project.path}/-/{path}")

    def jobs(self, project: ProjectConfig, pipeline: PipelineDTO) -> tuple[Job, ...]:
        raw = self.pages(
            f"projects/{project.id.value}/pipelines/{pipeline.id}/jobs",
            JobDTO,
            {"include_retried": "true"},
        )
        counts: dict[tuple[str, str], int] = {}
        jobs: list[Job] = []
        for job in sorted(raw, key=lambda j: j.id):
            key = (job.name, job.stage)
            counts[key] = counts.get(key, 0) + 1
            jobs.append(
                Job(
                    project=project.id,
                    id=JobId(value=job.id),
                    name=job.name,
                    stage=job.stage,
                    status=status(job.status),
                    attempt=counts[key],
                    retried=job.retried,
                    failure_reason=job.failure_reason,
                    link=self.link(project, f"jobs/{job.id}"),
                )
            )
        return tuple(jobs)

    def snapshot(self, app: AppConfig, prefs: Preferences) -> Snapshot:
        remote_version = self.single("version", VersionDTO).version
        try:
            read_release(remote_version, self.config.supported_version)
        except ValueError as error:
            raise AdapterError(
                "compatibility", "GitLab version differs from pinned 18.11.12 contract"
            ) from error
        user = self.single("user", UserDTO)
        items: list[WorkItem] = []
        warnings: list[str] = []
        milestones: dict[ProjectMilestoneKey | GroupMilestoneKey, Milestone] = {}
        for project in self.config.projects:
            base = f"projects/{project.id.value}"
            issues = self.pages(base + "/issues", IssueDTO, {"scope": "all", "state": "all"})
            for raw_milestone in self.pages(
                base + "/milestones", MilestoneDTO, {"state": "all", "include_ancestors": "true"}
            ):
                milestone = self.milestone(raw_milestone, project)
                milestones[milestone.key] = milestone
            branches = self.pages(base + "/repository/branches", BranchDTO)
            tags = self.pages(base + "/repository/tags", TagDTO)
            deployments = self.pages(base + "/deployments", DeployDTO)
            for issue in issues:
                if issue.project_id != project.id.value:
                    raise AdapterError("validation", "Issue project identity mismatch")
                key = WorkKey(project=project.id, issue=IssueIid(value=issue.iid))
                issue_milestone = (
                    self.milestone(issue.milestone, project) if issue.milestone else None
                )
                if issue_milestone:
                    milestones[issue_milestone.key] = issue_milestone
                overrides = tuple(o for o in prefs.overrides if o.key == key)
                convention = app.branch_template.replace("{iid}", str(issue.iid))
                branch_names = {convention, *(o.value for o in overrides if o.kind == "branch")}
                related_mrs = self.pages(
                    base + f"/issues/{issue.iid}/related_merge_requests", MrDTO
                )
                # GitLab infers IID-prefix branches; it stores no branch creation relation here.
                branch_names.update(b.name for b in branches if b.name.startswith(f"{issue.iid}-"))
                explicit_branches = {
                    m.source_branch
                    for m in related_mrs
                    if m.project_id == project.id.value and m.source_project_id == project.id.value
                }
                branch_names.update(explicit_branches)
                item_branches: list[Branch] = []
                item_mrs: dict[int, MergeRequest] = {}
                item_pipelines: dict[int, Pipeline] = {}
                item_tags: list[Tag] = []
                refs: set[str] = set()
                mr_pipeline_rows: list[PipelineDTO] = []
                for related_mr in related_mrs:
                    if related_mr.project_id != project.id.value:
                        warnings.append(
                            f"Issue {key.key} references MR !{related_mr.iid} in another "
                            "target project; outside local hydration scope"
                        )
                        continue
                    item_mrs[related_mr.iid] = self.merge_request(
                        project,
                        related_mr,
                        Association(
                            origin=Origin.API,
                            reason=f"GET issues/{issue.iid}/related_merge_requests reports "
                            f"MR !{related_mr.iid}; branch creation provenance is not exposed",
                        ),
                    )
                    mr_pipeline_rows.extend(
                        self.pages(
                            base + f"/merge_requests/{related_mr.iid}/pipelines", PipelineDTO
                        )[: self.config.max_pipelines_per_ref]
                    )
                for branch in branches:
                    if branch.name not in branch_names:
                        continue
                    override = next(
                        (o for o in overrides if o.kind == "branch" and o.value == branch.name),
                        None,
                    )
                    association = Association(
                        origin=Origin.OPERATOR
                        if override
                        else Origin.API
                        if branch.name in explicit_branches
                        else Origin.CONVENTION,
                        reason=override.reason
                        if override
                        else (
                            f"Issue {issue.iid} API-related MR names source branch {branch.name}; "
                            "creation provenance unknown"
                            if branch.name in explicit_branches
                            else f"Branch naming convention for issue {issue.iid}; "
                            "creation provenance unknown"
                        ),
                        overrides=convention if override else None,
                    )
                    raw_mrs = list(
                        self.pages(
                            base + "/merge_requests",
                            MrDTO,
                            {"source_branch": branch.name, "state": "all"},
                        )
                    )
                    rebase: Rebase = Unknown(reason="No diverged commit evidence available")
                    open_details: list[MrDTO] = []
                    for raw_mr in raw_mrs:
                        detail = self.single(
                            base + f"/merge_requests/{raw_mr.iid}",
                            MrDTO,
                            {
                                "include_diverged_commits_count": "true",
                                "include_rebase_in_progress": "true",
                            },
                        )
                        if detail.project_id != project.id.value:
                            raise AdapterError("validation", "MR project identity mismatch")
                        if detail.source_project_id != project.id.value:
                            warnings.append(
                                f"MR !{detail.iid} belongs to a fork; "
                                "local branch association omitted"
                            )
                            continue
                        if detail.state == "opened":
                            open_details.append(detail)
                        prior = item_mrs.get(detail.iid)
                        item_mrs[detail.iid] = self.merge_request(
                            project,
                            detail,
                            prior.association
                            if prior
                            else Association(
                                origin=Origin.API,
                                reason="MR source_branch matches associated branch",
                            ),
                        )
                        mr_pipeline_rows.extend(
                            self.pages(
                                base + f"/merge_requests/{detail.iid}/pipelines", PipelineDTO
                            )[: self.config.max_pipelines_per_ref]
                        )
                    if open_details:
                        evidence = {
                            (m.sha, m.target_branch, m.diverged_commits_count, m.rebase_in_progress)
                            for m in open_details
                        }
                        if len(evidence) == 1:
                            detail = open_details[0]
                            count = detail.diverged_commits_count
                            if (
                                detail.sha == branch.commit.id
                                and count is not None
                                and detail.rebase_in_progress is False
                            ):
                                rebase = RebaseVerified(
                                    required=count > 0,
                                    behind=count,
                                    source_sha=detail.sha,
                                    target_branch=detail.target_branch,
                                    source=(
                                        f"GET MR !{detail.iid} diverged_commits_count "
                                        f"against {detail.target_branch}"
                                    ),
                                    checked_at=datetime.now(UTC),
                                )
                            else:
                                rebase = Unknown(
                                    reason=(
                                        "MR source SHA changed, rebase is in progress "
                                        "or ancestry evidence is incomplete"
                                    )
                                )
                        else:
                            rebase = Unknown(
                                reason=(
                                    "Associated open MRs have differing target or ancestry evidence"
                                )
                            )
                    item_branches.append(
                        Branch(
                            project=project.id,
                            name=branch.name,
                            sha=branch.commit.id,
                            association=association,
                            rebase=rebase,
                            link=self.link(project, "tree/" + quote(branch.name, safe="")),
                        )
                    )
                    refs.add(branch.name)
                for override in (o for o in overrides if o.kind == "mr"):
                    if not override.value.isdecimal() or int(override.value) < 1:
                        raise AdapterError("configuration", "MR override must be a positive IID")
                    detail = self.single(base + f"/merge_requests/{int(override.value)}", MrDTO)
                    if detail.project_id != project.id.value:
                        raise AdapterError("validation", "MR override project mismatch")
                    item_mrs[detail.iid] = self.merge_request(
                        project,
                        detail,
                        Association(
                            origin=Origin.OPERATOR,
                            reason=override.reason,
                            overrides="source_branch association",
                        ),
                    )
                    mr_pipeline_rows.extend(
                        self.pages(base + f"/merge_requests/{detail.iid}/pipelines", PipelineDTO)[
                            : self.config.max_pipelines_per_ref
                        ]
                    )
                for tag in tags:
                    override = next(
                        (o for o in overrides if o.kind == "tag" and o.value == tag.name), None
                    )
                    if override or any(branch.sha == tag.commit.id for branch in item_branches):
                        item_tags.append(
                            Tag(
                                project=project.id,
                                name=tag.name,
                                sha=tag.commit.id,
                                association=Association(
                                    origin=Origin.OPERATOR if override else Origin.API,
                                    reason=override.reason
                                    if override
                                    else (
                                        "Tag SHA equals current branch SHA; "
                                        "historical origin unproven"
                                    ),
                                    overrides="SHA association" if override else None,
                                ),
                                link=self.link(project, "tags/" + quote(tag.name, safe="")),
                            )
                        )
                        refs.add(tag.name)
                raw_pipelines = mr_pipeline_rows
                for ref in sorted(refs):
                    raw_pipelines.extend(
                        self.pages(
                            base + "/pipelines",
                            PipelineDTO,
                            {"ref": ref, "order_by": "id", "sort": "desc"},
                        )[: self.config.max_pipelines_per_ref]
                    )
                for row in raw_pipelines:
                    if row.id in item_pipelines:
                        continue
                    item_pipelines[row.id] = Pipeline(
                        project=project.id,
                        id=PipelineId(value=row.id),
                        ref=row.ref,
                        sha=row.sha,
                        source=row.source,
                        status=status(row.status),
                        jobs=self.jobs(project, row),
                        association=Association(
                            origin=Origin.API, reason="GET ref or MR pipeline relationship"
                        ),
                        link=self.link(project, f"pipelines/{row.id}"),
                    )
                publishes: list[Publish] = []
                for pipeline in item_pipelines.values():
                    for job in pipeline.jobs:
                        rule = app.effective_pipeline(project.id).rules.classify(job.name)
                        if rule is not None and rule.role == "publish":
                            publishes.append(
                                Publish(
                                    pipeline=pipeline.id,
                                    job=job.id,
                                    status=job.status,
                                    artifact="Artifact identity unknown",
                                    source=(
                                        "Configured Nexus publish job; "
                                        "repository contents not verified"
                                    ),
                                )
                            )
                envs: list[Environment] = []
                for definition in app.effective_pipeline(project.id).rules.environments:
                    name = definition.name
                    related = tuple(
                        Deployment(
                            project=project.id,
                            id=deploy.id,
                            status=status(deploy.status),
                            ref=deploy.ref,
                            sha=deploy.sha,
                            source="GitLab deployment API",
                            link=self.link(project, f"environments/{deploy.environment.id}"),
                        )
                        for deploy in sorted(deployments, key=lambda deployment: deployment.id)
                        if deploy.environment.name == name and deploy.ref in refs
                    )
                    configured_endpoint = next(
                        (e for e in app.endpoints if e.key == key and e.name == name), None
                    )
                    expected = (
                        Version(branch=item_branches[0].name, sha=item_branches[0].sha)
                        if (definition.ref_source == "branch" and len(item_branches) == 1)
                        else Version(tag=item_tags[-1].name, sha=item_tags[-1].sha)
                        if definition.ref_source == "tag" and len(item_tags) == 1
                        else None
                    )
                    if configured_endpoint is not None and configured_endpoint.expected is not None:
                        expected = configured_endpoint.expected
                    envs.append(
                        Environment(
                            name=name,
                            expected=expected,
                            observation=Unknown(reason="Environment has not been observed"),
                            deployments=related,
                        )
                    )
                items.append(
                    WorkItem(
                        identity=key,
                        project_path=project.path,
                        title=issue.title,
                        state=issue.state,
                        assigned_to_me=any(a.id == user.id for a in issue.assignees),
                        labels=issue.labels,
                        milestone=issue_milestone.key if issue_milestone else None,
                        link=self.link(project, f"issues/{issue.iid}"),
                        branches=tuple(item_branches),
                        merge_requests=tuple(item_mrs.values()),
                        pipelines=tuple(item_pipelines.values()),
                        publishes=tuple(publishes),
                        tags=tuple(item_tags),
                        environments=tuple(envs),
                    )
                )
        warnings.append(
            "Job attempt numbers describe returned history; earlier attempts may be unavailable"
        )
        return Snapshot(
            source="glab",
            gitlab_version=remote_version,
            fetched_at=datetime.now(UTC),
            items=tuple(items),
            milestones=tuple(milestones.values()),
            issue_coverage="complete_configured_projects",
            warnings=tuple(warnings),
        )

    def milestone(self, raw: MilestoneDTO, project: ProjectConfig) -> Milestone:
        if (raw.project_id is None) == (raw.group_id is None):
            raise AdapterError(
                "validation", "Milestone requires exactly one project or group owner"
            )
        if raw.project_id is not None:
            if raw.project_id != project.id.value:
                raise AdapterError("validation", "Milestone project identity mismatch")
            key = ProjectMilestoneKey(project=project.id, id=MilestoneId(value=raw.id))
        else:
            assert raw.group_id is not None
            key = GroupMilestoneKey(group=GroupId(value=raw.group_id), id=MilestoneId(value=raw.id))
        origin = urlsplit(self.config.web_origin)
        url = urlsplit(raw.web_url)
        suffix = f"/-/milestones/{raw.iid}"
        if (
            url.scheme != origin.scheme
            or url.netloc != origin.netloc
            or not url.path.endswith(suffix)
            or (raw.project_id is not None and url.path != f"/{project.path}{suffix}")
            or (raw.group_id is not None and not url.path.startswith("/groups/"))
        ):
            raise AdapterError(
                "validation", "Milestone link does not match its API owner and origin"
            )
        return Milestone(
            key=key,
            iid=MilestoneIid(value=raw.iid),
            title=raw.title,
            state=raw.state,
            start_date=raw.start_date,
            due_date=raw.due_date,
            link=Link(url=raw.web_url, verification="source_contract"),
        )

    def merge_request(
        self, project: ProjectConfig, raw: MrDTO, association: Association
    ) -> MergeRequest:
        state = MrState.UNKNOWN
        if raw.state in ("opened", "merged", "closed"):
            state = {"opened": MrState.OPEN, "merged": MrState.MERGED, "closed": MrState.CLOSED}[
                raw.state
            ]
        return MergeRequest(
            project=ProjectId(value=raw.project_id),
            source_project=ProjectId(value=raw.source_project_id),
            iid=MrIid(value=raw.iid),
            title=raw.title,
            state=state,
            draft=raw.draft,
            source_branch=raw.source_branch,
            target_branch=raw.target_branch,
            source_sha=raw.sha,
            association=association,
            link=self.link(project, f"merge_requests/{raw.iid}"),
        )
