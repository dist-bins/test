// DOM builder, original icon set, semantic badges and formatting helpers.
// Facts stay separate: pipeline, job, publish, deployment record, runtime
// identity and application test never collapse into one status.

import type { Link, MergeRequest, Rebase, Status } from './api';
import { localUrl } from './url';

/* ================================================================ dom */

export type Handler = (e: Event) => void;
export type PropValue = string | number | boolean | null | undefined | Handler;
export type Props = Readonly<Record<string, PropValue>>;
export type Kid = Node | string | number | null | undefined | false | readonly Kid[];

function setProp(el: HTMLElement, k: string, v: string | number | boolean): void {
  // Live DOM properties (not attributes) for form state.
  if (
    k === 'value' &&
    (el instanceof HTMLInputElement || el instanceof HTMLSelectElement || el instanceof HTMLTextAreaElement || el instanceof HTMLOptionElement)
  ) {
    el.value = String(v);
  } else if (k === 'checked' && el instanceof HTMLInputElement) el.checked = v === true;
  else if (k === 'indeterminate' && el instanceof HTMLInputElement) el.indeterminate = v === true;
  else if (k === 'selected' && el instanceof HTMLOptionElement) el.selected = v === true;
  else if (k === 'open' && el instanceof HTMLDetailsElement) el.open = v === true;
  else if (
    k === 'disabled' &&
    (el instanceof HTMLButtonElement ||
      el instanceof HTMLInputElement ||
      el instanceof HTMLSelectElement ||
      el instanceof HTMLTextAreaElement ||
      el instanceof HTMLFieldSetElement ||
      el instanceof HTMLOptionElement)
  ) {
    el.disabled = v === true;
  } else el.setAttribute(k, v === true ? '' : String(v));
}

export function h<K extends keyof HTMLElementTagNameMap>(tag: K, props?: Props | null, ...kids: Kid[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  if (props) {
    for (const k of Object.keys(props)) {
      const v = props[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = String(v);
      else if (typeof v === 'function') {
        if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      } else setProp(el, k, v);
    }
  }
  append(el, kids);
  return el;
}

export function append(el: Element, kids: readonly Kid[]): void {
  for (const k of kids) {
    if (k == null || k === false) continue;
    if (Array.isArray(k)) append(el, k);
    else if (k instanceof Node) el.append(k);
    else el.append(String(k));
  }
}

/** Value of the form control that raised an event ('' when there is none). */
export function controlValue(e: Event): string {
  const t = e.target;
  if (t instanceof HTMLInputElement || t instanceof HTMLSelectElement || t instanceof HTMLTextAreaElement) return t.value;
  return '';
}

/** Checked state of the checkbox that raised an event. */
export function checkedOf(e: Event): boolean {
  const t = e.target;
  return t instanceof HTMLInputElement && t.checked;
}

/** Open state of the <details> that raised a toggle event. */
export function openOf(e: Event): boolean {
  const t = e.target;
  return t instanceof HTMLDetailsElement && t.open;
}

/* ============================================================== icons */
// Original 16px set, 1.5 stroke, currentColor. Status glyphs differ in shape
// so state never depends on colour alone.

const SVG_NS = 'http://www.w3.org/2000/svg';
const circ = (x: number, y: number, r: number): string => `M${x - r} ${y}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0`;
const RING = circ(8, 8, 5.75);

const ICONS = {
  work: 'M3 2.5h10l.5.5v10l-.5.5H3l-.5-.5V3zM5 6h6M5 8.5h6M5 11h3.5',
  compare: 'M2.5 2.5h4.5v11H2.5zM9 2.5h4.5v11H9zM2.5 6h4.5M9 6h4.5',
  mr: `${circ(4, 3.5, 1.5)}${circ(4, 12.5, 1.5)}${circ(12, 12.5, 1.5)}M4 5v6M12 11V7a2 2 0 0 0-2-2H7M8.5 3.5 7 5l1.5 1.5`,
  branch: `${circ(4.5, 3.5, 1.5)}${circ(4.5, 12.5, 1.5)}${circ(11.5, 4.5, 1.5)}M4.5 5v6M11.5 6c0 3.5-7 2.5-7 5`,
  pipeline: `${circ(3, 8, 1.5)}${circ(8, 8, 1.5)}${circ(13, 8, 1.5)}M4.5 8h2M9.5 8h2`,
  bookmark: 'M4 2.5h8v11l-4-3-4 3z',
  views: 'M8 2.5 13.5 5 8 7.5 2.5 5zM2.5 8 8 10.5 13.5 8M2.5 11 8 13.5 13.5 11',
  source: 'M3 4c0-.9 2.2-1.5 5-1.5s5 .6 5 1.5-2.2 1.5-5 1.5S3 4.9 3 4zM3 4v8c0 .9 2.2 1.5 5 1.5s5-.6 5-1.5V4M3 8c0 .9 2.2 1.5 5 1.5S13 8.9 13 8',
  repo: 'M3.5 12.5v-9a1 1 0 0 1 1-1h8v9h-8a1 1 0 0 0 0 2h8M6 5h4',
  shield: 'M8 1.8 13 3.5v4.1c0 3-2.1 5.3-5 6.6-2.9-1.3-5-3.6-5-6.6V3.5zM5.8 8l1.6 1.6 2.8-3',
  pulse: 'M1.5 8.5h3l1.5-4 3 8 1.5-4h4',
  send: 'M2.5 7.5 13.5 2.5 9.5 13.5 7.5 9zM7.5 9l6-6.5',
  pin: 'M6 2.5h4l-.5 4 2 2v1h-7v-1l2-2zM8 9.5v4',
  hide: `M2 8s2.2-4 6-4 6 4 6 4-2.2 4-6 4-6-4-6-4z${circ(8, 8, 1.75)}M3 13 13 3`,
  eye: `M1.5 8s2.4-4.5 6.5-4.5S14.5 8 14.5 8 12.1 12.5 8 12.5 1.5 8 1.5 8z${circ(8, 8, 2)}`,
  check: 'M3.5 8.5l3 3 6-7',
  close: 'M4 4l8 8M12 4l-8 8',
  refresh: 'M13 8a5 5 0 1 1-1.6-3.7M13 2.5v3h-3',
  retry: 'M3 8a5 5 0 1 0 1.6-3.7M3 2.5v3h3',
  external: 'M9 2.5h4.5V7M13.5 2.5 7.5 8.5M11.5 9.5v4h-9v-9h4',
  search: `${circ(7, 7, 4.25)}M10.2 10.2 13.5 13.5`,
  columns: 'M2.5 3h11v10h-11zM6.2 3v10M9.8 3v10',
  rows: 'M2.5 3h11v10h-11zM2.5 6.3h11M2.5 9.7h11',
  lanes: `M4 2.5v11M12 2.5v11${circ(4, 5, 1.25)}${circ(4, 11, 1.25)}${circ(12, 8, 1.25)}`,
  sort: 'M5 3v10M2.5 10.5 5 13l2.5-2.5M11 13V3M8.5 5.5 11 3l2.5 2.5',
  sun: `${circ(8, 8, 2.75)}M8 1.5v1.5M8 13v1.5M1.5 8H3M13 8h1.5M3.4 3.4l1 1M11.6 11.6l1 1M3.4 12.6l1-1M11.6 4.4l1-1`,
  moon: 'M13 9.6A5.5 5.5 0 1 1 6.4 3a4.5 4.5 0 0 0 6.6 6.6z',
  system: 'M2.5 3h11v7.5h-11zM6 13.5h4M8 10.5v3',
  tag: `M2.5 2.5h5l6 6-5 5-6-6z${circ(5.5, 5.5, 1)}`,
  server: 'M2.5 3h11v4h-11zM2.5 9h11v4h-11zM5 5h.5M5 11h.5',
  observe: `${circ(8, 8, 5.5)}${circ(8, 8, 2)}M8 1v2.5M8 12.5V15M1 8h2.5M12.5 8H15`,
  warning: 'M8 2.5l6 11H2zM8 6.5v3M8 11.5v.2',
  info: `${RING}M8 7.5v4M8 5v.2`,
  lock: 'M4 7.5h8v6H4zM5.5 7.5v-2a2.5 2.5 0 0 1 5 0v2',
  plus: 'M8 3v10M3 8h10',
  trash: 'M3 4.5h10M6 4.5V3h4v1.5M4.5 4.5l.6 9h5.8l.6-9',
  back: 'M10 3.5 5.5 8l4.5 4.5',
  save: 'M3 2.5h8l2 2v9H3zM5.5 2.5v3h5v-3M5.5 13.5v-4h5v4',
  checklist: 'M2.5 4l1.5 1.5L6.5 3M8.5 4.5h5M2.5 10l1.5 1.5L6.5 9M8.5 10.5h5',
  group: 'M2.5 4.5v8h11V6H8L6.5 4.5z',
  commit: `${circ(8, 8, 2.5)}M1.5 8h4M10.5 8h4`,
  deploy: 'M8 10.5V2.5M5 5.5l3-3 3 3M3 9.5v4h10v-4',
  test: 'M6 2.5h4M6.5 2.5v4L3 13h10L9.5 6.5v-4',
  publish: 'M2.5 5 8 2.5 13.5 5v6L8 13.5 2.5 11zM2.5 5 8 7.5 13.5 5M8 7.5v6',
  rebase: `${circ(4, 3.5, 1.5)}${circ(4, 12.5, 1.5)}${circ(12, 8, 1.5)}M4 5v6M10.5 8H7a3 3 0 0 0-3 3`,
  job: 'M3 3h10v10H3zM6.5 6l3.5 2-3.5 2z',
  link: 'M6.5 9.5l3-3M7 4.5l1-1a2.5 2.5 0 0 1 3.5 3.5l-1 1M9 11.5l-1 1a2.5 2.5 0 0 1-3.5-3.5l1-1',
  edit: 'M10.5 2.5l3 3-8 8h-3v-3z',
  milestone: 'M3.5 14V2.5M3.5 3h8.5l-2 2.75L12 8.5H3.5',
  settings: `M2.5 4.5h6.5M12 4.5h1.5M2.5 11.5h2M7 11.5h6.5${circ(10.5, 4.5, 1.5)}${circ(5.5, 11.5, 1.5)}`,
  sort_asc: 'M4 13V3M1.5 5.5 4 3l2.5 2.5M8.5 4.5h6M8.5 8h4.5M8.5 11.5h3',
  sort_desc: 'M4 3v10M1.5 10.5 4 13l2.5-2.5M8.5 4.5h3M8.5 8h4.5M8.5 11.5h6',
  star: 'M8 2.2l1.75 3.6 3.95.55-2.85 2.8.68 3.95L8 11.25 4.47 13.1l.68-3.95L2.3 6.35l3.95-.55z',
  next: 'M3 8h10M9 4l4 4-4 4',
  history: `${circ(8, 8, 5.75)}M8 5v3.2l2.2 1.4`,
  filter: 'M2.5 3.5h11L9.5 8.5v4l-3 1.5v-5.5z',
  up: 'M8 13V3M4 7l4-4 4 4',
  down: 'M8 3v10M4 9l4 4 4-4',
  // visual overview and the curated navigation-decoration set
  layers: 'M8 2.5 13.5 5.5 8 8.5 2.5 5.5zM2.5 8.5 8 11.5l5.5-3M2.5 11 8 14l5.5-3',
  flag: 'M3.5 14V2.5M3.5 3h7l-1.5 2.5L10.5 8h-7',
  folder: 'M2 4.5V12.5h12V5.5H7.5L6 4z',
  calendar: 'M2.5 4h11v9.5h-11zM2.5 7h11M5.5 2.5v3M10.5 2.5v3',
  list: 'M5.5 4.5h8M5.5 8h8M5.5 11.5h8M2.5 4.5h.5M2.5 8h.5M2.5 11.5h.5',
  code: 'M5.5 4.5 2 8l3.5 3.5M10.5 4.5 14 8l-3.5 3.5M9 3 7 13',
  rocket: 'M9.5 2.5c2.5 0 4 1.5 4 4L9 11 5 7zM5 7 3 7.5 2 10l3-.5M9 11l-.5 2-2.5 1 .5-3M3.5 12.5l1.5-1.5',
  issue: `${circ(8, 8, 5.75)}${circ(8, 8, 1.25)}`,
  clock: `${circ(8, 8, 5.75)}M8 4.5V8h3`,
  arrow_down: 'M8 2.5v10M4.5 9 8 12.5 11.5 9',
  // statuses
  s_ok: `${RING}M5.5 8.2l1.8 1.8 3.4-3.8`,
  s_fail: `${RING}M6 6l4 4M10 6l-4 4`,
  s_run: `${RING}M6.8 5.6v4.8L10.5 8z`,
  s_pend: `${RING}M8 5v3.2l2 1.3`,
  s_manual: `${RING}M6.6 5.8v4.4M9.4 5.8v4.4`,
  s_skip: `${RING}M5.5 8h4.5M8.5 6.3 10.2 8l-1.7 1.7`,
  s_cancel: `${RING}M4 12 12 4`,
  s_created: `${RING}${circ(8, 8, 1)}`,
  s_unknown: `${RING}M6.5 6.6a1.5 1.5 0 1 1 2.2 1.3c-.5.3-.7.6-.7 1.2M8 11v.2`,
  s_match: `${RING}M5.3 6.8h5.4M5.3 9.2h5.4`,
  s_mismatch: `${RING}M5.3 6.8h5.4M5.3 9.2h5.4M9.3 4.8l-2.6 6.4`,
  s_neutral: RING,
} as const;

export type IconName = keyof typeof ICONS;

export function icon(name: IconName, cls = ''): SVGSVGElement {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 16 16');
  svg.setAttribute('class', `i ${cls}`.trim());
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  const p = document.createElementNS(SVG_NS, 'path');
  p.setAttribute('d', ICONS[name]);
  svg.append(p);
  return svg;
}

// Approved brand assets: colour wolf for the brand, neutral gray wolf for
// quiet empty/unconfigured states. Both are static files beside the bundle.
export function wolf(gray = false, cls = ''): HTMLImageElement {
  return h('img', {
    class: `wolf ${cls}`.trim(),
    src: localUrl(gray ? '/assets/gspace-wolf-gray.svg' : '/assets/gspace-wolf.svg'),
    alt: '',
    width: '20',
    height: '20',
    decoding: 'async',
  });
}

/* =========================================================== semantics */

export type Tone = 'ok' | 'fail' | 'warn' | 'info' | 'manual' | 'muted' | 'neutral' | 'unknown';

export const STATUS: Readonly<Record<Status, readonly [Tone, IconName, string]>> = {
  success: ['ok', 's_ok', 'Success'],
  failed: ['fail', 's_fail', 'Failed'],
  running: ['info', 's_run', 'Running'],
  pending: ['info', 's_pend', 'Pending'],
  manual: ['manual', 's_manual', 'Manual'],
  skipped: ['muted', 's_skip', 'Skipped'],
  canceled: ['muted', 's_cancel', 'Canceled'],
  created: ['muted', 's_created', 'Created'],
  unknown: ['unknown', 's_unknown', 'Unknown'],
};

export function tone(t: Tone, ico: IconName, text: string, title: string | null = null, chip = true): HTMLSpanElement {
  return h('span', { class: `${chip ? 'chip ' : ''}st t-${t}`, title }, icon(ico, 'sm'), h('span', null, text));
}

export function statusBadge(s: Status, opts: { prefix?: string; title?: string; chip?: boolean } = {}): HTMLSpanElement {
  const [t, ico, label] = STATUS[s];
  return tone(t, ico, opts.prefix ? `${opts.prefix} ${label.toLowerCase()}` : label, opts.title ?? null, opts.chip !== false);
}

export function compareBadge(c: { readonly result: string; readonly reason: string } | null): HTMLSpanElement {
  if (!c) return tone('unknown', 's_unknown', 'No comparison', 'The snapshot did not include a comparison for this environment');
  if (c.result === 'match') return tone('ok', 's_match', 'Runtime match', c.reason);
  if (c.result === 'mismatch') return tone('warn', 's_mismatch', 'Runtime mismatch', c.reason);
  return tone('unknown', 's_unknown', 'Runtime unknown', c.reason);
}

// Version-bound manual outcome (ApplicationTestEvidence.outcome). A pass or
// fail always belongs to one exact SHA/version; not_tested is explicit.
export function appTestBadge(outcome: 'passed' | 'failed' | 'not_tested'): HTMLSpanElement {
  if (outcome === 'passed') return tone('ok', 's_ok', 'App test passed', 'Manual operator record for this exact version');
  if (outcome === 'failed') return tone('fail', 's_fail', 'App test failed', 'Manual operator record for this exact version');
  return tone('unknown', 's_unknown', 'App test not tested', 'No manual result for this exact SHA/version');
}

// Older servers only send the computed compatibility value.
export function legacyAppTestBadge(v: 'unconfirmed' | 'passed' | 'failed'): HTMLSpanElement {
  if (v === 'passed') return tone('ok', 's_ok', 'App test passed (legacy)', 'Computed compatibility value without version evidence');
  if (v === 'failed') return tone('fail', 's_fail', 'App test failed (legacy)', 'Computed compatibility value without version evidence');
  return tone('unknown', 's_unknown', 'App test unconfirmed', 'No application test result has been confirmed');
}

export function rebaseBadge(r: Rebase | null): HTMLSpanElement {
  if (r?.kind !== 'verified') return tone('unknown', 's_unknown', 'Rebase unknown', r?.reason ?? 'No rebase evidence');
  const title = `${r.source} · checked ${fmtTime(r.checked_at) ?? 'time not supplied'}`;
  if (r.required) return tone('warn', 'rebase', `Rebase required · ${r.behind} behind ${r.target_branch}`, title);
  return tone('ok', 's_ok', `Up to date with ${r.target_branch}`, title);
}

const MR_STATE: Readonly<Record<MergeRequest['state'], readonly [Tone, IconName, string]>> = {
  open: ['info', 's_run', 'Open'],
  merged: ['manual', 'mr', 'Merged'],
  closed: ['muted', 's_cancel', 'Closed'],
  unknown: ['unknown', 's_unknown', 'State unknown'],
};

export function mrStateBadge(mr: MergeRequest): HTMLSpanElement {
  const [t, ico, label] = MR_STATE[mr.state];
  return tone(t, ico, label);
}

export function draftChip(mr: MergeRequest): HTMLSpanElement | null {
  return mr.draft ? h('span', { class: 'chip', title: 'GitLab Draft flag (read-only; the manual checklist never changes it)' }, 'Draft') : null;
}

export function workStateBadge(s: 'opened' | 'closed'): HTMLSpanElement {
  return s === 'opened' ? tone('info', 's_run', 'Opened') : tone('muted', 's_cancel', 'Closed');
}

/* ============================================================ format */

const pad = (n: number): string => String(n).padStart(2, '0');

export function fmtTime(s: string | null | undefined): string | null {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return String(s);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function fmtClock(ms: number): string {
  const d = new Date(ms);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export function time(s: string | null | undefined, missing = 'Time not supplied'): HTMLElement {
  const t = fmtTime(s);
  return t && s ? h('time', { datetime: s, title: s }, t) : h('span', { class: 'muted' }, missing);
}

// Outside one item's process there are no per-item letters, so lists and
// drawers mark every SHA with the same neutral commit glyph.
export function sha(s: string | null | undefined, missing = 'SHA not supplied'): HTMLSpanElement {
  return s
    ? h(
        'span',
        { class: 'cmt', title: `Commit ${s}` },
        h('span', { class: 'cm cm-n', 'aria-hidden': 'true' }, icon('commit', 'xs')),
        h('code', { class: 'mono' }, s.slice(0, 8)),
      )
    : h('span', { class: 'cmt' }, h('span', { class: 'cm cm-u', 'aria-hidden': 'true' }, '?'), h('span', { class: 'muted' }, missing));
}

export const none = (text: string): HTMLSpanElement => h('span', { class: 'muted' }, text);
export const lines = (...kids: Kid[]): HTMLDivElement => h('div', { class: 'lines' }, kids);
export const line = (...kids: Kid[]): HTMLDivElement => h('div', { class: 'line' }, kids);
export const plural = (n: number, word: string): string => `${n} ${word}${n === 1 ? '' : 's'}`;

export function extLink(link: Link | null | undefined, text = 'GitLab'): HTMLElement {
  if (!link?.url) return h('span', { class: 'unavail' }, 'No link supplied');
  if (link.verification === 'source_contract' && /^https?:\/\//i.test(link.url)) {
    return h('a', { class: 'xlink', href: link.url, target: '_blank', rel: 'noopener noreferrer' }, icon('external', 'sm'), text);
  }
  return h(
    'span',
    { class: 'fixture-link', title: `Fixture link, deliberately unavailable: ${link.url}` },
    icon('lock', 'sm'),
    text,
    h('span', { class: 'sr' }, ' (fixture link, unavailable)'),
  );
}

// Long identifiers (artifacts, image refs) may break only after ":" or "/".
export function breakable(text: string): Kid[] {
  const out: Kid[] = [];
  for (const part of String(text).split(/(?<=[:/])/)) out.push(part, h('wbr'));
  out.pop();
  return out;
}

// Wraps a run of nodes into a .line only when at least one exists, so
// optional detail rows never add empty grid gaps.
export function lineOpt(...kids: Kid[]): HTMLDivElement | null {
  return hasContent(kids) ? h('div', { class: 'line' }, kids) : null;
}

export function hasContent(kids: readonly Kid[]): boolean {
  return kids.some((k) => (Array.isArray(k) ? hasContent(k) : k != null && k !== false));
}

const SOURCE_LABEL: Readonly<Record<string, string>> = {
  merge_request_event: 'MR event',
  push: 'push',
  web: 'run from web',
  api: 'API trigger',
  schedule: 'schedule',
  trigger: 'trigger token',
  pipeline: 'multi-project',
  parent_pipeline: 'child of a parent pipeline (parent not identified)',
  external: 'external',
  chat: 'chat',
  webide: 'Web IDE',
};
export const sourceLabel = (s: string | null | undefined): string => (s ? (SOURCE_LABEL[s] ?? s) : 'source not supplied');
