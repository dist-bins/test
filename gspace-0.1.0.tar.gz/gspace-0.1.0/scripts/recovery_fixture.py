"""Owned application-recovery fixture: temporary state, GET mocks, loopback server.

No authentication environment is read. ProfileTransport receives an inert marker
through an explicit resolver and every remote request terminates in MockTransport.
This harness never starts the GitLab lab or enables application mutation effects.
"""

from __future__ import annotations

import socket
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory

import httpx
import tomli_w
import uvicorn

import gspace.api as api
from gspace.access import ProfileTransport
from gspace.access_models import AccessProfile, PatProfile
from gspace.actions import ActionService
from gspace.config import load_config
from gspace.models import IssueIid, ProjectId, WorkKey
from gspace.navigation import Bookmark, BranchReference, SavedView, ViewFilters
from gspace.operator_settings import OperatorSettings
from gspace.preferences import StoredPreferences
from gspace.service import BookmarkSet, FlagChange, SavedViewSet, Service
from gspace.web_config import WebConfig

ROOT = Path(__file__).resolve().parents[1]
INERT_MARKER = "synthetic-fixture-marker-not-a-credential"


@dataclass
class RecoveryFixture:
    service: Service
    actions: ActionService
    config_path: Path
    base: str
    calls: list[dict[str, str]]


def profile_actions(sha: str) -> tuple[ActionService, list[dict[str, str]]]:
    profiles = tuple(
        PatProfile(
            name=name,
            host="http://127.0.0.1:8929",
            projects=(ProjectId(value=42),),
            secret_env="GSPACE_SYNTHETIC_UNUSED",
            write_enabled=name != "readonly",
        )
        for name in ("owner", "readonly", "limited", "unavailable")
    )
    calls: list[dict[str, str]] = []

    def factory(profile: AccessProfile) -> ProfileTransport:
        def handle(request: httpx.Request) -> httpx.Response:
            if (
                request.method != "GET"
                or request.url.host != "127.0.0.1"
                or request.url.port != 8929
                or not request.url.path.startswith("/api/v4/")
            ):
                raise AssertionError("Recovery mock rejects unscoped or non-GET requests")
            path = request.url.path.removeprefix("/api/v4/")
            calls.append({"profile": profile.name, "method": request.method, "path": path})
            if path == "version":
                value: object = {"version": "18.11.12"}
            elif path == "metadata":
                value = {"version": "18.11.12", "enterprise": False}
            elif path == "user":
                value = {"id": 7}
            elif path == "personal_access_tokens/self":
                value = {"user_id": 7, "scopes": ["api"], "active": True, "revoked": False}
            elif path == "projects/42":
                value = {
                    "id": 42,
                    "archived": False,
                    "description": "GSpace isolated integration lab v1",
                    "permissions": {"project_access": {"access_level": 50}},
                    "merge_requests_enabled": True,
                    "builds_access_level": "enabled",
                }
                if profile.name == "limited":
                    value.pop("permissions")
            elif path.startswith("projects/42/repository/branches/"):
                value = {"name": path.rsplit("/", 1)[1], "commit": {"id": sha}, "protected": False}
            elif path == "projects/42/protected_tags":
                value = []
            else:
                raise AssertionError("Recovery mock has no evidence for the requested endpoint")
            return httpx.Response(200, json=value)

        return ProfileTransport(
            profile,
            resolver=lambda _: None if profile.name == "unavailable" else INERT_MARKER,
            http_transport=httpx.MockTransport(handle),
        )

    return ActionService(profiles, transport_factory=factory), calls


def seed_preferences(core: Service) -> None:
    for iid in (791, 792, 793, 794):
        core.change(
            FlagChange(
                operation="select",
                key=WorkKey(project=ProjectId(value=42), issue=IssueIid(value=iid)),
                enabled=True,
                revision=core.preferences.read().revision,
            )
        )
    core.change(
        SavedViewSet(
            revision=core.preferences.read().revision,
            view=SavedView(
                name="Flight active work",
                host=core.host,
                scope="work_items",
                projects=(ProjectId(value=42),),
                filters=ViewFilters(state="opened"),
                orientation="columns",
            ),
        )
    )
    core.change(
        BookmarkSet(
            revision=core.preferences.read().revision,
            bookmark=Bookmark(
                host=core.host,
                reference=BranchReference(project=ProjectId(value=99), name="issue-791"),
                label="Ground service · issue-791",
            ),
        )
    )


@contextmanager
def recovery_fixture(
    assets: Path | None = None,
    *,
    port: int = 0,
    settings: OperatorSettings | None = None,
    preferences: StoredPreferences | None = None,
    web: WebConfig | None = None,
) -> Iterator[RecoveryFixture]:
    if not 0 <= port <= 65535:
        raise ValueError("Invalid loopback port")
    if preferences is not None and preferences.instance_origin != "fixture":
        raise ValueError("Recovery preferences must belong to the synthetic fixture")
    with TemporaryDirectory(prefix="gspace-recovery-") as directory:
        config_path = Path(directory) / "config.toml"
        config_path.write_text(
            '# Synthetic recovery state only\nmode="fixture"\n'
            'preferences_path="prefs.toml"\ncache_path="cache.json"\n'
            + (
                tomli_w.dumps(settings.model_dump(mode="json", exclude_none=True))
                if settings is not None
                else ""
            )
            + (tomli_w.dumps({"web": web.model_dump(exclude_none=True)}) if web else ""),
            encoding="utf-8",
        )
        if preferences is not None:
            (Path(directory) / "prefs.toml").write_text(
                tomli_w.dumps(preferences.model_dump(mode="json", exclude_none=True)),
                encoding="utf-8",
            )
        core = Service(load_config(config_path), config_path=config_path)
        if preferences is None:
            seed_preferences(core)
        branch = core.snapshot().items[0].branches[0]
        actions, calls = profile_actions(branch.sha)
        original_static = api.STATIC
        api.STATIC = (assets or ROOT / "frontend-new").resolve()
        application = api.create_app(service=core, actions=actions)

        # Additional harness guard: finite action execution is never available here.
        @application.middleware("http")
        async def prohibit_effects(request, call_next):
            if request.url.path in (
                "/api/actions/execute",
                (web.root_path if web else "") + "/api/actions/execute",
            ):
                from starlette.responses import JSONResponse

                return JSONResponse({"detail": "Synthetic recovery has no effect transport"}, 403)
            return await call_next(request)

        listener = socket.socket()
        listener.bind(("127.0.0.1", port))
        port = listener.getsockname()[1]
        server = uvicorn.Server(
            uvicorn.Config(
                application, host="127.0.0.1", port=port, access_log=False, log_level="error"
            )
        )
        thread = threading.Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=True)
        thread.start()
        try:
            for _ in range(100):
                if server.started:
                    break
                if not thread.is_alive():
                    raise RuntimeError("Recovery fixture server exited")
                time.sleep(0.05)
            else:
                raise RuntimeError("Recovery fixture startup timed out")
            yield RecoveryFixture(core, actions, config_path, f"http://127.0.0.1:{port}", calls)
        finally:
            server.should_exit = True
            thread.join(timeout=6)
            listener.close()
            api.STATIC = original_static
            if thread.is_alive():
                raise RuntimeError("Recovery fixture server did not stop")
