// Derived relationships and the per-item process model. Everything here is
// computed from validated DTOs; nothing is inferred from names alone, and
// missing relationships or commit identity stay explicit (null).

import type {
  ApplicationTestEvidence,
  AuthoredMr,
  Branch,
  Column,
  Comparison,
  Deployment,
  Environment,
  ItemView,
  Job,
  JobConfiguration,
  MergeRequest,
  MilestoneCount,
  Pipeline,
  Publish,
  Tag,
  WorkItem,
} from './api';
import { versionParts } from './api';
import type { IconName } from './dom';
import type { RefSource } from './state';
import { adoptEnvColumns, msKeyStr, S, wkStr } from './state';

/* ========================================================== derived */

export type RefKind = 'tag' | 'branch' | 'ambiguous' | 'ref';

export interface MrEntry {
  readonly key: string;
  readonly mr: MergeRequest;
  /** The authored-catalog row, or null for an MR known only from a work item. */
  readonly row: AuthoredMr | null;
  views: ItemView[];
}
export interface CatalogEntry extends MrEntry {
  readonly row: AuthoredMr;
}
export interface PipeEntry {
  readonly key: string;
  readonly pipeline: Pipeline;
  readonly views: ItemView[];
  readonly publishes: Publish[];
  refKind: RefKind;
}
export interface BranchEntry {
  readonly key: string;
  readonly project: number;
  readonly name: string;
  readonly entries: { readonly view: ItemView; readonly branch: Branch }[];
  readonly mrs: MrEntry[];
  readonly pipelines: PipeEntry[];
  readonly envs: { readonly view: ItemView; readonly env: Environment; readonly role: 'expected' | 'observed' }[];
}
export interface Derived {
  readonly projects: Map<number, string>;
  readonly items: Map<string, ItemView>;
  readonly catalog: Map<string, CatalogEntry>;
  readonly wmrs: Map<string, MergeRequest>;
  readonly mrViews: Map<string, ItemView[]>;
  readonly pipes: Map<string, PipeEntry>;
  readonly branches: Map<string, BranchEntry>;
  readonly tagNames: Set<string>;
  readonly branchNames: Set<string>;
  /** Operator job classification by project/pipeline/job ID. */
  readonly jobCfg: Map<string, JobConfiguration>;
  /** Milestone catalog entries by typed key. */
  readonly ms: Map<string, MilestoneCount>;
  readonly msCurrent: Set<string>;
}

export const views = (): readonly ItemView[] => S.dash?.views ?? [];

let procCache = new WeakMap<ItemView, Proc>();
/** Forget cached process readings (data or configured environments changed). */
export function invalidateProcess(): void {
  procCache = new WeakMap();
}

export function derive(): void {
  adoptEnvColumns(); // newly reported configured environments join un-customised field lists
  const D: Derived = {
    projects: new Map(),
    items: new Map(),
    catalog: new Map(),
    wmrs: new Map(),
    mrViews: new Map(),
    pipes: new Map(),
    branches: new Map(),
    tagNames: new Set(),
    branchNames: new Set(),
    jobCfg: new Map(),
    ms: new Map(),
    msCurrent: new Set(),
  };
  for (const p of S.projects) D.projects.set(p.id.value, p.path);
  const branchEntry = (p: number, name: string): BranchEntry => {
    const k = `${p}/${name}`;
    let e = D.branches.get(k);
    if (!e) {
      e = { key: k, project: p, name, entries: [], mrs: [], pipelines: [], envs: [] };
      D.branches.set(k, e);
    }
    return e;
  };

  for (const v of views()) {
    const it = v.item;
    const pid = it.identity.project.value;
    D.items.set(wkStr(it.identity), v);
    if (!D.projects.has(pid)) D.projects.set(pid, it.project_path);
    for (const b of it.branches) {
      branchEntry(b.project.value, b.name).entries.push({ view: v, branch: b });
      D.branchNames.add(`${b.project.value}/${b.name}`);
    }
    for (const t of it.tags) D.tagNames.add(`${t.project.value}/${t.name}`);
    for (const m of it.merge_requests) {
      const k = `${m.project.value}/${m.iid.value}`;
      if (!D.wmrs.has(k)) D.wmrs.set(k, m);
      const vs = D.mrViews.get(k) ?? [];
      if (!vs.includes(v)) vs.push(v);
      D.mrViews.set(k, vs);
    }
    for (const p of it.pipelines) {
      const k = `${p.project.value}/${p.id.value}`;
      const e: PipeEntry = D.pipes.get(k) ?? { key: k, pipeline: p, views: [], publishes: [], refKind: 'ref' };
      if (!e.views.includes(v)) e.views.push(v);
      D.pipes.set(k, e);
    }
  }
  // Publish evidence per pipeline (project and pipeline are already scoped by
  // the entry key). One job may publish several artifacts (1:N), so an entry
  // is a duplicate only when every reported field matches: the same evidence
  // seen through several work-item views is listed once, distinct artifacts,
  // sources, statuses or links of the same job are all kept.
  const pubKey = (p: Publish): string => JSON.stringify([p.job.value, p.artifact, p.source, p.status, p.link ? [p.link.url, p.link.verification] : null]);
  for (const v of views()) {
    const pid = v.item.identity.project.value;
    for (const pub of v.item.publishes) {
      const e = D.pipes.get(`${pid}/${pub.pipeline.value}`);
      if (!e) continue;
      const k = pubKey(pub);
      if (!e.publishes.some((x) => pubKey(x) === k)) e.publishes.push(pub);
    }
  }
  for (const e of D.pipes.values()) {
    const k = `${e.pipeline.project.value}/${e.pipeline.ref}`;
    const isTag = D.tagNames.has(k);
    const isBranch = D.branchNames.has(k);
    e.refKind = isTag && isBranch ? 'ambiguous' : isTag ? 'tag' : isBranch ? 'branch' : 'ref';
  }
  // Authored catalog: only rows returned by /api/merge-requests (never mixed
  // with other authors' work-item MRs).
  for (const row of S.mrs?.rows ?? []) {
    const m = row.mr;
    const k = `${m.project.value}/${m.iid.value}`;
    if (!D.projects.has(m.project.value)) D.projects.set(m.project.value, row.project_path);
    D.catalog.set(k, { key: k, mr: m, row, views: D.mrViews.get(k) ?? [] });
  }
  for (const e of D.catalog.values()) {
    if (e.mr.source_branch) branchEntry(e.mr.source_project.value, e.mr.source_branch).mrs.push(e);
  }
  for (const [k, m] of D.wmrs) {
    if (D.catalog.has(k)) continue;
    const b = D.branches.get(`${m.source_project.value}/${m.source_branch}`);
    if (b) b.mrs.push({ key: k, mr: m, row: null, views: D.mrViews.get(k) ?? [] });
  }
  for (const e of D.pipes.values()) {
    D.branches.get(`${e.pipeline.project.value}/${e.pipeline.ref}`)?.pipelines.push(e);
  }
  for (const v of views()) {
    const pid = v.item.identity.project.value;
    for (const env of v.item.environments) {
      const exp = versionParts(env.expected).branch;
      if (exp) D.branches.get(`${pid}/${exp}`)?.envs.push({ view: v, env, role: 'expected' });
      const obs = env.observation.kind === 'observed' ? versionParts(env.observation.value).branch : null;
      if (obs) D.branches.get(`${pid}/${obs}`)?.envs.push({ view: v, env, role: 'observed' });
    }
  }
  for (const v of [...views(), ...S.items.values()]) {
    for (const c of v.job_configuration) D.jobCfg.set(`${c.project.value}/${c.pipeline.value}/${c.job.value}`, c);
  }
  for (const e of S.ms?.entries ?? []) D.ms.set(msKeyStr(e.milestone.key), e);
  for (const k of S.ms?.date_current_candidates ?? []) D.msCurrent.add(msKeyStr(k));
  S.d = D;
  invalidateProcess();
}

export const projectPath = (id: number): string => S.d?.projects.get(id) ?? `project ${id}`;

export function scopeLabel(): string {
  if (S.scope.project == null) return `All configured projects (${S.projects.length || '?'})`;
  return projectPath(S.scope.project);
}

/* ======================================================= environments */
// Environment names are configured strings (settings → effective rules per
// project), not a dev/preprod enum. Names that appear only in the data are
// kept with an unknown ref source. When settings are unavailable, dev and
// preprod fall back to the contract defaults (branch and tag).

export interface EnvDef {
  readonly name: string;
  readonly label: string;
  readonly refSource: RefSource | null;
  /** True when the name comes from the operator settings. */
  readonly configured: boolean;
  /** Saved-view field that shows this environment (dev, preprod or environment:<name>). */
  readonly col: Column;
}

const DEFAULT_ENV: Readonly<Record<string, readonly [string, RefSource]>> = { dev: ['Dev', 'branch'], preprod: ['Preprod', 'tag'] };
export const scopeProjects = (): number[] | null => (S.scope.project != null ? [S.scope.project] : null);

// The column comes from Dashboard.environment_columns (the server's shared
// descriptors). Only when a server reports no descriptors at all do custom
// environments fall back to the dev/preprod fields by their ref source.
function envCol(name: string, ref: RefSource | null): Column {
  const descriptors = S.dash?.environment_columns ?? [];
  const d = descriptors.find((x) => x.name === name);
  if (d) return d.column;
  if (name === 'dev' || name === 'preprod') return name;
  if (descriptors.length) return `environment:${name}`;
  return ref === 'branch' ? 'dev' : 'preprod';
}

function envDefs(projectIds: readonly number[] | null): Map<string, EnvDef> {
  const out = new Map<string, EnvDef>();
  const R = S.set.resp;
  if (!R) return out;
  const eff = R.effective.filter((x) => !projectIds || projectIds.includes(x.project.value));
  const lists = eff.length ? eff.map((x) => x.rules.environments) : [R.settings.pipeline.environments];
  for (const list of lists) {
    for (const e of list) {
      if (!out.has(e.name)) out.set(e.name, { name: e.name, label: e.label, refSource: e.ref_source, configured: true, col: envCol(e.name, e.ref_source) });
    }
  }
  return out;
}

export function envList(vs: readonly ItemView[], projectIds: readonly number[] | null): EnvDef[] {
  const m = envDefs(projectIds);
  const extra = (name: string): void => {
    if (!name || m.has(name)) return;
    const d = DEFAULT_ENV[name];
    const ref = d && !S.set.resp ? d[1] : null;
    m.set(name, { name, label: d ? d[0] : name, refSource: ref, configured: false, col: envCol(name, ref) });
  };
  for (const v of vs) {
    for (const e of v.item.environments) extra(e.name);
    for (const t of v.application_tests) extra(t.environment);
    for (const c of v.comparisons) extra(c.name);
  }
  if (!m.size) {
    extra('dev');
    extra('preprod');
  }
  return [...m.values()];
}

// Environments shown for a set of records: configured ones first, then names
// that occur only in the data. With field selection, an environment is shown
// when its column (dev = branch-ref, preprod = tag-ref or unconfigured) is.
export function visibleEnvs(vs: readonly ItemView[], cols: readonly Column[] | null, projectIds: readonly number[] | null): EnvDef[] {
  return envList(vs, projectIds).filter((e) => !cols || cols.includes(e.col));
}

export function envLabel(name: string): string {
  return envDefs(null).get(name)?.label ?? DEFAULT_ENV[name]?.[0] ?? name;
}

/* ===================================================== MR source commit */
// The MR record's own reported source_sha first, then a source SHA the
// authored catalog actually reports. Absence from the catalog says nothing
// about the commit, and nothing is ever taken from a branch head, pipeline,
// name or tag.

export type MrSource =
  | { readonly known: true; readonly sha: string; readonly from: 'MR record' | 'authored catalog'; readonly other: string | null }
  | { readonly known: false; readonly why: string };

export function mrSource(m: MergeRequest, row: AuthoredMr | null): MrSource {
  const cat = row?.source_sha ?? row?.mr.source_sha ?? null;
  if (m.source_sha) return { known: true, sha: m.source_sha, from: 'MR record', other: cat && cat !== m.source_sha ? cat : null };
  if (cat) return { known: true, sha: cat, from: 'authored catalog', other: null };
  return {
    known: false,
    why: row
      ? 'Neither the MR record nor the authored catalog reports a source commit (source_sha is null or missing).'
      : 'The MR record reports no source commit (source_sha is null or missing). This MR is not in your authored catalog, which is unrelated to its commit.',
  };
}
export const mrSha = (s: MrSource): string | null => (s.known ? s.sha : null);

/* ============================================================ jobs */

export const jobCfgOf = (p: Pipeline, j: Job): JobConfiguration | null => S.d?.jobCfg.get(`${p.project.value}/${p.id.value}/${j.id.value}`) ?? null;

// Stage order: configured stage_order where known, otherwise the order in
// which the pipeline lists its stages.
export function stageOrder(jobs: readonly Job[], p: Pipeline | null = null): string[] {
  const out: string[] = [];
  for (const j of jobs) if (!out.includes(j.stage)) out.push(j.stage);
  if (!p) return out;
  const rank = (s: string): number => {
    let r = Number.POSITIVE_INFINITY;
    for (const j of jobs) {
      const c = j.stage === s ? jobCfgOf(p, j) : null;
      if (c && c.stage_order !== null && Number.isInteger(c.stage_order)) r = Math.min(r, c.stage_order);
    }
    return r;
  };
  return out
    .map((s, i) => ({ s, r: rank(s), i }))
    .sort((a, b) => a.r - b.r || a.i - b.i)
    .map((x) => x.s);
}

// Expected predecessors of a stage: operator expectation, not observed DAG.
export function stageDeps(p: Pipeline, jobs: readonly Job[], s: string): string[] {
  const out = new Set<string>();
  for (const j of jobs) if (j.stage === s) for (const d of jobCfgOf(p, j)?.depends_on ?? []) out.add(d);
  return [...out];
}

export interface JobGroup {
  readonly name: string;
  readonly current: Job;
  readonly attempts: readonly Job[];
}

export function groupJobs(jobs: readonly Job[]): JobGroup[] {
  const m = new Map<string, Job[]>();
  for (const j of jobs) {
    const list = m.get(j.name) ?? [];
    list.push(j);
    m.set(j.name, list);
  }
  const out: JobGroup[] = [];
  for (const [name, attempts] of m) {
    attempts.sort((a, b) => a.attempt - b.attempt || a.id.value - b.id.value);
    const live = attempts.filter((a) => !a.retried);
    const pool = live.length ? live : attempts;
    const current = pool[pool.length - 1];
    if (current) out.push({ name, current, attempts });
  }
  return out;
}

/* ========================================================== process */
// Builds the vertical delivery reading for one work item from typed fields.
// Commits get per-item letters (A, B, …) so equal SHAs read as the same
// commit; nothing is inferred from names alone.

const LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';

export interface Commit {
  readonly sha: string;
  readonly letter: string;
  readonly idx: number;
  readonly where: string[];
}
export interface BranchNode {
  readonly b: Branch;
  readonly c: Commit | null;
}
export interface MrNode {
  readonly m: MergeRequest;
  readonly sp: number;
  readonly br: BranchNode | null;
  readonly row: AuthoredMr | null;
  readonly src: MrSource;
  readonly c: Commit | null;
  readonly oc: Commit | null;
}
export interface TagNode {
  readonly t: Tag;
  readonly c: Commit | null;
  readonly sameAs: readonly BranchNode[];
}
export type PipeKind = 'ambiguous' | 'tag' | 'branch' | 'other';
export interface PipeNode {
  readonly p: Pipeline;
  readonly br: BranchNode | null;
  readonly tg: TagNode | null;
  readonly mrsByRef: readonly MrNode[];
  readonly kind: PipeKind;
  readonly c: Commit | null;
}
export interface PubNode {
  readonly x: Publish;
  readonly pp: PipeNode | null;
  readonly job: Job | null;
}
export interface DepNode {
  readonly d: Deployment;
  readonly br: BranchNode | null;
  readonly tg: TagNode | null;
  readonly c: Commit | null;
}
export interface EnvNode {
  readonly name: string;
  readonly def: EnvDef;
  readonly env: Environment | null;
  readonly cmp: Comparison | null;
  readonly deps: readonly DepNode[];
  readonly expC: Commit | null;
  readonly obsC: Commit | null;
  readonly test: ApplicationTestEvidence | null;
  readonly tC: Commit | null;
  readonly curC: Commit | null;
}
export interface Proc {
  readonly v: ItemView;
  readonly it: WorkItem;
  readonly commits: readonly Commit[];
  readonly branches: readonly BranchNode[];
  readonly mrs: readonly MrNode[];
  readonly tags: readonly TagNode[];
  readonly pipes: readonly PipeNode[];
  readonly pubs: readonly PubNode[];
  readonly envs: ReadonlyMap<string, EnvNode>;
  readonly envDefs: readonly EnvDef[];
}

export function processOf(v: ItemView): Proc {
  const cached = procCache.get(v);
  if (cached) return cached;
  const it = v.item;
  const commits = new Map<string, Commit>();
  const commit = (s: string | null | undefined, where: string): Commit | null => {
    if (!s) return null;
    let c = commits.get(s);
    if (!c) {
      c = { sha: s, letter: LETTERS[commits.size] ?? '?', idx: commits.size, where: [] };
      commits.set(s, c);
    }
    if (!c.where.includes(where)) c.where.push(where);
    return c;
  };
  const k2 = (p: number, n: string): string => `${p}/${n}`;

  const branches: BranchNode[] = it.branches.map((b) => ({ b, c: commit(b.sha, `branch ${b.name}`) }));
  const bBy = new Map(branches.map((x) => [k2(x.b.project.value, x.b.name), x] as const));

  const mrs: MrNode[] = it.merge_requests.map((m) => {
    const sp = m.source_project.value;
    const br = bBy.get(k2(sp, m.source_branch)) ?? null;
    const row = S.d?.catalog.get(k2(m.project.value, String(m.iid.value)))?.row ?? null;
    const src = mrSource(m, row);
    const c = commit(mrSha(src), `MR !${m.iid.value} source`);
    const oc = commit(src.known ? src.other : null, `MR !${m.iid.value} source per catalog`);
    return { m, sp, br, row, src, c, oc };
  });

  const tags: TagNode[] = it.tags.map((t) => ({
    t,
    c: commit(t.sha, `tag ${t.name}`),
    sameAs: branches.filter((x) => x.b.sha === t.sha && x.b.project.value === t.project.value),
  }));
  const tBy = new Map(tags.map((x) => [k2(x.t.project.value, x.t.name), x] as const));

  const pipes: PipeNode[] = it.pipelines.map((p) => {
    const br = bBy.get(k2(p.project.value, p.ref)) ?? null;
    const tg = tBy.get(k2(p.project.value, p.ref)) ?? null;
    const mrsByRef = mrs.filter((x) => x.sp === p.project.value && x.m.source_branch === p.ref);
    let kind: PipeKind = 'other';
    if (tg && (br || mrsByRef.length)) kind = 'ambiguous';
    else if (tg) kind = 'tag';
    else if (br || mrsByRef.length) kind = 'branch';
    return { p, br, tg, mrsByRef, kind, c: commit(p.sha, `pipeline #${p.id.value}`) };
  });

  const pubs: PubNode[] = it.publishes.map((x) => {
    const pp = pipes.find((y) => y.p.id.value === x.pipeline.value) ?? null;
    const job = pp ? (pp.p.jobs.find((j) => j.id.value === x.job.value) ?? null) : null;
    return { x, pp, job };
  });

  const envs = new Map<string, EnvNode>();
  const defs = envList([v], [it.identity.project.value]);
  for (const def of defs) {
    const name = def.name;
    const env = it.environments.find((e) => e.name === name) ?? null;
    const cmp = v.comparisons.find((c) => c.name === name) ?? null;
    const deps: DepNode[] = (env?.deployments ?? []).map((d) => ({
      d,
      br: bBy.get(k2(d.project.value, d.ref)) ?? null,
      tg: tBy.get(k2(d.project.value, d.ref)) ?? null,
      c: commit(d.sha, `${def.label} deployment #${d.id}`),
    }));
    const expC = commit(versionParts(env?.expected).sha, `${def.label} expected`);
    const obs = env?.observation;
    const obsC = obs?.kind === 'observed' ? commit(versionParts(obs.value).sha, `${def.label} runtime`) : null;
    const test = v.application_tests.find((t) => t.environment === name) ?? null;
    const tC = commit(versionParts(test?.target).sha, `${def.label} app-test target`);
    const curC = commit(versionParts(test?.current?.version).sha, `${def.label} app-test record`);
    envs.set(name, { name, def, env, cmp, deps, expC, obsC, test, tC, curC });
  }
  const P: Proc = { v, it, commits: [...commits.values()], branches, mrs, tags, pipes, pubs, envs, envDefs: defs };
  procCache.set(v, P);
  return P;
}

/**
 * Newest pipeline per (project, ref) among the given nodes, newest first.
 * A newer pipeline on another ref says nothing about this ref, and a ref
 * match is not commit identity; older pipelines stay counted by the caller.
 */
export function latestPerRef(list: readonly PipeNode[]): PipeNode[] {
  const best = new Map<string, PipeNode>();
  for (const x of list) {
    const k = `${x.p.project.value}/${x.p.ref}`;
    const cur = best.get(k);
    if (!cur || x.p.id.value > cur.p.id.value) best.set(k, x);
  }
  return [...best.values()].sort((a, b) => b.p.id.value - a.p.id.value);
}

/** Current (not superseded) failed jobs of a pipeline; retried attempts never count. */
export function failedJobs(p: Pipeline): Job[] {
  return groupJobs(p.jobs)
    .map((g) => g.current)
    .filter((j) => j.status === 'failed' && !j.retried);
}

/**
 * The operator-classified deploy jobs (role deploy + this environment) in the
 * item's own pipelines. A job is not a deployment record.
 */
export function deployJobsOf(P: Proc, env: string): { readonly p: Pipeline; readonly j: Job }[] {
  const out: { p: Pipeline; j: Job }[] = [];
  for (const x of P.pipes) {
    for (const g of groupJobs(x.p.jobs)) {
      const c = jobCfgOf(x.p, g.current);
      if (c?.role === 'deploy' && c.environment === env) out.push({ p: x.p, j: g.current });
    }
  }
  return out;
}

/** Short human name of a version: tag, then version text, then branch (the commit is shown separately). */
export function versionName(v: Parameters<typeof versionParts>[0]): string | null {
  const p = versionParts(v);
  return p.tag ?? p.version ?? p.branch;
}

/* ============================================================ stages */
// Process stages, in reading order. `col` maps to the closed column IDs used
// by saved views. Deployment stages come from the configured environments:
// branch-ref environments follow Publish, tag-ref environments follow the tag
// pipeline, and environments without a configured ref source come last.
// Runtime and tests list whichever environments are visible.

export type StageId = 'branch' | 'mr' | 'pipeline' | 'jobs' | 'publish' | 'deploy' | 'tag' | 'tagpipe' | 'runtime' | 'apptest' | 'commits';

export interface StageDef {
  readonly id: StageId;
  /** Environment name for deployment stages, otherwise null. */
  readonly env: string | null;
  /** Saved-view fields that show this stage (any of them). */
  readonly cols: readonly Column[];
  readonly label: string;
  readonly icon: IconName;
  readonly hint: string;
  readonly summary: boolean;
}

const stage = (id: StageId, cols: readonly Column[], label: string, icon: IconName, hint: string, summary = false): StageDef => ({
  id,
  env: null,
  cols,
  label,
  icon,
  hint,
  summary,
});

export function stagesFor(envs: readonly EnvDef[]): StageDef[] {
  // Runtime and application-test rows show whenever any environment field is.
  const envCols: Column[] = ['dev', 'preprod', ...envs.map((e) => e.col).filter((c) => c !== 'dev' && c !== 'preprod')];
  const dep = (e: EnvDef): StageDef => ({
    id: 'deploy',
    env: e.name,
    cols: [e.col],
    label: `${e.label} deployment`,
    icon: 'deploy',
    summary: false,
    hint: `GitLab deployment records for ${e.label} (ref and commit only)${e.refSource ? `; configured to deploy a ${e.refSource} ref` : '; ref source not configured'}`,
  });
  return [
    stage('branch', ['branch'], 'Branch & commit', 'branch', 'Branches associated with the work item and their head commits'),
    stage('mr', ['mr'], 'Merge request', 'mr', 'Merge requests and the source branch each one names'),
    stage('pipeline', ['pipeline'], 'Branch/MR pipeline', 'pipeline', 'Pipelines whose ref is one of the branches or an MR source branch'),
    stage(
      'jobs',
      ['jobs'],
      'Jobs & attempts',
      'job',
      'Jobs recorded inside those pipelines, by stage, with retried attempts; ★ marks operator-configured important jobs',
    ),
    stage('publish', ['publish'], 'Publish', 'publish', 'Publish evidence and the pipeline/job it references by ID'),
    ...envs.filter((e) => e.refSource === 'branch').map(dep),
    stage('tag', ['ref'], 'Tag', 'tag', 'Tags and the commit they point at; equal SHA is only a candidate link'),
    stage('tagpipe', ['ref'], 'Tag pipeline', 'pipeline', 'Pipelines whose ref is one of the tags'),
    ...envs.filter((e) => e.refSource === 'tag').map(dep),
    ...envs.filter((e) => e.refSource === null).map(dep),
    stage('runtime', envCols, 'Runtime identity', 'observe', 'Identity advertised by the running service, compared with the expected identity'),
    stage(
      'apptest',
      envCols,
      'Application tests',
      'test',
      'Manual application test records bound to an exact SHA/version, independent of pipelines and deployments',
    ),
    stage('commits', ['sha'], 'Commits', 'commit', 'Every commit seen for this item and where it appears', true),
  ];
}

export function visibleStages(cols: readonly Column[], envs: readonly EnvDef[]): StageDef[] {
  return stagesFor(envs).filter((s) => s.cols.some((c) => cols.includes(c)));
}
