// Provenance is progressively disclosed through a stable trigger and one
// out-of-flow popover. The trigger is a fixed 18px button; an operator
// override keeps a visible "Override" chip as its trigger so its existence
// stays obvious. Opening never changes the trigger box or any row height.
// `key` is unique per screen and doubles as the focus-restoration key.
//
// One popover at a time lives in #ev-layer, a sibling of #main, so
// re-renders never destroy it. Below and start-aligned by default, flipped
// above when there is no room, kept 8px inside the viewport, re-placed on
// any scroll/resize, closed when its trigger disappears or scrolls out of its
// container. Narrow or touch screens get a bottom sheet; the trigger never
// moves.

import type { Association } from './api';
import type { Kid } from './dom';
import { append, h, icon } from './dom';
import { S } from './state';

const ORIGIN: Readonly<Record<Association['origin'], readonly [string, string]>> = {
  api: ['API', 'Linked by GitLab API data'],
  convention: ['Convention', 'Linked by a naming convention only'],
  operator_override: ['Override', 'Linked by an operator override'],
  fixture: ['Fixture', 'Synthetic fixture association'],
};

interface EvEntry {
  readonly head: string;
  readonly body: () => Kid[];
}

const evReg = new Map<string, EvEntry>();
/** Called at the start of every render; triggers re-register as they render. */
export const clearEvidence = (): void => evReg.clear();

export function evidence(key: string, a: Association | null, extra: readonly Kid[] = [], heading: string | null = null): HTMLButtonElement | null {
  const more = extra.filter((x) => x != null && x !== false);
  if (!a && !more.length) return null;
  const origin = a ? ORIGIN[a.origin] : null;
  const ovr = a?.origin === 'operator_override';
  const head = a && origin ? `${origin[0]} association` : (heading ?? 'Details');
  evReg.set(key, {
    head,
    body: () => [
      a && origin ? h('p', null, h('strong', null, origin[0]), ` association. ${origin[1]}.`) : null,
      a?.reason ? h('p', null, h('span', { class: 'muted' }, 'Reason: '), a.reason) : null,
      a?.overrides ? h('p', null, h('span', { class: 'muted' }, 'Overrides: '), h('span', { class: 'mono' }, a.overrides)) : null,
      more.map((x) => (x instanceof Node && x.isConnected ? x.cloneNode(true) : x)),
    ],
  });
  const open = S.pop?.key === key;
  return h(
    'button',
    {
      type: 'button',
      class: ovr ? 'chip st t-manual ev-o' : 'ev-i',
      'data-ev': key,
      'data-fk': key,
      'aria-haspopup': 'dialog',
      'aria-expanded': String(open),
      'aria-controls': open ? 'ev-pop' : null,
      'aria-label': ovr ? 'Override: show association evidence' : `Evidence: ${head}`,
      'data-tip': ovr ? null : head,
      onclick: () => toggleEv(key),
    },
    icon('info', 'sm'),
    ovr ? h('span', null, 'Override') : null,
  );
}

/* ----------------------------------------------------------- engine */

const sheetQuery = window.matchMedia('(max-width: 599px), (pointer: coarse)');

export function evTrigger(): HTMLElement | null {
  if (!S.pop) return null;
  const t = document.querySelector(`[data-ev="${CSS.escape(S.pop.key)}"]`);
  return t instanceof HTMLElement ? t : null;
}

function toggleEv(key: string): void {
  if (S.pop?.key === key) closeEv(true);
  else openEv(key);
}

function openEv(key: string): void {
  const reg = evReg.get(key);
  const layer = document.getElementById('ev-layer');
  if (!reg || !layer) return;
  closeEv(false);
  S.pop = { key };
  const head = h('h2', { id: 'ev-pop-h', tabindex: '-1' }, `Evidence: ${reg.head}`);
  const pop = h(
    'div',
    { id: 'ev-pop', class: `ev-pop${sheetQuery.matches ? ' sheet' : ''}`, role: 'dialog', 'aria-labelledby': 'ev-pop-h', onkeydown: evKeys },
    h(
      'div',
      { class: 'ev-pop-h' },
      head,
      h(
        'button',
        { class: 'btn sm icon ghost', type: 'button', 'aria-label': 'Close evidence', title: 'Close (Esc)', onclick: () => closeEv(true) },
        icon('close', 'sm'),
      ),
    ),
    h('div', { class: 'ev-pop-b' }, reg.body()),
  );
  layer.replaceChildren(pop);
  placeEv();
  head.focus({ preventScroll: true });
}

export function closeEv(returnFocus: boolean): void {
  if (!S.pop) return;
  const t = evTrigger();
  S.pop = null;
  document.getElementById('ev-layer')?.replaceChildren();
  for (const x of document.querySelectorAll('[data-ev][aria-expanded="true"]')) {
    x.setAttribute('aria-expanded', 'false');
    x.removeAttribute('aria-controls');
  }
  if (returnFocus && t) t.focus({ preventScroll: true });
}

function anchorVisible(t: HTMLElement): boolean {
  const r = t.getBoundingClientRect();
  if (!r.width && !r.height) return false;
  for (let el = t.parentElement; el && el !== document.body; el = el.parentElement) {
    if (!el.matches('.mx-wrap, .insp-body, .main, .tbl-wrap, .pg')) continue;
    const c = el.getBoundingClientRect();
    if (r.bottom <= c.top || r.top >= c.bottom || r.right <= c.left || r.left >= c.right) return false;
  }
  return r.bottom > 0 && r.top < window.innerHeight;
}

// After a re-render the trigger's evidence may have changed (refresh,
// reload). Refresh the open popover's body unless focus is inside it.
export function refreshEvBody(): void {
  if (!S.pop) return;
  const reg = evReg.get(S.pop.key);
  const body = document.querySelector('#ev-pop .ev-pop-b');
  if (!reg || !body || body.contains(document.activeElement)) return;
  body.replaceChildren();
  append(body, reg.body());
}

export function placeEv(): void {
  if (!S.pop) return;
  const pop = document.getElementById('ev-pop');
  if (!pop) {
    S.pop = null;
    return;
  }
  const t = evTrigger();
  const sheet = sheetQuery.matches;
  if (!t || (!sheet && !anchorVisible(t))) {
    const inside = pop.contains(document.activeElement);
    closeEv(false);
    if (inside) (t ?? document.getElementById('main'))?.focus({ preventScroll: true });
    return;
  }
  for (const x of document.querySelectorAll(`[data-ev="${CSS.escape(S.pop.key)}"]`)) {
    x.setAttribute('aria-expanded', 'true');
    x.setAttribute('aria-controls', 'ev-pop');
  }
  pop.classList.toggle('sheet', sheet);
  if (sheet) {
    pop.style.removeProperty('top');
    pop.style.removeProperty('left');
    return;
  }
  // Position via CSSOM properties (permitted by the self-only CSP); this is
  // the only element whose geometry is set from script.
  const r = t.getBoundingClientRect();
  const vw = document.documentElement.clientWidth;
  const vh = window.visualViewport?.height ?? window.innerHeight;
  const pw = pop.offsetWidth;
  const ph = pop.offsetHeight;
  const gap = 6;
  const m = 8;
  let top = r.bottom + gap;
  if (top + ph > vh - m) {
    const above = r.top - gap - ph;
    top = above >= m ? above : Math.max(m, vh - m - ph);
  }
  const left = Math.max(m, Math.min(r.left, vw - m - pw));
  pop.style.setProperty('top', `${Math.round(top)}px`);
  pop.style.setProperty('left', `${Math.round(left)}px`);
}

let evRaf = 0;
function schedulePlace(): void {
  if (!S.pop || evRaf) return;
  evRaf = window.requestAnimationFrame(() => {
    evRaf = 0;
    placeEv();
  });
}
window.addEventListener('scroll', schedulePlace, { capture: true, passive: true });
window.addEventListener('resize', schedulePlace);
window.visualViewport?.addEventListener('resize', schedulePlace);
sheetQuery.addEventListener('change', schedulePlace);

// Tab past the end closes and continues after the trigger; Shift+Tab from
// the start returns to the trigger. No hard focus trap.
function evKeys(e: Event): void {
  if (!(e instanceof KeyboardEvent) || e.key !== 'Tab') return;
  const pop = e.currentTarget;
  if (!(pop instanceof HTMLElement)) return;
  const f = [...pop.querySelectorAll('a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])')];
  const t = evTrigger();
  const a = document.activeElement;
  if (e.shiftKey && (a === f[0] || a?.id === 'ev-pop-h')) {
    if (t) {
      e.preventDefault();
      t.focus({ preventScroll: true });
    }
  } else if (!e.shiftKey && (a === f[f.length - 1] || !f.length)) {
    closeEv(false);
    t?.focus({ preventScroll: true });
  }
}

// Outside pointer closes. Focus returns to the trigger only if it was inside
// the popover; a focusable element the user just pressed keeps its focus.
document.addEventListener(
  'pointerdown',
  (e) => {
    if (!S.pop) return;
    const pop = document.getElementById('ev-pop');
    const target = e.target;
    if (target instanceof Node && pop?.contains(target)) return;
    if (target instanceof Element && target.closest('[data-ev]')?.getAttribute('data-ev') === S.pop.key) return;
    const inside = pop?.contains(document.activeElement) ?? false;
    const t = evTrigger();
    closeEv(false);
    if (inside) t?.focus({ preventScroll: true });
  },
  true,
);

// An open evidence popover consumes Esc before menus and drawers (window
// capture phase runs before the document handlers).
window.addEventListener(
  'keydown',
  (e) => {
    if (e.key !== 'Escape' || !S.pop) return;
    e.preventDefault();
    e.stopPropagation();
    const pop = document.getElementById('ev-pop');
    const t = evTrigger();
    const inside = (pop?.contains(document.activeElement) ?? false) || document.activeElement === t;
    closeEv(false);
    if (inside || !document.activeElement || document.activeElement === document.body) t?.focus({ preventScroll: true });
  },
  true,
);
