ARG PYTHON_BASE
FROM ${PYTHON_BASE} AS dependencies
WORKDIR /app
ENV UV_NO_BUILD=1 UV_PYTHON_DOWNLOADS=never UV_NO_CONFIG=1
RUN python -m pip install --no-cache-dir uv==0.12.17
COPY pyproject.toml uv.lock ./
RUN uv sync --locked --no-dev --no-install-project --python /usr/local/bin/python
COPY gspace-0.1.0-py3-none-any.whl ./
RUN uv pip install --no-deps --python /app/.venv/bin/python gspace-0.1.0-py3-none-any.whl

FROM ${PYTHON_BASE} AS runtime
WORKDIR /app
COPY --from=dependencies /app/.venv /app/.venv
COPY runtime_container_probe.py asset-hashes.json ./
ENV PATH=/app/.venv/bin:/usr/local/bin:/usr/bin:/bin \
    HOME=/tmp PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 \
    RES_OPTIONS="timeout:1 attempts:1"
USER 65534:65534
ENTRYPOINT ["/app/.venv/bin/python", "/app/runtime_container_probe.py"]
