"""Deterministic public-event monitor for this task's own Claude CLI output.

Thinking blocks, token telemetry, prompt text, result bodies and environment/auth
metadata are never rendered. Timestamps are observation times, not invented
event occurrence times. This reader does not message or attach to Claude.
"""

from __future__ import annotations

import argparse
import json
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG_ROOT = ROOT / "output/claude"


def public_events(row: dict) -> list[dict]:
    if row.get("type") == "system" and row.get("subtype") == "init":
        return [{"event": "init", "model": row.get("model"), "state": "running"}]
    if row.get("type") == "assistant":
        return [
            {
                "event": "tool",
                "tool": block.get("name"),
                "file": block.get("input", {}).get("file_path"),
                "state": "running",
            }
            for block in row.get("message", {}).get("content", [])
            if block.get("type") == "tool_use"
        ]
    if row.get("type") == "user":
        return [
            {
                "event": "tool_result",
                "tool_use_id": block.get("tool_use_id"),
                "image_blocks": sum(
                    entry.get("type") == "image"
                    for entry in block.get("content", [])
                    if isinstance(entry, dict)
                )
                if isinstance(block.get("content"), list)
                else 0,
                "state": "error" if block.get("is_error") else "running",
            }
            for block in row.get("message", {}).get("content", [])
            if block.get("type") == "tool_result"
        ]
    if row.get("type") == "result":
        return [{"event": "result", "state": "error" if row.get("is_error") else "done"}]
    return []


def own_path(value: Path) -> Path:
    resolved = value.resolve()
    if not resolved.is_relative_to(LOG_ROOT.resolve()):
        raise ValueError("Only this task's own Claude logs may be monitored")
    return resolved


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stream", type=Path, default=LOG_ROOT / "clean-stream.jsonl")
    parser.add_argument("--status", type=Path, default=LOG_ROOT / "clean-status.json")
    parser.add_argument("--follow", action="store_true")
    args = parser.parse_args()
    stream = own_path(args.stream)
    status = own_path(args.status)
    with stream.open() as file:
        while True:
            line = file.readline()
            if line:
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                for event in public_events(row):
                    print(
                        json.dumps({"observed_at": datetime.now(UTC).isoformat(), **event}),
                        flush=True,
                    )
            elif not args.follow:
                break
            else:
                state = json.loads(status.read_text())
                if state["status"] != "running":
                    print(
                        json.dumps(
                            {
                                "observed_at": datetime.now(UTC).isoformat(),
                                "event": "process",
                                **state,
                            }
                        ),
                        flush=True,
                    )
                    break
                time.sleep(0.5)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
