"""Verify finite UX corrections against isolated synthetic state and requests.

Only owned loopback fixtures, no corporate services, credentials or lab effects.
Exercises disclosures/drafts/focus/error/busy and actual mobile geometry.
"""

from __future__ import annotations

import argparse
import json
import traceback
from pathlib import Path

from playwright.sync_api import expect, sync_playwright
from recovery_fixture import ROOT, recovery_fixture

from gspace.models import ProjectId
from gspace.operator_settings import SettingsChange, SettingsResponse
from gspace.pipeline_config import ProjectPipelineOverride


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--width", type=int, choices=(390, 1600))
    parser.add_argument("--theme", choices=("light", "dark"))
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to(ROOT / "output/verification"):
        parser.error("Use owned verification output")
    output.mkdir(parents=True, exist_ok=False)
    checks, captures, errors, outside = [], [], [], []
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            if args.width is not None and args.width != width:
                continue
            if args.theme is not None and args.theme != theme:
                continue
            with recovery_fixture(args.assets) as fixture:
                base = fixture.base
                context = browser.new_context(
                    viewport={"width": width, "height": 1100 if width == 1600 else 844},
                    service_workers="block",
                    reduced_motion="reduce",
                )
                page = context.new_page()
                page.set_default_timeout(5000)
                page.on("pageerror", lambda error: errors.append(str(error)))

                def guard(route, _request, base=base):
                    if route.request.url.startswith(base + "/"):
                        route.continue_()
                    else:
                        outside.append(route.request.url)
                        route.abort()

                context.route("**/*", guard)

                def go(path, page=page, base=base):
                    page.goto(base + "/#/" + path)
                    expect(page.locator("main")).to_be_visible()
                    page.wait_for_timeout(250)

                def capture(name, page=page, theme=theme, width=width):
                    # UI commits a render on animation frames; measure the
                    # settled state instead of the preceding frame's geometry.
                    page.evaluate(
                        "() => new Promise(r => requestAnimationFrame("
                        "() => requestAnimationFrame(r)))"
                    )
                    page.wait_for_function(
                        "limit => document.documentElement.scrollWidth <= limit",
                        arg=width + 1,
                        timeout=1500,
                    )
                    filename = f"{name}-{theme}-{width}.png"
                    page.screenshot(path=str(output / filename), animations="disabled")
                    captures.append(filename)

                def check(name, operation, theme=theme, width=width, page=page):
                    try:
                        operation()
                        checks.append(
                            {"check": name, "theme": theme, "width": width, "passed": True}
                        )
                    except Exception as error:
                        checks.append(
                            {
                                "check": name,
                                "theme": theme,
                                "width": width,
                                "passed": False,
                                "error": str(error)[:2000],
                                "trace": traceback.format_exc()[-1800:],
                                "document_width": page.evaluate(
                                    "document.documentElement.scrollWidth"
                                ),
                                "viewport_geometry": page.evaluate(
                                    "({inner:innerWidth,client:document.documentElement.clientWidth,"
                                    "body:document.body.scrollWidth,viewport:visualViewport.width,"
                                    "scrollX,scrollY})"
                                ),
                            }
                        )
                        page.screenshot(
                            path=str(output / f"failure-{len(checks)}-{theme}-{width}.png"),
                            animations="disabled",
                        )
                        page.keyboard.press("Escape")

                go("work")
                page.locator('[data-fk="theme"]').click()
                page.locator(f'[data-fk="ap-th-{theme}"]').click()
                page.keyboard.press("Escape")

                def folded_and_draft(page=page, go=go, capture=capture, base=base, width=width):
                    go("item/42/791")
                    record = page.locator('[data-fk="at-rec-42/791:dev"]')
                    group = page.get_by_role(
                        "group", name="Record the Dev application test outcome", include_hidden=True
                    )
                    expect(record).to_be_visible()
                    expect(group).not_to_be_visible()
                    dev = page.get_by_role("article", name="Dev environment", exact=True)
                    for fact in ("Deployed", "Deploy job", "Running", "Tested", "054396c6"):
                        expect(dev).to_contain_text(fact)
                    capture("item-folded")
                    record.focus()
                    page.keyboard.press("Enter")
                    expect(group).to_be_visible()
                    notes = page.locator('[data-fk="at-notes-42/791:dev"]')
                    notes.fill("Interrupted exact-version draft")
                    record.click()
                    expect(group).not_to_be_visible()
                    page.get_by_role("button", name="Detailed", exact=True).click()
                    if not group.is_visible():
                        record.click()
                    expect(notes).to_have_value("Interrupted exact-version draft")
                    go("work")
                    page.get_by_role("button", name="Overview", exact=True).click()
                    trigger = "sp-42/791-dev" if width == 390 else "rt-42/791-dev"
                    page.locator(f'[data-fk="{trigger}"]').click()
                    expect(page).to_have_url(base + "/#/item/42/791")
                    expect(group).to_be_visible()
                    expect(notes).to_have_value("Interrupted exact-version draft")
                    capture("record-focus-draft")

                check(
                    "Folded exact-target editor; keyboard; draft; Work CTA opens editor",
                    folded_and_draft,
                )

                def failed_record(page=page, go=go, capture=capture, base=base, width=width):
                    go("item/42/791")
                    group = page.get_by_role(
                        "group", name="Record the Dev application test outcome", include_hidden=True
                    )
                    record = page.locator('[data-fk="at-rec-42/791:dev"]')
                    if not group.is_visible():
                        record.click()
                    page.locator('[data-fk="at-notes-42/791:dev"]').fill(
                        "Keep my failed-save notes"
                    )
                    calls = []
                    held = []

                    def reject(route):
                        if route.request.method == "POST":
                            calls.append(route.request.method)
                            held.append(route)
                        else:
                            route.continue_()

                    page.route(base + "/api/preferences", reject)
                    try:
                        group.get_by_role("button", name="Failed", exact=True).click()
                        expect(group).to_contain_text("Saving")
                        record.click()
                        expect(group).not_to_be_visible()
                        for _ in range(40):
                            if held:
                                break
                            page.wait_for_timeout(50)
                        assert len(held) == 1
                        held.pop().fulfill(
                            status=502, json={"detail": "Synthetic save unavailable"}
                        )
                        expect(page.locator(".at-rec .inline-err")).to_contain_text("Not saved")
                        expect(group).to_be_visible()
                        page.wait_for_timeout(500)
                        assert calls == ["POST"], "No automatic retry"
                        go("work")
                        page.get_by_role("button", name="Overview", exact=True).click()
                        trigger = "sp-42/791-dev" if width == 390 else "rt-42/791-dev"
                        page.locator(f'[data-fk="{trigger}"]').click()
                        expect(group).to_be_visible()
                        expect(page.locator('[data-fk="at-notes-42/791:dev"]')).to_have_value(
                            "Keep my failed-save notes"
                        )
                        capture("record-save-error")
                    finally:
                        for route in held:
                            route.fulfill(status=502, json={"detail": "Synthetic save unavailable"})
                        page.unroute(base + "/api/preferences", reject)

                check(
                    "Failed record keeps editor/error/draft across navigation; no retry",
                    failed_record,
                )

                def busy_record(page=page, go=go, capture=capture, base=base):
                    go("item/42/791")
                    group = page.get_by_role(
                        "group", name="Record the Dev application test outcome", include_hidden=True
                    )
                    if not group.is_visible():
                        page.locator('[data-fk="at-rec-42/791:dev"]').click()
                    held = []

                    def hold(route):
                        if route.request.method == "POST":
                            held.append((route, route.fetch()))
                        else:
                            route.continue_()

                    page.route(base + "/api/preferences", hold)
                    try:
                        group.get_by_role("button", name="Passed", exact=True).click()
                        expect(group).to_contain_text("Saving")
                        expect(
                            group.get_by_role("button", name="Passed", exact=True)
                        ).to_be_disabled()
                        expect(group).to_be_visible()
                        for _ in range(40):
                            if held:
                                break
                            page.wait_for_timeout(50)
                        assert len(held) == 1
                        capture("record-saving")
                        route, response = held.pop()
                        route.fulfill(response=response)
                        expect(group).not_to_contain_text("Saving")
                        data = page.request.get(base + "/api/items/42/791").json()
                        assert data["application_tests"][0]["outcome"] == "passed"
                        assert not data["checklist"]["dev_test"]
                        assert data["item"]["merge_requests"][0]["draft"]
                        go("item/42/791")
                        history = page.locator('[data-fk="at-hist-42/791:dev"]')
                        expect(history).to_be_visible()
                        history.click()
                        expect(page.locator(".at-hist[open]")).to_contain_text(
                            "Keep my failed-save notes"
                        )
                    finally:
                        for route, response in held:
                            route.fulfill(response=response)
                        page.unroute(base + "/api/preferences", hold)

                check(
                    "Busy save; exact result/history; checklist and draft stay separate",
                    busy_record,
                )

                def mobile_and_access(page=page, go=go, capture=capture, width=width, base=base):
                    go("work")
                    page.get_by_role("button", name="Overview", exact=True).click()
                    expect(page.locator("main")).to_contain_text("Preserve passenger preferences")
                    if width == 390:
                        first = page.get_by_role(
                            "link",
                            name="Preserve passenger preferences during rescheduling",
                            exact=True,
                        ).first
                        box = first.bounding_box()
                        assert box and box["y"] < 500, box
                        attention = page.locator('[aria-label="Attention in the shown items"]')
                        expect(attention).to_be_visible()
                        differs = attention.get_by_role(
                            "button", name="Running version differs", exact=False
                        )
                        expect(differs).to_be_visible()
                        assert "observed identity" in (differs.get_attribute("title") or "")
                        differs.click()
                        expect(differs).to_have_attribute("aria-pressed", "true")
                        expect(page.locator("main")).to_contain_text("Add airport transfer")
                        differs.click()
                        expect(differs).to_have_attribute("aria-pressed", "false")
                        capture("work-compact-top")
                        page.locator('[data-fk="appmenu"]').click()
                        page.locator('[data-fk="menu-settings"]').click()
                        expect(page).to_have_url(base + "/#/settings")
                    go("access")
                    expect(page.locator("main")).to_contain_text("Write configured")
                    expect(page.locator("main")).to_contain_text("inactive here")
                    expect(page.locator("main")).not_to_contain_text(
                        "Write enabled by configuration"
                    )
                    assert page.request.post(base + "/api/actions/execute", data={}).status == 403
                    capture("access-inactive-writes")

                check(
                    "Compact mobile top/Settings; inactive configured writes truthful",
                    mobile_and_access,
                )

                def effective_and_invalid(
                    page=page, go=go, capture=capture, base=base, fixture=fixture, width=width
                ):
                    go("settings")
                    expect(page.locator(".eff")).to_have_count(1)
                    if width == 390:
                        page.locator('[data-fk="set-eff"]').click()
                    expect(page.locator("main")).to_contain_text(
                        "All configured projects (2) use the global rules"
                    )
                    capture("settings-global-rules")
                    current = SettingsResponse.model_validate(
                        page.request.get(base + "/api/settings").json()
                    )
                    updated = current.settings.model_copy(
                        update={
                            "project_pipeline_overrides": (
                                ProjectPipelineOverride(
                                    project=ProjectId(value=42),
                                    important_job_patterns=("custom-*",),
                                ),
                            )
                        }
                    )
                    change = SettingsChange(revision=current.revision, settings=updated)
                    response = page.request.post(
                        base + "/api/settings",
                        data=change.model_dump_json(),
                        headers={"Content-Type": "application/json"},
                    )
                    assert response.status == 200
                    page.locator('[data-fk="set-reload"]').click()
                    expect(page.locator(".eff")).to_have_count(2)
                    expect(page.locator(".eff").first).to_contain_text("Project override")
                    expect(page.locator(".eff").first).to_contain_text("custom-*")
                    expect(page.locator("main")).not_to_contain_text(
                        "All configured projects (2) use the global rules"
                    )
                    capture("settings-project-rules")
                    good = fixture.config_path.read_bytes()
                    try:
                        fixture.config_path.write_text("timezone = [")
                        page.locator('[data-fk="set-reload"]').click()
                        expect(page.locator("main")).to_contain_text("invalid")
                        expect(page.locator(".note")).to_contain_text("Last valid revision")
                        expect(page.locator(".note")).not_to_contain_text("Saved; revision")
                        expect(page.locator('[data-fk="retry-settings-load"]')).to_have_count(0)
                        expect(page.locator('[data-fk="set-save"]')).to_be_disabled()
                        assert (
                            fixture.service.config.project_pipeline_overrides
                            == updated.project_pipeline_overrides
                        )
                        capture("settings-invalid-inline")
                    finally:
                        fixture.config_path.write_bytes(good)
                        page.locator('[data-fk="set-reload"]').click()

                check(
                    "Global rules dedup; mixed provenance; invalid inline last-good",
                    effective_and_invalid,
                )

                def interrupted_settings(
                    page=page, go=go, capture=capture, base=base, fixture=fixture
                ):
                    go("settings")
                    expect(page.locator('[data-fk="set-reload"]')).to_be_enabled()
                    page.locator('[data-fk="set-tz"]').fill("Asia/Tokyo")
                    good = fixture.config_path.read_bytes()
                    held = []

                    def hold(route):
                        held.append((route, route.fetch()))

                    page.route(base + "/api/settings", hold)
                    try:
                        fixture.config_path.write_text("timezone = [")
                        page.evaluate("window.dispatchEvent(new Event('focus'))")
                        page.wait_for_timeout(250)
                        assert len(held) == 1
                        go("work")
                        route, response = held.pop()
                        assert response.status == 400
                        route.fulfill(response=response)
                        expect(page.locator('[data-fk="retry-settings-load"]')).to_be_visible()
                        expect(page.locator('[data-fk="retry-settings-load"]')).to_have_text(
                            "Reload"
                        )
                        go("settings")
                        expect(page.locator('[data-fk="set-tz"]')).to_have_value("Asia/Tokyo")
                        expect(page.locator("main .inline-err")).to_contain_text("Operator file")
                        expect(page.locator('[data-fk="retry-settings-load"]')).to_have_count(0)
                        expect(page.locator('[data-fk="set-save"]')).to_be_disabled()
                        capture("settings-interrupted-return")
                        go("work")
                        expect(page.locator('[data-fk="retry-settings-load"]')).to_be_visible()
                        go("settings")
                        expect(page.locator('[data-fk="retry-settings-load"]')).to_have_count(0)
                        fixture.config_path.write_bytes(good)
                        page.unroute(base + "/api/settings", hold)
                        page.locator('[data-fk="set-reload"]').click()
                        expect(page.locator('[data-fk="set-save"]')).to_be_enabled()
                        expect(page.locator('[data-fk="set-tz"]')).to_have_value("Asia/Tokyo")
                    finally:
                        for route, response in held:
                            route.fulfill(response=response)
                        page.unroute(base + "/api/settings", hold)
                        fixture.config_path.write_bytes(good)

                check(
                    "Interrupted Settings read; feedback elsewhere; dirty return; safe Save",
                    interrupted_settings,
                )

                def rare_tools(page=page, go=go, capture=capture):
                    go("item/42/791")
                    previous = page.locator('[data-fk="prev-tag"]')
                    expect(previous).not_to_be_visible()
                    page.locator('[data-fk="side-previews:42/791"]').click()
                    expect(previous).to_be_visible()
                    previous.fill("flight-2.4.08")
                    page.locator('[data-fk="pv-tag"]').click()
                    expect(page.locator(".preview-result")).to_contain_text("Not executed")
                    expect(page.locator(".preview-result")).to_contain_text("flight-2.4.09")
                    expect(page.locator(".preview-result")).to_contain_text(
                        "Remote mutation available: no"
                    )
                    page.locator('[data-fk="side-overrides:42/791"]').click()
                    page.locator('[data-fk="ov-val"]').fill("passenger-followup")
                    page.locator('[data-fk="ov-reason"]').fill("Interrupted association draft")
                    page.locator('[data-fk="grp-new-open"]').click()
                    page.locator('[data-fk="grp-new"]').fill("Synthetic review group")
                    page.get_by_role("button", name="Detailed", exact=True).click()
                    expect(page.locator('[data-fk="prev-tag"]')).to_have_value("flight-2.4.08")
                    expect(page.locator('[data-fk="ov-val"]')).to_have_value("passenger-followup")
                    expect(page.locator('[data-fk="ov-reason"]')).to_have_value(
                        "Interrupted association draft"
                    )
                    expect(page.locator('[data-fk="grp-new"]')).to_have_value(
                        "Synthetic review group"
                    )
                    go("work")
                    go("item/42/791")
                    expect(page.locator('[data-fk="ov-reason"]')).to_have_value(
                        "Interrupted association draft"
                    )
                    expect(page.locator('[data-fk="grp-new"]')).to_have_value(
                        "Synthetic review group"
                    )
                    capture("rare-tools-preserved")

                check(
                    "Reachable tag preview never executes; override/group drafts survive rerenders",
                    rare_tools,
                )
                context.close()
        browser.close()
    report = {
        "purpose": "Actual finite UX corrections both-theme desktop/mobile journeys",
        "checks": checks,
        "captures": captures,
        "browser_errors": errors,
        "outside": outside,
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    failed = [c for c in checks if not c["passed"]]
    print(
        json.dumps(
            {
                "checks": len(checks),
                "failed": len(failed),
                "captures": len(captures),
                "errors": errors,
                "outside": outside,
            }
        )
    )
    return int(bool(failed or errors or outside))


if __name__ == "__main__":
    raise SystemExit(main())
