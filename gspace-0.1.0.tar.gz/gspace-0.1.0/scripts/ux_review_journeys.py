"""Actual empty/error/back/close journeys and viewport-only synthetic UI captures.

Uses only fresh RecoveryFixture state and owned loopback browser requests.
Never reads authentication files, starts the lab or enables action effects.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import traceback
from pathlib import Path

from playwright.sync_api import expect, sync_playwright
from recovery_fixture import INERT_MARKER, ROOT, recovery_fixture


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    if not output.is_relative_to(ROOT / "output/verification"):
        parser.error("Use owned verification output")
    output.mkdir(parents=True, exist_ok=False)
    checks = []
    captures = []
    errors = []
    outside = []
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            with recovery_fixture() as fixture:
                base = fixture.base
                context = browser.new_context(
                    viewport={"width": width, "height": 1100 if width == 1600 else 844},
                    service_workers="block",
                )
                page = context.new_page()
                page.set_default_timeout(5000)
                page.on("pageerror", lambda error: errors.append(str(error)))

                def guard(route, _request, base=base):
                    if route.request.url.startswith(base + "/"):
                        route.continue_()
                    else:
                        outside.append(route.request.url)
                        route.abort()

                context.route("**/*", guard)

                def go(path, page=page, base=base):
                    page.goto(base + "/#/" + path)
                    expect(page.locator("main")).to_be_visible()
                    page.wait_for_timeout(250)

                def capture(name, page=page, theme=theme, width=width):
                    expect(page.locator("body")).not_to_contain_text(INERT_MARKER)
                    assert page.evaluate("document.documentElement.scrollWidth") <= width + 1
                    filename = f"{name}-{theme}-{width}.png"
                    page.screenshot(path=str(output / filename), animations="disabled")
                    captures.append(
                        {
                            "file": filename,
                            "viewport_only": True,
                            "geometry": page.locator("main").evaluate(
                                "e => ({scrollTop:e.scrollTop,scrollHeight:e.scrollHeight,"
                                "clientHeight:e.clientHeight,documentHeight:document.documentElement.scrollHeight})"
                            ),
                        }
                    )

                def check(name, operation, page=page, theme=theme, width=width):
                    try:
                        operation()
                        checks.append(
                            {"check": name, "theme": theme, "width": width, "passed": True}
                        )
                    except Exception as error:
                        checks.append(
                            {
                                "check": name,
                                "theme": theme,
                                "width": width,
                                "passed": False,
                                "error": str(error)[:1600],
                                "trace": traceback.format_exc()[-1800:],
                            }
                        )
                        page.keyboard.press("Escape")

                go("work")
                page.locator('[data-fk="theme"]').click()
                page.locator(f'[data-fk="ap-th-{theme}"]').click()
                page.keyboard.press("Escape")

                def viewport_scroll(page=page, go=go, capture=capture):
                    for name, route in (
                        ("work", "work"),
                        ("compare", "compare"),
                        ("item", "item/42/791"),
                        ("settings", "settings"),
                    ):
                        go(route)
                        capture(name + "-viewport-top")
                        page.locator("main").evaluate(
                            "e => {e.scrollTop=Math.max(0,(e.scrollHeight-e.clientHeight)/2)}"
                        )
                        capture(name + "-viewport-middle")
                        page.locator("main").evaluate("e => {e.scrollTop=e.scrollHeight}")
                        capture(name + "-viewport-bottom")

                check("Actual viewport top/middle/bottom retain reachable content", viewport_scroll)

                def empty_states(page=page, go=go, capture=capture, base=base):
                    go("work")
                    page.locator('[data-fk="q-work"]').fill("synthetic-no-match-20261011")
                    expect(page.locator("main")).to_contain_text(
                        "No work items match these filters"
                    )
                    capture("empty-work")
                    page.locator('[data-fk="q-work"]').fill("")
                    expect(page.locator("main")).to_contain_text("Preserve passenger preferences")
                    go("pipelines")
                    page.locator('[data-fk="q-pipelines"]').fill("synthetic-no-match-20261011")
                    expect(page.locator("main")).to_contain_text("No pipelines match these filters")
                    capture("empty-pipelines")
                    page.locator('[data-fk="q-pipelines"]').fill("")
                    expect(page.locator("main")).to_contain_text("#9201")
                    go("compare")
                    page.locator('[data-fk="cmp-clear"]').click()
                    expect(page.get_by_role("dialog")).to_be_visible()
                    page.keyboard.press("Escape")
                    expect(page.get_by_role("dialog")).to_have_count(0)
                    assert len(page.request.get(base + "/api/preferences").json()["selected"]) == 4
                    page.locator('[data-fk="cmp-clear"]').click()
                    page.get_by_role("dialog").get_by_role(
                        "button", name="Clear selection", exact=True
                    ).click()
                    expect(page.locator("main")).to_contain_text("No items selected")
                    capture("empty-compare")
                    assert not page.request.get(base + "/api/preferences").json()["selected"]
                    page.get_by_role("link", name="Go to Work items", exact=True).click()
                    expect(page.locator("main h1")).to_have_text("Work items")

                check(
                    "Empty filters recover; cancelled clear preserves shared selection",
                    empty_states,
                )

                def back_close(page=page, go=go, capture=capture, width=width):
                    go("mrs")
                    page.locator('main a[href="#/mrs/42/154"]').first.click()
                    expect(page.locator(".inspector")).to_be_visible()
                    capture("mr-open")
                    page.get_by_role("link", name="Close details", exact=True).click()
                    expect(page.locator(".inspector")).to_have_count(0)
                    page.go_back()
                    expect(page.locator(".inspector")).to_be_visible()
                    page.keyboard.press("Escape")
                    expect(page.locator(".inspector")).to_have_count(0)
                    capture("mr-closed")
                    if width == 390:
                        page.locator('[data-fk="appmenu"]').click()
                        expect(page.locator('[data-fk="menu-settings"]')).to_be_visible()
                        page.keyboard.press("Escape")
                        expect(page.locator(".app-menu[open]")).to_have_count(0)
                        page.locator('[data-fk="appmenu"]').click()
                        page.locator('[data-fk="menu-settings"]').click()
                        expect(page.locator("main h1")).to_have_text("Settings")
                        expect(page.locator(".app-menu[open]")).to_have_count(0)
                        page.go_back()
                        expect(page.locator("main h1")).to_have_text("Merge requests")

                check("Inspector close/back/Escape and mobile Menu/back remain usable", back_close)

                def read_error(page=page, go=go, capture=capture):
                    calls = []
                    failing = [True]

                    def unavailable(route):
                        calls.append(route.request.url)
                        if failing[0]:
                            route.fulfill(
                                status=502,
                                content_type="application/json",
                                body='{"detail":"Synthetic unavailable read","code":"transport"}',
                            )
                        else:
                            route.continue_()

                    page.route("**/api/dashboard*", unavailable)
                    try:
                        go("work")
                        # Hash-only navigation retains the already loaded dashboard.
                        # Reload the document to exercise an actual failed initial read.
                        page.reload()
                        expect(page.locator("main")).to_contain_text("could not be loaded")
                        capture("read-error")
                        page.wait_for_timeout(400)
                        assert len(calls) == 1, "No automatic retry is permitted"
                        failing[0] = False
                        page.locator("main").get_by_role(
                            "button", name="Try again", exact=True
                        ).click()
                        expect(page.locator("main")).to_contain_text(
                            "Preserve passenger preferences"
                        )
                        assert len(calls) == 2
                        capture("read-error-recovered")
                    finally:
                        page.unroute("**/api/dashboard*", unavailable)
                    go("item/42/99999")
                    expect(page.locator("main")).to_contain_text(
                        "Work item #99999 (project 42) is unavailable"
                    )
                    capture("missing-item")
                    page.get_by_role("link", name="Back to Work items", exact=True).click()
                    expect(page.locator("main h1")).to_have_text("Work items")

                check(
                    "Read failure has deliberate recovery; missing item has a usable back action",
                    read_error,
                )
                context.close()
        browser.close()
    report = {
        "purpose": "Actual owned viewport and empty/error/back/close/mobile journeys",
        "checks": checks,
        "captures": captures,
        "browser_errors": errors,
        "outside": outside,
        "assets": {
            name: hashlib.sha256((ROOT / "frontend-new" / name).read_bytes()).hexdigest()
            for name in ("app.js", "styles.css", "index.html", "theme.js")
        },
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    failed = sum(not entry["passed"] for entry in checks)
    print(json.dumps({"checks": len(checks), "failed": failed, "captures": len(captures)}))
    return int(bool(failed or errors or outside))


if __name__ == "__main__":
    raise SystemExit(main())
