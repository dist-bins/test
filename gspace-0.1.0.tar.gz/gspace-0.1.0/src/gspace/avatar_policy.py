"""Operator-only opt-in project avatar policy. Browser inputs never define remote URLs."""

from __future__ import annotations

import ipaddress
from typing import Self

from pydantic import Field, model_validator

from gspace.models import Model


class AvatarPolicy(Model, frozen=True):
    enabled: bool = Field(default=False, strict=True)
    allowed_networks: tuple[str, ...] = Field(default=(), max_length=16)
    max_bytes: int = Field(default=131072, strict=True, ge=128, le=1048576)
    max_dimension: int = Field(default=512, strict=True, ge=1, le=1024)
    timeout_seconds: float = Field(default=5.0, gt=0, le=10)
    ttl_seconds: int = Field(default=3600, strict=True, ge=1, le=21600)
    max_cached: int = Field(default=64, strict=True, ge=1, le=128)

    @model_validator(mode="after")
    def networks(self) -> Self:
        for network in self.allowed_networks:
            ipaddress.ip_network(network, strict=True)
        if len(set(self.allowed_networks)) != len(self.allowed_networks):
            raise ValueError("duplicate avatar network")
        return self
