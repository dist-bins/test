"""Verify bounded review findings and capture previously unpictured UI states.

All settings conflicts/invalid files are newly owned synthetic fixture state.
No authentication file, corporate transport or action effect is used.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import traceback
from pathlib import Path

from playwright.sync_api import expect, sync_playwright
from recovery_fixture import INERT_MARKER, ROOT, recovery_fixture


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    if not output.is_relative_to(ROOT / "output/verification"):
        parser.error("Use owned verification output")
    output.mkdir(parents=True, exist_ok=False)
    checks = []
    outside = []
    errors = []
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            with recovery_fixture() as fixture:
                base = fixture.base
                context = browser.new_context(
                    viewport={"width": width, "height": 1100 if width == 1600 else 844},
                    service_workers="block",
                )

                def guard(route, _request, *, base=base):
                    if route.request.url.startswith(base + "/"):
                        route.continue_()
                    else:
                        outside.append(route.request.url)
                        route.abort()

                context.route("**/*", guard)
                page = context.new_page()
                page.set_default_timeout(5000)
                page.on("pageerror", lambda error: errors.append(str(error)))

                def go(path, page=page, base=base):
                    page.goto(base + "/#/" + path)
                    page.wait_for_selector("main")
                    page.wait_for_timeout(250)

                def capture(name, page=page, theme=theme, width=width):
                    expect(page.locator("body")).not_to_contain_text(INERT_MARKER)
                    assert page.evaluate("document.documentElement.scrollWidth") <= width + 1
                    page.screenshot(
                        path=str(output / f"{name}-{theme}-{width}.png"), animations="disabled"
                    )

                def check(name, operation, theme=theme, width=width, page=page):
                    try:
                        operation()
                        checks.append(
                            {"check": name, "theme": theme, "width": width, "passed": True}
                        )
                    except Exception as error:
                        checks.append(
                            {
                                "check": name,
                                "theme": theme,
                                "width": width,
                                "passed": False,
                                "error": str(error)[:1400],
                                "trace": traceback.format_exc()[-1600:],
                            }
                        )
                        page.keyboard.press("Escape")

                go("work")
                page.locator('[data-fk="theme"]').click()
                page.locator(f'[data-fk="ap-th-{theme}"]').click()
                page.keyboard.press("Escape")

                def unknown(page=page, go=go, capture=capture):
                    go("work")
                    trigger = page.locator('[data-ev="ev-unk-42/791"]')
                    trigger.focus()
                    page.keyboard.press("Enter")
                    expect(page.locator("#ev-pop")).to_be_visible()
                    expect(page.locator("#ev-pop")).to_contain_text("passenger-followup")
                    expect(page.locator("#ev-pop")).to_contain_text("Preprod running version")
                    capture("unknown-evidence-open")
                    page.keyboard.press("Escape")
                    expect(page.locator("#ev-pop")).not_to_be_visible()

                check("Compact unknown reasons remain reachable by keyboard/touch", unknown)

                def modes(page=page, width=width, go=go, capture=capture):
                    go("compare")
                    if width == 1600:
                        tag = page.locator(".fr-tag.same")
                        expect(tag).to_be_visible()
                        expect(tag).to_contain_text("Same outcome; versions may differ")
                        cells = tag.locator("td")
                        assert cells.count() == 4
                        for cell in cells.all():
                            expect(cell).to_contain_text("candidate")
                            expect(
                                cell.get_by_role(
                                    "button", name="Override: show association evidence"
                                )
                            ).to_be_visible()
                        trigger = cells.first.get_by_role(
                            "button", name="Override: show association evidence"
                        )
                        trigger.focus()
                        page.keyboard.press("Enter")
                        expect(page.locator("#ev-pop")).to_contain_text("Override association")
                        expect(page.locator("#ev-pop")).to_contain_text("flight-2.4.08")
                        page.keyboard.press("Escape")
                        capture("compare-candidate-qualifiers")
                        page.locator('[data-fk="rx-compare-pipeline"]').click()
                        expect(page.locator(".fr-pipeline")).to_contain_text("unit-tests")
                        capture("aligned-evidence-open")
                    page.get_by_role("button", name="Detailed", exact=True).click()
                    expect(page.locator(".mx").first).to_be_visible()
                    capture("compare-detailed")
                    page.get_by_role("button", name="Overview", exact=True).click()

                check("Candidate qualifier and complete aligned/Detailed evidence", modes)

                def resources(page=page, width=width, go=go, capture=capture):
                    for scope in ("mrs", "branches", "pipelines"):
                        go(scope)
                        expect(page.locator(".vgrid").first).to_be_visible()
                        if width == 390:
                            page.locator(f'[data-fk="vopts-{scope}"]').click()
                        page.locator(f'[data-fk="or-r-{scope}"]').click()
                        page.keyboard.press("Escape")
                        if width == 1600:
                            positions = page.locator(".vc-flow").evaluate_all(
                                "els => els.slice(0, 5).map(e => e.getBoundingClientRect().x)"
                            )
                            assert max(positions) - min(positions) < 1
                            heights = page.locator(".vc-b > .chip").evaluate_all(
                                "els => els.map(e => e.getBoundingClientRect().height)"
                            )
                            assert all(height < 28 for height in heights)
                        capture(f"{scope}-rows-aligned")
                        if width == 390:
                            page.locator(f'[data-fk="vopts-{scope}"]').click()
                        else:
                            page.locator(f'[data-fk="colsbtn-{scope}"]').click()
                        field = page.locator(f'[data-fk="col-{scope}-sha"]')
                        expect(field).to_be_checked()
                        field.uncheck()
                        page.keyboard.press("Escape")
                        labels = page.locator(".vc-flow .vc-l").all_text_contents()
                        assert "Commit" not in labels and "Head" not in labels
                        capture(f"{scope}-chosen-fields")
                        if width == 390:
                            page.locator(f'[data-fk="vopts-{scope}"]').click()
                        else:
                            page.locator(f'[data-fk="colsbtn-{scope}"]').click()
                        field.check()
                        page.keyboard.press("Escape")

                check("Resource Rows align and variable chosen fields remain effective", resources)

                def navigation(page=page, width=width, go=go, capture=capture):
                    go("work")
                    if width == 390:
                        page.locator('[data-fk="appmenu"]').click()
                        expect(page.locator('[data-fk="menu-settings"]')).to_be_visible()
                        capture("mobile-menu-open")
                        page.keyboard.press("Escape")
                    page.locator('[data-fk="theme"]').click()
                    expect(page.locator('[data-fk="ap-th-dark"]')).to_be_visible()
                    capture("appearance-open")
                    page.keyboard.press("Escape")
                    go("item/42/791")
                    page.locator('[data-fk="graph-toggle"]').click()
                    expect(page.locator("#item-graph")).to_have_attribute("open", "")
                    expect(page.locator("#item-graph")).to_contain_text("ground-service")
                    page.locator("#item-graph").scroll_into_view_if_needed()
                    capture("native-graph-open")

                check("Menu, Appearance and native graph remain discoverable", navigation)

                def settings(page=page, fixture=fixture, base=base, go=go, capture=capture):
                    go("settings")
                    page.locator('[data-fk="set-branch"]').fill("review-{iid}")
                    expect(page.locator(".savebar")).to_contain_text("Unsaved")
                    page.locator(".savebar").scroll_into_view_if_needed()
                    capture("settings-unsaved")
                    latest = page.request.get(base + "/api/settings").json()
                    latest["settings"]["timezone"] = "UTC"
                    assert (
                        page.request.post(
                            base + "/api/settings",
                            data={"revision": latest["revision"], "settings": latest["settings"]},
                        ).status
                        == 200
                    )
                    with page.expect_response(
                        lambda response: (
                            response.url == base + "/api/settings"
                            and response.request.method == "POST"
                        )
                    ) as saved:
                        page.locator('[data-fk="set-save"]').click()
                    assert saved.value.status == 409
                    expect(page.locator('[data-fk="set-branch"]')).to_have_value("review-{iid}")
                    capture("settings-conflict")
                    page.get_by_role(
                        "button", name="Load latest and keep my edits", exact=True
                    ).click()
                    expect(page.locator('[data-fk="set-save"]')).to_be_enabled()
                    with page.expect_response(
                        lambda response: (
                            response.url == base + "/api/settings"
                            and response.request.method == "POST"
                        )
                    ) as reapplied:
                        page.locator('[data-fk="set-save"]').click()
                    assert reapplied.value.status == 200
                    applied = reapplied.value.json()
                    assert applied["settings"]["branch_template"] == "review-{iid}", applied
                    expect(page.locator('[data-fk="set-save"]')).to_be_disabled()
                    assert fixture.service.config.branch_template == "review-{iid}", (
                        "Service differs before invalid-file injection",
                        fixture.service.config.branch_template,
                    )
                    good = fixture.config_path.read_text()
                    injection = fixture.config_path.with_suffix(".invalid-test.tmp")
                    injection.write_text('secret_marker="review-inert-hidden"\n[broken')
                    injection.replace(fixture.config_path)
                    page.locator('[data-fk="set-reload"]').click()
                    expect(page.locator("main")).to_contain_text("invalid")
                    expect(page.locator("body")).not_to_contain_text("review-inert-hidden")
                    expect(page.locator(".note")).to_contain_text("Last valid revision")
                    expect(page.locator(".note")).not_to_contain_text("Saved; revision")
                    expect(page.locator(".note")).to_contain_text("No GitLab request was made")
                    assert fixture.service.config.branch_template == "review-{iid}", (
                        "Last-good differs after invalid-file injection",
                        fixture.service.config.branch_template,
                    )
                    capture("settings-invalid-last-good")
                    injection.write_text(good)
                    injection.replace(fixture.config_path)
                    page.locator('[data-fk="set-reload"]').click()
                    expect(page.locator("main")).to_contain_text("In use locally")
                    expect(page.locator(".note")).to_contain_text("Saved; revision")

                check(
                    "Settings unsaved/conflict/invalid states preserve draft and last-good",
                    settings,
                )
                context.close()
        browser.close()
    report = {
        "purpose": "Actual bounded findings and previously unpictured states",
        "checks": checks,
        "browser_errors": errors,
        "outside": outside,
        "compiled_assets": {
            name: hashlib.sha256((ROOT / "frontend-new" / name).read_bytes()).hexdigest()
            for name in ("index.html", "app.js", "theme.js", "styles.css")
        },
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    failures = sum(not c["passed"] for c in checks) + len(errors) + len(outside)
    print(
        json.dumps(
            {"checks": len(checks), "failed": failures, "report": str(output / "report.json")}
        )
    )
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
