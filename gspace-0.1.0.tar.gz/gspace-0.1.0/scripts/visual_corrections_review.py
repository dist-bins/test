"""Check observed visual-review regressions on an isolated compiled fixture.

These checks exercise visible evidence, containment and retained controls; they
never modify the operator preview or infer successful deployment from a job.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "output/verification/visual-corrections-20261007"
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    checks = []
    measurements = []
    outside = []
    errors = []
    with fixture_server(args.assets.resolve()) as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(service_workers="block")

        def guard(route):
            url = urlsplit(route.request.url)
            if url.scheme == "http" and url.hostname == "127.0.0.1" and url.port == port:
                route.continue_()
            else:
                outside.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.set_default_timeout(5000)
        page.on("pageerror", lambda error: errors.append(str(error)))

        def go(path):
            page.goto(base + "/#/" + path)
            page.wait_for_load_state("networkidle")

        def mode(value):
            page.locator(f'[data-fk="mode-{value}"]').click()

        def check(name, operation):
            try:
                operation()
                checks.append({"name": name, "passed": True})
            except Exception as error:
                checks.append({"name": name, "passed": False, "error": str(error)[:1800]})
                page.keyboard.press("Escape")

        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            height = 1100 if width > 500 else 844
            page.set_viewport_size({"width": width, "height": height})
            go("work")
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            page.reload()
            page.wait_for_load_state("networkidle")
            mode("visual")

            def deploy_identity(theme=theme, width=width):
                go("item/42/792")
                expect(page.locator("main")).to_contain_text("SHA differs from branch head")
                expect(page.locator("main")).to_contain_text("success #3002")
                expect(page.locator("main")).to_contain_text("mismatch")
                expect(page.locator("main")).to_contain_text("failed")
                page.screenshot(path=str(args.output / f"deploy-identity-{theme}-{width}.png"))

            check(
                f"visual deployment status/SHA/runtime/manual-test remain separate {theme} {width}",
                deploy_identity,
            )

            def graph_relationships(theme=theme, width=width):
                go("item/42/791")
                graph = page.get_by_role("list", name="Pipelines by trigger depth, upstream first")
                expect(graph).to_contain_text("Application SHA")
                expect(graph).to_contain_text("Config/deploy SHA")
                root = graph.get_by_role(
                    "article", name="Pipeline demo/flight-service #9201", exact=True
                )
                unrelated = graph.get_by_role(
                    "article", name="Pipeline demo/flight-service #9202", exact=True
                )
                expect(root).to_contain_text(re.compile("triggers", re.IGNORECASE))
                expect(root).to_contain_text("97792")
                expect(unrelated).not_to_contain_text("97792")
                graph.scroll_into_view_if_needed()
                if width < 500:
                    boxes = graph.locator(".gnode").evaluate_all(
                        "els=>els.map(e=>{const b=e.getBoundingClientRect();"
                        "return {x:b.x,right:b.right,width:b.width}})"
                    )
                    assert boxes and all(
                        b["x"] >= -0.5 and b["right"] <= width + 0.5 for b in boxes
                    ), boxes
                    measurements.append(
                        {"theme": theme, "width": width, "mobile_graph_nodes": boxes}
                    )
                page.screenshot(path=str(args.output / f"graph-{theme}-{width}.png"))

            check(
                f"native graph identifies the actual edge and contains nodes {theme} {width}",
                graph_relationships,
            )

            def fixed_card_controls(width=width):
                go("pipelines")
                fields = page.get_by_label("Visible fields", exact=True)
                assert fields.count() == 0 or not fields.is_visible() or fields.is_disabled()
                if width < 500:
                    page.get_by_label(re.compile("^View options:")).click()
                    jobs = page.get_by_role("checkbox", name="Jobs", exact=True)
                    assert jobs.count() == 0 or not jobs.is_visible() or jobs.is_disabled()
                expect(page.locator("main")).to_contain_text("2.4.8")
                artifact = page.locator(".vcard .vc-b").get_by_text(
                    "demo.flight:flight-service:2.4.8", exact=True
                )
                expect(artifact).to_be_visible()
                bounds = artifact.evaluate(
                    "e=>{const r=document.createRange();r.selectNodeContents(e);"
                    "const b=e.closest('.vcard').getBoundingClientRect();"
                    "return {card:{left:b.left,right:b.right},"
                    "text:[...r.getClientRects()].map(x=>({left:x.left,right:x.right}))}}"
                )
                assert bounds["text"] and all(
                    row["left"] >= bounds["card"]["left"] - 0.5
                    and row["right"] <= bounds["card"]["right"] + 0.5
                    for row in bounds["text"]
                ), bounds
                mode("detailed")
                if width < 500:
                    jobs = page.get_by_role("checkbox", name="Jobs", exact=True)
                    if not jobs.is_visible():
                        page.get_by_label(re.compile("^View options:")).click()
                    expect(jobs).to_be_enabled()
                    page.keyboard.press("Escape")
                else:
                    expect(page.get_by_label("Visible fields", exact=True)).to_be_enabled()
                    expect(page.locator("main table").first).to_be_visible()
                expect(page.locator("main")).to_contain_text("#9201")
                mode("visual")

            check(
                f"fixed visual cards explain controls and retain Detailed fields {theme} {width}",
                fixed_card_controls,
            )

            def popover(theme=theme, width=width, height=height):
                go("item/42/791")
                mode("visual")
                trigger = page.locator(".flow-lane button[data-ev]").first
                trigger.scroll_into_view_if_needed()
                before = trigger.bounding_box()
                trigger.click()
                expect(page.locator("#ev-pop")).to_be_visible()
                # CSS entrance animation lasts140ms. Inspect and capture its final
                # position, not a transient screenshot with the sheet below view.
                page.wait_for_timeout(200)
                box = page.locator("#ev-pop").bounding_box()
                after = trigger.bounding_box()
                assert before and after and box
                assert max(abs(after[key] - before[key]) for key in before) < 0.75
                assert box["x"] >= -0.5 and box["x"] + box["width"] <= width + 0.5
                assert box["y"] >= -0.5 and box["y"] + box["height"] <= height + 0.5
                measurements.append({"theme": theme, "width": width, "steady_popover": box})
                page.screenshot(path=str(args.output / f"popover-{theme}-{width}.png"))
                page.keyboard.press("Escape")
                expect(trigger).to_be_focused()

            check(
                f"steady evidence popover visible/contained/no-shift/focus {theme} {width}", popover
            )
        browser.close()
    failed = sum(not row["passed"] for row in checks) + len(errors) + len(outside)
    report = {
        "purpose": __doc__,
        "checks": checks,
        "measurements": measurements,
        "js_errors": errors,
        "outside": outside,
        "failed": failed,
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {"checks": len(checks), "failed": failed, "report": str(args.output / "report.json")}
        )
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
