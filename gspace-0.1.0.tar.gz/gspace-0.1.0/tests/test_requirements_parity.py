"""Identity, evidence, concurrent operator edits and typed CLI requirement regressions."""

import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime, timedelta
from urllib.parse import urlsplit

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from gspace.access import ProfileTransport
from gspace.access_models import GlabProfile
from gspace.api import create_app
from gspace.config import AppConfig, load_config
from gspace.fixture import synthetic_snapshot
from gspace.glab import AdapterError, GlabAdapter, MilestoneDTO, RunResult
from gspace.milestones import catalog, date_current
from gspace.models import (
    ApplicationTestRecord,
    MilestoneFilter,
    ProjectId,
    Snapshot,
    Version,
    WorkItem,
)
from gspace.operator_settings import (
    OperatorSettings,
    OperatorStore,
    SettingsChange,
    SettingsConflict,
)
from gspace.pipeline_config import PipelineRules
from gspace.preferences import Filters
from gspace.service import ApplicationTestChange, FilterChange, Service
from tests.test_glab import live


def test_milestone_identity_counts_and_shared_selection(service):
    result = service.milestones()
    assert [e.work_items for e in result.entries] == [2, 2, 1, 1]
    assert [e.visible_work_items for e in result.entries] == [2, 1, 1, 0]
    assert result.unassigned_work_items == 1
    assert result.entries[0].milestone.iid == result.entries[1].milestone.iid
    assert result.entries[0].milestone.key != result.entries[1].milestone.key
    key = result.entries[1].milestone.key
    service.change(
        FilterChange(
            revision=0,
            filters=Filters(
                state="all",
                assigned=False,
                milestone=MilestoneFilter(mode="selected", selected=key),
            ),
        )
    )
    assert {v.item.identity.key for v in service.dashboard().views} == {"42:793", "99:791"}
    scoped = service.milestones(ProjectId(value=42))
    assert scoped.entries[1].work_items == 1
    assert scoped.count_scope == "all_snapshot_issues_in_selected_configured_projects"


def test_milestone_current_is_date_timezone_not_active_or_arbitrary_choice():
    snapshot = synthetic_snapshot()
    args = (
        snapshot,
        "fixture",
        (ProjectId(value=42), ProjectId(value=99)),
        MilestoneFilter(),
        snapshot.items,
        "Europe/Zurich",
    )
    result = catalog(*args, now=datetime(2026, 10, 15, 21, 30, tzinfo=UTC))
    assert len(result.date_current_candidates) == 2
    assert result.warnings and result.selection.mode == "all"
    after = catalog(*args, now=datetime(2026, 10, 15, 22, 30, tzinfo=UTC))
    assert after.date.day == 16 and len(after.date_current_candidates) == 1
    assert after.entries[-1].date_current == "unknown"
    closed = snapshot.milestones[0].model_copy(update={"state": "closed"})
    assert date_current(closed, result.date)[0] == "no"


def test_legacy_or_incomplete_coverage_never_claims_total_counts():
    data = synthetic_snapshot().model_dump()
    data["issue_coverage"] = "unknown"
    result = catalog(
        Snapshot.model_validate(data),
        "fixture",
        (ProjectId(value=42),),
        MilestoneFilter(),
        (),
        "Europe/Zurich",
    )
    assert all(row.work_items is None and row.opened_work_items is None for row in result.entries)
    assert result.unassigned_work_items is None and result.warnings


def test_milestone_selection_and_timezone_validate_closed_models(config):
    with pytest.raises(ValidationError):
        MilestoneFilter(mode="selected")
    with pytest.raises(ValidationError):
        MilestoneFilter(mode="active", selected=synthetic_snapshot().milestones[0].key)
    with pytest.raises(ValidationError):
        AppConfig(timezone="No/SuchZone")
    data = synthetic_snapshot().model_dump()
    data["items"][0]["milestone"]["project"]["value"] = 99
    with pytest.raises(ValidationError):
        Snapshot.model_validate(data)


def record(service, key, outcome="passed", environment="dev", at=None):
    target = next(e for e in service.item(key).environments if e.name == environment).expected
    return ApplicationTestRecord(
        key=key,
        environment=environment,
        version=target,
        outcome=outcome,
        checked_at=at or datetime.now(UTC),
        notes="Manual synthetic test",
    )


def test_manual_outcome_is_exact_version_scoped_and_persistent(service, key):
    first = record(service, key)
    service.change(ApplicationTestChange(revision=0, record=first))
    assert (
        service.view(service.item(key), service.preferences.read()).application_tests[0].outcome
        == "passed"
    )
    restored = Service(service.config)
    assert (
        restored.view(restored.item(key), restored.preferences.read()).application_tests[0].current
        == first
    )
    data = service.item(key).model_dump()
    data["environments"][0]["expected"]["sha"] = "b" * 40
    changed = WorkItem.model_validate(data)
    evidence = service.view(changed, service.preferences.read()).application_tests[0]
    assert evidence.outcome == "not_tested" and evidence.current is None
    assert evidence.history == (first,)
    # Independently successful deploy evidence and old observed commit do not transfer a pass.
    assert changed.environments[0].deployments[0].status == "success"


def test_manual_reset_and_error_separation(service, key):
    first = record(service, key)
    service.change(ApplicationTestChange(revision=0, record=first))
    reset = record(service, key, "not_tested", at=first.checked_at + timedelta(seconds=1))
    service.change(ApplicationTestChange(revision=1, record=reset))
    view = service.view(service.item(key), service.preferences.read())
    assert view.application_tests[0].outcome == "not_tested"
    assert view.comparisons[0].result == "match"
    assert not view.checklist.complete and view.item.merge_requests[0].draft


@pytest.mark.parametrize("version", [{"branch": "issue-791"}, {"tag": "release-1"}])
def test_manual_tests_reject_mutable_refs_and_naive_time(service, key, version):
    with pytest.raises(ValidationError):
        ApplicationTestRecord(
            key=key,
            environment="dev",
            version=Version(**version),
            outcome="passed",
            checked_at=datetime.now(UTC),
        )
    with pytest.raises(ValidationError):
        ApplicationTestRecord(
            key=key,
            environment="dev",
            version=Version(sha="a" * 40),
            outcome="passed",
            checked_at=datetime(2026, 10, 6),
        )


@pytest.mark.parametrize(
    "change",
    [
        {"stages": [{"name": "test", "depends_on": ["deploy"]}, {"name": "deploy"}]},
        {"stages": [{"name": "test"}, {"name": "test"}]},
        {"jobs": [{"pattern": "publish", "role": "publish", "environment": "dev"}]},
        {"jobs": [{"pattern": "deploy", "role": "deploy", "environment": "not-configured"}]},
        {"environments": []},
    ],
)
def test_pipeline_configuration_negative_models(change):
    with pytest.raises(ValidationError):
        PipelineRules.model_validate(change)


def test_config_atomic_roundtrip_preserves_scope_comments_and_effective_override(tmp_path):
    path = tmp_path / "operator.toml"
    path.write_text(
        '# Keep operator notes\nmode = "fixture" # Keep inline note\n'
        'preferences_path = "prefs.toml"\ncache_path = "cache.json"\n'
    )
    service = Service(load_config(path), config_path=path)
    current = service.settings()
    payload = current.settings.model_dump(mode="json")
    payload["pipeline"]["environments"].append(
        {"name": "qa", "label": "Quality assurance", "ref_source": "branch"}
    )
    payload["pipeline"]["jobs"].append(
        {"pattern": "deploy-qa", "role": "deploy", "environment": "qa"}
    )
    payload["project_pipeline_overrides"] = [
        {"project": {"value": 42}, "important_job_patterns": ["publish-*"]}
    ]
    saved = service.update_settings(
        SettingsChange(revision=current.revision, settings=OperatorSettings.model_validate(payload))
    )
    assert saved.effective[0].sources["important_job_patterns"] == "project_override"
    assert saved.effective[1].sources["important_job_patterns"] == "global"
    text = path.read_text()
    assert "# Keep operator notes" in text and "# Keep inline note" in text
    assert load_config(path).preferences_path == tmp_path / "prefs.toml"
    assert saved.settings == OperatorSettings.from_config(load_config(path))
    assert [e.name for e in service.dashboard().views[0].item.environments] == [
        "dev",
        "preprod",
        "qa",
    ]
    jobs = service.dashboard().views[0].job_configuration
    assert any(j.role == "publish" and j.important for j in jobs)
    assert any(j.role == "normal" and not j.important for j in jobs)
    assert all(j.dependency_evidence == "operator_expectation" for j in jobs)


def test_concurrent_config_updates_one_wins_and_invalid_does_not_replace(tmp_path):
    path = tmp_path / "operator.toml"
    store = OperatorStore(
        path,
        AppConfig(preferences_path=tmp_path / "prefs.toml", cache_path=tmp_path / "cache.json"),
    )
    change = SettingsChange(revision=store.revision(), settings=OperatorSettings())

    def update(_):
        try:
            store.update(change)
            return "saved"
        except SettingsConflict:
            return "conflict"

    with ThreadPoolExecutor(max_workers=2) as pool:
        assert sorted(pool.map(update, range(2))) == ["conflict", "saved"]
    before = path.read_bytes()
    with pytest.raises(ValidationError):
        store.update(
            SettingsChange(revision=store.revision(), settings=OperatorSettings(timezone="No/Zone"))
        )
    assert path.read_bytes() == before


def test_api_settings_milestones_and_manual_results(service, key):
    client = TestClient(create_app(service=service))
    assert client.get("/api/milestones?project=42").status_code == 200
    current = client.get("/api/settings").json()
    request = {"revision": current["revision"], "settings": current["settings"]}
    request["settings"]["timezone"] = "UTC"
    assert client.post("/api/settings", json=request).status_code == 200
    assert client.post("/api/settings", json=request).status_code == 409
    invalid = dict(request, revision=client.get("/api/settings").json()["revision"])
    invalid["settings"] = {**invalid["settings"], "endpoints": [{"url": "https://evil.invalid"}]}
    assert client.post("/api/settings", json=invalid).status_code == 422
    body = {
        "operation": "application_test",
        "revision": 0,
        "record": record(service, key, "failed").model_dump(mode="json"),
    }
    assert client.post("/api/preferences", json=body).status_code == 200
    result = client.get("/api/items/42/791").json()["application_tests"][0]
    assert result["outcome"] == "failed" and result["current"]["source"] == "operator"


def test_pinned_adapter_api_issue_relation_precedes_convention_and_links():
    sha = "a" * 40
    ms = dict(
        id=701,
        iid=11,
        project_id=42,
        title="October",
        state="active",
        start_date="2026-10-01",
        due_date="2026-10-15",
        web_url="https://gitlab.example.invalid/demo/flight/-/milestones/11",
    )
    mr = dict(
        iid=154,
        project_id=42,
        source_project_id=42,
        title="Custom branch MR",
        source_branch="custom-branch",
        target_branch="main",
        state="opened",
        sha=sha,
        draft=True,
        diverged_commits_count=0,
        rebase_in_progress=False,
    )
    calls = []

    def runner(argv, timeout):
        path = urlsplit(argv[-1]).path
        calls.append(path)
        values = {
            "version": {"version": "18.11.12"},
            "user": {"id": 7},
            "projects/42/issues": [
                dict(
                    iid=791,
                    project_id=42,
                    title="Issue",
                    state="opened",
                    assignees=[{"id": 7}],
                    milestone=ms,
                )
            ],
            "projects/42/milestones": [ms],
            "projects/42/issues/791/related_merge_requests": [mr],
            "projects/42/repository/branches": [
                {"name": name, "commit": {"id": sha}}
                for name in ("custom-branch", "791-from-ui", "unrelated")
            ],
            "projects/42/repository/tags": [],
            "projects/42/deployments": [],
            "projects/42/merge_requests": [mr],
            "projects/42/merge_requests/154": mr,
            "projects/42/merge_requests/154/pipelines": [],
            "projects/42/pipelines": [],
        }
        return RunResult(code=0, stdout=json.dumps(values[path]).encode())

    adapter = GlabAdapter(live(), runner)
    from gspace.preferences import Preferences

    snapshot = adapter.snapshot(AppConfig(mode="live", live=live()), Preferences())
    item = snapshot.items[0]
    assert item.milestone == snapshot.milestones[0].key
    assert snapshot.issue_coverage == "complete_configured_projects"
    assert {b.name for b in item.branches} == {"custom-branch", "791-from-ui"}
    assert item.branches[0].association.origin == "api"
    assert item.branches[1].association.origin == "convention"
    assert "related_merge_requests" in item.merge_requests[0].association.reason
    assert "creation provenance unknown" in item.branches[0].association.reason
    with pytest.raises(AdapterError):
        adapter.get("projects/99/issues")
    with pytest.raises(AdapterError):
        adapter.milestone(
            MilestoneDTO.model_validate({**ms, "web_url": "https://evil.invalid/x"}),
            live().projects[0],
        )


def test_profile_wrapper_supports_new_get_scope_only():
    profile = GlabProfile(
        name="devpod", host="https://gitlab.example.invalid", projects=(ProjectId(value=42),)
    )
    transport = ProfileTransport(profile)
    transport.path("projects/42/milestones")
    transport.path("projects/42/issues/791/related_merge_requests")
    with pytest.raises(AdapterError):
        transport.path("projects/99/milestones")


def test_typed_cli_is_cli_only_and_new_commands_share_api(tmp_path):
    path = tmp_path / "config.toml"
    path.write_text('mode="fixture"\npreferences_path="prefs.toml"\ncache_path="cache.json"\n')
    env = {**os.environ, "GSPACE_MODE": "live", "JSON": "false", "CONFIG": "/not/authorized"}
    (tmp_path / ".env").write_text("CONFIG=/not/authorized\n")

    def cli(*args):
        return subprocess.run(
            [sys.executable, "-m", "gspace", args[0], "--config", str(path), *args[1:]],
            capture_output=True,
            text=True,
            timeout=20,
            env=env,
        )

    result = cli("milestones", "--json")
    assert result.returncode == 0 and result.stderr == ""
    assert json.loads(result.stdout)["issue_coverage"] == "complete_configured_projects"
    assert cli("filters", "--milestone-key", "group:9:702", "--json").returncode == 0
    rows = json.loads(cli("dashboard", "--json").stdout)["views"]
    assert [v["item"]["identity"]["issue"]["value"] for v in rows] == [793]
    settings = json.loads(cli("settings", "--json").stdout)
    change = tmp_path / "change.json"
    change.write_text(
        json.dumps({"revision": settings["revision"], "settings": settings["settings"]})
    )
    assert cli("settings-set", str(change), "--json").returncode == 0
    assert cli("settings-set", str(change), "--json").returncode == 2
    manual_core = Service(load_config(path), config_path=path)
    target_key = manual_core.snapshot().items[2].identity
    manual = tmp_path / "manual.json"
    manual.write_text(record(manual_core, target_key).model_dump_json())
    assert cli("app-test", str(manual), "--json").returncode == 0
    response = TestClient(create_app(load_config(path), config_path=path)).get("/api/items/42/793")
    assert response.json()["application_tests"][0]["current"]["source"] == "operator"
    assert response.json()["application_tests"][0]["outcome"] == "passed"
    invalid = cli("dashboard", "--width", "20", "--json")
    assert invalid.returncode == 2 and invalid.stdout == "" and json.loads(invalid.stderr)["error"]


def test_operator_edits_preserve_unchanged_nested_comments(tmp_path):
    path = tmp_path / "config.toml"
    path.write_text(
        'mode="fixture"\n[pipeline]\n'
        '# Keep job documentation\nimportant_job_patterns=["unit-*"] # Keep comment\n'
    )
    core = Service(load_config(path), config_path=path)
    response = core.settings()
    data = response.settings.model_dump()
    data["timezone"] = "UTC"
    core.update_settings(
        SettingsChange(revision=response.revision, settings=OperatorSettings.model_validate(data))
    )
    text = path.read_text()
    assert "# Keep job documentation" in text and "# Keep comment" in text


def test_loading_config_preserves_explicit_legacy_publish_override(tmp_path):
    path = tmp_path / "live.toml"
    text = (
        'mode="live"\n[pipeline]\njobs=[{pattern="new-publish",role="publish"}]\n'
        '[live]\nhostname="gitlab.example.invalid"\n'
        'web_origin="https://gitlab.example.invalid"\n'
        '[[live.projects]]\nid={value=42}\npath="demo/flight"\n'
    )
    path.write_text(text)
    config = load_config(path)
    assert config.effective_pipeline(ProjectId(value=42)).sources["jobs"] == "global"
    assert (
        config.effective_pipeline(ProjectId(value=42)).rules.classify("new-publish").role
        == "publish"
    )
    path.write_text(text.replace("[live]\n", '[live]\nnexus_job_names=["old-publish"]\n'))
    config = load_config(path)
    assert config.effective_pipeline(ProjectId(value=42)).sources["jobs"] == "legacy_live_override"
    assert (
        config.effective_pipeline(ProjectId(value=42)).rules.classify("old-publish").role
        == "publish"
    )


def test_ambiguous_job_roles_rejected_before_config_file_write(service):
    current = service.settings()
    data = current.settings.model_dump()
    data["pipeline"]["jobs"] += ({"pattern": "publish-*", "role": "publish"},)
    with pytest.raises(ValueError, match="several rules"):
        service.update_settings(
            SettingsChange(
                revision=current.revision, settings=OperatorSettings.model_validate(data)
            )
        )
    assert not service.operator_store.path.exists()
