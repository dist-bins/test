"""General GET-only catalogs, separate from work-item association snapshots."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Literal, Self
from urllib.parse import quote

from pydantic import AwareDatetime, Field, model_validator

from gspace.config import ProjectConfig
from gspace.fixture import synthetic_snapshot
from gspace.gitlab_release import read_release
from gspace.glab import AdapterError, BranchDTO, GlabAdapter, PipelineDTO, VersionDTO, status
from gspace.models import (
    Association,
    Branch,
    Link,
    Model,
    Origin,
    Pipeline,
    PipelineId,
    Text,
    Unknown,
)


class BranchSummary(Model, frozen=True):
    branch: Branch
    project_path: Text


class PipelineSummary(Model, frozen=True):
    pipeline: Pipeline
    project_path: Text
    jobs_coverage: Literal["not_loaded"] = "not_loaded"


class CatalogBase(Model, frozen=True):
    source: Literal["fixture", "glab"]
    host: Text
    scope: Literal["all_in_configured_projects"] = "all_in_configured_projects"
    coverage: Literal["complete"] = "complete"
    coverage_basis: Literal["synthetic_fixture", "bounded_GET_pagination"]
    projects: tuple[ProjectConfig, ...]
    fetched_at: AwareDatetime
    total: int = Field(strict=True, ge=0)
    scope_total: int = Field(strict=True, ge=0)
    display_filter: str = Field(default="", max_length=200)

    @model_validator(mode="after")
    def coverage_count(self) -> Self:
        if self.scope_total < self.total or (
            not self.display_filter and self.scope_total != self.total
        ):
            raise ValueError("Filtered catalog count exceeds complete scope")
        if (self.source == "fixture") != (self.coverage_basis == "synthetic_fixture"):
            raise ValueError("Catalog coverage source differs")
        return self


class BranchCatalog(CatalogBase, frozen=True):
    kind: Literal["branches"] = "branches"
    rows: tuple[BranchSummary, ...]

    @model_validator(mode="after")
    def scoped(self) -> Self:
        identities = [(r.branch.project, r.branch.name) for r in self.rows]
        if self.total != len(self.rows) or len(set(identities)) != len(identities):
            raise ValueError("Branch catalog count/identities are inconsistent")
        paths = {p.id: p.path for p in self.projects}
        if any(paths.get(r.branch.project) != r.project_path for r in self.rows):
            raise ValueError("Branch catalog exceeds project scope")
        return self


class PipelineCatalog(CatalogBase, frozen=True):
    kind: Literal["pipelines"] = "pipelines"
    pipeline_sources: Literal["default_and_child"] = "default_and_child"
    rows: tuple[PipelineSummary, ...]

    @model_validator(mode="after")
    def scoped(self) -> Self:
        identities = [(r.pipeline.project, r.pipeline.id) for r in self.rows]
        if self.total != len(self.rows) or len(set(identities)) != len(identities):
            raise ValueError("Pipeline catalog count/identities are inconsistent")
        paths = {p.id: p.path for p in self.projects}
        if any(
            paths.get(r.pipeline.project) != r.project_path or r.pipeline.jobs for r in self.rows
        ):
            raise ValueError("Pipeline summary exceeds scope or claims unloaded jobs")
        return self


class CatalogPipelineDTO(PipelineDTO):
    project_id: int = Field(strict=True, gt=0)


def resources(
    kind: Literal["branches", "pipelines"],
    projects: tuple[ProjectConfig, ...],
    adapter: GlabAdapter | None = None,
) -> BranchCatalog | PipelineCatalog:
    branch_rows: list[BranchSummary] = []
    pipeline_rows: list[PipelineSummary] = []
    now = datetime.now(UTC)
    if adapter is None:
        snapshot = synthetic_snapshot()
        allowed = {p.id for p in projects}
        branches = {
            (b.project, b.name): (b, i.project_path)
            for i in snapshot.items
            if i.identity.project in allowed
            for b in i.branches
        }
        pipelines = {
            (p.project, p.id): (p, i.project_path)
            for i in snapshot.items
            if i.identity.project in allowed
            for p in i.pipelines
        }
        # Synthetic catalog deliberately includes resources with no work item.
        for project in projects:
            example = next(b for (pid, _), (b, _) in branches.items() if pid == project.id)
            data = example.model_dump()
            data.update(
                name="main",
                rebase=Unknown(reason="Catalog does not establish target ancestry"),
                association=Association(origin=Origin.FIXTURE, reason="Synthetic unlinked branch"),
                link={
                    "url": f"https://gitlab.example.invalid/{project.path}/-/tree/main",
                    "verification": "fixture",
                },
            )
            branches[(project.id, "main")] = (Branch.model_validate(data), project.path)
            pipeline = Pipeline(
                project=project.id,
                id=PipelineId(value=99000 + project.id.value),
                ref="main",
                sha=example.sha,
                source="push",
                status=status("success"),
                association=Association(
                    origin=Origin.FIXTURE, reason="Synthetic unlinked pipeline"
                ),
                link=Link(
                    url=f"https://gitlab.example.invalid/{project.path}/-/pipelines/"
                    f"{99000 + project.id.value}",
                    verification="fixture",
                ),
            )
            pipelines[(project.id, pipeline.id)] = (pipeline, project.path)
        branch_rows = [BranchSummary(branch=b, project_path=path) for b, path in branches.values()]
        pipeline_rows = [
            PipelineSummary(
                pipeline=Pipeline.model_validate({**p.model_dump(), "jobs": ()}), project_path=path
            )
            for p, path in pipelines.values()
        ]
        host, source, basis = "fixture", "fixture", "synthetic_fixture"
    else:
        if any(p not in adapter.config.projects for p in projects):
            raise AdapterError("configuration", "Catalog exceeds configured project scope")
        try:
            read_release(
                adapter.single("version", VersionDTO).version, adapter.config.supported_version
            )
        except ValueError as error:
            raise AdapterError(
                "compatibility", "GitLab version differs from pinned 18.11.12 contract"
            ) from error
        for project in projects:
            if kind == "branches":
                rows = adapter.pages(
                    f"projects/{project.id.value}/repository/branches",
                    BranchDTO,
                    {"sort": "name_asc", "pagination": "offset"},
                )
                branch_rows.extend(
                    BranchSummary(
                        branch=Branch(
                            project=project.id,
                            name=r.name,
                            sha=r.commit.id,
                            association=Association(
                                origin=Origin.API,
                                reason="General project branch GET; no issue association inferred",
                            ),
                            rebase=Unknown(reason="Catalog does not establish target ancestry"),
                            link=adapter.link(project, "tree/" + quote(r.name, safe="")),
                        ),
                        project_path=project.path,
                    )
                    for r in rows
                )
            else:
                raw = adapter.pages(
                    f"projects/{project.id.value}/pipelines",
                    CatalogPipelineDTO,
                    {"order_by": "id", "sort": "desc", "pagination": "offset"},
                )
                if any(r.project_id != project.id.value for r in raw):
                    raise AdapterError("validation", "Pipeline catalog project identity mismatch")
                children = adapter.pages(
                    f"projects/{project.id.value}/pipelines",
                    CatalogPipelineDTO,
                    {
                        "source": "parent_pipeline",
                        "order_by": "id",
                        "sort": "desc",
                        "pagination": "offset",
                    },
                )
                if any(
                    r.project_id != project.id.value or r.source != "parent_pipeline"
                    for r in children
                ):
                    raise AdapterError(
                        "validation", "Child pipeline catalog identity/source mismatch"
                    )
                raw = (*raw, *children)
                pipeline_rows.extend(
                    PipelineSummary(
                        pipeline=Pipeline(
                            project=project.id,
                            id=PipelineId(value=r.id),
                            ref=r.ref,
                            sha=r.sha,
                            source=r.source,
                            status=status(r.status),
                            association=Association(
                                origin=Origin.API,
                                reason="General project pipeline GET; jobs not loaded",
                            ),
                            link=adapter.link(project, f"pipelines/{r.id}"),
                        ),
                        project_path=project.path,
                    )
                    for r in raw
                )
        host, source, basis = (
            adapter.config.web_origin.rstrip("/"),
            "glab",
            "bounded_GET_pagination",
        )
    common = dict(source=source, host=host, coverage_basis=basis, projects=projects, fetched_at=now)
    try:
        if kind == "branches":
            return BranchCatalog.model_validate(
                {
                    **common,
                    "rows": branch_rows,
                    "total": len(branch_rows),
                    "scope_total": len(branch_rows),
                }
            )
        return PipelineCatalog.model_validate(
            {
                **common,
                "rows": pipeline_rows,
                "total": len(pipeline_rows),
                "scope_total": len(pipeline_rows),
            }
        )
    except ValueError as error:
        raise AdapterError("validation", "Catalog identity/coverage validation failed") from error
