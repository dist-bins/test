"""Actual loopback browser verification of parity and stable evidence interactions."""

from __future__ import annotations

import argparse
import json
import traceback
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright
from visual_capture import fixture_server

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "output/verification/parity-browser")
    parser.add_argument("--assets", type=Path, default=ROOT / "frontend-new")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    checks = []
    errors = []
    outbound = []
    measurements = []
    with fixture_server(args.assets.resolve()) as port, sync_playwright() as engine:
        base = f"http://127.0.0.1:{port}"
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(
            viewport={"width": 1600, "height": 1100}, service_workers="block"
        )

        def guard(route):
            parsed = urlsplit(route.request.url)
            if parsed.scheme == "http" and parsed.hostname == "127.0.0.1" and parsed.port == port:
                route.continue_()
            else:
                outbound.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))

        def check(name, operation):
            try:
                operation()
                checks.append({"check": name, "result": "passed"})
            except Exception as error:
                checks.append(
                    {
                        "check": name,
                        "result": "failed",
                        "error": str(error)[:1100],
                        "trace": traceback.format_exc()[-2200:],
                    }
                )

        def route(path):
            page.goto(base + "/#/" + path)
            page.wait_for_timeout(200)

        route("work")
        page.wait_for_selector(".mx.proc")

        def milestone_filter():
            selector = page.locator('[data-fk="w-ms"]')
            catalog = page.request.get(base + "/api/milestones").json()
            key = catalog["entries"][0]["milestone"]["key"]
            # Select the first actual typed key via its displayed title; no title
            # is used as identity in the submitted preference record.
            title = catalog["entries"][0]["milestone"]["title"]
            option = selector.locator("option").filter(has_text=title).first
            value = option.get_attribute("value")
            with page.expect_response(base + "/api/preferences") as saved:
                selector.select_option(value)
            assert saved.value.status == 200
            prefs = page.request.get(base + "/api/preferences").json()
            assert prefs["filters"]["milestone"] == {"mode": "selected", "selected": key}
            page.reload()
            expect(selector).to_have_value(value)
            page.get_by_role("checkbox", name="Select #791 for comparison", exact=True).check()
            route("compare")
            expect(selector).to_have_value(value)
            selector.select_option("all")
            page.wait_for_timeout(200)
            assert page.request.get(base + "/api/preferences").json()["filters"]["milestone"] == {
                "mode": "all",
                "selected": None,
            }

        check("typed milestone filter persists across reload and work/compare", milestone_filter)
        check(
            "shared milestone catalog page",
            lambda: (
                route("milestones"),
                expect(page.locator("main")).to_contain_text("Flight October"),
                expect(page.locator("main")).to_contain_text("Shared October"),
            ),
        )

        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            page.set_viewport_size({"width": width, "height": 1100 if width > 500 else 844})
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            page.reload()
            route("work")
            # This regression checks the retained Detailed table/popover;
            # a fresh browser now intentionally opens the responsive Overview.
            page.get_by_role("button", name="Detailed", exact=True).click()
            page.wait_for_selector(".mx tbody button[data-ev]")

            def popover_contract(theme=theme, width=width):
                assert page.locator("html").get_attribute("data-theme") == theme
                trigger = page.locator(".mx tbody button[data-ev]").first
                trigger.scroll_into_view_if_needed()
                before = trigger.bounding_box()
                assert before
                row = trigger.locator("xpath=ancestor::tr").first
                height = row.bounding_box()["height"]
                for _ in range(12):
                    trigger.click()
                    expect(page.locator("#ev-pop")).to_be_visible()
                    after = trigger.bounding_box()
                    assert after and max(abs(after[k] - before[k]) for k in before) < 0.75, (
                        f"Trigger moved: {before} -> {after}"
                    )
                    assert abs(row.bounding_box()["height"] - height) < 0.75
                    # A mobile bottom sheet may cover the trigger. Closing it
                    # through Escape avoids Playwright scrolling a covered
                    # trigger into view merely to click it again.
                    if width <= 599:
                        page.keyboard.press("Escape")
                    else:
                        trigger.click()
                    expect(page.locator("#ev-pop")).not_to_be_visible()
                trigger.focus()
                page.keyboard.press("Enter")
                expect(page.locator("#ev-pop")).to_be_visible()
                expect(page.locator("#ev-pop")).to_contain_text("Reason:")
                page.keyboard.press("Escape")
                expect(trigger).to_be_focused()
                trigger.click()
                page.screenshot(path=str(args.output / f"popover-{theme}-{width}.png"))
                pop = page.locator("#ev-pop").bounding_box()
                assert pop and pop["x"] >= -0.5 and pop["x"] + pop["width"] <= width + 0.5, (
                    f"Popover outside viewport: {pop}"
                )
                page.mouse.wheel(0, 160)
                page.wait_for_timeout(100)
                if page.locator("#ev-pop").is_visible():
                    pop = page.locator("#ev-pop").bounding_box()
                    assert pop and pop["y"] >= 0
                page.keyboard.press("Escape")
                trigger.scroll_into_view_if_needed()
                trigger.click()
                page.locator(".brand").click()
                expect(page.locator("#ev-pop")).not_to_be_visible()
                measurements.append(
                    {
                        "theme": theme,
                        "width": width,
                        "trigger": before,
                        "row_height": height,
                        "toggles": 12,
                    }
                )

            check(f"no-shift toggle/focus/scroll/outside close {theme} {width}", popover_contract)

        page.set_viewport_size({"width": 1600, "height": 1100})
        route("item/42/791")

        def manual_test():
            control = page.get_by_role("group", name="Record the Dev application test outcome")
            expect(control).to_be_visible()
            with page.expect_response(base + "/api/preferences") as saved:
                control.get_by_role("button", name="Passed", exact=True).click()
            assert saved.value.status == 200
            page.wait_for_timeout(300)
            data = page.request.get(base + "/api/items/42/791").json()
            test = data["application_tests"][0]
            assert test["outcome"] == "passed" and test["current"]["source"] == "operator"
            assert test["current"]["version"]["sha"] == test["target"]["sha"]
            assert (
                data["item"]["merge_requests"][0]["draft"] and not data["checklist"]["local_test"]
            )
            control.get_by_role("button", name="Reset to not tested", exact=True).click()
            page.wait_for_timeout(300)
            assert (
                page.request.get(base + "/api/items/42/791").json()["application_tests"][0][
                    "outcome"
                ]
                == "not_tested"
            )

        check("manual version-bound test UI persistence and reset", manual_test)

        def inspector_evidence():
            route("mrs/42/154")
            trigger = page.locator(".inspector button[data-ev]").first
            expect(trigger).to_be_visible()
            trigger.focus()
            page.keyboard.press("Enter")
            expect(page.locator("#ev-pop")).to_be_visible()
            page.keyboard.press("Tab")
            assert page.locator("#ev-pop").evaluate("e=>e.contains(document.activeElement)")
            page.keyboard.press("Escape")
            expect(trigger).to_be_focused()
            expect(page.locator(".inspector")).to_be_visible()
            page.keyboard.press("Escape")
            expect(page.locator(".inspector")).not_to_be_visible()

        check("drawer evidence keyboard containment and Escape priority", inspector_evidence)
        route("item/42/791")

        def geometry():
            offsets = page.locator(".lane-body .pn").evaluate_all("""nodes=>nodes.map(n=>{
              const body=n.closest('.lane-body'), p=getComputedStyle(n,'::before'),
                r=getComputedStyle(body,'::before'), nb=n.getBoundingClientRect(),
                bb=body.getBoundingClientRect(), b=getComputedStyle(body);
              return nb.x+parseFloat(p.left)+parseFloat(p.width)/2-
                (bb.x+parseFloat(b.borderLeftWidth)+parseFloat(r.left)+parseFloat(r.borderLeftWidth)/2);
            }).filter(Number.isFinite)""")
            assert offsets and max(map(abs, offsets)) <= 1
            select = page.get_by_role("combobox", name="Repository", exact=True)
            padding = select.evaluate("e=>parseFloat(getComputedStyle(e).paddingLeft)")
            selector = select.bounding_box()
            icon = select.locator("xpath=..").locator("svg").first.bounding_box()
            assert selector and icon and icon["x"] + icon["width"] <= selector["x"] + padding
            measurements.append(
                {
                    "rail_node_offsets": offsets,
                    "repository_select_padding": padding,
                    "repository_icon": icon,
                    "repository_select": selector,
                }
            )

        check("process nodes align to rail and project icon has text clearance", geometry)
        route("settings")
        check(
            "settings page effective operator expectations",
            lambda: (
                expect(page.locator("main")).to_contain_text("Important"),
                expect(page.locator("main")).to_contain_text("environment"),
            ),
        )

        def settings_roundtrip():
            page.locator('[data-fk="g-important_job_patterns-ip-0"]').fill("unit-tests*")
            page.locator('[data-fk="g-environments-e-add"]').click()
            page.locator('[data-fk="g-environments-en-2"]').fill("qa")
            page.locator('[data-fk="g-environments-el-2"]').fill("QA")
            page.locator('[data-fk="ov-add"]').select_option("42")
            page.locator('[data-fk="ov42-on-important_job_patterns"]').check()
            page.locator('[data-fk="ov42-important_job_patterns-ip-0"]').fill("publish-*")
            with page.expect_response(base + "/api/settings") as saved:
                page.locator('[data-fk="set-save"]').click()
            assert saved.value.status == 200
            current = page.request.get(base + "/api/settings").json()
            assert current["settings"]["pipeline"]["important_job_patterns"][0] == "unit-tests*"
            assert current["settings"]["pipeline"]["environments"][2]["name"] == "qa"
            effective = next(x for x in current["effective"] if x["project"]["value"] == 42)
            assert effective["sources"]["important_job_patterns"] == "project_override"
            assert effective["rules"]["important_job_patterns"][0] == "publish-*"
            page.reload()
            expect(page.locator('[data-fk="g-environments-en-2"]')).to_have_value("qa")
            route("item/42/792")
            expect(
                page.get_by_role("group", name="Record the QA application test outcome")
            ).to_be_visible()
            page.screenshot(path=str(args.output / "custom-environment.png"), full_page=True)

        check(
            "structured settings persist global rules/project override/custom environment",
            settings_roundtrip,
        )

        def settings_conflict():
            route("settings")
            page.locator('[data-fk="set-branch"]').fill("task-{iid}")
            latest = page.request.get(base + "/api/settings").json()
            latest["settings"]["timezone"] = "UTC"
            external = page.request.post(
                base + "/api/settings",
                data={
                    "revision": latest["revision"],
                    "settings": latest["settings"],
                },
            )
            assert external.status == 200
            submissions = []

            def submitted(request):
                if request.url == base + "/api/settings" and request.method == "POST":
                    submissions.append(request.post_data_json)

            page.on("request", submitted)
            with page.expect_response(base + "/api/settings") as conflict:
                page.locator('[data-fk="set-save"]').click()
            assert conflict.value.status == 409
            page.wait_for_timeout(300)
            assert len(submissions) == 1
            expect(page.locator('[data-fk="set-branch"]')).to_have_value("task-{iid}")
            expect(page.locator('[data-fk="set-save"]')).to_be_disabled()
            page.screenshot(path=str(args.output / "settings-conflict.png"), full_page=True)
            page.get_by_role("button", name="Load latest and keep my edits", exact=True).click()
            expect(page.locator('[data-fk="set-save"]')).to_be_enabled()
            with page.expect_response(base + "/api/settings") as reapplied:
                page.locator('[data-fk="set-save"]').click()
            assert reapplied.value.status == 200 and len(submissions) == 2
            assert (
                page.request.get(base + "/api/settings").json()["settings"]["branch_template"]
                == "task-{iid}"
            )
            page.remove_listener("request", submitted)

        check(
            "settings conflict keeps edits without retries and permits explicit reapply",
            settings_conflict,
        )
        browser.close()
    report = {
        "checks": checks,
        "measurements": measurements,
        "browser_errors": errors,
        "outbound": outbound,
        "source": "actual local synthetic browser",
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    failed = sum(check["result"] != "passed" for check in checks) + len(errors) + len(outbound)
    print(
        json.dumps(
            {"checks": len(checks), "failed": failed, "report": str(args.output / "report.json")}
        )
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
