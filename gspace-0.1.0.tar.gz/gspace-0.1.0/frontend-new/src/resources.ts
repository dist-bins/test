// Resource screens: bookmarks, saved views, authored MRs, branches,
// pipelines (with drawers), milestones and sources. Relations by name always
// show their commit relation; a matching name alone is not commit identity.

import { actionEntry, editDraftEntry } from './access';
import type { Bookmark, Column, ItemView, MilestoneCatalog, MilestoneCount, MilestoneKey, Pipeline, Rebase, ResourceReference, Status } from './api';
import { versionParts } from './api';
import type { IconName, Kid } from './dom';
import {
  breakable,
  controlValue,
  draftChip,
  extLink,
  fmtTime,
  h,
  icon,
  line,
  lines,
  mrStateBadge,
  none,
  rebaseBadge,
  STATUS,
  sha,
  sourceLabel,
  statusBadge,
  time,
  tone,
} from './dom';
import { evidence } from './evidence';
import { loadMilestones, loadMrs } from './load';
import type { BranchEntry, CatalogEntry, PipeEntry, RefKind } from './model';
import { envLabel, failedJobs, groupJobs, jobCfgOf, mrSha, mrSource, projectPath, scopeLabel, stageDeps, stageOrder } from './model';
import { avatarNote, bookmarkTarget, decoIcon, decorationFor, projectAvatar, shortcutManager, styleBtn, viewTarget } from './nav';
import { cfgMarks, jobsBlock, processNode } from './process';
import { render } from './render';
import type { ListUi, MsFilter, Scope, ScreenName, ViewState } from './state';
import {
  branchHref,
  COLS,
  ENV_PREFIX,
  itemHref,
  jobHref,
  mrHref,
  msKeyStr,
  normMs,
  pipeHref,
  pref,
  refKey,
  refProject,
  S,
  SCOPE_ICON,
  SCOPE_LABEL,
  SCOPES,
  SORT_LABEL,
  STATES,
  say,
  sectionOpen,
  to,
  wkStr,
} from './state';
import { confirmDialog, dialog, emptyState, go, kvList, scopeGate, sec, setTheme, simpleTable, themeChoice } from './ui';
import type { MatrixGroup, SortKey } from './views';
import { applyView, matrix, modeSwitch, sortRecords, viewControls, viewProjectsLabel } from './views';
import type { CardStep } from './visual';
import { cardFlow, jobDots } from './visual';
import { milestoneControl, msModeLabel, msOwner, msTitle, selectedMilestoneKey, setWorkFilter } from './work';

/* ========================================================= bookmarks */

function findBookmark(ref: ResourceReference): Bookmark | undefined {
  const k = refKey(ref);
  return (S.prefs?.bookmarks ?? []).find((b) => b.host === S.host && refKey(b.reference) === k);
}

export function bookmarkBtn(ref: ResourceReference, label: string): HTMLButtonElement {
  const b = findBookmark(ref);
  const host = S.host;
  return h(
    'button',
    {
      class: 'btn',
      type: 'button',
      'aria-pressed': String(!!b),
      'data-fk': `bm-${refKey(ref)}`,
      disabled: !S.prefs || !host,
      title: !host
        ? 'Host unknown; a bookmark must name its host'
        : b
          ? `Bookmarked as "${b.label}" — activate to remove`
          : 'Add a shared bookmark for this host',
      onclick: () => {
        if (b) void pref({ operation: 'bookmark_delete', reference: ref }, `Remove bookmark "${b.label}"`);
        else if (host) void pref({ operation: 'bookmark_set', bookmark: { host, reference: ref, label: label.slice(0, 500) } }, `Bookmark "${label}"`);
      },
    },
    icon('bookmark'),
    b ? 'Bookmarked' : 'Bookmark',
  );
}

type RefState = 'available' | 'unavailable' | 'loading' | 'other' | 'host';
interface Resolved {
  readonly kind: string;
  readonly icon: IconName;
  readonly desc: string;
  readonly title: string;
  readonly href: string | null;
  readonly state: RefState;
  readonly note: string | null;
}

// state: available | unavailable (in scope, not in data) | loading | other
// (another repository scope) | host (saved for a different host)
export function resolveRef(b: Bookmark): Resolved {
  const r = b.reference;
  const D = S.d;
  const p = refProject(r);
  let info: { kind: string; icon: IconName; desc: string; path: string; found: boolean; title: (found: boolean) => string };
  switch (r.kind) {
    case 'work_item': {
      const v = D?.items.get(wkStr(r.key));
      info = {
        kind: 'Work item',
        icon: 'work',
        desc: `#${r.key.issue.value} · ${projectPath(p)}`,
        path: itemHref(r.key),
        found: !!v,
        title: (f) => (f && v ? `#${r.key.issue.value} ${v.item.title}` : `#${r.key.issue.value}`),
      };
      break;
    }
    case 'mr': {
      const k = `${p}/${r.iid.value}`;
      const title = D?.catalog.get(k)?.mr.title ?? D?.wmrs.get(k)?.title ?? null;
      info = {
        kind: 'Merge request',
        icon: 'mr',
        desc: `!${r.iid.value} · ${projectPath(p)}`,
        path: mrHref(p, r.iid.value),
        found: title !== null,
        title: (f) => (f && title ? `!${r.iid.value} ${title}` : `!${r.iid.value}`),
      };
      break;
    }
    case 'branch':
      info = {
        kind: 'Branch',
        icon: 'branch',
        desc: `${r.name} · ${projectPath(p)}`,
        path: branchHref(p, r.name),
        found: !!D?.branches.get(`${p}/${r.name}`),
        title: () => r.name,
      };
      break;
    case 'pipeline': {
      const e = D?.pipes.get(`${p}/${r.id.value}`);
      info = {
        kind: 'Pipeline',
        icon: 'pipeline',
        desc: `#${r.id.value} · ${projectPath(p)}`,
        path: pipeHref(p, r.id.value),
        found: !!e,
        title: (f) => (f && e ? `#${r.id.value} ${e.pipeline.ref}` : `#${r.id.value}`),
      };
      break;
    }
  }
  const base = { kind: info.kind, icon: info.icon, desc: info.desc };
  if (b.host !== S.host)
    return {
      ...base,
      state: 'host',
      title: info.title(false),
      href: null,
      note: `Saved for host ${b.host}; this console is connected to ${S.host ?? 'an unknown host'}.`,
    };
  if (S.scope.project != null && p !== S.scope.project) {
    return {
      ...base,
      state: 'other',
      title: info.title(false),
      href: to(info.path, p),
      note: `In ${projectPath(p)}, outside the selected repository. Opening it switches the repository.`,
    };
  }
  // Inside the current repository scope the link keeps that scope (all
  // configured projects stays all); only an out-of-scope bookmark switches.
  if (!S.dash || !info.found) {
    return {
      ...base,
      state: S.dash ? 'unavailable' : 'loading',
      title: info.title(false),
      href: to(info.path),
      note: S.dash ? 'Not present in the current snapshot or catalog. The bookmark is kept.' : 'Loading repository data…',
    };
  }
  return { ...base, state: 'available', title: info.title(true), href: to(info.path), note: null };
}

const REF_SCREEN: Readonly<Record<ResourceReference['kind'], ScreenName>> = { work_item: 'item', mr: 'mrs', branch: 'branches', pipeline: 'pipelines' };

/** Click handler for a bookmark link: a repository switch is announced, never silent. */
export function bookmarkOpen(b: Bookmark): (() => void) | null {
  const p = refProject(b.reference);
  if (b.host !== S.host || S.scope.project == null || S.scope.project === p) return null;
  return () => {
    const from = S.scope.project == null ? 'all configured projects' : projectPath(S.scope.project);
    const text = `Opened bookmark “${b.label}”: repository scope changed from ${from} to ${projectPath(p)}.`;
    S.scopeNotice = { text, screen: REF_SCREEN[b.reference.kind] };
    say(text);
  };
}

function stateTone(r: Resolved): HTMLSpanElement {
  switch (r.state) {
    case 'available':
      return tone('ok', 's_ok', 'Available');
    case 'unavailable':
      return tone('unknown', 'lock', 'Unavailable', r.note);
    case 'loading':
      return tone('info', 's_pend', 'Loading');
    case 'other':
      return tone('neutral', 'repo', 'Other repository', r.note);
    case 'host':
      return tone('unknown', 'server', 'Other host', r.note);
  }
}

export function bookmarkScreen(): HTMLElement {
  const bs = S.prefs?.bookmarks ?? [];
  const rename = (b: Bookmark): void => {
    const input = h('input', { class: 'input', value: b.label, required: true, maxlength: '200', autocomplete: 'off' });
    dialog('Rename bookmark', h('label', { class: 'field' }, h('span', null, 'Label'), input), {
      okLabel: 'Rename',
      onOk: async () => {
        const label = input.value.trim();
        if (!label) return 'Enter a label.';
        return (await pref({ operation: 'bookmark_set', bookmark: { host: b.host, reference: b.reference, label } }, `Rename bookmark to "${label}"`))
          ? null
          : 'Not saved — see the problem list.';
      },
    });
    input.focus();
    input.select();
  };
  const about =
    'Bookmarks name a host and a project-scoped reference; no URL is stored. Bookmarks in another repository open by switching to it. Unavailable bookmarks are kept until removed.';
  const head = (count: string): HTMLDivElement =>
    h('div', { class: 'sh' }, h('div', { class: 'sh-title' }, h('h1', null, 'Bookmarks'), h('span', { class: 'count' }, count)));
  if (!bs.length) {
    return h(
      'div',
      { class: 'screen' },
      head('0 saved · shared preferences'),
      emptyState({
        title: 'No bookmarks yet',
        body: ['Use the Bookmark button on a work item, merge request, branch or pipeline.', about],
        actions: h('a', { class: 'btn sm', href: to('#/work') }, icon('work', 'sm'), 'Go to Work items'),
      }),
    );
  }
  // Grouped by what the bookmark points at; each group keeps every column.
  const KINDS: readonly (readonly [ResourceReference['kind'], string, IconName])[] = [
    ['work_item', 'Work items', 'work'],
    ['mr', 'Merge requests', 'mr'],
    ['branch', 'Branches', 'branch'],
    ['pipeline', 'Pipelines', 'pipeline'],
  ];
  const table = (list: readonly Bookmark[]): HTMLElement =>
    simpleTable(
      ['Label', 'Reference', 'Host', 'Availability', ''],
      list.map((b) => {
        const r = resolveRef(b);
        const target = bookmarkTarget(b);
        return [
          r.href
            ? h('a', { class: 'line', href: r.href, onclick: bookmarkOpen(b) }, decoIcon(decorationFor(target), r.icon), b.label || r.title)
            : h('span', { class: 'line' }, decoIcon(decorationFor(target), r.icon), b.label || r.title),
          h('span', { class: 'mono' }, r.desc),
          h('span', { class: 'mono' }, b.host),
          stateTone(r),
          h(
            'div',
            { class: 'line' },
            styleBtn(target, b.label || r.title, r.icon),
            h('button', { class: 'btn sm', type: 'button', disabled: !S.prefs, onclick: () => rename(b) }, icon('edit', 'sm'), 'Rename'),
            h(
              'button',
              {
                class: 'btn sm danger',
                type: 'button',
                disabled: !S.prefs,
                onclick: () =>
                  void (async () => {
                    if (await confirmDialog('Remove bookmark', `Remove "${b.label}" from shared bookmarks?`, 'Remove'))
                      void pref({ operation: 'bookmark_delete', reference: b.reference }, `Remove bookmark "${b.label}"`);
                  })(),
              },
              icon('trash', 'sm'),
              'Remove',
            ),
          ),
        ];
      }),
      'No bookmarks.',
      { label: 'Bookmarks' },
    );
  return h(
    'div',
    { class: 'screen' },
    head(`${bs.length} saved · shared preferences`),
    h('p', { class: 'hint' }, about),
    KINDS.map(([kind, label, ico]) => {
      const list = bs.filter((b) => b.reference.kind === kind);
      return list.length ? sec(`${label} (${list.length})`, ico, table(list)) : null;
    }),
    shortcutManager(),
  );
}

/* ======================================================= saved views */

export function viewsScreen(): HTMLElement {
  const vs = S.prefs?.saved_views ?? [];
  const body = SCOPES.map((scope) => {
    const items = vs.filter((v) => v.scope === scope);
    if (!items.length) return null;
    return sec(
      SCOPE_LABEL[scope],
      SCOPE_ICON[scope],
      simpleTable(
        ['Name', 'Host · projects', 'Filters', 'Sort', 'Fields', 'Layout', ''],
        items.map((v) => {
          const f = v.filters;
          const ignored = v.columns.filter((c) => !COLS[scope].includes(c) && !(scope === 'work_items' && c.startsWith(ENV_PREFIX)));
          const otherHost = v.host !== S.host;
          const ms: MsFilter = normMs(f.milestone);
          const target = viewTarget(v);
          return [
            h('span', { class: 'line' }, decoIcon(decorationFor(target), SCOPE_ICON[scope]), h('strong', null, v.name)),
            h(
              'span',
              { class: 'reason' },
              h('span', { class: 'mono' }, v.host),
              ' · ',
              viewProjectsLabel(v),
              otherHost
                ? h('span', { class: 'chip st t-unknown', title: `This console is connected to ${S.host ?? 'an unknown host'}` }, h('span', null, 'other host'))
                : null,
            ),
            h(
              'span',
              { class: 'reason' },
              [
                `state ${f.state}`,
                f.search ? `"${f.search}"` : null,
                f.assigned ? 'assigned' : null,
                f.group ? `group ${f.group}` : null,
                f.show_hidden ? 'hidden shown' : null,
                scope === 'mrs' ? 'authored by me' : null,
                scope === 'work_items' && ms.mode !== 'all' ? `milestone: ${msModeLabel(ms)}` : null,
              ]
                .filter(Boolean)
                .join(' · '),
            ),
            `${SORT_LABEL[v.sort]} ${v.descending ? '↓' : '↑'}`,
            h(
              'span',
              null,
              `${v.columns.length}`,
              ignored.length
                ? h(
                    'span',
                    { class: 'chip st t-warn', title: `Not usable for this scope: ${ignored.join(', ')}` },
                    h('span', null, `${ignored.length} ignored`),
                  )
                : null,
            ),
            v.orientation === 'columns' ? 'Records as columns' : 'Records as rows',
            h(
              'div',
              { class: 'line' },
              h(
                'button',
                {
                  class: 'btn sm',
                  type: 'button',
                  disabled: otherHost,
                  title: scope === 'work_items' ? 'Opens the view; its filters become the shared work-item filters' : 'Opens the view in this browser',
                  onclick: () => applyView(v),
                },
                'Open',
              ),
              styleBtn(target, v.name, SCOPE_ICON[scope]),
              h(
                'button',
                {
                  class: 'btn sm danger',
                  type: 'button',
                  disabled: !S.prefs,
                  onclick: () =>
                    void (async () => {
                      if (await confirmDialog('Delete view', `Delete saved view "${v.name}" for everyone using these preferences?`, 'Delete'))
                        void pref({ operation: 'saved_view_delete', name: v.name }, `Delete view "${v.name}"`);
                    })(),
                },
                icon('trash', 'sm'),
                'Delete',
              ),
            ),
          ];
        }),
        '',
      ),
    );
  }).filter((x): x is HTMLElement => x !== null);
  return h(
    'div',
    { class: 'screen' },
    h(
      'div',
      { class: 'sh' },
      h('div', { class: 'sh-title' }, h('h1', null, 'Saved views'), h('span', { class: 'count' }, `${vs.length} saved · shared preferences`)),
    ),
    body.length
      ? h(
          'p',
          { class: 'hint' },
          'Open applies a view’s filters, fields, sort and layout. Work-item filters are shared preferences, so opening a work-item view changes them for everyone using this preference file. A view saved for another repository scope switches to it and says so. Overview/Detailed is a browser setting and is not part of a view.',
        )
      : null,
    body.length
      ? [body, shortcutManager()]
      : emptyState({
          title: 'No saved views yet',
          body: 'Arrange filters (including the milestone filter), fields, sort and orientation on any list, then choose "Save view". Views remember the host and repository scope.',
          actions: h('a', { class: 'btn sm', href: to('#/work') }, icon('work', 'sm'), 'Go to Work items'),
        }),
  );
}

/* =================================================== resource shells */

function textMatch(q: string, parts: readonly (string | null | undefined)[]): boolean {
  const t = q.trim().toLowerCase();
  if (!t) return true;
  const hay = parts.filter(Boolean).join(' ').toLowerCase();
  return t.split(/\s+/).every((x) => hay.includes(x));
}

function resourceShell(o: {
  title: string;
  count: string | null;
  scope: Scope;
  bar: Kid;
  table: Kid;
  inspector: HTMLElement | null;
  closeHref: string;
  extra?: Kid;
}): HTMLElement {
  const gate = scopeGate();
  return h(
    'div',
    { class: 'screen fill' },
    h(
      'div',
      { class: 'sh' },
      h('div', { class: 'sh-title' }, h('h1', null, o.title), o.count ? h('span', { class: 'count' }, o.count) : null),
      viewControls(o.scope, o.scope),
    ),
    o.extra ?? null,
    o.bar,
    gate ??
      h(
        'div',
        { class: `split${o.inspector ? ' has-insp' : ''}` },
        h('div', { class: 'col' }, o.table),
        o.inspector
          ? [h('button', { class: 'scrim', type: 'button', 'aria-label': 'Close details', tabindex: '-1', onclick: () => go(o.closeHref) }), o.inspector]
          : null,
      ),
  );
}

function inspectorEl(title: string, sub: string | null, tools: Kid, body: Kid, closeHref: string): HTMLElement {
  return h(
    'aside',
    { class: 'inspector', 'aria-label': `${title} details` },
    h(
      'div',
      { class: 'insp-head' },
      h('div', { class: 'grow' }, h('h2', null, title), sub ? h('div', { class: 'muted' }, sub) : null),
      tools,
      h('a', { class: 'btn icon ghost', href: closeHref, 'aria-label': 'Close details', 'data-fk': 'insp-close' }, icon('close')),
    ),
    h('div', { class: 'insp-body', 'data-scroll': 'insp' }, body),
  );
}

function searchBox(scope: Scope, placeholder: string): HTMLDivElement {
  const ui = S.ui[scope];
  return h(
    'div',
    { class: 'search' },
    icon('search'),
    h('input', {
      class: 'input',
      type: 'search',
      placeholder,
      'aria-label': `Search ${SCOPE_LABEL[scope].toLowerCase()}`,
      value: ui.filters.search,
      'data-fk': `q-${scope}`,
      'data-search': '',
      maxlength: '200',
      oninput: (e: Event) => {
        ui.filters.search = controlValue(e);
        render();
      },
    }),
  );
}

const cap = (s: string): string => `${s.charAt(0).toUpperCase()}${s.slice(1)}`;

function stateSeg(scope: Scope): HTMLDivElement {
  const ui = S.ui[scope];
  return h(
    'div',
    { class: 'seg', role: 'group', 'aria-label': 'State' },
    STATES[scope].map((s) =>
      h(
        'button',
        {
          type: 'button',
          'aria-pressed': String(ui.filters.state === s),
          'data-fk': `st-${scope}-${s}`,
          onclick: () => {
            ui.filters.state = s;
            render();
          },
        },
        cap(s),
      ),
    ),
  );
}

const isViewState = (scope: Scope, s: string): s is ViewState => STATES[scope].some((x) => x === s);
const isStatus = (s: string): s is Status => Object.hasOwn(STATUS, s);
const statusLabel = (s: ViewState): string => (s === 'all' ? 'All statuses' : isStatus(s) ? STATUS[s][2] : s);

function stateSelect(scope: Scope): HTMLSelectElement {
  const ui = S.ui[scope];
  return h(
    'select',
    {
      class: 'select',
      'aria-label': 'Status filter',
      'data-fk': `st-${scope}`,
      onchange: (e: Event) => {
        const v = controlValue(e);
        if (isViewState(scope, v)) {
          ui.filters.state = v;
          render();
        }
      },
    },
    STATES[scope].map((s) => h('option', { value: s, selected: ui.filters.state === s }, statusLabel(s))),
  );
}

function itemLinks(vs: readonly ItemView[]): HTMLElement {
  return vs.length
    ? h(
        'div',
        { class: 'lines' },
        vs.map((v) =>
          h(
            'a',
            { href: to(itemHref(v.item.identity)), class: 'trunc', title: v.item.title },
            h('span', { class: 'mono' }, `#${v.item.identity.issue.value}`),
            ' ',
            v.item.title,
          ),
        ),
      )
    : none('No work item');
}

function rowLink(path: string, closePath: string, selected: boolean, text: string, label: string): HTMLAnchorElement {
  return h(
    'a',
    {
      class: 'row-link',
      href: to(selected ? closePath : path),
      'aria-current': selected ? 'true' : null,
      'aria-label': selected ? `${label} (selected; activate to close)` : label,
      'data-fk': `rl-${path}`,
    },
    text,
  );
}

const inProjectSet = (ui: ListUi, pid: number): boolean => !ui.projectSet || ui.projectSet.has(pid);
const selKeyOf = (args: readonly string[]): string | null => (args[0] !== undefined && args[1] !== undefined ? `${args[0]}/${args[1]}` : null);

// One vocabulary for commit relations: "same SHA as <ref kind>".
function shaRelation(a: string | null | undefined, b: string | null | undefined, what: string): HTMLSpanElement {
  if (!a || !b) return tone('unknown', 's_unknown', 'SHA not established', 'One of the SHAs is not supplied; a name match is not commit identity');
  return a === b ? tone('neutral', 's_match', `same SHA as ${what}`) : tone('muted', 's_mismatch', `SHA differs from ${what}`);
}

/* --------------------------------------------------------------- MRs */

const pipesOnRef = (project: number, ref: string): PipeEntry[] =>
  [...(S.d?.pipes.values() ?? [])].filter((x) => x.pipeline.project.value === project && x.pipeline.ref === ref);

const byIdDesc = (a: PipeEntry, b: PipeEntry): number => b.pipeline.id.value - a.pipeline.id.value;

// Newest pipeline on a ref with its failed (or important) jobs; older ones are
// counted, not hidden. The pipeline is matched by ref name, which is not
// commit proof, so its commit relation is always stated.
function latestPipe(ps: readonly PipeEntry[], against: string | null, what: string): Kid {
  const top = ps[0];
  if (!top) return none('No pipeline on this ref in the snapshot');
  const p = top.pipeline;
  const failed = failedJobs(p);
  return lines(
    line(
      statusBadge(p.status),
      h('a', { class: 'mono', href: to(pipeHref(p.project.value, p.id.value)) }, `#${p.id.value}`),
      against
        ? h(
            'span',
            {
              class: 'muted',
              title: p.sha === against ? `Same SHA as the ${what}` : `SHA differs from the ${what}; the same ref name is not proof of the same commit`,
            },
            p.sha === against ? '= SHA' : '≠ SHA',
          )
        : h('span', { class: 'muted', title: `The ${what} commit is not known; a ref name match is not proof of the same commit` }, 'commit not established'),
    ),
    failed.length ? jobDots(p, failed) : jobDots(p),
    ps.length > 1 ? h('span', { class: 'muted' }, `+${ps.length - 1} older on this ref`) : null,
  );
}

function itemChips(vs: readonly ItemView[]): Kid {
  return vs.length
    ? h(
        'div',
        { class: 'chips' },
        vs.map((v) =>
          h('a', { class: 'chip', href: to(itemHref(v.item.identity)), title: v.item.title }, icon('work', 'sm'), `#${v.item.identity.issue.value}`),
        ),
      )
    : none('No work item');
}

// Overview cards show the fields the user chose (the same Fields selection
// as the Detailed table); identity and state always head the card.
function stepsFor(cols: readonly Column[], all: readonly (readonly [Column, CardStep])[]): CardStep[] {
  return all.filter(([c]) => cols.includes(c)).map(([, s]) => s);
}

function mrCard(e: CatalogEntry, selKey: string | null, cols: readonly Column[]): HTMLElement {
  const m = e.mr;
  const src = mrSha(mrSource(m, e.row));
  const ps = pipesOnRef(m.source_project.value, m.source_branch).sort(byIdDesc);
  const steps = stepsFor(cols, [
    [
      'branch',
      {
        label: 'Branch',
        icon: 'branch',
        basis: 'root',
        body: h(
          'span',
          { class: 'mono' },
          h('a', { href: to(branchHref(m.source_project.value, m.source_branch)) }, m.source_branch),
          h('span', { class: 'muted' }, ` → ${m.target_branch}`),
        ),
      },
    ],
    ['sha', { label: 'Commit', icon: 'commit', basis: src ? 'root' : 'none', body: sha(src, 'Source commit unknown') }],
    ['pipeline', { label: 'Pipeline', icon: 'pipeline', basis: ps.length ? 'cand' : 'none', body: latestPipe(ps, src, 'MR source') }],
    ['title', { label: 'Items', icon: 'work', basis: e.views.length ? 'root' : 'none', body: itemChips(e.views) }],
    ['updated_at', { label: 'Updated', icon: 'clock', basis: 'none', body: time(e.row.updated_at) }],
  ]);
  return h(
    'div',
    { class: 'vc' },
    h(
      'div',
      { class: 'vc-h' },
      rowLink(mrHref(m.project.value, m.iid.value), '#/mrs', e.key === selKey, `!${m.iid.value}`, `Show merge request !${m.iid.value}`),
      // Overview cards always sit in the groups of mrGroups: "Open" and
      // "Open · draft" guarantee the open state (and the draft flag) of every
      // card in them, so only the mixed history group repeats the badges.
      // Detailed tables and the drawer always show them.
      m.state === 'open' ? null : mrStateBadge(m),
      m.state === 'open' ? null : draftChip(m),
    ),
    h('p', { class: 'vc-t', title: m.title }, m.title),
    cols.includes('project')
      ? h('div', { class: 'vc-sub' }, projectAvatar(m.project.value, 'avatar sm'), h('span', { class: 'trunc' }, e.row.project_path))
      : null,
    steps.length ? cardFlow(`Flow of merge request !${m.iid.value}`, steps) : null,
  );
}

const mrGroups = (rs: readonly CatalogEntry[]): MatrixGroup<CatalogEntry>[] => [
  {
    key: 'open',
    label: 'Open',
    tone: 'info',
    hint: 'Open and not a draft',
    records: rs.filter((e) => e.mr.state === 'open' && !e.mr.draft),
    open: true,
  },
  {
    key: 'draft',
    label: 'Open · draft',
    tone: null,
    hint: 'Draft stays draft until someone changes it in GitLab',
    records: rs.filter((e) => e.mr.state === 'open' && e.mr.draft),
    open: true,
  },
  {
    key: 'finished',
    label: 'Merged, closed or unknown state',
    tone: null,
    hint: 'History of your authored merge requests',
    records: rs.filter((e) => e.mr.state !== 'open'),
    open: false,
  },
];

export function mrScreen(args: readonly string[]): HTMLElement {
  const ui = S.ui.mrs;
  const f = ui.filters;
  const C = S.mrs;
  const all = [...(S.d?.catalog.values() ?? [])];
  const recs = sortRecords(
    all.filter(
      (e) =>
        inProjectSet(ui, e.mr.project.value) &&
        (f.state === 'all' || e.mr.state === f.state) &&
        textMatch(f.search, [
          `!${e.mr.iid.value}`,
          e.mr.title,
          e.mr.source_branch,
          e.mr.target_branch,
          e.row.project_path,
          ...e.views.map((v) => `#${v.item.identity.issue.value}`),
        ]),
    ),
    ui,
    (e, s): SortKey => {
      switch (s) {
        case 'title':
          return [e.mr.title];
        case 'state':
          return [e.mr.state, e.mr.iid.value];
        case 'project':
          return [e.row.project_path, e.mr.iid.value];
        case 'updated_at':
          return [Date.parse(e.row.updated_at) || null, e.mr.iid.value];
        default:
          return [e.mr.project.value, e.mr.iid.value];
      }
    },
  );
  const selKey = selKeyOf(args);
  const sel = selKey ? (S.d?.catalog.get(selKey) ?? null) : null;

  const catalog = h(
    'div',
    { class: 'filterbar' },
    S.mrsLoading ? h('span', { class: 'pill', role: 'status' }, icon('s_pend', 'sm'), 'Loading catalog…') : null,
    C
      ? [
          // The fixture explanation is this pill's description (and on Sources),
          // not a separate sentence under the toolbar.
          h(
            'span',
            {
              class: `pill${C.source === 'fixture' ? ' st t-warn' : ''}`,
              title: C.source === 'fixture' ? 'Synthetic rows; links are deliberately unavailable example.invalid addresses' : null,
            },
            icon('source', 'sm'),
            C.source === 'fixture' ? 'Synthetic fixture catalog' : 'glab catalog',
            C.source === 'fixture' ? h('span', { class: 'sr' }, ': synthetic rows; links are deliberately unavailable') : null,
          ),
          h(
            'span',
            { class: 'pill', title: 'Coverage: MRs you authored, all states, within the configured projects only' },
            `Authored by me · all states · ${C.rows.length}${C.total !== C.rows.length && S.scope.project == null ? ` of ${C.total}` : ''}`,
          ),
          h('span', { class: 'pill' }, 'Fetched ', fmtTime(C.fetched_at) ?? 'time unknown'),
          S.mrsError ? h('span', { class: 'pill st t-warn', title: S.mrsError }, icon('warning', 'sm'), 'Last refresh failed; showing earlier catalog') : null,
        ]
      : null,
    h(
      'button',
      {
        class: 'btn sm',
        type: 'button',
        disabled: S.mrsLoading || !!S.scopeError,
        onclick: () => void loadMrs(true),
        title: 'Explicit read of the authored catalog; changes nothing remotely',
        'data-fk': 'mr-refresh',
      },
      icon('refresh', 'sm'),
      'Refresh catalog',
    ),
  );

  const problems = [
    !C && S.mrsError
      ? h(
          'div',
          { class: 'inline-err' },
          icon('s_fail', 'sm'),
          h(
            'div',
            null,
            h('strong', null, 'Authored merge request catalog unavailable. '),
            `${S.mrsError} Incomplete remote fetches are rejected rather than shown partially.`,
          ),
        )
      : null,
    C && S.scope.project == null && C.total !== C.rows.length
      ? h('div', { class: 'inline-err' }, icon('warning', 'sm'), h('div', null, `The catalog reports ${C.total} MRs but returned ${C.rows.length} rows.`))
      : null,
  ];

  const bar = h('div', { class: 'filterbar', role: 'search' }, searchBox('mrs', 'Search !iid, title, branch, project, #item'), stateSeg('mrs'));

  const table = matrix<CatalogEntry>({
    id: 'mx-mrs',
    label: 'Authored merge requests',
    scope: 'mrs',
    records: recs,
    columns: ui.columns,
    orientation: ui.orientation,
    keyOf: (e) => e.key,
    selectedKey: selKey,
    head: (e, inv) =>
      h(
        'div',
        { class: 'lines' },
        h(
          'div',
          { class: 'idc' },
          rowLink(mrHref(e.mr.project.value, e.mr.iid.value), '#/mrs', e.key === selKey, `!${e.mr.iid.value}`, `Show merge request !${e.mr.iid.value}`),
        ),
        inv ? h('span', { class: 'title-line' }, e.mr.title) : null,
      ),
    cell: (e, c) => {
      const m = e.mr;
      switch (c) {
        case 'title':
          return lines(
            h('span', { class: 'title-text' }, m.title),
            e.views.length
              ? h(
                  'div',
                  { class: 'chips' },
                  e.views.map((v) =>
                    h('a', { class: 'chip', href: to(itemHref(v.item.identity)), title: v.item.title }, icon('work', 'sm'), `#${v.item.identity.issue.value}`),
                  ),
                )
              : none('No linked work item'),
          );
        case 'state':
          return h('div', { class: 'chips' }, mrStateBadge(m), draftChip(m));
        case 'project':
          return e.row.project_path;
        case 'branch':
          return h(
            'span',
            { class: 'mono' },
            h('a', { href: to(branchHref(m.source_project.value, m.source_branch)) }, m.source_branch),
            ' → ',
            m.target_branch,
          );
        case 'sha':
          return sha(mrSha(mrSource(m, e.row)), 'Source commit unknown');
        case 'pipeline': {
          // Matched by source ref name only (dashed); the catalog itself carries no pipeline facts.
          const ps = pipesOnRef(m.source_project.value, m.source_branch).sort((a, b) => b.pipeline.id.value - a.pipeline.id.value);
          if (!ps.length) return none('None in the snapshot');
          const src = mrSha(mrSource(m, e.row));
          return lines(
            ps
              .slice(0, 2)
              .map((x) =>
                h(
                  'span',
                  { class: 'line byref', title: 'Matched to this MR by source ref name only' },
                  statusBadge(x.pipeline.status),
                  h('a', { class: 'mono', href: to(pipeHref(x.pipeline.project.value, x.pipeline.id.value)) }, `#${x.pipeline.id.value}`),
                  src
                    ? x.pipeline.sha === src
                      ? h('span', { class: 'muted', title: 'Same SHA as the MR source' }, '= source')
                      : h('span', { class: 'muted', title: 'SHA differs from the MR source' }, '≠ source')
                    : null,
                ),
              ),
            ps.length > 2 ? h('span', { class: 'muted' }, `+${ps.length - 2} more`) : null,
          );
        }
        case 'updated_at':
          return time(e.row.updated_at);
        default:
          return none('—');
      }
    },
    emptyText: S.mrsLoading ? 'Loading the authored catalog…' : !C ? 'The authored catalog is not loaded.' : 'No authored merge requests match these filters.',
    drawer: !!selKey,
    visualCard: (e, cols) => mrCard(e, selKey, cols),
    groups: mrGroups,
  });

  let insp: HTMLElement | null = null;
  if (selKey) {
    if (!sel) {
      const wm = S.d?.wmrs.get(selKey) ?? null;
      const ws = wm ? mrSource(wm, null) : null;
      insp = inspectorEl(
        `!${args[1] ?? ''}`,
        projectPath(Number(args[0])),
        null,
        [
          h(
            'p',
            { class: 'muted' },
            wm
              ? 'This merge request is referenced by a work item but is not in your authored catalog, so the browser does not list it. Its work-item copy is summarised here.'
              : 'This merge request is not in your authored catalog for this repository scope. Bookmarks to it are kept.',
          ),
          wm && ws
            ? h(
                'dl',
                { class: 'kv' },
                h('dt', null, 'Title'),
                h('dd', null, wm.title),
                h('dt', null, 'State'),
                h('dd', null, h('div', { class: 'chips' }, mrStateBadge(wm), draftChip(wm))),
                h('dt', null, 'Source → target'),
                h('dd', { class: 'mono' }, `${wm.source_branch} → ${wm.target_branch}`),
                h('dt', null, 'Source commit'),
                h('dd', null, ws.known ? sha(ws.sha) : lines(none('Source commit unknown'), h('div', { class: 'reason' }, ws.why))),
                h('dt', null, 'Work items'),
                h('dd', null, itemLinks(S.d?.mrViews.get(selKey) ?? [])),
              )
            : null,
        ],
        to('#/mrs'),
      );
    } else insp = mrInspector(sel);
  }

  return resourceShell({
    title: 'Merge requests',
    scope: 'mrs',
    count: C ? `${recs.length} shown` : null,
    extra: [catalog, problems],
    bar,
    table,
    inspector: insp,
    closeHref: to('#/mrs'),
  });
}

function mrInspector(sel: CatalogEntry): HTMLElement {
  const m = sel.mr;
  const row = sel.row;
  const sp = m.source_project.value;
  const pipes = pipesOnRef(sp, m.source_branch);
  const src = mrSource(m, row);
  const srcSha = mrSha(src);
  const rel = (s: string): HTMLSpanElement =>
    !srcSha
      ? tone('unknown', 's_unknown', 'SHA not established', 'The MR source commit is unknown')
      : s === srcSha
        ? tone('neutral', 's_match', 'same SHA as MR source')
        : tone('muted', 's_mismatch', 'SHA differs from MR source');
  return inspectorEl(
    `!${m.iid.value} ${m.title}`,
    row.project_path,
    bookmarkBtn({ kind: 'mr', project: { value: m.project.value }, iid: { value: m.iid.value } }, `!${m.iid.value} ${m.title}`),
    [
      h('div', { class: 'chips' }, mrStateBadge(m), draftChip(m), extLink(m.link, 'Merge request')),
      h(
        'ol',
        { class: 'lane compact', 'aria-label': 'Merge request process' },
        h(
          'li',
          { class: 'lane-step lk-root' },
          h('div', { class: 'lane-label' }, icon('branch', 'sm'), 'Source'),
          h(
            'div',
            { class: 'lane-body' },
            processNode('root', [
              line(
                h('a', { class: 'mono strong', href: to(branchHref(sp, m.source_branch)) }, m.source_branch),
                h('span', { class: 'muted' }, `→ ${m.target_branch}`),
              ),
              line(
                h('span', { class: 'muted' }, 'source commit'),
                sha(srcSha, 'Source commit unknown'),
                src.known
                  ? evidence(`ev-mr-${m.project.value}-${m.iid.value}-src`, null, [
                      h('div', null, 'Source commit ', h('code', { class: 'mono' }, src.sha), ` reported by the ${src.from}.`),
                    ])
                  : null,
              ),
              src.known && src.other
                ? line(
                    tone('warn', 's_mismatch', 'catalog source differs', `The authored catalog reports ${src.other}; the MR record reports ${src.sha}`),
                    sha(src.other),
                  )
                : null,
              src.known ? null : h('div', { class: 'reason' }, src.why),
              sp !== m.project.value ? h('div', { class: 'reason' }, `From fork project ${projectPath(sp)}`) : null,
            ]),
          ),
        ),
        h(
          'li',
          { class: 'lane-step lk-ref' },
          h('div', { class: 'lane-label' }, icon('mr', 'sm'), 'Merge request'),
          h(
            'div',
            { class: 'lane-body' },
            processNode('ref', [
              h(
                'dl',
                { class: 'kv' },
                h('dt', null, 'Author ID'),
                h('dd', { class: 'mono' }, String(row.author_id.value)),
                h('dt', null, 'Created'),
                h('dd', null, time(row.created_at)),
                h('dt', null, 'Updated'),
                h('dd', null, time(row.updated_at)),
              ),
              line(editDraftEntry(m, srcSha)),
            ]),
          ),
        ),
        h(
          'li',
          { class: `lane-step lk-${pipes.length ? 'cand' : 'none'}` },
          h('div', { class: 'lane-label' }, icon('pipeline', 'sm'), 'Pipelines on source ref'),
          h(
            'div',
            { class: 'lane-body' },
            pipes.length
              ? pipes.map((e) =>
                  processNode('cand', [
                    line(
                      statusBadge(e.pipeline.status, { prefix: 'Pipeline' }),
                      h('a', { class: 'mono strong', href: to(pipeHref(e.pipeline.project.value, e.pipeline.id.value)) }, `#${e.pipeline.id.value}`),
                      h('span', { class: 'muted' }, sourceLabel(e.pipeline.source)),
                    ),
                    line(sha(e.pipeline.sha), rel(e.pipeline.sha)),
                    jobsBlock(e.pipeline),
                  ]),
                )
              : processNode('empty', [
                  none('None in the work-item snapshot'),
                  h('div', { class: 'reason' }, 'The catalog is a summary and carries no pipeline, job or deployment facts.'),
                ]),
          ),
        ),
      ),
      sec(
        'Linked work items',
        'work',
        sel.views.length
          ? h(
              'ul',
              { class: 'list box' },
              sel.views.map((v) => {
                const im = v.item.merge_requests.find((x) => x.iid.value === m.iid.value && x.project.value === m.project.value);
                return h(
                  'li',
                  null,
                  h(
                    'a',
                    { class: 'grow', href: to(itemHref(v.item.identity)) },
                    h('span', { class: 'mono' }, `#${v.item.identity.issue.value}`),
                    ' ',
                    v.item.title,
                  ),
                  im ? evidence(`ev-mr-${m.project.value}-${m.iid.value}-${wkStr(v.item.identity)}`, im.association) : null,
                );
              }),
            )
          : h('p', { class: 'muted' }, 'No work item in this snapshot references this MR. Historical MRs without a work item are still part of your catalog.'),
      ),
      h('p', { class: 'hint' }, 'Pipelines are matched to this MR by ref name only and come from work-item snapshots; commit identity is shown separately.'),
    ],
    to('#/mrs'),
  );
}

/* ---------------------------------------------------------- branches */

const branchShas = (b: BranchEntry): string[] => [...new Set(b.entries.map((e) => e.branch.sha).filter(Boolean))];

function rebaseDiagram(name: string, r: Rebase): HTMLElement | null {
  if (r.kind !== 'verified') return null;
  const behind = Math.max(0, r.behind);
  const shown = Math.min(behind, 8);
  return h(
    'div',
    { class: 'rb', role: 'img', 'aria-label': `${r.target_branch} has ${behind} commit${behind === 1 ? '' : 's'} not in ${name}` },
    h(
      'div',
      { class: 'rb-row' },
      h('span', { class: 'mono trunc' }, r.target_branch),
      h(
        'div',
        { class: 'rb-track' },
        h('span', { class: 'rb-dot' }),
        Array.from({ length: shown }, () => h('span', { class: 'rb-dot new' })),
        behind > shown ? h('span', { class: 'rb-more' }, `+${behind - shown}`) : null,
      ),
    ),
    h(
      'div',
      { class: 'rb-row' },
      h('span', { class: 'mono trunc' }, name),
      h('div', { class: 'rb-track' }, h('span', { class: 'rb-dot' }), h('span', { class: 'rb-dot head', title: r.source_sha })),
    ),
    h(
      'div',
      { class: 'muted' },
      behind
        ? `${behind} commit${behind === 1 ? '' : 's'} on ${r.target_branch} not in this branch · ${r.required ? 'rebase required' : 'rebase not required'}`
        : `Not behind ${r.target_branch} · rebase not required`,
    ),
    h('div', { class: 'reason' }, 'Source: ', r.source, ' · checked ', h('span', { class: 'nowrap' }, fmtTime(r.checked_at) ?? 'time not supplied')),
  );
}

function branchCard(b: BranchEntry, selKey: string | null, cols: readonly Column[]): HTMLElement {
  const shas = branchShas(b);
  const bsha = shas.length === 1 ? (shas[0] ?? null) : null;
  const views = [...new Set(b.entries.map((e) => e.view))];
  const steps = stepsFor(cols, [
    [
      'sha',
      {
        label: 'Head',
        icon: 'commit',
        basis: shas.length ? 'root' : 'none',
        body: shas.length
          ? lines(
              shas.map((x) => sha(x)),
              shas.length > 1 ? tone('warn', 'warning', 'Items disagree') : null,
            )
          : none('No SHA (named only as an MR source)'),
      },
    ],
    [
      'state',
      {
        label: 'Rebase',
        icon: 'rebase',
        basis: b.entries.length ? 'root' : 'none',
        body: b.entries.length
          ? h(
              'div',
              { class: 'chips' },
              b.entries.map((e) => rebaseBadge(e.branch.rebase)),
            )
          : none('No rebase evidence'),
      },
    ],
    [
      'mr',
      {
        label: 'MR',
        icon: 'mr',
        basis: b.mrs.length ? 'ref' : 'none',
        body: b.mrs.length
          ? lines(
              b.mrs.map((e) =>
                line(
                  h('a', { class: 'mono', href: to(mrHref(e.mr.project.value, e.mr.iid.value)) }, `!${e.mr.iid.value}`),
                  mrStateBadge(e.mr),
                  draftChip(e.mr),
                ),
              ),
            )
          : none('None'),
      },
    ],
    [
      'pipeline',
      {
        label: 'Pipeline',
        icon: 'pipeline',
        basis: b.pipelines.length ? 'ref' : 'none',
        body: latestPipe([...b.pipelines].sort(byIdDesc), bsha, 'branch head'),
      },
    ],
    ['title', { label: 'Items', icon: 'work', basis: views.length ? 'root' : 'none', body: itemChips(views) }],
  ]);
  return h(
    'div',
    { class: 'vc' },
    h(
      'div',
      { class: 'vc-h' },
      icon('branch', 'sm'),
      rowLink(branchHref(b.project, b.name), '#/branches', b.key === selKey, b.name, `Select branch ${b.name} (visual only)`),
    ),
    cols.includes('project')
      ? h('div', { class: 'vc-sub' }, projectAvatar(b.project, 'avatar sm'), h('span', { class: 'trunc' }, projectPath(b.project)))
      : null,
    steps.length ? cardFlow(`Flow of branch ${b.name}`, steps) : null,
  );
}

const behindNow = (b: BranchEntry): boolean => b.entries.some((e) => e.branch.rebase.kind === 'verified' && e.branch.rebase.required);

const branchGroups = (rs: readonly BranchEntry[]): MatrixGroup<BranchEntry>[] => [
  {
    key: 'behind',
    label: 'Needs rebase',
    tone: 'warn',
    hint: 'Verified rebase evidence says the branch is behind its target',
    records: rs.filter((b) => b.entries.length && behindNow(b)),
    open: true,
  },
  {
    key: 'linked',
    label: 'Named by work items',
    tone: null,
    hint: 'Up to date or rebase state unknown',
    records: rs.filter((b) => b.entries.length && !behindNow(b)),
    open: true,
  },
  {
    key: 'mronly',
    label: 'Only known as an MR source',
    tone: 'unknown',
    hint: 'Named only by an authored MR: no head commit or rebase evidence in the snapshot',
    records: rs.filter((b) => !b.entries.length),
    open: false,
  },
];

export function branchScreen(args: readonly string[]): HTMLElement {
  const ui = S.ui.branches;
  const f = ui.filters;
  const all = [...(S.d?.branches.values() ?? [])];
  const recs = sortRecords(
    all.filter(
      (b) =>
        inProjectSet(ui, b.project) &&
        textMatch(f.search, [b.name, projectPath(b.project), ...branchShas(b), ...b.entries.map((e) => `#${e.view.item.identity.issue.value}`)]),
    ),
    ui,
    (b, s): SortKey => (s === 'project' ? [projectPath(b.project), b.name] : [b.name, b.project]),
  );
  const selKey = selKeyOf(args);
  const sel = selKey ? (S.d?.branches.get(selKey) ?? null) : null;

  // The selection pill and its "nothing is checked out" caveat appear only
  // once a branch is selected; before that, one line says what is listed.
  const pill = h(
    'div',
    { class: 'filterbar' },
    selKey
      ? h(
          'span',
          { class: `pill${sel ? ' st t-info' : ''}` },
          icon('branch', 'sm'),
          sel ? h('span', { class: 'mono' }, sel.name) : `${args[1] ?? ''} (unavailable)`,
        )
      : null,
    h(
      'span',
      { class: 'hint' },
      selKey ? 'Visual selection only; nothing is checked out.' : 'Branches named by work items and authored MRs in this repository scope.',
    ),
  );

  const bar = h('div', { class: 'filterbar', role: 'search' }, searchBox('branches', 'Search branch, project, SHA, #item'));

  const table = matrix<BranchEntry>({
    id: 'mx-branches',
    label: 'Branches',
    scope: 'branches',
    records: recs,
    columns: ui.columns,
    orientation: ui.orientation,
    keyOf: (b) => b.key,
    selectedKey: selKey,
    head: (b) =>
      h(
        'div',
        { class: 'idc' },
        icon('branch', 'sm'),
        rowLink(branchHref(b.project, b.name), '#/branches', b.key === selKey, b.name, `Select branch ${b.name} (visual only)`),
      ),
    cell: (b, c) => {
      switch (c) {
        case 'title':
          return itemLinks([...new Set(b.entries.map((e) => e.view))]);
        case 'project':
          return projectPath(b.project);
        case 'sha': {
          const s = branchShas(b);
          return s.length
            ? lines(
                s.map((x) => sha(x)),
                s.length > 1 ? tone('warn', 'warning', 'Items disagree') : null,
              )
            : none('No SHA (named only as an MR source)');
        }
        case 'state':
          return b.entries.length ? lines(b.entries.map((e) => rebaseBadge(e.branch.rebase))) : none('No rebase evidence');
        case 'mr':
          return b.mrs.length
            ? lines(
                b.mrs.map((e) =>
                  line(
                    h('a', { class: 'mono', href: to(mrHref(e.mr.project.value, e.mr.iid.value)) }, `!${e.mr.iid.value}`),
                    mrStateBadge(e.mr),
                    draftChip(e.mr),
                    e.row ? null : h('span', { class: 'chip', title: 'Referenced by a work item; not in your authored catalog' }, 'not authored'),
                  ),
                ),
              )
            : none('None');
        case 'pipeline':
          return b.pipelines.length
            ? lines(
                b.pipelines.map((e) =>
                  line(
                    statusBadge(e.pipeline.status),
                    h('a', { class: 'mono', href: to(pipeHref(e.pipeline.project.value, e.pipeline.id.value)) }, `#${e.pipeline.id.value}`),
                  ),
                ),
              )
            : none('None on this ref');
        default:
          return none('—');
      }
    },
    emptyText: 'No branches match. Branches appear when a work item or authored MR in this repository scope names them.',
    drawer: !!selKey,
    visualCard: (b, cols) => branchCard(b, selKey, cols),
    groups: branchGroups,
  });

  let insp: HTMLElement | null = null;
  if (selKey) {
    if (!sel)
      insp = inspectorEl(
        args[1] ?? '',
        projectPath(Number(args[0])),
        null,
        h('p', { class: 'muted' }, 'This branch is not named by any work item or MR in the current data. Bookmarks to it are kept.'),
        to('#/branches'),
      );
    else {
      const shas = branchShas(sel);
      const bsha = shas.length === 1 ? (shas[0] ?? null) : null;
      const link = sel.entries[0]?.branch.link ?? null;
      insp = inspectorEl(
        sel.name,
        `${projectPath(sel.project)} · visual selection, not checked out`,
        bookmarkBtn({ kind: 'branch', project: { value: sel.project }, name: sel.name }, sel.name),
        [
          h(
            'dl',
            { class: 'kv' },
            h('dt', null, 'Head commit'),
            h('dd', null, shas.length ? shas.map((s) => sha(s)) : none('Not supplied — named only as an MR source branch')),
            h('dt', null, 'Link'),
            h('dd', null, link ? extLink(link, 'Branch') : none('No link supplied')),
          ),
          shas.length > 1
            ? h('div', { class: 'inline-err' }, icon('warning', 'sm'), h('div', null, 'Work items report different head commits for this branch name.'))
            : null,
          bsha
            ? h(
                'div',
                { class: 'line' },
                actionEntry('run_pipeline', { project: sel.project, branch: sel.name, expected_sha: bsha }, 'Run pipeline…'),
                actionEntry('create_tag', { project: sel.project, branch: sel.name, expected_sha: bsha }, 'Create tag…'),
                actionEntry('create_draft_mr', { project: sel.project, source_branch: sel.name, expected_sha: bsha }, 'Create draft MR…'),
              )
            : null,
          sec(
            'Rebase evidence',
            'rebase',
            sel.entries.length
              ? lines(
                  sel.entries.map(
                    (e) =>
                      rebaseDiagram(sel.name, e.branch.rebase) ??
                      lines(rebaseBadge(e.branch.rebase), h('div', { class: 'muted' }, e.branch.rebase.kind === 'unknown' ? e.branch.rebase.reason : '')),
                  ),
                )
              : none('No rebase evidence for this name.'),
          ),
          sec(
            'Associated work items',
            'work',
            sel.entries.length
              ? h(
                  'ul',
                  { class: 'list box' },
                  sel.entries.map((e) =>
                    h(
                      'li',
                      null,
                      h(
                        'a',
                        { class: 'grow', href: to(itemHref(e.view.item.identity)) },
                        h('span', { class: 'mono' }, `#${e.view.item.identity.issue.value}`),
                        ' ',
                        e.view.item.title,
                      ),
                      evidence(`ev-br-${sel.key}-${wkStr(e.view.item.identity)}`, e.branch.association),
                    ),
                  ),
                )
              : none('No work item associates this branch.'),
          ),
          sec(
            'Merge requests with this source branch',
            'mr',
            sel.mrs.length
              ? h(
                  'ul',
                  { class: 'list box' },
                  sel.mrs.map((e) =>
                    h(
                      'li',
                      null,
                      h('a', { class: 'mono', href: to(mrHref(e.mr.project.value, e.mr.iid.value)) }, `!${e.mr.iid.value}`),
                      h('span', { class: 'grow trunc' }, e.mr.title),
                      mrStateBadge(e.mr),
                      draftChip(e.mr),
                      shaRelation(mrSha(mrSource(e.mr, e.row)), bsha, 'branch head'),
                      e.row ? null : h('span', { class: 'chip', title: 'Referenced by a work item; not in your authored catalog' }, 'not authored'),
                    ),
                  ),
                )
              : none('None.'),
          ),
          sec(
            'Pipelines on this ref',
            'pipeline',
            sel.pipelines.length
              ? h(
                  'ul',
                  { class: 'list box' },
                  sel.pipelines.map((e) =>
                    h(
                      'li',
                      null,
                      statusBadge(e.pipeline.status),
                      h('a', { class: 'mono', href: to(pipeHref(e.pipeline.project.value, e.pipeline.id.value)) }, `#${e.pipeline.id.value}`),
                      h('span', { class: 'grow muted' }, sourceLabel(e.pipeline.source)),
                      shaRelation(e.pipeline.sha, bsha, 'branch head'),
                    ),
                  ),
                )
              : none('None.'),
          ),
          sec(
            'Environments naming this branch',
            'server',
            sel.envs.length
              ? h(
                  'ul',
                  { class: 'list box' },
                  sel.envs.map((e) => {
                    const s =
                      e.role === 'expected'
                        ? versionParts(e.env.expected).sha
                        : e.env.observation.kind === 'observed'
                          ? versionParts(e.env.observation.value).sha
                          : null;
                    return h(
                      'li',
                      null,
                      h('strong', { title: `Environment ${e.env.name}` }, envLabel(e.env.name)),
                      h('span', { class: 'muted' }, e.role === 'expected' ? 'expected' : 'observed runtime'),
                      h('a', { class: 'grow', href: to(itemHref(e.view.item.identity)) }, `#${e.view.item.identity.issue.value}`),
                      shaRelation(s, bsha, 'branch head'),
                    );
                  }),
                )
              : none('None.'),
          ),
          h('p', { class: 'hint' }, 'Relations by name always show their commit relation. A matching name alone is not commit identity.'),
        ],
        to('#/branches'),
      );
    }
  }
  return resourceShell({
    title: 'Branches',
    scope: 'branches',
    count: S.dash ? `${recs.length} shown` : null,
    extra: pill,
    bar,
    table,
    inspector: insp,
    closeHref: to('#/branches'),
  });
}

/* --------------------------------------------------------- pipelines */

const REF_KIND: Readonly<Record<RefKind, string>> = { tag: 'tag', branch: 'branch', ambiguous: 'branch and tag name', ref: 'ref' };

function pipelineGraph(p: Pipeline, selJob: number | null): HTMLElement {
  const jobs = p.jobs;
  if (!jobs.length) return h('p', { class: 'muted' }, 'No jobs reported for this pipeline.');
  return h(
    'ol',
    { class: 'pg', 'aria-label': `Stages of pipeline #${p.id.value}, in order` },
    stageOrder(jobs, p).map((s) => {
      const groups = groupJobs(jobs.filter((j) => j.stage === s));
      const deps = stageDeps(p, jobs, s);
      return h(
        'li',
        { class: 'pg-stage' },
        h(
          'div',
          { class: 'pg-h' },
          h('span', { class: 'trunc mono' }, s),
          deps.length
            ? h('span', { class: 'pg-dep', title: 'Expected predecessors: operator expectation, not the observed CI DAG' }, `after ${deps.join(', ')}`)
            : null,
          h('span', { class: 'muted' }, String(groups.length)),
        ),
        h(
          'ul',
          { class: 'pg-jobs' },
          groups.map((g) => {
            const j = g.current;
            const [t, ico, label] = STATUS[j.status];
            const earlier = g.attempts.filter((a) => a !== j);
            const selected = g.attempts.some((a) => a.id.value === selJob);
            return h(
              'li',
              null,
              h(
                'a',
                {
                  class: `jc t-${t}${selected ? ' sel' : ''}`,
                  href: to(jobHref(p.project.value, p.id.value, j.id.value)),
                  'aria-current': selected ? 'true' : null,
                  title: `${j.name}: ${label}, attempt ${j.attempt}${j.failure_reason ? ` — ${j.failure_reason}` : ''}`,
                },
                icon(ico, 'sm'),
                h('span', { class: 'jc-name' }, j.name),
                h('span', { class: 'sr' }, `: ${label}`),
                cfgMarks(p, j, true),
                j.attempt > 1 ? h('span', { class: 'jm-att' }, `try ${j.attempt}`) : null,
                earlier.length
                  ? h(
                      'span',
                      { class: 'jm-att', title: earlier.map((a) => `attempt ${a.attempt}: ${a.status}`).join(', ') },
                      icon('retry', 'sm'),
                      String(earlier.length),
                      h('span', { class: 'sr' }, ' earlier attempts'),
                    )
                  : null,
              ),
            );
          }),
        ),
      );
    }),
  );
}

const JOB_OPS = ['retry', 'cancel', 'play'] as const;
const PIPE_OPS = ['retry', 'cancel'] as const;
const opLabel = (op: string, what: string): string => `${op.charAt(0).toUpperCase()}${op.slice(1)} ${what}…`;

function jobDetail(e: PipeEntry, jid: number): HTMLElement {
  const p = e.pipeline;
  const j = p.jobs.find((x) => x.id.value === jid);
  if (!j) return h('div', { class: 'inline-err' }, icon('warning', 'sm'), h('div', null, `Job #${jid} is not listed in pipeline #${p.id.value}.`));
  const attempts = p.jobs.filter((x) => x.name === j.name && x.stage === j.stage).sort((a, b) => a.attempt - b.attempt);
  const pubs = e.publishes.filter((x) => x.job.value === j.id.value);
  const cfg = jobCfgOf(p, j);
  return h(
    'section',
    { class: 'box pad lines jd', 'aria-label': `Job ${j.name}` },
    h('div', { class: 'sec-h' }, icon('job', 'sm'), h('h2', null, j.name), h('span', { class: 'mono muted' }, `#${j.id.value}`)),
    h(
      'div',
      { class: 'chips' },
      statusBadge(j.status, { prefix: 'Job' }),
      j.retried ? h('span', { class: 'chip', title: 'A later attempt superseded this one' }, 'Superseded attempt') : null,
      extLink(j.link, 'Job'),
    ),
    h(
      'dl',
      { class: 'kv' },
      h('dt', null, 'Stage'),
      h('dd', null, j.stage),
      h('dt', null, 'Attempt'),
      h('dd', null, `${j.attempt} of ${attempts.length}`),
      h('dt', null, 'Failure reason'),
      h('dd', null, j.failure_reason || none(j.status === 'failed' ? 'Not supplied' : 'None')),
      h('dt', null, 'Pipeline'),
      h('dd', null, h('span', { class: 'mono' }, `#${p.id.value}`), ` on ${REF_KIND[e.refKind]} `, h('span', { class: 'mono' }, p.ref), ' · ', sha(p.sha)),
      h('dt', null, 'Configuration'),
      h(
        'dd',
        null,
        cfg
          ? h(
              'div',
              { class: 'chips' },
              cfg.important
                ? h('span', { class: 'chip st t-info' }, icon('star', 'xs'), h('span', null, 'Important'))
                : h('span', { class: 'chip' }, 'Not marked important'),
              h(
                'span',
                { class: 'chip' },
                `Role: ${cfg.role}${cfg.role === 'deploy' ? ` → ${cfg.environment ? envLabel(cfg.environment) : 'environment not named'}` : ''}`,
              ),
              h('span', { class: 'chip' }, cfg.stage_order !== null ? `Stage position ${cfg.stage_order + 1}` : 'Stage not configured'),
              cfg.depends_on.length
                ? h('span', { class: 'chip', title: 'Operator expectation, not the observed CI DAG' }, `Expected after ${cfg.depends_on.join(', ')}`)
                : null,
            )
          : none('No operator classification for this job'),
      ),
    ),
    attempts.length > 1
      ? h(
          'div',
          null,
          h('h3', null, 'Attempts'),
          h(
            'ul',
            { class: 'list' },
            attempts.map((a) =>
              h(
                'li',
                null,
                statusBadge(a.status),
                h(
                  'a',
                  { class: 'mono', href: to(jobHref(p.project.value, p.id.value, a.id.value)), 'aria-current': a === j ? 'true' : null },
                  `#${a.id.value}`,
                ),
                h('span', { class: 'muted' }, `attempt ${a.attempt}${a.retried ? ' · retried' : ' · current'}`),
                a.failure_reason ? h('span', { class: 'reason' }, a.failure_reason) : null,
              ),
            ),
          ),
        )
      : null,
    pubs.length
      ? h(
          'div',
          null,
          h('h3', null, 'Publish evidence referencing this job'),
          h(
            'ul',
            { class: 'list' },
            pubs.map((x) => h('li', null, statusBadge(x.status, { prefix: 'Publish' }), h('code', { class: 'mono grow art-b' }, breakable(x.artifact)))),
          ),
        )
      : null,
    h(
      'div',
      { class: 'line' },
      JOB_OPS.map((op) =>
        actionEntry('change_job', { project: p.project.value, id: j.id.value, pipeline: p.id.value, expected_sha: p.sha, operation: op }, opLabel(op, 'job')),
      ),
    ),
  );
}

// The drawer's first lines: pipeline status, publish evidence and configured
// deploy jobs as separate facts, then the way to the cross-project graph.
function pipeFacts(e: PipeEntry): HTMLElement {
  const p = e.pipeline;
  const failed = failedJobs(p);
  const deploys = groupJobs(p.jobs)
    .map((g) => ({ j: g.current, c: jobCfgOf(p, g.current) }))
    .filter((x) => x.c?.role === 'deploy');
  const row = (label: string, ...kids: Kid[]): HTMLLIElement => h('li', null, h('span', { class: 'pf-l' }, label), h('span', { class: 'pf-v' }, kids));
  return h(
    'section',
    { class: 'pf box pad', 'aria-label': 'Separate facts of this pipeline' },
    h(
      'ul',
      { class: 'pf-list' },
      row(
        'Pipeline',
        statusBadge(p.status),
        failed.length ? h('span', null, `failed: ${failed.map((j) => `${j.name}${j.failure_reason ? ` (${j.failure_reason})` : ''}`).join(', ')}`) : null,
      ),
      // Every publish entry (1:N) with its artifact, status and the job it
      // names; this is the drawer's only publish list.
      e.publishes.length
        ? e.publishes.map((x) => {
            const j = p.jobs.find((y) => y.id.value === x.job.value);
            return row(
              'Publish',
              statusBadge(x.status),
              h('code', { class: 'mono art-b' }, breakable(x.artifact)),
              j
                ? h('a', { class: 'muted', href: to(jobHref(p.project.value, p.id.value, j.id.value)) }, `job ${j.name}`)
                : h('span', { class: 'muted' }, `job #${x.job.value} (not listed)`),
            );
          })
        : row('Publish', h('span', { class: 'muted unk' }, 'No publish evidence (not proof that nothing was published)')),
      deploys.map(({ j, c }) =>
        row(
          `Deploy job → ${c?.environment ? envLabel(c.environment) : '?'}`,
          h('a', { class: 'mono', href: to(jobHref(p.project.value, p.id.value, j.id.value)) }, j.name),
          statusBadge(j.status),
        ),
      ),
    ),
    // Stated once per drawer (the list headings and the job panel no longer repeat it).
    h(
      'p',
      { class: 'hint' },
      'Separate facts: a failed pipeline does not mean publish or a deployment failed, and a job status (deploy jobs included) is not a deployment record, runtime identity or application test.',
    ),
    e.views.length
      ? h(
          'div',
          { class: 'line' },
          h('span', { class: 'muted' }, 'Cross-project relations:'),
          e.views.map((v) =>
            h(
              'a',
              {
                class: 'btn sm',
                href: to(itemHref(v.item.identity)),
                'data-fk': `pgraph-${wkStr(v.item.identity)}`,
                title: 'Opens the native pipeline graph on the work item. A trigger does not show which application version was deployed downstream.',
                onclick: () => {
                  S.focusTarget = `graph:${wkStr(v.item.identity)}`;
                },
              },
              icon('pipeline', 'sm'),
              `Graph on #${v.item.identity.issue.value}`,
            ),
          ),
        )
      : null,
  );
}

function pipeCard(e: PipeEntry, selKey: string | null, cols: readonly Column[]): HTMLElement {
  const p = e.pipeline;
  const failed = failedJobs(p);
  const steps = stepsFor(cols, [
    [
      'ref',
      {
        label: 'Ref',
        icon: e.refKind === 'tag' ? 'tag' : 'branch',
        basis: 'root',
        body: lines(
          line(h('span', { class: 'mono trunc' }, p.ref), h('span', { class: 'chip' }, REF_KIND[e.refKind])),
          h('span', { class: 'muted' }, sourceLabel(p.source)),
        ),
      },
    ],
    ['sha', { label: 'Commit', icon: 'commit', basis: 'root', body: sha(p.sha) }],
    [
      'jobs',
      { label: failed.length ? 'Failed' : 'Jobs', icon: 'job', basis: p.jobs.length ? 'root' : 'none', body: failed.length ? jobDots(p, failed) : jobDots(p) },
    ],
    [
      'publish',
      {
        label: 'Publish',
        icon: 'publish',
        basis: e.publishes.length ? 'root' : 'none',
        body: e.publishes.length
          ? // The artifact wraps (never an ellipsis), so its version stays readable.
            lines(e.publishes.map((x) => lines(statusBadge(x.status, { prefix: 'Publish' }), h('code', { class: 'mono art-b' }, breakable(x.artifact)))))
          : h('span', { class: 'muted unk', title: 'Not proof that nothing was published' }, 'No publish evidence'),
      },
    ],
    ['title', { label: 'Items', icon: 'work', basis: e.views.length ? 'root' : 'none', body: itemChips(e.views) }],
  ]);
  return h(
    'div',
    { class: 'vc' },
    h(
      'div',
      { class: 'vc-h' },
      rowLink(pipeHref(p.project.value, p.id.value), '#/pipelines', e.key === selKey, `#${p.id.value}`, `Show pipeline ${p.id.value}`),
      statusBadge(p.status),
      cols.includes('ref') ? null : h('span', { class: 'mono muted trunc' }, p.ref),
    ),
    cols.includes('project')
      ? h('div', { class: 'vc-sub' }, projectAvatar(p.project.value, 'avatar sm'), h('span', { class: 'trunc' }, projectPath(p.project.value)))
      : null,
    steps.length ? cardFlow(`Flow of pipeline ${p.id.value}`, steps) : null,
  );
}

const ACTIVE: readonly Status[] = ['running', 'pending', 'created', 'manual'];
const pipeGroups = (rs: readonly PipeEntry[]): MatrixGroup<PipeEntry>[] => [
  {
    key: 'failed',
    label: 'Failed',
    tone: 'fail',
    hint: 'Pipeline status failed',
    records: rs.filter((e) => e.pipeline.status === 'failed'),
    open: true,
  },
  {
    key: 'active',
    label: 'Running, waiting or manual',
    tone: 'info',
    hint: 'Not finished, or waiting for a manual job',
    records: rs.filter((e) => ACTIVE.includes(e.pipeline.status)),
    open: true,
  },
  { key: 'success', label: 'Succeeded', tone: 'ok', hint: 'Pipeline status success', records: rs.filter((e) => e.pipeline.status === 'success'), open: true },
  {
    key: 'other',
    label: 'Canceled, skipped or unknown',
    tone: null,
    hint: 'Finished without a result, or the status is not known',
    records: rs.filter((e) => ['canceled', 'skipped', 'unknown'].includes(e.pipeline.status)),
    open: false,
  },
];

export function pipelineScreen(args: readonly string[]): HTMLElement {
  const ui = S.ui.pipelines;
  const f = ui.filters;
  const all = [...(S.d?.pipes.values() ?? [])];
  const recs = sortRecords(
    all.filter(
      (e) =>
        inProjectSet(ui, e.pipeline.project.value) &&
        (f.state === 'all' || e.pipeline.status === f.state) &&
        textMatch(f.search, [
          `#${e.pipeline.id.value}`,
          e.pipeline.ref,
          e.pipeline.sha,
          e.pipeline.source,
          projectPath(e.pipeline.project.value),
          ...e.pipeline.jobs.map((j) => j.name),
          ...e.views.map((v) => `#${v.item.identity.issue.value}`),
        ]),
    ),
    ui,
    (e, s): SortKey =>
      s === 'state'
        ? [e.pipeline.status, e.pipeline.id.value]
        : s === 'project'
          ? [projectPath(e.pipeline.project.value), e.pipeline.id.value]
          : [e.pipeline.id.value],
  );
  const selKey = selKeyOf(args);
  const sel = selKey ? (S.d?.pipes.get(selKey) ?? null) : null;
  const selJob = args[2] === 'job' && /^\d+$/.test(args[3] ?? '') ? Number(args[3]) : null;

  const bar = h(
    'div',
    { class: 'filterbar', role: 'search' },
    searchBox('pipelines', 'Search #id, ref, SHA, job, #item'),
    stateSelect('pipelines'),
    h('span', { class: 'hint' }, 'Pipelines referenced by work items in this repository scope.'),
  );

  const table = matrix<PipeEntry>({
    id: 'mx-pipes',
    label: 'Pipelines',
    scope: 'pipelines',
    records: recs,
    columns: ui.columns,
    orientation: ui.orientation,
    keyOf: (e) => e.key,
    selectedKey: selKey,
    head: (e) =>
      h(
        'div',
        { class: 'idc' },
        rowLink(
          pipeHref(e.pipeline.project.value, e.pipeline.id.value),
          '#/pipelines',
          e.key === selKey,
          `#${e.pipeline.id.value}`,
          `Show pipeline ${e.pipeline.id.value}`,
        ),
      ),
    cell: (e, c) => {
      const p = e.pipeline;
      switch (c) {
        case 'title':
          return itemLinks(e.views);
        case 'state':
          return statusBadge(p.status);
        case 'project':
          return projectPath(p.project.value);
        case 'ref':
          return lines(
            line(h('span', { class: 'mono' }, p.ref), h('span', { class: 'chip' }, REF_KIND[e.refKind])),
            h('span', { class: 'muted' }, sourceLabel(p.source)),
          );
        case 'sha':
          return sha(p.sha);
        case 'jobs':
          return jobsBlock(p);
        case 'publish':
          return e.publishes.length
            ? lines(
                e.publishes.map((x) => lines(statusBadge(x.status, { prefix: 'Publish' }), h('code', { class: 'mono trunc', title: x.artifact }, x.artifact))),
              )
            : none('No publish evidence');
        default:
          return none('—');
      }
    },
    emptyText: 'No pipelines match these filters.',
    drawer: !!selKey,
    visualCard: (e, cols) => pipeCard(e, selKey, cols),
    groups: pipeGroups,
  });

  let insp: HTMLElement | null = null;
  if (selKey) {
    if (!sel)
      insp = inspectorEl(
        `#${args[1] ?? ''}`,
        projectPath(Number(args[0])),
        null,
        h('p', { class: 'muted' }, 'This pipeline is not referenced by any work item in this repository scope. Bookmarks to it are kept.'),
        to('#/pipelines'),
      );
    else {
      const p = sel.pipeline;
      insp = inspectorEl(
        `Pipeline #${p.id.value}`,
        projectPath(p.project.value),
        bookmarkBtn({ kind: 'pipeline', project: { value: p.project.value }, id: { value: p.id.value } }, `Pipeline #${p.id.value}`),
        [
          pipeFacts(sel),
          // The status is in the facts above; this line keeps the GitLab link.
          h('div', { class: 'chips' }, extLink(p.link, 'Pipeline')),
          h(
            'dl',
            { class: 'kv' },
            h('dt', null, 'Ran on'),
            h('dd', null, h('span', { class: 'chip' }, REF_KIND[sel.refKind]), ' ', h('span', { class: 'mono' }, p.ref)),
            h('dt', null, 'Commit'),
            h('dd', null, sha(p.sha)),
            h('dt', null, 'Source'),
            h('dd', null, sourceLabel(p.source)),
            h('dt', null, 'Work items'),
            h(
              'dd',
              null,
              sel.views.map((v) => {
                const ip = v.item.pipelines.find((x) => x.id.value === p.id.value);
                return line(
                  h('a', { class: 'mono', href: to(itemHref(v.item.identity)) }, `#${v.item.identity.issue.value}`),
                  ip ? evidence(`ev-pl-${sel.key}-${wkStr(v.item.identity)}`, ip.association) : null,
                );
              }),
            ),
          ),
          sec('Stages and jobs', 'job', pipelineGraph(p, selJob)),
          selJob != null ? jobDetail(sel, selJob) : h('p', { class: 'hint' }, 'Select a job for its attempts, failure reason and publish evidence.'),
          h(
            'div',
            { class: 'line' },
            PIPE_OPS.map((op) =>
              actionEntry('change_pipeline', { project: p.project.value, id: p.id.value, expected_sha: p.sha, operation: op }, opLabel(op, 'pipeline')),
            ),
          ),
        ],
        to('#/pipelines'),
      );
    }
  }
  return resourceShell({
    title: 'Pipelines',
    scope: 'pipelines',
    count: S.dash ? `${recs.length} shown` : null,
    bar,
    table,
    inspector: insp,
    closeHref: to('#/pipelines'),
  });
}

/* ---------------------------------------------------------- milestones */
// Catalog for the selected configured projects. Counts are server facts:
// null is "unknown", never zero. Active (GitLab state) and date-current
// (dates include today's configured local date) are different questions.

function countCell(n: number | null, what: string): HTMLSpanElement {
  return n === null
    ? h(
        'span',
        { class: 'chip st t-unknown', title: `The source did not provide the ${what}; unknown, not zero` },
        icon('s_unknown', 'sm'),
        h('span', null, 'Unknown'),
      )
    : h('span', { class: 'num' }, String(n));
}

function dateCurrentBadge(e: MilestoneCount): HTMLSpanElement {
  if (e.date_current === 'yes') return tone('ok', 's_ok', 'Date-current', e.date_reason);
  if (e.date_current === 'no') return tone('muted', 's_neutral', 'Not current', e.date_reason);
  return tone('unknown', 's_unknown', 'Unknown', e.date_reason);
}

function showMilestone(m: MsFilter): void {
  setWorkFilter({ milestone: m });
  go(to('#/work'));
}

// Date timeline. Dates are calendar days (no time of day); "today" is the
// server's configured local date, never the browser clock. Bar positions are
// CSS custom properties set through the CSSOM (the CSP forbids inline styles).
const DAY_MS = 86_400_000;
const dayNo = (s: string | null | undefined): number | null => {
  const m = s ? /^(\d{4})-(\d{2})-(\d{2})$/.exec(s) : null;
  return m ? Math.round(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) / DAY_MS) : null;
};
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] as const;
const withVars = <E extends HTMLElement>(el: E, vars: Readonly<Record<string, string>>): E => {
  for (const [k, v] of Object.entries(vars)) el.style.setProperty(k, v);
  return el;
};

function msTimeline(C: MilestoneCatalog, sel: string | null, noneSel: boolean): HTMLElement {
  const today = dayNo(C.date);
  const span = (e: MilestoneCount): { a: number | null; b: number | null } => ({ a: dayNo(e.milestone.start_date), b: dayNo(e.milestone.due_date) });
  const dated = C.entries
    .filter((e) => {
      const s = span(e);
      return s.a !== null || s.b !== null;
    })
    .sort((x, y) => {
      const sx = span(x);
      const sy = span(y);
      const end = (s: { b: number | null }): number => s.b ?? Number.MAX_SAFE_INTEGER;
      return (sx.a ?? sx.b ?? 0) - (sy.a ?? sy.b ?? 0) || end(sx) - end(sy) || x.milestone.title.localeCompare(y.milestone.title);
    });
  const undated = C.entries.filter((e) => !dated.includes(e));
  const points = dated.flatMap((e) => {
    const s = span(e);
    return [s.a, s.b];
  });
  if (today !== null) points.push(today);
  const known = points.filter((x): x is number => x !== null);
  const lo0 = known.length ? Math.min(...known) : 0;
  const hi0 = known.length ? Math.max(...known) : 1;
  const pad = Math.max(3, Math.round((hi0 - lo0) * 0.04));
  const lo = lo0 - pad;
  const total = Math.max(1, hi0 + pad - lo);
  const at = (d: number): string => `${(((d - lo) / total) * 100).toFixed(3)}%`;

  const todayLine = (): Kid => (today !== null ? withVars(h('span', { class: 'tl-today', 'aria-hidden': 'true' }), { '--x': at(today) }) : null);

  // Month ticks, thinned so that at most about a dozen are labelled.
  const ticks: HTMLElement[] = [];
  if (known.length) {
    const start = new Date(lo * DAY_MS);
    let y = start.getUTCFullYear();
    let mo = start.getUTCMonth() + 1;
    const months = Math.ceil(total / 30);
    const step = Math.max(1, Math.ceil(months / 12));
    for (let i = 0; i < 400; i++) {
      if (mo > 11) {
        y += Math.floor(mo / 12);
        mo %= 12;
      }
      const d = Math.round(Date.UTC(y, mo, 1) / DAY_MS);
      if (d > lo + total) break;
      if (mo % step === 0) ticks.push(withVars(h('span', { class: 'tl-tick' }, mo === 0 ? `${MONTHS[0]} ${y}` : (MONTHS[mo] ?? '')), { '--x': at(d) }));
      mo += 1;
    }
  }

  const row = (e: MilestoneCount): HTMLElement => {
    const ms = e.milestone;
    const ks = msKeyStr(ms.key);
    const { a, b } = span(e);
    const t = ms.state === 'closed' ? 'muted' : e.date_current === 'yes' ? 'ok' : e.date_current === 'unknown' ? 'unknown' : 'info';
    let bar: Kid = h('span', { class: 'tl-nodate' }, 'No start or due date');
    let dates = 'no dates';
    if (a !== null && b !== null) {
      const bad = b < a;
      bar = withVars(h('span', { class: `tl-bar t-${bad ? 'warn' : t}`, 'aria-hidden': 'true' }), { '--a': at(Math.min(a, b)), '--b': at(Math.max(a, b) + 1) });
      dates = `${ms.start_date} → ${ms.due_date}${bad ? ' (due before start)' : ''}`;
    } else if (a !== null) {
      bar = withVars(h('span', { class: `tl-bar tl-open-end t-${t}`, 'aria-hidden': 'true' }), { '--a': at(a), '--b': '100%' });
      dates = `${ms.start_date} → no due date`;
    } else if (b !== null) {
      bar = withVars(h('span', { class: `tl-bar tl-open-start t-${t}`, 'aria-hidden': 'true' }), { '--a': '0%', '--b': at(b + 1) });
      dates = `no start date → ${ms.due_date}`;
    }
    return h(
      'li',
      { class: `tl-row${ks === sel ? ' sel' : ''}` },
      h(
        'button',
        {
          class: 'tl-name',
          type: 'button',
          'data-fk': `ms-tl-${ks}`,
          'aria-pressed': String(ks === sel),
          title: 'Show work items in this milestone',
          onclick: () => showMilestone({ mode: 'selected', selected: ms.key }),
        },
        h('span', { class: 'tl-title' }, ms.title),
        h('span', { class: 'tl-dates mono' }, dates),
        h('span', { class: 'tl-owner' }, msOwner(ms.key)),
      ),
      h('div', { class: 'tl-track' }, todayLine(), bar),
      h(
        'div',
        { class: 'tl-facts' },
        ms.state === 'active' ? tone('info', 's_run', 'Active') : tone('muted', 's_cancel', 'Closed'),
        dateCurrentBadge(e),
        h(
          'span',
          { class: 'tl-n', title: 'Work items in this milestone (all states)' },
          countCell(e.work_items, 'work-item count'),
          h('span', { class: 'muted' }, e.work_items === 1 ? 'item' : 'items'),
          h('span', { class: 'muted', title: 'The subset that passes your saved work-item filters' }, `· ${e.visible_work_items} visible`),
        ),
      ),
    );
  };

  return h(
    'section',
    { class: 'tl box', 'aria-label': 'Milestone timeline' },
    h(
      'div',
      { class: 'tl-row tl-axis', 'aria-hidden': 'true' },
      h('span', { class: 'tl-name muted' }, known.length ? 'Milestone' : ''),
      h(
        'div',
        { class: 'tl-track' },
        ticks,
        today !== null ? withVars(h('span', { class: 'tl-today-l' }, `Today ${C.date}`), { '--x': at(today) }) : null,
        todayLine(),
      ),
      h('span', { class: 'tl-facts muted' }, 'State · date-current · count'),
    ),
    h(
      'ol',
      { class: 'tl-list' },
      dated.map(row),
      undated.map(row),
      h(
        'li',
        { class: `tl-row tl-none${noneSel ? ' sel' : ''}` },
        h(
          'button',
          {
            class: 'tl-name',
            type: 'button',
            'data-fk': 'ms-tl-none',
            'aria-pressed': String(noneSel),
            title: 'Show work items without a milestone',
            onclick: () => showMilestone({ mode: 'unassigned', selected: null }),
          },
          h('span', { class: 'tl-title' }, 'No milestone'),
          h('span', { class: 'tl-dates' }, 'items without a milestone'),
        ),
        h('div', { class: 'tl-track' }, todayLine()),
        h(
          'div',
          { class: 'tl-facts' },
          h(
            'span',
            { class: 'tl-n' },
            countCell(C.unassigned_work_items, 'count of items without a milestone'),
            h('span', { class: 'muted' }, C.unassigned_work_items === 1 ? 'item' : 'items'),
          ),
        ),
      ),
    ),
    h(
      'p',
      { class: 'tl-legend hint' },
      h('span', { class: 'tl-key t-ok' }),
      'date-current ',
      h('span', { class: 'tl-key t-info' }),
      'active ',
      h('span', { class: 'tl-key t-unknown' }),
      'date-current unknown ',
      h('span', { class: 'tl-key t-muted' }),
      'closed ',
      h('span', { class: 'tl-key tl-open-end t-info' }),
      'one date missing. The vertical line is today on the server (',
      `${C.date} ${C.timezone}`,
      '). Choose a milestone to show its work items.',
    ),
  );
}

export function milestonesScreen(): HTMLElement {
  const C = S.ms;
  const m = S.ui.work_items.filters.milestone;
  const sel = selectedMilestoneKey();
  const head = h(
    'div',
    { class: 'sh' },
    h(
      'div',
      { class: 'sh-title' },
      h('h1', null, 'Milestones'),
      C ? h('span', { class: 'count' }, `${C.entries.length} milestone${C.entries.length === 1 ? '' : 's'} · ${C.date} ${C.timezone}`) : null,
    ),
    h(
      'div',
      { class: 'toolbar' },
      modeSwitch(),
      h(
        'button',
        {
          class: 'btn',
          type: 'button',
          'data-fk': 'ms-reload',
          disabled: S.msLoading || !!S.scopeError,
          onclick: () => void loadMilestones(),
          title: 'Reads the catalog again from the GSpace server; changes nothing',
        },
        icon('refresh', S.msLoading ? 'spin' : ''),
        h('span', { class: 'lbl-wide' }, 'Reload'),
      ),
    ),
  );
  if (S.scopeError) return h('div', { class: 'screen' }, head, scopeGate());
  if (!C) {
    return h(
      'div',
      { class: 'screen' },
      head,
      S.msError
        ? emptyState({
            title: 'Milestone catalog unavailable',
            body: S.msError,
            actions: h('button', { class: 'btn sm', type: 'button', onclick: () => void loadMilestones() }, 'Try again'),
          })
        : emptyState({ title: `Loading milestones for ${scopeLabel()}…`, status: true }),
    );
  }
  const cands = C.date_current_candidates;
  const covered = C.projects.map((p) => projectPath(p.value)).join(', ') || 'none reported';

  const facts = h(
    'div',
    { class: 'filterbar' },
    h(
      'span',
      { class: `pill${C.source === 'fixture' ? ' st t-warn' : ''}` },
      icon('source', 'sm'),
      C.source === 'fixture' ? 'Synthetic fixture catalog' : `${C.source} catalog`,
    ),
    h('span', { class: 'pill' }, 'Fetched ', fmtTime(C.fetched_at) ?? 'time unknown'),
    // Today's server date and timezone are in the heading, the Date-current
    // panel and the timeline marker, so no separate chip repeats them.
    C.issue_coverage === 'complete_configured_projects'
      ? h('span', { class: 'pill', title: `Configured projects: ${covered}` }, 'Issue counts complete for configured projects')
      : h(
          'span',
          { class: 'pill st t-unknown', title: 'The source could not confirm complete issue coverage' },
          icon('s_unknown', 'sm'),
          'Issue coverage unknown',
        ),
    S.msError ? h('span', { class: 'pill st t-warn', title: S.msError }, icon('warning', 'sm'), 'Last reload failed; showing earlier catalog') : null,
  );

  const filterRow = h(
    'div',
    { class: 'filterbar' },
    h('span', { class: 'hint' }, 'Shared work-item filter:'),
    milestoneControl(),
    h('a', { class: 'btn sm', href: to('#/work') }, icon('work', 'sm'), 'Open Work items'),
    // That the filter is shared (saved in shared preferences) is explained in
    // the filter's evidence (ⓘ) beside the control.
  );
  // The server's date-current warning belongs to the Date-current panel;
  // any other warning keeps its own box.
  const dcWarn = C.warnings.filter((w) => /date-current/i.test(w));
  const otherWarn = C.warnings.filter((w) => !dcWarn.includes(w));

  const pick = (k: MilestoneKey): HTMLButtonElement =>
    h(
      'button',
      {
        class: 'chip ms-pick',
        type: 'button',
        'data-fk': `ms-cand-${msKeyStr(k)}`,
        title: 'Show work items in this milestone',
        onclick: () => showMilestone({ mode: 'selected', selected: k }),
      },
      icon('milestone', 'sm'),
      h('span', null, `${msTitle(k)} · ${msOwner(k)}`),
    );

  const current = h(
    'section',
    { class: 'box pad lines', 'aria-label': 'Date-current milestones' },
    h(
      'div',
      { class: 'line' },
      h('strong', null, 'Date-current'),
      h('span', { class: 'muted' }, `active milestones whose start and due dates both include ${C.date} (${C.timezone})`),
    ),
    dcWarn.map((w) => h('p', { class: 'ms-warn st t-warn' }, icon('warning', 'sm'), h('span', null, w))),
    cands.length ? h('div', { class: 'chips' }, cands.map(pick)) : h('p', { class: 'muted' }, 'No milestone is date-current today.'),
    // When the server's own warning already says that several milestones are
    // date-current, only the filter consequence is added here.
    cands.length > 1
      ? h(
          'p',
          { class: 'hint' },
          dcWarn.length
            ? 'The "Date-current" filter includes them all.'
            : `${cands.length} milestones are date-current. GSpace never picks one automatically; the "Date-current" filter includes them all.`,
        )
      : null,
    h(
      'div',
      { class: 'line' },
      h(
        'button',
        { class: 'btn sm', type: 'button', 'data-fk': 'ms-show-cur', onclick: () => showMilestone({ mode: 'date_current', selected: null }) },
        'Show date-current items',
      ),
      h(
        'button',
        { class: 'btn sm', type: 'button', 'data-fk': 'ms-show-act', onclick: () => showMilestone({ mode: 'active', selected: null }) },
        'Show items in active milestones',
      ),
    ),
  );

  const rows = C.entries.map((e) => {
    const ms = e.milestone;
    const ks = msKeyStr(ms.key);
    return {
      sel: ks === sel,
      cells: [
        h(
          'div',
          { class: 'lines' },
          h('span', { class: 'strong' }, ms.title),
          h(
            'span',
            { class: 'muted mono', title: `Milestone ID ${ms.key.id.value}; IIDs can repeat across owners` },
            `%${ms.iid.value} · ${ms.key.kind === 'group' ? 'group' : 'project'} milestone`,
          ),
        ),
        msOwner(ms.key),
        ms.state === 'active' ? tone('info', 's_run', 'Active') : tone('muted', 's_cancel', 'Closed'),
        ms.start_date || ms.due_date ? h('span', { class: 'nowrap mono' }, `${ms.start_date ?? '—'} → ${ms.due_date ?? '—'}`) : none('No dates'),
        h('div', { class: 'lines' }, dateCurrentBadge(e), h('span', { class: 'reason' }, e.date_reason)),
        countCell(e.work_items, 'work-item count'),
        countCell(e.opened_work_items, 'opened work-item count'),
        h('span', { class: 'num', title: 'Reported by the server for your saved work-item filters' }, String(e.visible_work_items)),
        extLink(ms.link, 'Milestone'),
        h(
          'button',
          {
            class: 'btn sm',
            type: 'button',
            'data-fk': `ms-show-${ks}`,
            'aria-pressed': String(ks === sel),
            onclick: () => showMilestone({ mode: 'selected', selected: ms.key }),
          },
          icon('filter', 'sm'),
          'Show items',
        ),
      ],
    };
  });
  rows.push({
    sel: m.mode === 'unassigned',
    cells: [
      h('span', { class: 'strong' }, 'No milestone'),
      none('—'),
      none('—'),
      none('—'),
      none('—'),
      countCell(C.unassigned_work_items, 'count of items without a milestone'),
      none('—'),
      none('—'),
      none('—'),
      h(
        'button',
        {
          class: 'btn sm',
          type: 'button',
          'data-fk': 'ms-show-none',
          'aria-pressed': String(m.mode === 'unassigned'),
          onclick: () => showMilestone({ mode: 'unassigned', selected: null }),
        },
        icon('filter', 'sm'),
        'Show items',
      ),
    ],
  });

  return h(
    'div',
    { class: 'screen' },
    head,
    facts,
    filterRow,
    otherWarn.length
      ? h(
          'div',
          { class: 'inline-err' },
          icon('warning', 'sm'),
          h(
            'div',
            null,
            otherWarn.map((w) => h('p', null, w)),
          ),
        )
      : null,
    current,
    S.mode === 'visual'
      ? msTimeline(C, sel, m.mode === 'unassigned')
      : simpleTable(
          ['Milestone', 'Owner', 'State', 'Start → due', 'Date-current', 'Work items', 'Opened', 'Visible', 'Link', ''],
          rows,
          'No milestones in the configured projects.',
          { label: 'Milestones' },
        ),
    h(
      'p',
      { class: 'hint' },
      `Counts cover all snapshot issues in ${scopeLabel()} (configured: ${covered}), whatever their state. "Visible" is the subset that passes your saved work-item filters. Unknown is not zero. Group milestones are identified by group and ID, so equal IIDs never merge.`,
    ),
  );
}

/* ------------------------------------------------------------ sources */

export function sourcesScreen(): HTMLElement {
  const d = S.dash;
  const envCols = d?.environment_columns ?? [];
  const c = themeChoice();
  const themeBtn = (k: 'system' | 'light' | 'dark', l: string, ico: IconName): HTMLButtonElement =>
    h('button', { type: 'button', 'aria-pressed': String(c === k), 'data-fk': `th-${k}`, onclick: () => setTheme(k) }, icon(ico, 'sm'), l);
  return h(
    'div',
    { class: 'screen' },
    h('div', { class: 'sh' }, h('div', { class: 'sh-title' }, h('h1', null, 'Sources'))),
    h(
      'div',
      { class: 'd-grid' },
      h(
        'div',
        { class: 'd-main' },
        sec(
          'Repository scope',
          'repo',
          h(
            'div',
            { class: 'box pad lines' },
            kvList([
              ['Host', S.host],
              ['Coverage', S.coverage === 'configured_projects' ? 'Configured projects only' : S.coverage],
              ['Selected', scopeLabel()],
            ]),
            S.projectsError ? h('p', { class: 'muted' }, `Project list unavailable: ${S.projectsError}`) : null,
            S.projects.length
              ? h(
                  'ul',
                  { class: 'list' },
                  S.projects.map((p) =>
                    h(
                      'li',
                      null,
                      projectAvatar(p.id.value),
                      h('a', { class: 'grow', href: to('#/work', p.id.value) }, p.path),
                      h('span', { class: 'muted' }, avatarNote(p.id.value)),
                      h('span', { class: 'mono muted' }, `id ${p.id.value}`),
                    ),
                  ),
                )
              : null,
          ),
        ),
        sec(
          'Environment columns',
          'server',
          h(
            'div',
            { class: 'box pad lines' },
            envCols.length
              ? h(
                  'ul',
                  { class: 'list' },
                  envCols.map((e) =>
                    h(
                      'li',
                      null,
                      h('strong', null, e.label),
                      h('span', { class: 'mono muted' }, e.name),
                      h('span', { class: 'grow muted' }, projectPath(e.project.value)),
                      h('span', { class: 'chip mono', title: 'Work-item field this environment fills' }, e.column),
                    ),
                  ),
                )
              : h('p', { class: 'muted' }, d ? 'No environment descriptors reported; Dev and Preprod are placed by ref kind.' : 'Loading…'),
            h(
              'p',
              { class: 'hint' },
              'Configured on the server. Environments other than Dev and Preprod become extra work-item fields; choose them under Fields. Unconfigured environments are never guessed.',
            ),
          ),
        ),
        sec(
          'Snapshot',
          'source',
          h(
            'div',
            { class: 'box pad' },
            kvList([
              [
                'Source',
                d
                  ? d.snapshot_source === 'fixture'
                    ? 'fixture: synthetic records; authenticated GitLab integration tests have not run for this demo'
                    : 'glab: read from GitLab; this does not show that any tests passed'
                  : null,
              ],
              ['GitLab version', d?.gitlab_version],
              ['Fetched at', d ? time(d.fetched_at) : null],
              ['Cache state', d?.cache_state],
              ['Items in scope', d ? `${d.views.length} returned (total ${d.total})` : S.dashError ? `Unavailable: ${S.dashError}` : null],
              ['Preference revision (snapshot)', d?.preference_revision],
            ]),
          ),
        ),
        sec(
          'Warnings',
          'warning',
          d?.warnings.length
            ? h(
                'ul',
                { class: 'list box' },
                d.warnings.map((w) => h('li', null, icon('warning', 'sm'), w)),
              )
            : h('p', { class: 'muted' }, 'No warnings reported.'),
        ),
        sec(
          'Merge request catalog',
          'mr',
          h(
            'div',
            { class: 'box pad' },
            S.mrs
              ? kvList([
                  ['Source', S.mrs.source],
                  ['Scope', 'Authored by me, all states, configured projects'],
                  ['Fetched at', time(S.mrs.fetched_at)],
                  ['Total', S.mrs.total],
                  ['Rows', S.mrs.rows.length],
                ])
              : h('p', { class: 'muted' }, S.mrsError ? `Unavailable: ${S.mrsError}` : 'Loading…'),
          ),
        ),
      ),
      h(
        'div',
        { class: 'd-side' },
        sec(
          'Preferences',
          'save',
          h(
            'div',
            { class: 'box pad' },
            S.prefs
              ? [
                  // Revision and schema identify the shared file; the entry
                  // counters are diagnostics, one disclosure away.
                  kvList([
                    ['Revision', S.prefs.revision],
                    ['Schema version', S.prefs.schema_version],
                  ]),
                  h(
                    'details',
                    {
                      class: 'pref-counts',
                      open: sectionOpen('sources:prefcounts', false),
                      ontoggle: (e: Event) => {
                        const t = e.target;
                        if (!(t instanceof HTMLDetailsElement)) return;
                        if (t.open) S.sections.set('sources:prefcounts', true);
                        else S.sections.delete('sources:prefcounts');
                      },
                    },
                    h('summary', { 'data-fk': 'pref-counts' }, 'Stored entries'),
                    kvList([
                      ['Pinned', S.prefs.pinned.length],
                      ['Hidden', S.prefs.hidden.length],
                      ['Selected', S.prefs.selected.length],
                      ['Groups', S.prefs.groups.length],
                      ['Checklists', S.prefs.checklists.length],
                      ['Overrides', S.prefs.overrides.length],
                      ['Saved views', S.prefs.saved_views.length],
                      ['Bookmarks', S.prefs.bookmarks.length],
                      ['Navigation styles', S.nav ? S.nav.decorations.length : S.navError ? `Unavailable: ${S.navError}` : 'Loading…'],
                    ]),
                  ),
                ]
              : h('p', { class: 'muted' }, 'Not loaded.'),
          ),
        ),
        sec(
          'Appearance',
          'sun',
          h(
            'div',
            { class: 'box pad lines' },
            h(
              'div',
              { class: 'seg', role: 'group', 'aria-label': 'Theme' },
              themeBtn('system', 'System', 'system'),
              themeBtn('light', 'Light', 'sun'),
              themeBtn('dark', 'Dark', 'moon'),
            ),
            modeSwitch(),
            h(
              'p',
              { class: 'hint' },
              'Theme and the Overview/Detailed reading are stored in this browser only (also in the top-bar Appearance menu). Views, bookmarks and navigation styles are shared through preferences; operator rules are in Settings.',
            ),
          ),
        ),
        sec(
          'Keyboard',
          'info',
          h(
            'div',
            { class: 'box pad' },
            kvList([
              ['/', 'Focus search'],
              ['Enter or Space on ⓘ', 'Open evidence (again to close)'],
              ['Esc', 'Close evidence first, then a menu, dialog or details drawer'],
              ['Tab', 'Move between controls; Tab past the end of evidence closes it'],
              ['Arrows in a table', 'Scroll the focused table region'],
            ]),
          ),
        ),
      ),
    ),
  );
}
