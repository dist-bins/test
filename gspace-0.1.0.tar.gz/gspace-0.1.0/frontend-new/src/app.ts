// GSpace console entry — same-origin /api only.
// Facts stay separate: pipeline, job, publish, deployment record, runtime
// identity and application test never collapse into one status. The only
// remote write path is the server's confirm-gated isolated-lab action flow;
// nothing here executes or retries on its own. Design record: docs/design.md.

import { accessScreen } from './access';
import type { IconName, Kid } from './dom';
import { append, fmtClock, fmtTime, h, icon, wolf } from './dom';
import { clearEvidence, closeEv, placeEv, refreshEvBody } from './evidence';
import { boot, loadItem, loadMilestones, loadNavigation, loadScope, refreshSnapshot } from './load';
import { derive, scopeLabel, views } from './model';
import { avatarNote, bookmarkTarget, decoIcon, decorationFor, projectAvatar, topShortcuts, viewTarget } from './nav';
import type { RenderOptions } from './render';
import { render, setRenderer } from './render';
import { bookmarkOpen, bookmarkScreen, branchScreen, milestonesScreen, mrScreen, pipelineScreen, resolveRef, sourcesScreen, viewsScreen } from './resources';
import { loadSettings, settingsDirty, settingsScreen } from './settings';
import type { Problem, Route, ScreenName } from './state';
import { dismissProblem, forgetAlert, isKnown, onPrefsChanged, report, S, SCOPE_ICON, SCOPE_LABEL, SCOPE_ROUTE, to } from './state';
import { emptyState, go, menu, scopeGate, setTheme, THEMES, themeChoice } from './ui';
import { applyView, mobileQuery, modeSwitch, updateOverflow, viewProjectsLabel } from './views';
import { itemScreen, onFiltersSaved, workScreen } from './work';

/* ============================================================ router */

function parseRoute(): Route {
  const raw = location.hash.replace(/^#\/?/, '');
  const qi = raw.indexOf('?');
  const path = qi >= 0 ? raw.slice(0, qi) : raw;
  const params = new URLSearchParams(qi >= 0 ? raw.slice(qi + 1) : '');
  const pr = params.get('project');
  const project = pr && /^[1-9]\d*$/.test(pr) ? Number(pr) : null;
  const parts = path
    .split('/')
    .filter(Boolean)
    .map((s) => {
      try {
        return decodeURIComponent(s);
      } catch {
        return s;
      }
    });
  const first = parts[0] ?? 'work';
  return isKnown(first) ? { screen: first, args: parts.slice(1), project } : { screen: 'missing', args: parts, project };
}

const KEEP_ON_SWITCH: readonly ScreenName[] = [
  'work',
  'compare',
  'milestones',
  'mrs',
  'branches',
  'pipelines',
  'bookmarks',
  'views',
  'settings',
  'sources',
  'access',
];

// The repository selector keeps the screen, the shared filters, fields,
// orientation, sort and the browser reading; only the scope changes.
function switchProject(id: number | null): void {
  const r = S.route;
  S.scopeNotice = null;
  go(to(`#/${KEEP_ON_SWITCH.includes(r.screen) ? r.screen : 'work'}`, id));
}

window.addEventListener('hashchange', () => {
  const prev = S.route;
  S.route = parseRoute();
  closeEv(false);
  // Navigation closes any open menu (the mobile Menu sheet included).
  S.openMenu = null;
  if (S.scopeNotice && S.scopeNotice.screen !== S.route.screen) S.scopeNotice = null;
  if (S.route.screen === 'settings' && prev.screen !== 'settings' && !S.booting && !settingsDirty()) void loadSettings();
  if (S.route.screen === 'milestones' && prev.screen !== 'milestones' && !S.booting && S.dash && !S.msLoading) void loadMilestones();
  if (!S.booting && S.route.project !== S.scope.project) {
    S.scope.project = S.route.project;
    loadScope();
  } else if (S.route.screen === 'item' && !S.booting && S.dash) {
    const [p, i] = S.route.args;
    if (p !== undefined && i !== undefined && !S.items.has(`${p}/${i}`)) void loadItem(p, i);
  }
  render({ screenChanged: prev.screen !== S.route.screen || S.route.screen === 'item' });
});

/* ============================================================ render */

interface UiSnapshot {
  readonly fk: string | null;
  readonly sel: readonly [number, number] | null;
  readonly scroll: ReadonlyMap<string, readonly [number, number]>;
  readonly mainTop: number;
}

function el(id: string): HTMLElement {
  const e = document.getElementById(id);
  if (!e) throw new Error(`The page is missing #${id}.`);
  return e;
}

function captureUi(): UiSnapshot {
  const a = document.activeElement;
  let sel: readonly [number, number] | null = null;
  if (a instanceof HTMLInputElement || a instanceof HTMLTextAreaElement) {
    try {
      if (a.selectionStart !== null && a.selectionEnd !== null) sel = [a.selectionStart, a.selectionEnd];
    } catch {
      sel = null; // inputs without a text selection
    }
  }
  const scroll = new Map<string, readonly [number, number]>();
  for (const s of document.querySelectorAll('[data-scroll]')) {
    if (s instanceof HTMLElement && s.dataset.scroll) scroll.set(s.dataset.scroll, [s.scrollLeft, s.scrollTop]);
  }
  return { fk: a instanceof HTMLElement ? (a.dataset.fk ?? null) : null, sel, scroll, mainTop: el('main').scrollTop };
}

function restoreUi(snap: UiSnapshot, screenChanged: boolean): void {
  const main = el('main');
  if (screenChanged) {
    main.scrollTop = 0;
    main.focus({ preventScroll: true });
    return;
  }
  for (const s of document.querySelectorAll('[data-scroll]')) {
    if (!(s instanceof HTMLElement) || !s.dataset.scroll) continue;
    const pos = snap.scroll.get(s.dataset.scroll);
    if (pos) {
      s.scrollLeft = pos[0];
      s.scrollTop = pos[1];
    }
  }
  main.scrollTop = snap.mainTop;
  if (snap.fk) {
    const target = document.querySelector(`[data-fk="${CSS.escape(snap.fk)}"]`);
    if (target instanceof HTMLElement) {
      target.focus({ preventScroll: true });
      if (snap.sel && (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) {
        try {
          target.setSelectionRange(snap.sel[0], snap.sel[1]);
        } catch {
          // not a text input
        }
      }
    }
  }
}

function renderNow(opts: RenderOptions): void {
  const screenChanged = opts.screenChanged ?? false;
  const snap = captureUi();
  const side = el('sidebar');
  const navLeft = side.scrollLeft;
  clearEvidence();
  const bar = el('topbar');
  bar.replaceChildren();
  append(bar, topbar());
  side.replaceChildren(sidebar());
  el('main').replaceChildren(...[scopeNoticeEl(), screen()].filter((x): x is HTMLElement => x !== null));
  const tray = el('tray');
  const problems = trayProblems();
  tray.replaceChildren(...trayEls(problems));
  tray.hidden = !problems.length;
  el('app').classList.toggle('has-tray', problems.length > 0);
  restoreUi(snap, screenChanged);
  side.scrollLeft = navLeft;
  if (screenChanged) revealActiveNav();
  updateNavFade();
  updateOverflow();
  refreshEvBody();
  placeEv();
}

// Mobile tab strip: keep the current destination visible and show a fade
// where more destinations continue off-screen.
function revealActiveNav(): void {
  const side = el('sidebar');
  const a = side.querySelector('.nav-item[aria-current="page"]');
  if (!(a instanceof HTMLElement) || side.scrollWidth <= side.clientWidth) return;
  const l = a.offsetLeft;
  const r = l + a.offsetWidth;
  if (l < side.scrollLeft) side.scrollLeft = Math.max(0, l - 24);
  else if (r > side.scrollLeft + side.clientWidth) side.scrollLeft = r - side.clientWidth + 24;
}
function updateNavFade(): void {
  const side = el('sidebar');
  const over = side.scrollWidth > side.clientWidth + 1;
  side.classList.toggle('fade-r', over && side.scrollLeft + side.clientWidth < side.scrollWidth - 2);
  side.classList.toggle('fade-l', over && side.scrollLeft > 2);
}

/* ============================================================== shell */

// Repository selector: native select (keyboard and screen-reader friendly)
// with the selected project's safe avatar, or the packaged repository icon.
function repoSelect(): HTMLLabelElement {
  const n = S.projects.length;
  const unknownSel = S.scope.project != null && !S.projects.some((p) => p.id.value === S.scope.project);
  const known = S.scope.project != null && !unknownSel;
  return h(
    'label',
    {
      class: 'repo',
      title: `Repository scope on ${S.host ?? 'this host'}. Coverage: only the ${n || 'configured'} configured projects; nothing else is claimed.${known && S.scope.project != null ? ` ${avatarNote(S.scope.project)}.` : ''}`,
    },
    known ? projectAvatar(S.scope.project) : icon('repo'),
    h('span', { class: 'sr' }, 'Repository'),
    h(
      'select',
      {
        class: 'select repo-select',
        'data-fk': 'repo',
        disabled: S.booting,
        onchange: (e: Event) => {
          const t = e.target;
          if (t instanceof HTMLSelectElement) switchProject(t.value ? Number(t.value) : null);
        },
      },
      h('option', { value: '', selected: S.scope.project == null }, n ? `All configured projects (${n})` : 'All configured projects'),
      S.projects.map((p) => h('option', { value: String(p.id.value), selected: p.id.value === S.scope.project }, p.path)),
      unknownSel ? h('option', { value: String(S.scope.project), selected: true }, `Project ${S.scope.project} (not configured)`) : null,
    ),
  );
}

function syncEl(): HTMLSpanElement {
  const failed = S.problems.find((p) => p.op === 'refresh' || p.op === 'load');
  const d = S.dash;
  let t = 'muted';
  let ico: IconName = 's_ok';
  let text: string;
  let title: string;
  if (S.sync.busy) {
    t = 'info';
    ico = 'refresh';
    text = 'Refreshing…';
    title = 'Explicit read of the configured source in progress';
  } else if (S.loading) {
    t = 'info';
    ico = 's_pend';
    text = 'Loading…';
    title = `Loading ${scopeLabel()}`;
  } else if (failed) {
    t = 'fail';
    ico = 's_fail';
    text = failed.op === 'refresh' ? 'Refresh failed' : 'Load failed';
    title = failed.detail;
  } else if (S.sync.okAt) {
    text = `Refreshed ${fmtClock(S.sync.okAt)}`;
    title = `Snapshot fetched ${fmtTime(d?.fetched_at) ?? 'at an unreported time'}; source ${d?.snapshot_source ?? 'unknown'}, cache ${d?.cache_state ?? 'unknown'}`;
  } else if (d) {
    ico = 'source';
    text = `Data ${fmtTime(d.fetched_at)?.slice(5) ?? 'time unknown'}`;
    title = `Snapshot fetched ${fmtTime(d.fetched_at) ?? 'at an unreported time'}; source ${d.snapshot_source}, cache ${d.cache_state}. Not refreshed in this session.`;
  } else {
    t = 'unknown';
    ico = 's_unknown';
    text = 'No data';
    title = 'No snapshot loaded';
  }
  return h(
    'span',
    { class: `sync st t-${t}`, title },
    icon(ico, 'sm'),
    h('span', { class: 'sync-text' }, text),
    S.pending > 0
      ? h(
          'span',
          { class: 'saving', title: `Saving preferences (${S.pending})` },
          h('span', { class: 'dot', 'aria-hidden': 'true' }),
          h('span', { class: 'sr' }, 'Saving preferences'),
        )
      : null,
  );
}

// Current data source, on every screen and at every width (its own row on
// mobile). It comes only from the snapshot's reported source; a fixture
// snapshot reads as a synthetic demo and a GitLab snapshot shows its fetch
// time and cache state. Neither claims that seeding, tests or deployment ran.
function sourceBadge(): HTMLAnchorElement {
  const d = S.dash;
  const src = d?.snapshot_source ?? S.mrs?.source ?? null;
  let t = 'unknown';
  let text: string;
  let label: string;
  if (src === 'fixture') {
    t = 'warn';
    text = 'Demo · synthetic data';
    label = 'Synthetic records; authenticated GitLab integration tests have not run for this demo';
  } else if (src === 'glab') {
    const at = fmtTime(d?.fetched_at ?? S.mrs?.fetched_at);
    const state = !d ? 'catalog only' : d.cache_state === 'fresh' ? 'current' : d.cache_state;
    t = 'neutral';
    text = `GitLab · ${at ? at.slice(5) : 'time unknown'} · ${state}`;
    label = `Source GitLab (glab); snapshot fetched ${at ?? 'at an unreported time'}; ${d ? `cache state ${d.cache_state}` : 'only the MR catalog is loaded'}. A live source does not mean any tests passed`;
  } else if (S.booting || S.loading) {
    text = 'Source loading…';
    label = 'The data source is reported with the snapshot';
  } else {
    text = 'Source unknown';
    label = 'No snapshot is loaded, so the data source is not known';
  }
  return h(
    'a',
    { class: `src-badge st t-${t}`, href: to('#/sources'), title: label, 'data-fk': 'src' },
    icon('source', 'sm'),
    h('span', { class: 'src-text' }, text),
    h('span', { class: 'sr' }, `. ${label}. Open source details.`),
  );
}

// The brand node is created once and reused, so re-rendering the top bar
// never recreates (and briefly blanks) the decoded wolf image.
let brandEl: HTMLAnchorElement | null = null;
function brand(): HTMLAnchorElement {
  if (!brandEl) {
    const img = wolf(false, 'brand-mark');
    img.setAttribute('decoding', 'sync');
    img.setAttribute('fetchpriority', 'high');
    brandEl = h('a', { class: 'brand', 'aria-label': 'GSpace home' }, img, h('span', { class: 'brand-text' }, 'GSpace'));
  }
  brandEl.setAttribute('href', to('#/work'));
  return brandEl;
}

const THEME_ICON: Readonly<Record<'system' | 'light' | 'dark', IconName>> = { system: 'system', light: 'sun', dark: 'moon' };
const THEME_LABEL: Readonly<Record<'system' | 'light' | 'dark', string>> = { system: 'System', light: 'Light', dark: 'Dark' };

// Browser-only appearance: theme and the Overview/Detailed reading. Kept apart
// from shared preferences and from the operator rules in Settings.
function appearanceMenu(): HTMLDetailsElement {
  const c = themeChoice();
  return menu(
    'appearance',
    h(
      'summary',
      {
        class: 'btn icon ghost',
        'data-fk': 'theme',
        'aria-label': `Appearance: theme ${c}, ${S.mode === 'visual' ? 'Overview' : 'Detailed'} reading (this browser only)`,
        title: 'Appearance (this browser only)',
      },
      icon(THEME_ICON[c]),
    ),
    h(
      'div',
      { class: 'menu-stack' },
      h('div', { class: 'menu-title' }, 'Theme'),
      h(
        'div',
        { class: 'seg', role: 'group', 'aria-label': 'Theme' },
        THEMES.map((t) =>
          h(
            'button',
            { type: 'button', 'aria-pressed': String(c === t), 'data-fk': `ap-th-${t}`, onclick: () => setTheme(t) },
            icon(THEME_ICON[t], 'sm'),
            THEME_LABEL[t],
          ),
        ),
      ),
      h('div', { class: 'menu-title' }, 'Reading'),
      modeSwitch(),
      h('p', { class: 'hint ap-hint' }, 'Stored in this browser only. Shared filters, views and bookmarks are unchanged; operator rules are in Settings.'),
    ),
  );
}

interface NavDest {
  readonly screen: ScreenName;
  readonly icon: IconName;
  readonly label: string;
  readonly count: number | string | null;
  readonly countTitle: string | null;
}

// Every destination, grouped by purpose. The same groups make the desktop
// sidebar and the mobile Menu sheet, so nothing is reachable only one way.
function navGroups(): readonly (readonly [string, readonly NavDest[]])[] {
  const all = views();
  const P = S.prefs;
  const bms = (P?.bookmarks ?? []).filter((b) => b.host === S.host);
  const svs = (P?.saved_views ?? []).filter((v) => v.host === S.host);
  const dirty = settingsDirty();
  const d = (screen: ScreenName, ico: IconName, label: string, count: number | string | null, countTitle: string | null = null): NavDest => ({
    screen,
    icon: ico,
    label,
    count,
    countTitle,
  });
  return [
    [
      'Track',
      [
        d('work', 'work', 'Work items', S.dash ? all.filter((v) => !v.hidden).length : null),
        d('compare', 'compare', 'Compare', S.dash ? all.filter((v) => v.selected).length : null),
        d('milestones', 'milestone', 'Milestones', S.ms ? S.ms.entries.length : S.msError ? '!' : null),
      ],
    ],
    [
      'Inspect',
      [
        d('mrs', 'mr', 'Merge requests', S.mrs ? S.mrs.rows.length : S.mrsError ? '!' : null),
        d('branches', 'branch', 'Branches', S.d && S.dash ? S.d.branches.size : null),
        d('pipelines', 'pipeline', 'Pipelines', S.d && S.dash ? S.d.pipes.size : null),
      ],
    ],
    ['Return to', [d('views', 'views', 'Saved views', P ? svs.length : null), d('bookmarks', 'bookmark', 'Bookmarks', P ? bms.length : null)]],
    [
      'Configure',
      [
        d(
          'settings',
          'settings',
          'Settings',
          dirty ? '•' : S.set.error ? '!' : null,
          dirty ? 'Unsaved changes' : S.set.error ? 'The settings file could not be read' : null,
        ),
        d('access', 'shield', 'Access', S.profiles ? S.profiles.length : null),
        d('sources', 'source', 'Sources', null),
      ],
    ],
  ];
}

const isCurrent = (screen: ScreenName): boolean => S.route.screen === screen || (screen === 'work' && S.route.screen === 'item');

// Narrow screens: one button, always in the top bar, opens every destination
// grouped by purpose (Settings included), whatever the tab strip shows.
function appMenu(): HTMLDetailsElement {
  const groups = navGroups();
  const mark = groups.flatMap(([, ds]) => ds).find((x) => x.screen === 'settings')?.count ?? null;
  return menu(
    'appmenu',
    h(
      'summary',
      { class: 'btn app-menu-btn', 'data-fk': 'appmenu', 'aria-label': `Menu: all destinations${mark ? ', settings need attention' : ''}` },
      icon('list'),
      h('span', null, 'Menu'),
      mark ? h('span', { class: 'nav-count menu-mark' }, String(mark)) : null,
    ),
    h(
      'nav',
      { class: 'app-menu', 'aria-label': 'All destinations' },
      groups.map(([label, ds]) =>
        h(
          'div',
          { class: 'app-menu-g', role: 'group', 'aria-label': label },
          h('div', { class: 'menu-title' }, label),
          ds.map((x) =>
            h(
              'a',
              { class: 'nav-item', href: to(`#/${x.screen}`), 'aria-current': isCurrent(x.screen) ? 'page' : null, 'data-fk': `menu-${x.screen}` },
              icon(x.icon),
              h('span', null, x.label),
              x.count == null ? h('span') : h('span', { class: 'nav-count', title: x.countTitle }, String(x.count)),
            ),
          ),
        ),
      ),
    ),
  );
}

// An announced repository-scope change (saved view or bookmark), on the screen it led to.
function scopeNoticeEl(): HTMLElement | null {
  const n = S.scopeNotice;
  if (!n || n.screen !== S.route.screen) return null;
  return h(
    'div',
    { class: 'inline-err note scope-note', role: 'status' },
    icon('repo', 'sm'),
    h('div', null, n.text),
    h(
      'button',
      {
        class: 'btn sm icon ghost',
        type: 'button',
        'aria-label': 'Dismiss',
        onclick: () => {
          S.scopeNotice = null;
          render();
        },
      },
      icon('close', 'sm'),
    ),
  );
}

function topbar(): Kid[] {
  // The coverage statement lives in the repository selector's description;
  // the bar keeps the brand, scope, data source and the user's shortcuts.
  return [
    brand(),
    mobileQuery.matches ? appMenu() : null,
    repoSelect(),
    sourceBadge(),
    topShortcuts(),
    h('span', { class: 'spacer' }),
    syncEl(),
    // aria-disabled (not disabled) keeps keyboard focus on the button across
    // repeated refreshes; refreshSnapshot ignores activations while busy.
    h(
      'button',
      {
        class: 'btn',
        type: 'button',
        'aria-disabled': S.sync.busy || S.booting || S.loading ? 'true' : null,
        onclick: () => void refreshSnapshot(),
        'data-fk': 'refresh',
        'aria-label': 'Refresh snapshot',
        title: 'Explicit read of the configured source; changes nothing remotely',
      },
      icon('refresh', S.sync.busy ? 'spin' : ''),
      h('span', { class: 'lbl-wide', 'aria-hidden': 'true' }, 'Refresh'),
    ),
    appearanceMenu(),
  ];
}

function sidebar(): HTMLDivElement {
  const P = S.prefs;
  const item = (x: NavDest): HTMLAnchorElement =>
    h(
      'a',
      {
        class: 'nav-item',
        href: to(`#/${x.screen}`),
        'aria-current': isCurrent(x.screen) ? 'page' : null,
      },
      icon(x.icon),
      h('span', { class: 'trunc' }, x.label),
      x.count == null ? h('span') : h('span', { class: 'nav-count', title: x.countTitle }, String(x.count)),
    );
  const bms = (P?.bookmarks ?? []).filter((b) => b.host === S.host);
  const svs = (P?.saved_views ?? []).filter((v) => v.host === S.host);
  // Groups by purpose; on the narrow tab strip the headings fold away and the
  // destinations stay in the same order.
  const nav = h(
    'div',
    null,
    h(
      'div',
      { class: 'nav' },
      navGroups().map(([label, ds]) =>
        h('div', { class: 'nav-group', role: 'group', 'aria-label': label }, h('div', { class: 'nav-label nav-glabel' }, label), ds.map(item)),
      ),
    ),
  );
  if (P) {
    nav.append(
      h(
        'div',
        { class: 'nav-section' },
        h('div', { class: 'nav-label' }, 'Saved views'),
        svs.length
          ? svs.slice(0, 10).map((v) =>
              h(
                'a',
                {
                  class: 'nav-sub',
                  href: to(`#/${SCOPE_ROUTE[v.scope]}`),
                  title: `${SCOPE_LABEL[v.scope]} view · ${viewProjectsLabel(v)}`,
                  onclick: (e: Event) => {
                    e.preventDefault();
                    applyView(v);
                  },
                },
                decoIcon(decorationFor(viewTarget(v)), SCOPE_ICON[v.scope]),
                h('span', { class: 'trunc' }, v.name),
              ),
            )
          : h('p', { class: 'nav-empty' }, 'None for this host'),
      ),
    );
    nav.append(
      h(
        'div',
        { class: 'nav-section' },
        h('div', { class: 'nav-label' }, 'Bookmarks'),
        bms.length
          ? bms.slice(0, 12).map((b) => {
              const res = resolveRef(b);
              return h(
                'a',
                {
                  class: `nav-sub${res.state === 'available' ? '' : ' unavail'}`,
                  href: res.href ?? to('#/bookmarks'),
                  title: res.note ?? res.title,
                  onclick: res.href ? bookmarkOpen(b) : null,
                },
                res.state === 'available' ? decoIcon(decorationFor(bookmarkTarget(b)), res.icon) : icon(res.state === 'other' ? 'repo' : 'lock', 'sm'),
                h('span', { class: 'trunc' }, b.label || res.title),
              );
            })
          : h('p', { class: 'nav-empty' }, 'None for this host'),
      ),
    );
  }
  return nav;
}

// The Settings screen states a failed operator-file read inline (status bar
// and failure panel, or its unavailable state), also when it is reached with
// an unsaved draft and so is not re-read. There the matching tray entry would
// only repeat it over the form, so it is left out of the tray on that screen
// while the failure is known; every other problem stays, and other screens
// keep showing it. The entry itself is kept until a successful read resolves it.
function trayProblems(): Problem[] {
  const inline = S.route.screen === 'settings' && S.set.error !== null;
  return inline ? S.problems.filter((p) => p.op !== 'settings-load') : S.problems;
}

function trayEls(problems: readonly Problem[]): HTMLElement[] {
  if (!problems.length) return [];
  const list = [...problems].reverse();
  const limit = S.trayOpen ? list.length : mobileQuery.matches ? 1 : 3;
  const shown = list.slice(0, limit);
  const hiddenCount = list.length - shown.length;
  const out: HTMLElement[] = [
    h('h2', { class: 'sr' }, 'Problems'),
    h(
      'ul',
      { class: `tray-list${S.trayOpen ? ' open' : ''}` },
      shown.map((p) =>
        h(
          'li',
          { class: `prob t-${p.tone}` },
          icon(p.tone === 'warn' ? 'warning' : 's_fail', 'sm'),
          h(
            'div',
            { class: 'prob-text' },
            h('strong', null, p.title),
            p.count > 1 ? h('span', { class: 'prob-count', title: `Occurred ${p.count} times, last at ${fmtClock(p.last)}` }, `×${p.count}`) : null,
            h('span', { class: 'prob-detail', title: p.detail }, p.detail),
          ),
          p.retry
            ? h(
                'button',
                { class: 'btn sm', type: 'button', 'data-fk': `retry-${p.op}`, 'aria-label': `${p.retryLabel}: ${p.title}`, onclick: () => p.retry?.() },
                p.retryLabel,
              )
            : null,
          h(
            'button',
            {
              class: 'btn sm icon ghost',
              type: 'button',
              'data-fk': `dismiss-${p.op}`,
              'aria-label': `Dismiss: ${p.title}`,
              title: 'Dismiss',
              onclick: () => dismissProblem(p.id),
            },
            icon('close', 'sm'),
          ),
        ),
      ),
    ),
  ];
  if (hiddenCount > 0 || S.trayOpen || list.length > 1) {
    out.push(
      h(
        'div',
        { class: 'tray-foot' },
        hiddenCount > 0 || S.trayOpen
          ? h(
              'button',
              {
                class: 'btn sm ghost',
                type: 'button',
                'aria-expanded': String(S.trayOpen),
                'data-fk': 'tray-more',
                onclick: () => {
                  S.trayOpen = !S.trayOpen;
                  render();
                },
              },
              S.trayOpen ? 'Show fewer' : `${hiddenCount} more`,
            )
          : null,
        list.length > 1
          ? h(
              'button',
              {
                class: 'btn sm ghost',
                type: 'button',
                onclick: () => {
                  // Only what the tray shows is dismissed.
                  const ids = new Set(problems.map((p) => p.id));
                  S.problems = S.problems.filter((p) => !ids.has(p.id));
                  S.trayOpen = false;
                  forgetAlert();
                  render();
                  document.getElementById('main')?.focus({ preventScroll: true });
                },
              },
              'Dismiss all',
            )
          : null,
      ),
    );
  }
  return out;
}

function screen(): HTMLElement {
  if (S.booting) return h('div', { class: 'boot' }, wolf(true, 'wolf-lg'), h('p', null, 'Loading projects, preferences and capabilities…'));
  const r = S.route;
  switch (r.screen) {
    case 'work':
      return workScreen(false, scopeGate());
    case 'compare':
      return workScreen(true, scopeGate());
    case 'milestones':
      return milestonesScreen();
    case 'settings':
      return settingsScreen();
    case 'item':
      return itemScreen(r.args[0] ?? '', r.args[1] ?? '', scopeGate());
    case 'mrs':
      return mrScreen(r.args);
    case 'branches':
      return branchScreen(r.args);
    case 'pipelines':
      return pipelineScreen(r.args);
    case 'bookmarks':
      return bookmarkScreen();
    case 'views':
      return viewsScreen();
    case 'sources':
      return sourcesScreen();
    case 'access':
      return accessScreen();
    case 'missing':
      return h(
        'div',
        { class: 'screen' },
        emptyState({
          title: 'Not found',
          body: 'This address does not match a GSpace screen.',
          actions: h('a', { class: 'btn sm primary', href: to('#/work') }, icon('back', 'sm'), 'Back to Work items'),
        }),
      );
  }
}

/* ============================================================ keyboard */
// The evidence popover consumes Esc first (window capture, src/evidence.ts).

document.addEventListener('keydown', (e) => {
  const t = e.target;
  const typing =
    t instanceof HTMLElement && (t.isContentEditable || t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement || t instanceof HTMLSelectElement);
  if (e.key === '/' && !typing && !e.metaKey && !e.ctrlKey && !e.altKey) {
    const s = document.querySelector('#main [data-search]');
    if (s instanceof HTMLInputElement) {
      e.preventDefault();
      s.focus();
      s.select();
    }
  } else if (e.key === 'Escape' && !document.querySelector('dialog[open]')) {
    const open = document.querySelector('details.menu[open]');
    if (open instanceof HTMLDetailsElement) {
      open.open = false;
      S.openMenu = null;
      const summary = open.querySelector('summary');
      if (summary instanceof HTMLElement) summary.focus();
      return;
    }
    const r = S.route;
    if ((r.screen === 'mrs' || r.screen === 'branches' || r.screen === 'pipelines') && r.args.length) go(to(`#/${r.screen}`));
  }
});

/* =============================================================== start */

setRenderer(renderNow);
// Every preference change re-derives views; bookmark/view changes may also
// cascade to their navigation decorations, so the catalog is read again.
onPrefsChanged(() => {
  derive();
  void loadNavigation();
});
// Catalog "visible" counts follow the saved work-item filters.
onFiltersSaved(() => {
  if (S.route.screen === 'milestones') void loadMilestones();
});
el('sidebar').addEventListener('scroll', updateNavFade, { passive: true });
window.addEventListener('resize', () => {
  updateOverflow();
  updateNavFade();
});
mobileQuery.addEventListener('change', () => render());
// Back on the window with Settings open: re-read the operator file (a local
// GET; never a remote refresh). Unsaved edits are kept and a newer file
// revision asks for an explicit choice (src/settings.ts).
window.addEventListener('focus', () => {
  if (S.route.screen === 'settings' && !S.booting && !S.set.loading && !S.set.saving) void loadSettings('auto');
});

S.route = parseRoute();
render();
boot().catch((e: unknown) => {
  S.booting = false;
  report('boot', 'GSpace could not start', e instanceof Error ? e.message : String(e), { retry: () => location.reload() });
  render();
});
