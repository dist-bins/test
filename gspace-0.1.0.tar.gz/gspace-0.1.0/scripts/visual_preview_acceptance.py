"""Read-only acceptance of fixed owned fixture ports and frozen asset generations."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, choices=(8877, 8878, 8879), default=8878)
    parser.add_argument(
        "--generation", choices=("accepted", "corrections", "finite-text"), default="accepted"
    )
    args = parser.parse_args()
    base = f"http://127.0.0.1:{args.port}"
    prefix, name = {
        "accepted": ("visual-preview", "visual-mode-accepted-assets"),
        "corrections": (
            "visual-corrections-preview",
            "visual-corrections-accepted-assets-20261007",
        ),
        "finite-text": ("finite-text-preview", "finite-text-accepted-assets-20261007"),
    }[args.generation]
    output = ROOT / f"output/verification/{prefix}-{args.port}"
    output.mkdir(parents=True, exist_ok=True)
    frozen = ROOT / "output/verification" / name
    hashes = {}
    for path in frozen.iterdir():
        route = "/" if path.name == "index.html" else "/assets/" + path.name
        with urlopen(base + route, timeout=3) as response:
            content = response.read()
        assert content == path.read_bytes(), path.name
        hashes[path.name] = hashlib.sha256(content).hexdigest()
    preferences = ROOT / ".state/frontend-preview/preferences.toml"
    before = hashlib.sha256(preferences.read_bytes()).hexdigest()
    errors = []
    outside = []
    writes = []
    captures = []
    with sync_playwright() as engine:
        browser = engine.chromium.launch(
            executable_path="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            headless=True,
        )
        context = browser.new_context(service_workers="block")

        def guard(route):
            u = urlsplit(route.request.url)
            if u.scheme == "http" and u.hostname == "127.0.0.1" and u.port == args.port:
                if route.request.method != "GET":
                    writes.append({"path": u.path, "method": route.request.method})
                route.continue_()
            else:
                outside.append(route.request.url)
                route.abort()

        context.route("**/*", guard)
        page = context.new_page()
        page.set_default_timeout(5000)
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto(base + "/#/work")
        page.wait_for_load_state("networkidle")
        page.locator('[data-fk="mode-visual"]').click()
        for theme, width in (("light", 1600), ("dark", 1600), ("light", 390), ("dark", 390)):
            page.set_viewport_size({"width": width, "height": 1100 if width > 500 else 844})
            page.evaluate("v=>localStorage.setItem('gspace.theme',v)", theme)
            page.reload()
            page.wait_for_load_state("networkidle")
            expect(page.locator('[data-fk="mode-visual"]')).to_have_attribute(
                "aria-pressed", "true"
            )
            expect(page.locator("main")).to_contain_text("Preserve passenger")
            page.screenshot(path=str(output / f"work-{theme}-{width}.png"))
            page.goto(base + "/#/item/42/791")
            graph = page.get_by_role("list", name="Pipelines by trigger depth, upstream first")
            expect(graph).to_be_visible()
            graph.scroll_into_view_if_needed()
            assert graph.bounding_box()["width"] <= width
            expect(graph).to_contain_text("Config/deploy SHA")
            expect(graph).to_contain_text("Application SHA")
            image = output / f"graph-{theme}-{width}.png"
            page.screenshot(path=str(image))
            captures.append(
                {"name": image.name, "sha256": hashlib.sha256(image.read_bytes()).hexdigest()}
            )
            page.goto(base + "/#/work")
        page.set_viewport_size({"width": 1600, "height": 1100})
        page.locator('[data-fk="mode-detailed"]').click()
        expect(page.locator("main table").first).to_be_visible()
        browser.close()
    assert not outside and not errors and not writes, (outside, errors, writes)
    assert hashlib.sha256(preferences.read_bytes()).hexdigest() == before
    report = {
        "purpose": __doc__,
        "result": "passed",
        "url": base + "/#/work",
        "generation": args.generation,
        "asset_sha256": hashes,
        "preferences_unchanged": True,
        "captures": captures,
        "outside": outside,
        "js_errors": errors,
        "writes": writes,
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"result": "passed", "url": report["url"], "asset_count": len(hashes)}))


if __name__ == "__main__":
    main()
