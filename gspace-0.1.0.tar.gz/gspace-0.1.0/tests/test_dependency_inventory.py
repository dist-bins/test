import base64
import hashlib
import io
import json
import tarfile
from zipfile import ZipFile

import pytest
from pydantic import ValidationError

from scripts.dependency_inventory import (
    Bom,
    BuildProof,
    BundledFile,
    Component,
    Edge,
    Evidence,
    Inventory,
    NpmLock,
    PythonBuildProof,
    TextCollector,
    WheelProof,
    bundle_bindings,
    collect_npm,
    collect_python,
    declaration_gaps,
    is_license_text,
    proof_inputs,
    read_bounded,
    resolve_npm,
    validate_build_provenance,
    validate_source_artifact,
    write_outputs,
)


def test_notice_candidates_exclude_source_code_and_keep_named_notice_variants():
    for name in (
        "LICENSE",
        "LICENSE.txt",
        "LICENSE.PSF",
        "LICENSE-MIT",
        "ROME-LICENSE-MIT",
        "ThirdPartyNotices.txt",
        "COPYING",
        "AUTHORS",
        "utilsBundle.js.LICENSE",
    ):
        assert is_license_text(name), name
    for name in (
        "license.js",
        "license.ts",
        "thirdparty.pyi",
        "thirdparty.py",
        "license.json",
        "LICENSE.png",
        "licenseless.txt",
        "my-notice-handler.js",
    ):
        assert not is_license_text(name), name


def test_supplemental_license_disagreement_is_explicit():
    gaps = declaration_gaps(
        [
            Evidence(source="package.json", raw="MIT", interpretation="package_field"),
            Evidence(
                source="publisher LICENSE at pinned commit",
                raw="MIT-0",
                interpretation="declared_expression",
            ),
        ],
        compare_sources=True,
    )
    assert any("Conflicting SPDX license declarations" in gap for gap in gaps)


def test_record_hash_verification_detects_modified_installed_payload(tmp_path):
    info = tmp_path / "demo-1.dist-info"
    info.mkdir()
    metadata = b"Metadata-Version: 2.4\nName: demo\nVersion: 1\nLicense-Expression: MIT\n\n"
    (info / "METADATA").write_bytes(metadata)
    license_text = b"Copyright Example. MIT terms."
    (info / "LICENSE").write_bytes(license_text)
    module = tmp_path / "demo.py"
    module.write_bytes(b"value = 1\n")

    def row(name, payload):
        checksum = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(b"=")
        return f"{name},sha256={checksum.decode()},{len(payload)}\n"

    (info / "RECORD").write_text(
        row("demo-1.dist-info/METADATA", metadata)
        + row("demo-1.dist-info/LICENSE", license_text)
        + row("demo.py", module.read_bytes())
        + "demo-1.dist-info/RECORD,,\n"
    )
    bom = Bom.model_validate(
        dict(
            components=[
                dict(name="demo", version="1", **{"bom-ref": "demo"}, purl="pkg:pypi/demo@1")
            ],
            dependencies=[],
        )
    )
    before, _, _ = collect_python(bom, bom, tmp_path, TextCollector())
    assert not before[0].gaps
    assert before[0].record_integrity.verified_hashes == 3
    assert before[0].record_integrity.unhashed_entries == 1
    module.write_bytes(b"value = 2\n")
    after, _, _ = collect_python(bom, bom, tmp_path, TextCollector())
    assert any("RECORD hash mismatch: demo.py" in gap for gap in after[0].gaps)


def test_record_paths_reject_escape_and_symlink(tmp_path):
    from scripts.dependency_inventory import verify_python_record

    site = tmp_path / "site"
    info = site / "demo-1.dist-info"
    info.mkdir(parents=True)
    outside = tmp_path / "outside"
    outside.write_bytes(b"not package evidence")
    (site / "linked").symlink_to(outside)
    for entry in ("../outside", "linked", "/outside"):
        (info / "RECORD").write_text(f"{entry},sha256=AA,1\n")
        _, gaps, _ = verify_python_record(info, site)
        assert any("RECORD file rejected" in gap for gap in gaps), entry


def test_record_accepts_virtualenv_entrypoints_without_leaving_install_root(tmp_path):
    from scripts.dependency_inventory import verify_python_record

    site = tmp_path / "venv/lib/python3.12/site-packages"
    info = site / "demo-1.dist-info"
    info.mkdir(parents=True)
    entrypoint = tmp_path / "venv/bin/demo"
    entrypoint.parent.mkdir()
    entrypoint.write_bytes(b"print('demo')\n")
    checksum = base64.urlsafe_b64encode(hashlib.sha256(entrypoint.read_bytes()).digest()).rstrip(
        b"="
    )
    (info / "RECORD").write_text(
        f"../../../bin/demo,sha256={checksum.decode()},{entrypoint.stat().st_size}\n"
        "demo-1.dist-info/RECORD,,\n"
    )
    integrity, gaps, _ = verify_python_record(info, site)
    assert not gaps and integrity.verified_hashes == 1
    (info / "RECORD").write_text("../../../../outside,sha256=AA,1\n")
    _, gaps, _ = verify_python_record(info, site)
    assert any("RECORD file rejected" in gap for gap in gaps)


def test_python_build_scope_is_separate_and_can_overlap_development(tmp_path):
    component = dict(
        name="backend", version="1", **{"bom-ref": "backend"}, purl="pkg:pypi/backend@1"
    )
    all_bom = Bom.model_validate(dict(components=[component], dependencies=[]))
    empty = Bom.model_validate(dict(components=[], dependencies=[]))
    components, _, _ = collect_python(
        all_bom, empty, tmp_path, TextCollector(), build_bom=all_bom, development_bom=empty
    )
    assert components[0].scopes == ("locked", "build")
    components, _, _ = collect_python(
        all_bom, empty, tmp_path, TextCollector(), build_bom=all_bom, development_bom=all_bom
    )
    assert components[0].scopes == ("locked", "development", "build")


@pytest.fixture
def bundle_fixture(tmp_path):
    directory = tmp_path / "evidence/bundled"
    directory.mkdir(parents=True)
    validator = tmp_path / "frontend-new/contracts/schema-validation.js"
    validator.parent.mkdir(parents=True)
    validator.write_bytes(b"export const validator = true;\n")
    helper = tmp_path / "frontend-new/node_modules/@scope/helper/runtime.js"
    helper.parent.mkdir(parents=True)
    helper.write_bytes(b"module.exports = true;\n")
    proof = dict(
        app_matches_served=True,
        validator_matches_accepted_input=True,
        app_sha256="a" * 64,
        accepted_validator_sha256=hashlib.sha256(validator.read_bytes()).hexdigest(),
        inputs={
            p.relative_to(tmp_path).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (validator, helper)
        },
    )
    for name, inputs in (
        (
            "accepted-validator.metafile.json",
            {
                "../node_modules/@scope/helper/runtime.js": dict(bytes=helper.stat().st_size),
            },
        ),
        (
            "accepted-app.metafile.json",
            {
                "contracts/schema-validation.js": dict(bytes=validator.stat().st_size),
            },
        ),
    ):
        payload = json.dumps(dict(inputs=inputs)).encode()
        (directory / name).write_bytes(payload)
        proof[name] = dict(sha256=hashlib.sha256(payload).hexdigest(), inputs=list(inputs))
    (directory / "report.json").write_text(json.dumps(proof))
    component = Component(
        id="npm:@scope/helper@1#node_modules/@scope/helper",
        ecosystem="npm",
        name="@scope/helper",
        version="1",
        source="publisher",
        integrity=None,
        occurrence="node_modules/@scope/helper",
        installed=True,
        installation_evidence="hash",
        scopes=("locked", "development"),
        license_evidence=(),
        texts=(),
    )
    return directory, proof, helper, component


def test_current_bundle_proof_rejects_wrong_app_and_same_size_input_mutation(
    tmp_path, bundle_fixture
):
    directory, proof, helper, component = bundle_fixture
    kwargs = dict(project=tmp_path, provenance=directory)
    bindings = bundle_bindings(
        tmp_path / "evidence", tmp_path / "frontend-new", [component], "a" * 64, **kwargs
    )
    assert bindings[0].component == component.id
    assert bindings[0].distributed_app_sha256 == proof["app_sha256"]
    with pytest.raises(ValueError, match="distributed app"):
        bundle_bindings(
            tmp_path / "evidence", tmp_path / "frontend-new", [component], "b" * 64, **kwargs
        )
    helper.write_bytes(helper.read_bytes().replace(b"true", b"TRUE"))
    with pytest.raises(ValueError, match="differs from current file"):
        bundle_bindings(
            tmp_path / "evidence", tmp_path / "frontend-new", [component], "a" * 64, **kwargs
        )


def test_bundle_proof_rejects_missing_validator_binding_and_link(tmp_path, bundle_fixture):
    directory, proof, helper, _ = bundle_fixture
    proof["inputs"].pop("frontend-new/contracts/schema-validation.js")
    with pytest.raises(ValueError, match="current generated validator"):
        proof_inputs(BuildProof.model_validate(proof), tmp_path)
    raw = json.loads((directory / "report.json").read_text())
    helper.unlink()
    helper.symlink_to(tmp_path / "elsewhere")
    with pytest.raises(ValueError, match="Symlink"):
        proof_inputs(BuildProof.model_validate(raw), tmp_path)


def test_bundle_proof_rejects_modified_metafile(tmp_path, bundle_fixture):
    directory, _, _, component = bundle_fixture
    path = directory / "accepted-validator.metafile.json"
    path.write_text(path.read_text() + "\n")
    with pytest.raises(ValueError, match="does not bind its metafile"):
        bundle_bindings(
            tmp_path / "evidence",
            tmp_path / "frontend-new",
            [component],
            "a" * 64,
            project=tmp_path,
            provenance=directory,
        )


def test_empty_and_binary_license_evidence_remains_unknown(tmp_path):
    path = tmp_path / "LICENSE"
    for payload in (b"", b"\x00binary", b"\xff"):
        path.write_bytes(payload)
        with pytest.raises(ValueError, match="License evidence"):
            TextCollector().add("component", "root", path, tmp_path, "declared_file")


@pytest.fixture
def build_fixture(tmp_path, bundle_fixture):
    _, _, helper, component = bundle_fixture
    source = helper.parent / "LICENSE"
    source.write_bytes(b"Copyright Example. Actual MIT text.")
    text = TextCollector().add(
        component.id, component.occurrence, source, tmp_path, "declared_file"
    )
    npm = component.model_copy(
        update={
            "texts": (text,),
            "license_evidence": (
                Evidence(source="package.json", raw="MIT", interpretation="package_field"),
            ),
        }
    )
    backend = Component(
        id="python:backend@1",
        ecosystem="python",
        name="backend",
        version="1",
        source="publisher",
        integrity=None,
        occurrence="backend-1.dist-info",
        installed=True,
        installation_evidence=hashlib.sha256(b"metadata").hexdigest(),
        scopes=("locked", "build"),
        license_evidence=(),
        texts=(),
    )
    inputs = {}
    for name in ("pyproject.toml", "uv.lock"):
        (tmp_path / name).write_bytes(name.encode())
        inputs[name] = hashlib.sha256(name.encode()).hexdigest()
    app = b"current browser app"
    app_hash = hashlib.sha256(app).hexdigest()
    manifest = dict(
        components=[
            dict(
                name=npm.name,
                version=npm.version,
                file="helper.LICENSE",
                sha256=text.sha256,
                publisher_source=source.relative_to(tmp_path).as_posix(),
                scope="browser_bundled",
                license="MIT",
            )
        ]
    )
    payloads = {
        "gspace/static/app.js": app,
        "gspace/licenses/manifest.json": json.dumps(manifest).encode(),
        "gspace/licenses/helper.LICENSE": source.read_bytes(),
    }
    wheel = tmp_path / "delivery.whl"
    with ZipFile(wheel, "w") as archive:
        for name, payload in payloads.items():
            archive.writestr(name, payload)
    proof = PythonBuildProof.model_validate(
        dict(
            input_sha256=inputs,
            build_group="build",
            build_isolation="locked_uv_environment",
            components=[
                dict(
                    name="backend",
                    version="1",
                    metadata_sha256=backend.installation_evidence,
                    record_sha256="f" * 64,
                )
            ],
            python_version="3.12.12",
            interpreter_sha256="e" * 64,
            uv_version="uv local test",
            wheel=dict(
                path=wheel.name,
                sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
                members={
                    name: hashlib.sha256(payload).hexdigest() for name, payload in payloads.items()
                },
            ),
        )
    )
    bom = Bom.model_validate(
        dict(
            components=[
                dict(
                    name="backend", version="1", **{"bom-ref": "backend"}, purl="pkg:pypi/backend@1"
                )
            ],
            dependencies=[],
        )
    )
    binding = BundledFile(
        component=npm.id,
        source_path="node_modules/@scope/helper/runtime.js",
        source_sha256="d" * 64,
        accepted_validator_sha256="c" * 64,
        distributed_app_sha256=app_hash,
    )
    return proof, bom, [backend, npm], (binding,), {"app.js": app_hash}


def test_build_provenance_binds_locked_components_wheel_assets_and_notices(tmp_path, build_fixture):
    proof, bom, components, bundled, assets = build_fixture
    notices = validate_build_provenance(proof, bom, components, bundled, assets, project=tmp_path)
    assert len(notices) == 1 and notices[0].component == bundled[0].component
    assert notices[0].wheel_sha256 == proof.wheel.sha256
    changed = proof.model_copy(update={"components": ()})
    with pytest.raises(ValueError, match="native locked build group"):
        validate_build_provenance(changed, bom, components, bundled, assets, project=tmp_path)
    with pytest.raises(ValueError, match="distributed app"):
        validate_build_provenance(
            proof, bom, components, bundled, {"app.js": "a" * 64}, project=tmp_path
        )


def test_build_provenance_rejects_changed_wheel_and_project_inputs(tmp_path, build_fixture):
    proof, bom, components, bundled, assets = build_fixture
    (tmp_path / "uv.lock").write_bytes(b"changed")
    with pytest.raises(ValueError, match="input differs"):
        validate_build_provenance(proof, bom, components, bundled, assets, project=tmp_path)
    (tmp_path / "uv.lock").write_bytes(b"uv.lock")
    wheel = tmp_path / proof.wheel.path
    wheel.write_bytes(wheel.read_bytes() + b"changed")
    with pytest.raises(ValueError, match="wheel checksum"):
        validate_build_provenance(proof, bom, components, bundled, assets, project=tmp_path)


def test_build_provenance_rejects_consistent_artifact_without_required_notice(
    tmp_path, build_fixture
):
    proof, bom, components, bundled, assets = build_fixture
    wheel = tmp_path / proof.wheel.path
    with ZipFile(wheel) as archive:
        app = archive.read("gspace/static/app.js")
    payloads = {
        "gspace/static/app.js": app,
        "gspace/licenses/manifest.json": b'{"components": []}',
    }
    with ZipFile(wheel, "w") as archive:
        for name, payload in payloads.items():
            archive.writestr(name, payload)
    artifact = proof.wheel.model_copy(
        update={
            "sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
            "members": {
                name: hashlib.sha256(payload).hexdigest() for name, payload in payloads.items()
            },
        }
    )
    proof = proof.model_copy(update={"wheel": artifact})
    with pytest.raises(ValueError, match="lacks a required bundled dependency notice"):
        validate_build_provenance(proof, bom, components, bundled, assets, project=tmp_path)


def test_publisher_text_resolves_missing_text_but_retains_mit_mit_zero_conflict(tmp_path):
    from scripts.dependency_inventory import apply_official_evidence

    body = b"Publisher MIT No Attribution text. Copyright Publisher."
    checksum = hashlib.sha256(body).hexdigest()
    (tmp_path / checksum).write_bytes(body)
    component = Component(
        id="npm:demo@1#node_modules/demo",
        ecosystem="npm",
        name="demo",
        version="1",
        source="publisher",
        integrity="locked",
        occurrence="node_modules/demo",
        installed=True,
        installation_evidence="hash",
        scopes=("locked", "development"),
        license_evidence=(
            Evidence(source="package.json", raw="MIT", interpretation="package_field"),
        ),
        texts=(),
        gaps=("No npm license/NOTICE text available",),
    )
    manifest = tmp_path / "manifest.json"
    manifest.write_text(
        json.dumps(
            dict(
                records=[
                    dict(
                        components=[component.id],
                        source_url="https://example.invalid/pinned/LICENSE",
                        sha256=checksum,
                        file=checksum,
                        original_path="LICENSE",
                        provenance="pinned publisher commit",
                        declarations=[
                            dict(
                                source="publisher license",
                                raw="MIT-0",
                                interpretation="declared_expression",
                            )
                        ],
                    )
                ]
            )
        )
    )
    updated, _ = apply_official_evidence([component], TextCollector(), manifest)
    assert updated[0].texts[0].sha256 == checksum
    assert updated[0].gaps == ("Conflicting SPDX license declarations: MIT; MIT-0",)
    assert [item.raw for item in updated[0].license_evidence] == ["MIT", "MIT-0"]


def npm_artifact_fixture(tmp_path, *, special=None, special_body=b""):
    root = tmp_path / "frontend"
    package = root / "node_modules/demo"
    package.mkdir(parents=True)
    files = {
        "package.json": json.dumps(dict(name="demo", version="1", license="MIT")).encode(),
        "index.js": b"module.exports = 1;\n",
        "LICENSE": b"Copyright Demo. MIT terms.",
    }
    for name, body in files.items():
        (package / name).write_bytes(body)
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        for name, body in files.items():
            info = tarfile.TarInfo("package/" + name)
            info.size = len(body)
            archive.addfile(info, io.BytesIO(body))
        if special is not None:
            special.size = len(special_body)
            archive.addfile(special, io.BytesIO(special_body))
    payload = buffer.getvalue()
    digest = hashlib.sha512(payload).digest()
    encoded = base64.b64encode(digest).decode()
    cache = tmp_path / "content-v2"
    cached = cache / "sha512" / digest.hex()[:2] / digest.hex()[2:4] / digest.hex()[4:]
    cached.parent.mkdir(parents=True)
    cached.write_bytes(payload)
    lock = NpmLock.model_validate(
        dict(
            lockfileVersion=3,
            packages={
                "": dict(dependencies={"demo": "1"}),
                "node_modules/demo": dict(
                    version="1", license="MIT", integrity="sha512-" + encoded
                ),
            },
        )
    )
    return root, package, cache, cached, lock


def test_cached_npm_artifact_binds_complete_installed_tree_and_detects_same_size_change(tmp_path):
    root, package, cache, _, lock = npm_artifact_fixture(tmp_path)
    components, _, gaps = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert not gaps and not components[0].gaps
    assert components[0].npm_integrity.installed_tree_verified
    assert components[0].npm_integrity.verified_installed_files == 3
    assert set(components[0].npm_integrity.source_files) == {"package.json", "index.js", "LICENSE"}
    (package / "index.js").write_bytes(b"module.exports = 2;\n")
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert any(
        "Installed npm file differs from source artifact: index.js" in gap
        for gap in components[0].gaps
    )
    assert not components[0].npm_integrity.installed_tree_verified


def test_npm_integrity_reports_missing_artifact_and_corrupt_cache_bytes(tmp_path):
    root, _, cache, cached, lock = npm_artifact_fixture(tmp_path)
    original = cached.read_bytes()
    cached.write_bytes(original[:-1] + bytes([original[-1] ^ 1]))
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert any("SRI digest mismatch" in gap for gap in components[0].gaps)
    cached.unlink()
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert any("SRI artifact unavailable" in gap for gap in components[0].gaps)


@pytest.mark.parametrize("kind", ["traversal", "symlink", "hardlink"])
def test_npm_tarball_rejects_escaping_and_link_members_without_extraction(tmp_path, kind):
    member = tarfile.TarInfo("package/../../outside" if kind == "traversal" else "package/link")
    if kind != "traversal":
        member.type = tarfile.SYMTYPE if kind == "symlink" else tarfile.LNKTYPE
        member.linkname = "../../outside"
    root, _, cache, _, lock = npm_artifact_fixture(tmp_path, special=member)
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert any("Unsafe tar member" in gap for gap in components[0].gaps)
    assert not (tmp_path / "outside").exists()


def test_npm_tree_rejects_extra_and_missing_files(tmp_path):
    root, package, cache, _, lock = npm_artifact_fixture(tmp_path)
    (package / "unexpected.js").write_text("unexpected")
    (package / "index.js").unlink()
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert any("Unexpected installed npm file: unexpected.js" in gap for gap in components[0].gaps)
    assert any("Missing installed npm file: index.js" in gap for gap in components[0].gaps)


def test_npm_tarball_normalizes_benign_dot_components_but_does_not_extract(tmp_path):
    extra = tarfile.TarInfo("package/./extra.txt")
    root, package, cache, _, lock = npm_artifact_fixture(tmp_path, special=extra)
    (package / "extra.txt").write_bytes(b"")
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert not components[0].gaps
    assert components[0].npm_integrity.installed_tree_verified


@pytest.mark.parametrize("identical", [True, False])
def test_npm_tar_aliases_require_identical_member_bytes(tmp_path, identical):
    alias = tarfile.TarInfo("package/./index.js")
    root, _, cache, _, lock = npm_artifact_fixture(
        tmp_path,
        special=alias,
        special_body=b"module.exports = 1;\n" if identical else b"module.exports = 2;\n",
    )
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    if identical:
        assert not components[0].gaps
        assert components[0].npm_integrity.installed_tree_verified
        assert components[0].npm_integrity.normalized_tar_aliases == (
            "package/./index.js -> package/index.js",
        )
    else:
        assert any("Conflicting normalized tar members" in gap for gap in components[0].gaps)


def test_npm_sri_rejects_malformed_digest(tmp_path):
    root, _, cache, _, lock = npm_artifact_fixture(tmp_path)
    broken = lock.model_copy(
        update={
            "packages": {
                **lock.packages,
                "node_modules/demo": lock.packages["node_modules/demo"].model_copy(
                    update={"integrity": "sha512-corrupt"}
                ),
            }
        }
    )
    components, _, _ = collect_npm(broken, root, TextCollector(), npm_cache=cache)
    assert any("Malformed npm SRI digest" in gap for gap in components[0].gaps)


def test_npm_tree_excludes_separately_locked_child_and_generated_bin_links(tmp_path):
    root, package, cache, _, lock = npm_artifact_fixture(tmp_path)
    child = package / "node_modules/child"
    child.mkdir(parents=True)
    (child / "package.json").write_text(json.dumps(dict(name="child", version="1", license="MIT")))
    (child / "index.js").write_text("child source")
    generated = package / "node_modules/.bin"
    generated.mkdir()
    (generated / "child").symlink_to("../child/index.js")
    extended = lock.model_copy(
        update={
            "packages": {
                **lock.packages,
                "node_modules/demo/node_modules/child": lock.packages["node_modules/demo"],
            }
        }
    )
    components, _, gaps = collect_npm(extended, root, TextCollector(), npm_cache=cache)
    parent = next(component for component in components if component.name == "demo")
    assert not gaps and not parent.gaps
    assert parent.npm_integrity.installed_tree_verified
    assert parent.npm_integrity.generated_exclusions == ("node_modules/.bin",)


def test_npm_archive_size_limit_fails_closed(tmp_path, monkeypatch):
    root, _, cache, _, lock = npm_artifact_fixture(tmp_path)
    monkeypatch.setattr("scripts.dependency_inventory.MAX_ARCHIVE_FILE", 4)
    components, _, _ = collect_npm(lock, root, TextCollector(), npm_cache=cache)
    assert any("Tar member exceeds size limit" in gap for gap in components[0].gaps)


def test_source_archive_binds_current_source_and_staged_frontend_without_replacing_recovery(
    tmp_path,
):
    payloads = {
        "pyproject.toml": b"project metadata",
        "uv.lock": b"native lock",
        "scripts/collector.py": b"current source",
        "src/gspace/static/app.js": b"current browser app",
        "PKG-INFO": b"Name: gspace\nVersion: 1\n",
    }
    for name, payload in payloads.items():
        if name == "PKG-INFO":
            continue
        current = "frontend-new/app.js" if name.startswith("src/gspace/static/") else name
        path = tmp_path / current
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(payload)
    recovery = tmp_path / "src/gspace/static/app.js"
    recovery.parent.mkdir(parents=True)
    recovery.write_bytes(b"preserved recovery")
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        for name, payload in payloads.items():
            info = tarfile.TarInfo("gspace-1/" + name)
            info.size = len(payload)
            archive.addfile(info, io.BytesIO(payload))
    artifact = tmp_path / "source.tar.gz"
    artifact.write_bytes(buffer.getvalue())
    proof = WheelProof(
        path=artifact.name,
        sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),
        members={
            "gspace-1/" + name: hashlib.sha256(payload).hexdigest()
            for name, payload in payloads.items()
        },
    )
    inputs = {
        name: hashlib.sha256(payloads[name]).hexdigest() for name in ("pyproject.toml", "uv.lock")
    }
    assets = {"app.js": hashlib.sha256(payloads["src/gspace/static/app.js"]).hexdigest()}
    validate_source_artifact(proof, inputs, assets, project=tmp_path)
    assert recovery.read_bytes() == b"preserved recovery"
    (tmp_path / "scripts/collector.py").write_bytes(b"CHANGED source")
    with pytest.raises(ValueError, match="differs from current source"):
        validate_source_artifact(proof, inputs, assets, project=tmp_path)


def test_text_dedup_retains_each_component_and_distinct_copyright(tmp_path):
    collector = TextCollector()
    paths = [tmp_path / f"LICENSE-{n}" for n in range(3)]
    for path, body in zip(
        paths, (b"MIT copyright A", b"MIT copyright A", b"MIT copyright B"), strict=True
    ):
        path.write_bytes(body)
    refs = [
        collector.add(str(n), "root", path, tmp_path, "declared_file")
        for n, path in enumerate(paths)
    ]
    assert len(collector.blobs) == 2
    assert refs[0].sha256 == refs[1].sha256 != refs[2].sha256
    assert [ref.component for ref in refs] == ["0", "1", "2"]


def test_evidence_rejects_escape_symlink_and_oversize(tmp_path, monkeypatch):
    root = tmp_path / "root"
    root.mkdir()
    outside = tmp_path / "LICENSE"
    outside.write_bytes(b"private")
    with pytest.raises(ValueError, match="traversal"):
        read_bounded(root / "../LICENSE", root)
    link = root / "LICENSE"
    link.symlink_to(outside)
    with pytest.raises(ValueError, match="Symlink"):
        read_bounded(link, root)
    link.unlink()
    link.write_bytes(b"oversize")
    monkeypatch.setattr("scripts.dependency_inventory.MAX_FILE", 3)
    with pytest.raises(ValueError, match="size limit"):
        read_bounded(link, root)


def test_python_metadata_is_passive_and_preserves_spdx_expressions(tmp_path):
    info = tmp_path / "demo-1.0.dist-info"
    info.mkdir()
    (info / "METADATA").write_text(
        "Metadata-Version: 2.4\nName: demo\nVersion: 1.0\n"
        "License-Expression: MIT AND PSF-2.0\n"
        "License: Apache-2.0 OR BSD-2-Clause\n"
        "Requires-Dist: child>=2; platform_system == 'Windows'\n"
        "License-File: LICENSE\n\n"
    )
    (info / "LICENSE").write_bytes(b"Actual copyright-bearing license")
    (info / "RECORD").write_text("demo-1.0.dist-info/LICENSE,,\n")
    (tmp_path / "unrelated.pth").write_text("raise RuntimeError('must never execute')")
    bom = Bom.model_validate(
        {
            "components": [
                {"name": "demo", "version": "1.0", "bom-ref": "demo", "purl": "pkg:pypi/demo@1.0"}
            ],
            "dependencies": [],
        }
    )
    components, _, gaps = collect_python(bom, bom, tmp_path, TextCollector())
    assert not gaps
    evidence = components[0].license_evidence
    assert [e.raw for e in evidence] == ["MIT AND PSF-2.0", "Apache-2.0 OR BSD-2-Clause"]
    assert components[0].requires_raw == ("child>=2; platform_system == 'Windows'",)
    assert len(components[0].texts) == 1


def test_npm_nested_resolution_and_conflicting_license_evidence(tmp_path):
    packages = {
        "": {"dependencies": {"parent": "1"}},
        "node_modules/parent": {"version": "1", "license": "MIT", "dependencies": {"child": "2"}},
        "node_modules/parent/node_modules/child": {"version": "2", "license": "MIT"},
        "node_modules/child": {"version": "1", "license": "MIT"},
    }
    lock = NpmLock.model_validate({"lockfileVersion": 3, "packages": packages})
    assert resolve_npm("node_modules/parent", "child", lock.packages) == (
        "node_modules/parent/node_modules/child"
    )
    folder = tmp_path / "node_modules/parent"
    folder.mkdir(parents=True)
    (folder / "package.json").write_text(
        json.dumps({"name": "parent", "version": "1", "license": "Apache-2.0"})
    )
    (folder / "NOTICE").write_bytes(b"Copyright retained")
    components, edges, _ = collect_npm(lock, tmp_path, TextCollector())
    parent = next(c for c in components if c.name == "parent")
    assert "Conflicting npm lock/installed license declarations" in parent.gaps
    assert len(parent.texts) == 1
    edge = next(e for e in edges if e.source == parent.id)
    assert edge.target.endswith("#node_modules/parent/node_modules/child")
    assert next(c for c in components if c.occurrence == "node_modules/child").installed is False


def test_inventory_rejects_dangling_mapping():
    with pytest.raises(ValidationError, match="target is not inventoried"):
        Inventory(
            components=(),
            edges=(
                Edge(
                    source="root",
                    target="missing",
                    declared_name="missing",
                    requirement="1",
                    kind="dependency",
                ),
            ),
            input_sha256={},
            assets={},
            gaps=(),
        )


def test_reproducible_archive_and_unknown_failure_report(tmp_path):
    collector = TextCollector()
    component = Component(
        id="npm:x@1",
        ecosystem="npm",
        name="x",
        version="1",
        source="registry",
        integrity="sha512:test",
        occurrence="node_modules/x",
        installed=True,
        installation_evidence="hash",
        scopes=("browser_bundled",),
        license_evidence=(
            Evidence(source="package.json", raw="MIT OR CC0-1.0", interpretation="package_field"),
        ),
        texts=(),
        gaps=("Missing package license/NOTICE text",),
    )
    inventory = Inventory(components=(component,), edges=(), input_sha256={}, assets={}, gaps=())
    first, second = tmp_path / "first", tmp_path / "second"
    write_outputs(first, inventory, collector)
    write_outputs(second, inventory, collector)
    assert (first / "evidence.tar").read_bytes() == (second / "evidence.tar").read_bytes()
    assert json.loads((first / "report.json").read_text())["complete"] is False
    assert "MIT OR CC0-1.0" in (first / "inventory.json").read_text()
    assert (
        declaration_gaps(
            [
                Evidence(
                    source="METADATA", raw="MIT AND PSF-2.0", interpretation="declared_expression"
                ),
                Evidence(source="npm", raw="(MIT OR CC0-1.0)", interpretation="package_field"),
                Evidence(
                    source="exception",
                    raw="Apache-2.0 WITH LLVM-exception",
                    interpretation="declared_expression",
                ),
            ]
        )
        == []
    )
    assert declaration_gaps(
        [Evidence(source="npm", raw="NOASSERTION", interpretation="package_field")]
    )


def test_official_evidence_is_hashed_scoped_and_keeps_uninstalled_identity(tmp_path):
    import hashlib

    from scripts.dependency_inventory import apply_official_evidence

    component = Component(
        id="python:demo@1",
        ecosystem="python",
        name="demo",
        version="1",
        source="publisher",
        integrity="sha256:locked",
        occurrence="demo",
        installed=False,
        installation_evidence=None,
        scopes=("locked",),
        license_evidence=(),
        texts=(),
        gaps=(
            "Locked package not installed on current platform; artifact license unavailable",
            "No installed license declaration evidence",
            "No package license/NOTICE text available",
        ),
    )
    payload = b"Copyright Example. Actual license text."
    checksum = hashlib.sha256(payload).hexdigest()
    (tmp_path / checksum).write_bytes(payload)
    record = dict(
        components=[component.id],
        source_url="https://example.invalid/exact/LICENSE",
        sha256=checksum,
        file=checksum,
        original_path="LICENSE",
        provenance="exact release",
        declarations=[
            dict(source="verified metadata", raw="MIT", interpretation="declared_expression")
        ],
    )
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps(dict(records=[record])))
    collector = TextCollector()
    updated, sources = apply_official_evidence([component], collector, manifest)
    assert not updated[0].gaps and not updated[0].installed
    assert updated[0].installation_evidence is None
    assert sources[0].source_url == record["source_url"]
    assert updated[0].texts[0].sha256 == checksum
    (tmp_path / checksum).write_bytes(b"Altered")
    with pytest.raises(ValueError, match="checksum"):
        apply_official_evidence([component], TextCollector(), manifest)
    (tmp_path / checksum).write_bytes(payload)
    record["components"] = ["unknown"]
    manifest.write_text(json.dumps(dict(records=[record])))
    with pytest.raises(ValueError, match="not inventoried"):
        apply_official_evidence([component], TextCollector(), manifest)
    record["components"] = [component.id]
    record["file"] = "../LICENSE"
    manifest.write_text(json.dumps(dict(records=[record])))
    with pytest.raises(ValidationError):
        apply_official_evidence([component], TextCollector(), manifest)
