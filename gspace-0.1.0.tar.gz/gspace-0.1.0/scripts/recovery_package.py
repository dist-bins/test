"""Verify current wheel/source delivery while preserving original static assets.

The finite current-source builder overlays accepted frontend bytes only in its
owned temporary tree. Package checks launch the wheel from an unrelated directory.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

from install import ASSETS, ROOT, environment


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--uv-cache", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path)
    args = parser.parse_args()
    report = args.report.resolve()
    if not report.is_relative_to(ROOT / "output/verification"):
        parser.error("Report must stay in owned verification output")
    artifacts = args.artifacts.resolve() if args.artifacts else None
    if artifacts is not None and not artifacts.is_relative_to(ROOT / "output/verification"):
        parser.error("Artifacts must stay in owned verification output")
    if artifacts is not None:
        for name in ("gspace-0.1.0-py3-none-any.whl", "gspace-0.1.0.tar.gz"):
            target = artifacts / name
            if target.exists() or target.is_symlink():
                parser.error("Refusing to replace an existing artifact")
    before = {
        name: hashlib.sha256((ROOT / "src/gspace/static" / name).read_bytes()).hexdigest()
        for name in ASSETS
    }
    candidate = {
        name: hashlib.sha256((ROOT / "frontend-new" / name).read_bytes()).hexdigest()
        for name in ASSETS
    }
    result = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts/package_check.py"),
            "--report",
            str(report),
            "--uv-cache",
            str(args.uv_cache.resolve()),
        ],
        cwd=ROOT,
        env=environment(),
        timeout=600,
    )
    produced: dict[str, str] = {}
    if result.returncode == 0 and artifacts is not None:
        artifacts.mkdir(parents=True, exist_ok=True)
        for name in ("gspace-0.1.0-py3-none-any.whl", "gspace-0.1.0.tar.gz"):
            source = ROOT / "dist" / name
            destination = artifacts / name
            shutil.copyfile(source, destination)
            produced[name] = hashlib.sha256(destination.read_bytes()).hexdigest()
    after = {
        name: hashlib.sha256((ROOT / "src/gspace/static" / name).read_bytes()).hexdigest()
        for name in ASSETS
    }
    if before != after:
        raise RuntimeError("Original static assets changed during current package verification")
    manifest = {
        "purpose": "Offline current packaging without original asset replacement",
        "accepted_static_unchanged": before == after,
        "candidate_assets": candidate,
        "exit_code": result.returncode,
        "report": str(report),
        "artifacts": produced,
    }
    report.parent.mkdir(parents=True, exist_ok=True)
    report.with_suffix(".staging.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
