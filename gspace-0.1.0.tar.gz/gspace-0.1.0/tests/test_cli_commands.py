"""CLI discoverability, compatibility and focused human output contracts."""

import io
import json
import sys

import pytest
from rich.cells import cell_len
from rich.console import Console

from gspace import cli, cli_commands, cli_render
from gspace.cli_models import parse


@pytest.mark.parametrize("argv", [[], ["--help"], ["help"], ["access"], ["pipelines"]])
def test_discovery_does_not_load_configuration_or_services(monkeypatch, capsys, argv):
    def forbidden(*args, **kwargs):
        pytest.fail("Discovery must not load configuration or access services")

    monkeypatch.setattr(cli, "load_config", forbidden)
    monkeypatch.setattr(cli, "Service", forbidden)
    monkeypatch.setattr(sys, "argv", ["gspace", *argv])
    assert cli.main() == 0
    captured = capsys.readouterr()
    assert captured.out and not captured.err
    assert "Subcommands" not in captured.out
    assert "pipeline_catalog" not in captured.out
    assert "settings_set" not in captured.out


@pytest.mark.parametrize("group", cli_commands.GROUPS, ids=lambda group: group.name)
def test_every_nested_command_has_identical_legacy_parser_contract(group):
    values = {
        "PROJECT:IID": "42:791",
        "FILE": "/tmp/synthetic.json",
        "NAME": "sample",
        "FIELD": "local_test",
        "KIND": "branch",
        "VALUE": "issue-791",
        "ACTION": "tag",
    }
    for command in group.commands:
        args = [values[name] for name in command.arguments.split()]
        if command.target == "override":
            args += ["--reason", "synthetic"]
        nested, topic, display = cli_commands.prepare([group.name, command.verb, *args])
        assert topic is None
        assert nested == [command.target, *args]
        assert parse(nested, display_command=display) == parse([command.target, *args])


@pytest.mark.parametrize(
    "argv",
    [["missing"], ["settings", "missing"], ["pipelines", "show"], ["dashboard", "--missing"]],
)
def test_argument_errors_are_clean_json_stderr_without_io(monkeypatch, capsys, argv):
    def forbidden(*args, **kwargs):
        pytest.fail("Invalid arguments must not load services")

    monkeypatch.setattr(cli, "Service", forbidden)
    monkeypatch.setattr(sys, "argv", ["gspace", *argv, "--json"])
    assert cli.main() == 2
    captured = capsys.readouterr()
    assert captured.out == ""
    assert json.loads(captured.err)["error"]
    assert "\x1b" not in captured.err


def test_nested_leaf_help_uses_public_command_name(capsys):
    normalized, _, display = cli_commands.prepare(["pipelines", "list", "--help"])
    with pytest.raises(SystemExit) as error:
        parse(normalized, display_command=display)
    assert error.value.code == 0
    help_text = capsys.readouterr().out
    assert "gspace pipelines list" in help_text
    assert "pipeline-catalog" not in help_text
    assert "pipeline_catalog" not in help_text


@pytest.mark.parametrize("width", [40, 80, 120, 160])
def test_list_is_compact_but_preserves_same_filtered_keys_and_attention(service, width):
    data = service.dashboard()
    original = data.model_dump_json()

    def rendered(function):
        buffer = io.StringIO()
        function(
            data,
            Console(
                file=buffer,
                width=width,
                theme=cli_render.THEME,
                color_system=None,
                markup=False,
                highlight=False,
            ),
        )
        value = buffer.getvalue()
        assert all(cell_len(line) <= width for line in value.splitlines())
        return value

    compact, dashboard = rendered(cli_render.list_items), rendered(cli_render.matrix)
    for view in data.views:
        assert view.item.identity.key in compact and view.item.identity.key in dashboard
    assert len(compact.splitlines()) < len(dashboard.splitlines())
    assert "Unknown" in compact
    assert "failed" in compact and "mismatch" in compact
    assert data.model_dump_json() == original


def test_filters_human_output_is_focused_but_json_keeps_legacy_preferences(
    service, monkeypatch, capsys
):
    monkeypatch.setattr(cli, "Service", lambda *args, **kwargs: service)
    monkeypatch.setattr(sys, "argv", ["gspace", "preferences", "filters", "--search", "airport"])
    assert cli.main() == 0
    human = capsys.readouterr().out
    assert "Shared filters" in human and "airport" in human
    for unrelated in ("pins", "checklists", "overrides", "selected", "application tests"):
        assert unrelated not in human
    monkeypatch.setattr(sys, "argv", ["gspace", "filters", "--search", "airport", "--json"])
    assert cli.main() == 0
    raw = capsys.readouterr()
    assert not raw.err
    assert json.loads(raw.out) == json.loads(service.preferences.read().model_dump_json())


@pytest.mark.parametrize("selected", ["project:42:700", "group:8:700"])
def test_filter_report_keeps_selected_milestone_scope(selected):
    filters = cli.Filters(milestone=cli.parse_milestone("selected", selected))
    buffer = io.StringIO()
    cli_render.filters_report(
        filters, Console(file=buffer, color_system=None, width=100, theme=cli_render.THEME)
    )
    assert selected in buffer.getvalue()
