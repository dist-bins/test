// The one HTTP surface. Types come only from the root-generated
// contracts/api.d.ts (openapi-typescript); runtime checks come only from the
// root-generated precompiled validators. Every JSON body enters as `unknown`
// and becomes a DTO only after its validator accepts it. Request bodies are
// checked by the request validators before they are sent.

import type { components } from '../contracts/api';
import type { ValidationIssue, Validator } from '../contracts/schema-validation.js';
import { requests, responses, schemas } from '../contracts/schema-validation.js';
import { localUrl } from './url';

type Sch = components['schemas'];

/* ------------------------------------------------------------ DTO aliases */

export type Action = Sch['Action'];
export type ActionPlan = Sch['ActionPlan'];
export type ActionResult = Sch['ActionResult'];
export type ApplicationTestEvidence = Sch['ApplicationTestEvidence'];
export type ApplicationTestRecord = Sch['ApplicationTestRecord'];
export type Association = Sch['Association'];
export type AuthoredMr = Sch['AuthoredMr'];
export type Bookmark = Sch['Bookmark'];
export type Branch = Sch['Branch'];
export type CapabilitiesResponse = Sch['CapabilitiesResponse'];
export type Checklist = Sch['Checklist'];
export type Column = Sch['Column'];
export type Comparison = Sch['EnvironmentComparison'];
export type Dashboard = Sch['Dashboard'];
export type Deployment = Sch['Deployment'];
export type DoctorReport = Sch['DoctorReport'];
export type EffectivePipeline = Sch['EffectivePipeline'];
export type Environment = Sch['Environment'];
export type EnvironmentDefinition = Sch['EnvironmentDefinition'];
export type Filters = Sch['Filters'];
export type ItemView = Sch['ItemView'];
export type Job = Sch['Job'];
export type JobConfiguration = Sch['JobConfiguration'];
export type JobRule = Sch['JobRule'];
export type Link = Sch['Link'];
export type MergeRequest = Sch['MergeRequest'];
export type MilestoneCatalog = Sch['MilestoneCatalog'];
export type MilestoneCount = Sch['MilestoneCount'];
export type MilestoneFilter = Sch['MilestoneFilter'];
export type MilestoneKey = Sch['MilestoneKey'];
export type MRCatalogResponse = Sch['MRCatalogResponse'];
export type Observation = Sch['Observation'];
export type OperatorSettings = Sch['OperatorSettings'];
export type Permission = Sch['Permission'];
export type Pipeline = Sch['Pipeline'];
export type PipelineRules = Sch['PipelineRules'];
export type Preferences = Sch['Preferences'];
export type Preview = Sch['Preview'];
export type PreviewRequest = Sch['PreviewRequest'];
export type ProfileSummary = Sch['ProfileSummary'];
export type ProjectCatalogResponse = Sch['ProjectCatalogResponse'];
export type ProjectConfig = Sch['ProjectConfig'];
export type ProjectPipelineOverride = Sch['ProjectPipelineOverride'];
export type Publish = Sch['Publish'];
export type Rebase = Sch['Rebase'];
export type ResourceReference = Sch['ResourceReference'];
export type SavedView = Sch['SavedView'];
export type SettingsChange = Sch['SettingsChange'];
export type SettingsResponse = Sch['SettingsResponse'];
export type StageRule = Sch['StageRule'];
export type Status = Sch['Status'];
export type Tag = Sch['Tag'];
export type Version = Sch['Version'];
export type ViewFilters = Sch['ViewFilters'];
export type ViewScope = Sch['ViewScope'];
export type WorkItem = Sch['WorkItem'];
export type WorkKey = Sch['WorkKey'];
export type EnvironmentColumn = Sch['EnvironmentColumn'];
export type NavigationCatalog = Sch['NavigationCatalog'];
export type NavigationDecoration = Sch['NavigationDecoration'];
export type NavigationTarget = Sch['NavigationTarget'];
export type DecorationIcon = Sch['DecorationIcon'];
export type DecorationColor = Sch['DecorationColor'];
export type ProjectPresentation = Sch['ProjectPresentation'];
export type PipelineGraph = Sch['PipelineGraph'];
export type PipelineNode = Sch['PipelineNode'];
export type PipelineEdge = Sch['PipelineEdge'];
export type PipelineKey = Sch['PipelineKey'];
export type ReadCoverage = Sch['ReadCoverage'];
export type ProbeComparison = Sch['ProbeComparison'];
export type ProbeComparisonRow = Sch['ProbeComparisonRow'];

/** The type a generated validator proves. */
export type Validated<V> = V extends Validator<infer T> ? T : never;

/** Every POST /api/preferences command, exactly as the contract states. */
export type PreferenceCommand = Validated<(typeof requests)['POST /api/preferences']>;
/** POST /api/access/compare body: one typed action and 2–16 configured profile names. */
export type ProbeComparisonRequest = Validated<(typeof requests)['POST /api/access/compare']>;
type ConfirmAction = Sch['ConfirmAction'];
type EmptyRequest = Sch['EmptyRequest'];

/* ------------------------------------------------------- Version reading */

/** Version is a union in the contract; this reads its four optional parts. */
export interface VersionParts {
  readonly tag: string | null;
  readonly branch: string | null;
  readonly version: string | null;
  readonly sha: string | null;
}

export function versionParts(v: Version | null | undefined): VersionParts {
  if (!v) return { tag: null, branch: null, version: null, sha: null };
  return {
    tag: 'tag' in v && typeof v.tag === 'string' ? v.tag : null,
    branch: 'branch' in v && typeof v.branch === 'string' ? v.branch : null,
    version: 'version' in v && typeof v.version === 'string' ? v.version : null,
    sha: 'sha' in v && typeof v.sha === 'string' ? v.sha : null,
  };
}

/* ---------------------------------------------------------------- errors */

export class ApiError extends Error {
  readonly status: number;
  readonly code: string | null;
  constructor(status: number, message: string, code: string | null = null) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/** A response that belongs to an earlier repository selection. */
export class StaleError extends Error {
  readonly stale = true;
  constructor() {
    super('Response belongs to a previous repository selection');
  }
}

export const isStale = (e: unknown): boolean => e instanceof StaleError || (e instanceof DOMException && e.name === 'AbortError');

export const errorMessage = (e: unknown): string => (e instanceof Error ? e.message : String(e));
export const errorStatus = (e: unknown): number | null => (e instanceof ApiError ? e.status : null);

function issues(list: readonly ValidationIssue[] | null | undefined): string {
  if (!list?.length) return 'no details';
  return list
    .slice(0, 3)
    .map((i) => `${i.instancePath || '/'} ${i.message ?? i.keyword}`)
    .join('; ');
}

const LEAD: Readonly<Record<number, string>> = {
  403: 'Denied or disabled',
  404: 'Not found',
  409: 'Conflict',
  422: 'Rejected as invalid',
  502: 'GitLab adapter error',
};

function isRecord(x: unknown): x is Record<string, unknown> {
  return typeof x === 'object' && x !== null && !Array.isArray(x);
}

// Error bodies are checked against the contract's error shapes; FastAPI's
// request-validation list (detail: [...]) is read field by field.
function errorText(status: number, statusText: string, data: unknown, raw: string): { text: string; code: string | null } {
  let detail = '';
  let code: string | null = null;
  if (schemas.AdapterErrorResponse(data)) {
    detail = data.detail;
    code = data.code;
  } else if (schemas.DetailError(data)) {
    detail = data.detail;
  } else if (isRecord(data) && Array.isArray(data.detail)) {
    detail = data.detail.map((d: unknown) => (typeof d === 'string' ? d : isRecord(d) && typeof d.msg === 'string' ? d.msg : JSON.stringify(d))).join('; ');
  }
  if (!detail) detail = `${status} ${statusText}${raw && data === undefined ? `: ${raw.slice(0, 160)}` : ''}`;
  const lead = LEAD[status];
  return { text: `${lead ? `${lead}: ` : ''}${detail}${code ? ` [${code}]` : ''}`, code };
}

/* --------------------------------------------------------------- request */

async function fetchJson(path: string, method: 'GET' | 'POST', body: unknown, signal: AbortSignal | null): Promise<unknown> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  const init: RequestInit = { method, headers, credentials: 'same-origin', cache: 'no-store', signal };
  if (method === 'POST') {
    headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  let res: Response;
  try {
    res = await fetch(localUrl(path), init);
  } catch (e) {
    if (e instanceof DOMException && e.name === 'AbortError') throw e;
    throw new ApiError(0, `The GSpace server could not be reached (${errorMessage(e) || 'network error'}).`);
  }
  const text = await res.text();
  let data: unknown;
  try {
    data = text ? JSON.parse(text) : undefined;
  } catch {
    data = undefined;
  }
  if (!res.ok) {
    const { text: msg, code } = errorText(res.status, res.statusText, data, text);
    throw new ApiError(res.status, msg, code);
  }
  if (data === undefined) throw new ApiError(res.status, 'The server response was not valid JSON.');
  return data;
}

function accept<T>(what: string, ok: Validator<T>, data: unknown): T {
  if (ok(data)) return data;
  throw new ApiError(0, `The ${what} response does not match the contract (${issues(ok.errors)}).`);
}

async function get<T>(what: string, path: string, ok: Validator<T>, signal: AbortSignal | null): Promise<T> {
  return accept(what, ok, await fetchJson(path, 'GET', undefined, signal));
}

// The request validator checks the outgoing body first, so a body the
// contract would reject is never sent.
async function post<B, T>(what: string, path: string, reqOk: Validator<B>, body: B, ok: Validator<T>, signal: AbortSignal | null): Promise<T> {
  if (!reqOk(body)) throw new ApiError(0, `Not sent: the ${what} request does not match the contract (${issues(reqOk.errors)}).`);
  return accept(what, ok, await fetchJson(path, 'POST', body, signal));
}

const q = (project: number | null): string => (project != null ? `project=${project}` : '');
const seg = (x: number | string): string => encodeURIComponent(String(x));
const EMPTY: EmptyRequest = {};
const confirmBody = (confirmation: string): ConfirmAction => ({ confirmation, confirmed: true });

/* --------------------------------------------------------------- endpoints */

export const http = {
  projects: () => get('project list', '/api/projects', responses['GET /api/projects 200'], null),
  preferences: () => get('preferences', '/api/preferences', responses['GET /api/preferences 200'], null),
  capabilities: () => get('capabilities', '/api/capabilities', responses['GET /api/capabilities 200'], null),
  profiles: () => get('access profiles', '/api/access/profiles', responses['GET /api/access/profiles 200'], null),
  settings: () => get('settings', '/api/settings', responses['GET /api/settings 200'], null),

  dashboard: (project: number | null, signal: AbortSignal | null) =>
    get('dashboard', `/api/dashboard?all=true${project != null ? `&${q(project)}` : ''}`, responses['GET /api/dashboard 200'], signal),
  item: (project: number | string, issue: number | string, signal: AbortSignal | null) =>
    get('work item', `/api/items/${seg(project)}/${seg(issue)}`, responses['GET /api/items/{project}/{issue} 200'], signal),
  mergeRequests: (project: number | null, signal: AbortSignal | null) =>
    get('merge request catalog', `/api/merge-requests${project != null ? `?${q(project)}` : ''}`, responses['GET /api/merge-requests 200'], signal),
  milestones: (project: number | null, signal: AbortSignal | null) =>
    get('milestone catalog', `/api/milestones${project != null ? `?${q(project)}` : ''}`, responses['GET /api/milestones 200'], signal),
  navigation: () => get('navigation catalog', '/api/navigation', responses['GET /api/navigation 200'], null),
  presentation: (project: number) =>
    get('project presentation', `/api/projects/${seg(project)}/presentation`, responses['GET /api/projects/{project}/presentation 200'], null),
  pipelineGraph: (project: number | string, issue: number | string, signal: AbortSignal | null) =>
    get('pipeline graph', `/api/items/${seg(project)}/${seg(issue)}/pipeline-graph`, responses['GET /api/items/{project}/{issue}/pipeline-graph 200'], signal),

  refresh: (signal: AbortSignal | null) => post('refresh', '/api/refresh', requests['POST /api/refresh'], EMPTY, responses['POST /api/refresh 200'], signal),
  refreshMergeRequests: (signal: AbortSignal | null) =>
    post(
      'catalog refresh',
      '/api/merge-requests/refresh',
      requests['POST /api/merge-requests/refresh'],
      EMPTY,
      responses['POST /api/merge-requests/refresh 200'],
      signal,
    ),
  observe: (project: number, issue: number, environment: string, signal: AbortSignal | null) =>
    post(
      'runtime read',
      `/api/items/${seg(project)}/${seg(issue)}/observe/${seg(environment)}`,
      requests['POST /api/items/{project}/{issue}/observe/{environment}'],
      EMPTY,
      responses['POST /api/items/{project}/{issue}/observe/{environment} 200'],
      signal,
    ),
  itemPreview: (project: number, issue: number, body: PreviewRequest, signal: AbortSignal | null) =>
    post(
      'planning preview',
      `/api/items/${seg(project)}/${seg(issue)}/preview`,
      requests['POST /api/items/{project}/{issue}/preview'],
      body,
      responses['POST /api/items/{project}/{issue}/preview 200'],
      signal,
    ),
  changePreferences: (cmd: PreferenceCommand) =>
    post('preference change', '/api/preferences', requests['POST /api/preferences'], cmd, responses['POST /api/preferences 200'], null),
  saveSettings: (change: SettingsChange) =>
    post('settings save', '/api/settings', requests['POST /api/settings'], change, responses['POST /api/settings 200'], null),
  doctor: (profile: string) =>
    post(
      'doctor',
      `/api/access/doctor/${seg(profile)}`,
      requests['POST /api/access/doctor/{profile}'],
      EMPTY,
      responses['POST /api/access/doctor/{profile} 200'],
      null,
    ),
  probe: (action: Action) =>
    post('permission check', '/api/actions/probe', requests['POST /api/actions/probe'], action, responses['POST /api/actions/probe 200'], null),
  // GET-only permission probes for one action across configured profiles; executes nothing.
  compareAccess: (body: ProbeComparisonRequest) =>
    post('permission comparison', '/api/access/compare', requests['POST /api/access/compare'], body, responses['POST /api/access/compare 200'], null),
  actionPreview: (action: Action) =>
    post('action preview', '/api/actions/preview', requests['POST /api/actions/preview'], action, responses['POST /api/actions/preview 200'], null),
  execute: (confirmation: string) =>
    post(
      'action execution',
      '/api/actions/execute',
      requests['POST /api/actions/execute'],
      confirmBody(confirmation),
      responses['POST /api/actions/execute 200'],
      null,
    ),
} as const;

// A project avatar is shown only from the server's fixed, same-origin avatar
// route for that exact project; anything else (external URL, other path,
// other project) is refused and the packaged fallback icon is used instead.
export function safeAvatarSrc(p: ProjectPresentation): string | null {
  const m = /^\/api\/projects\/(\d+)\/avatar(?:\?[A-Za-z0-9=&._-]{0,120})?$/.exec(p.avatar_src);
  return m && Number(m[1]) === p.project.value ? localUrl(p.avatar_src) : null;
}

/** Contract checks for values that do not arrive over HTTP (advanced editor JSON). */
export const check = {
  projectOverride: schemas.ProjectPipelineOverride,
  describe: issues,
} as const;
