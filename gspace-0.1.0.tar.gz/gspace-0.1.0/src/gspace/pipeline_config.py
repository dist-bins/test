"""Operator expectations, never a fabricated remotely observed pipeline DAG."""

from __future__ import annotations

from fnmatch import fnmatchcase
from typing import Literal, Self

from pydantic import Field, model_validator

from gspace.models import EnvironmentLabel, Model, ProjectId, Text


class EnvironmentDefinition(Model, frozen=True):
    name: EnvironmentLabel
    label: Text
    ref_source: Literal["branch", "tag"]


class StageRule(Model, frozen=True):
    name: Text
    depends_on: tuple[Text, ...] = ()


class JobRule(Model, frozen=True):
    pattern: str = Field(min_length=1, max_length=100, pattern=r"^[A-Za-z0-9_.*? /:-]+$")
    role: Literal["normal", "publish", "deploy"] = "normal"
    environment: EnvironmentLabel | None = None

    @model_validator(mode="after")
    def deploy_environment(self) -> Self:
        if (self.role == "deploy") != (self.environment is not None):
            raise ValueError("Only deploy rules require an environment")
        return self


class PipelineRules(Model, frozen=True):
    stages: tuple[StageRule, ...] = (
        StageRule(name="test"),
        StageRule(name="publish", depends_on=("test",)),
        StageRule(name="deploy", depends_on=("publish",)),
    )
    important_job_patterns: tuple[Text, ...] = ("unit-*", "publish-*", "deploy-*")
    jobs: tuple[JobRule, ...] = (
        JobRule(pattern="publish-nexus", role="publish"),
        JobRule(pattern="deploy-dev", role="deploy", environment="dev"),
        JobRule(pattern="deploy-preprod", role="deploy", environment="preprod"),
    )
    environments: tuple[EnvironmentDefinition, ...] = (
        EnvironmentDefinition(name="dev", label="Dev", ref_source="branch"),
        EnvironmentDefinition(name="preprod", label="Preprod", ref_source="tag"),
    )

    @model_validator(mode="after")
    def coherent(self) -> Self:
        names = [s.name for s in self.stages]
        envs = [e.name for e in self.environments]
        if len(set(names)) != len(names) or len(set(envs)) != len(envs):
            raise ValueError("Duplicate stage or environment")
        if not envs:
            raise ValueError("At least one environment is required")
        if len(set(j.pattern for j in self.jobs)) != len(self.jobs):
            raise ValueError("Duplicate job rule pattern")
        for i, stage in enumerate(self.stages):
            if len(set(stage.depends_on)) != len(stage.depends_on):
                raise ValueError("Duplicate dependency")
            if any(dep not in names[:i] for dep in stage.depends_on):
                raise ValueError("Stage dependencies must refer to earlier configured stages")
        if any(j.environment not in envs for j in self.jobs if j.role == "deploy"):
            raise ValueError("Deploy rule refers to an undefined environment")
        return self

    def classify(self, name: str) -> JobRule | None:
        matched = [rule for rule in self.jobs if fnmatchcase(name, rule.pattern)]
        if len(matched) > 1:
            raise ValueError("Job matches several rules; disambiguate operator configuration")
        return matched[0] if matched else None

    def important(self, name: str) -> bool:
        return any(fnmatchcase(name, pattern) for pattern in self.important_job_patterns)


class ProjectPipelineOverride(Model, frozen=True):
    project: ProjectId
    stages: tuple[StageRule, ...] | None = None
    important_job_patterns: tuple[Text, ...] | None = None
    jobs: tuple[JobRule, ...] | None = None
    environments: tuple[EnvironmentDefinition, ...] | None = None


class EffectivePipeline(Model, frozen=True):
    project: ProjectId
    rules: PipelineRules
    sources: dict[str, Literal["global", "project_override", "legacy_live_override"]]
    dependency_evidence: Literal["operator_expectation"] = "operator_expectation"


def effective(
    root: PipelineRules,
    overrides: tuple[ProjectPipelineOverride, ...],
    project: ProjectId,
    legacy_publish_names: tuple[str, ...] | None = None,
) -> EffectivePipeline:
    data = root.model_dump()
    sources: dict[str, Literal["global", "project_override", "legacy_live_override"]] = {
        name: "global" for name in PipelineRules.model_fields
    }
    if legacy_publish_names is not None:
        data["jobs"] = tuple(j for j in root.jobs if j.role != "publish") + tuple(
            JobRule(pattern=name, role="publish") for name in legacy_publish_names
        )
        sources["jobs"] = "legacy_live_override"
    override = next((o for o in overrides if o.project == project), None)
    if override is not None:
        for name, value in override.model_dump(exclude={"project"}, exclude_none=True).items():
            data[name] = value
            sources[name] = "project_override"
    return EffectivePipeline(
        project=project, rules=PipelineRules.model_validate(data), sources=sources
    )
